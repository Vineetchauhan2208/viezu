#!/usr/bin/env sh

# Getting static files for Admin panel hosting!
set -e


#sudo chmod 777 /var/run/docker.sock
# Getting static files for Admin panel hosting!

#./manage.py migrate --settings=jasiri.settings.staging
#./manage.py migrate --fake account zero --settings=jasiri.settings.staging
#./manage.py migrate --fake  account --settings=jasiri.settings.staging
#./manage.py makemigrations --merge --settings=file_maker_system.settings.stage
./manage.py migrate --settings=file_maker_system.settings.stage
#./manage.py load_ecu --settings=file_maker_system.settings.stage
#./manage.py migrate --settings=jasiri.settings.staging
#./manage.py migrate customer --settings=jasiri.settings.staging
#./manage.py migrate invoice  --settings=jasiri.settings.staging

#./manage.py makemigrations

#./manage.py migrate


#./manage.py crontab remove
#./manage.py crontab add
sudo service cron start

#./manage.py loaddata role_data.json


#sudo chown -R clupchat:clupchat /home/clupchat/clupchat_attachments
#app startup
#gunicorn clupchat.wsgi:application --bind 0.0.0.0:8000
#x./manage.py runserver
./manage.py crontab remove  --settings=file_maker_system.settings.stage
./manage.py crontab add  --settings=file_maker_system.settings.stage
#./manage.py load_vehicle_data --settings=file_maker_system.settings.stage
#./manage.py load_articles --settings=file_maker_system.settings.stage
./manage.py runserver 0.0.0.0:8000 --settings=file_maker_system.settings.stage
 


#./manage.py runserver 0.0.0.0:8000
#gunicorn jasiri.wsgi.application --bind 0.0.0.0:8000
#gunicorn --settings=jasiri.settings.staging
