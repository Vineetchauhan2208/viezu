from django.contrib import admin
from apps.zoho.models import ZOHOToken, ZOHOCategoryTree

@admin.register(ZOHOToken)
class ZOHOTokenAdmin(admin.ModelAdmin):
    list_display = ("client_id","client_secret", 
                    "access_token", "refresh_token",)

admin.site.register(ZOHOCategoryTree)