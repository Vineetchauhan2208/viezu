from django.contrib import admin
from apps.alientech.models import (
    DecodeFiles,EncodeFiles, ManualFile
)

# Register your models here.


@admin.register(DecodeFiles)
class DecodeFilesAdmin(admin.ModelAdmin):
    list_display = ("ids",'guid','slot_guid','status','is_completed','tool_type','is_file_closed')


@admin.register(EncodeFiles)
class EncdeFilesAdmin(admin.ModelAdmin):
    list_display = ("ids",'guid','file_type','slot_guid','status','is_completed','is_file_closed')


@admin.register(ManualFile)
class EncdeFilesAdmin(admin.ModelAdmin):
    list_display = ("dir_name",'decode','encode',
                    'file_name','file_url',)

