import json
from rest_framework import serializers

from apps.account.serializer import UserDetailSerializer
from apps.alientech.models import DecodeFiles, EncodeFiles, ManualFile


class TestingDecodeFileSerializer(serializers.ModelSerializer):
    readfile  = serializers.FileField(required = True,write_only=True)
    tool_type  = serializers.IntegerField(required = True)
    file  = serializers.FileField(required = False,read_only=True)
    ids = serializers.CharField(required=False,read_only=True)
    decode_response = serializers.JSONField(required=False,read_only=True)
    async_response = serializers.JSONField(required=False,read_only=True)
    guid = serializers.CharField(required=False,read_only=True)
    slot_guid=  serializers.CharField(required=False,read_only=True)
    display_tool_type_status = serializers.CharField(source='get_tool_type_display', read_only=True)
    display_status_status = serializers.CharField(source='get_status_display', read_only=True)
    is_completed = serializers.BooleanField(read_only=True)
    async_response = serializers.SerializerMethodField()


    # decode = EncodeFilesFileSerializer(many=True)

    def get_async_response(self,obj):
        try:
            return json.loads(obj.async_response)
        except:
            return {}

    class Meta:
        model = DecodeFiles
        fields = ("readfile",'tool_type','is_completed',
                'slot_guid','file','ids',
                'decode_response','async_response','guid',
                'display_status_status','display_tool_type_status')

class EncodeFilesFileSerializer(serializers.ModelSerializer):
    readfile  = serializers.FileField(required = True,write_only=True)
    decode_ids  = serializers.CharField(required = True,write_only=True)
    type  = serializers.CharField(required = False,write_only=True)
    parent  = serializers.CharField(required = False,write_only=True)


    decode = TestingDecodeFileSerializer()
    file = serializers.FileField(required=False,read_only=True)
    file_type = serializers.CharField(required=False,read_only=True)
    ids = serializers.CharField(required=False,read_only=True)
    decode_response = serializers.JSONField(required=False,read_only=True)
    guid = serializers.CharField(required=False,read_only=True)
    slot_guid = serializers.CharField(required=False,read_only=True)
    async_response = serializers.SerializerMethodField()
    display_status_status = serializers.CharField(source='get_status_display', read_only=True)
    created_at = serializers.DateTimeField(required=False,read_only=True)

    final_status = serializers.SerializerMethodField()

    decode_obj =  serializers.SerializerMethodField()

    def get_decode_obj(self,obj):
        try:
            instance = EncodeFiles.objects.filter(ids = obj.ids,file_type = 'Encode').last()
            return json.loads(instance.async_response)
        except Exception as e:
            return {}

    def get_final_status(self,obj):
        last = EncodeFiles.objects.filter(ids = obj.ids).last()
        return 'Success' if last.status == 2 and last.file_type == 'Encode' else 'Pending'

    def get_async_response(self,obj):
        try:
            return json.loads(obj.async_response)
        except:
            return {}

    class Meta:
        model = EncodeFiles
        fields = ('readfile','decode','decode_obj',
                'final_status','created_at','file',
                'decode_ids','file_type','parent',
                'type','ids','decode_response','guid',
                'slot_guid','async_response',
                'display_status_status')



class DecodeFileSerializer(serializers.ModelSerializer):

    user = UserDetailSerializer(read_only=True)
    readfile  = serializers.FileField(required = True,write_only=True)
    tool_type  = serializers.IntegerField(required = True)
    file  = serializers.FileField(required = False,read_only=True)
    ids = serializers.CharField(required=False,read_only=True)
    decode_response = serializers.JSONField(required=False,read_only=True)
    async_response = serializers.JSONField(required=False,read_only=True)
    guid = serializers.CharField(required=False,read_only=True)
    slot_guid=  serializers.CharField(required=False,read_only=True)
    display_tool_type_status = serializers.CharField(source='get_tool_type_display', read_only=True)
    display_status_status = serializers.CharField(source='get_status_display', read_only=True)
    is_completed = serializers.BooleanField(read_only=True)
    async_response = serializers.SerializerMethodField()

    encode_result = serializers.SerializerMethodField()

    def get_encode_result(self,obj):
        try:
            instance = EncodeFiles.objects.filter(decode = obj,file_type = 'Encode').last()
            if instance is not None:
                return json.loads(instance.async_response)
            return {}
        except:
            return {}

    decode = EncodeFilesFileSerializer(many=True)

    def get_async_response(self,obj):
        try:
            return json.loads(obj.async_response)
        except:
            return {}

    class Meta:
        model = DecodeFiles
        fields = ("readfile","user","decode","encode_result",'tool_type','is_completed','slot_guid','file','ids','decode_response','async_response','guid','display_status_status','display_tool_type_status')


class ManualFileSerializer(serializers.ModelSerializer):

    class Meta:
        model = ManualFile
        fields = '__all__'
