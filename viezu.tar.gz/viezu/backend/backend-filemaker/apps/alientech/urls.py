from django.urls import include, path

from apps.alientech import views

app_name = 'alientech'



urlpatterns = [
    path('decode/', views.DecodeFileView.as_view()),
    path('decode/<str:ids>', views.DecodeByIDView.as_view()),
    # path('decode/download/kessv2/<str:ids>', views.DecodeDownloadKessv2FileView.as_view()),

    path('encode/modified/', views.EncodeModifiedFileView.as_view()),
    path('encode/modified/<str:ids>', views.EncodeModifiedByGuidFileView.as_view()),
    path('encode/kessv2/file/', views.EncodeFileView.as_view()),
    path('encode/ktag/file/', views.EncodeKTagFileView.as_view()),
    path('encode/kess3/file/', views.EncodeKKess3FileView.as_view()),

    path('download/any/file', views.DownloadAnyFileFileView.as_view()),

    path('view/manual/directory/<str:ids>', views.ViewManualDirectoryView.as_view()),



    # path('decode/file/status/<str:guid>', views.DecodeFileStatusView.as_view()),
    # path('decode/file/download/<str:guid>', views.DecodeFileDownloadView.as_view()),
    # path('encode/any/download', views.DecodeAnyFileFileView.as_view()),
    # path('encode/file/modified/', views.EncodeModifiedFileView.as_view()),
    # path('encode/file/modified/<str:guid>', views.EncodeModifiedByGuidFileView.as_view()),
    # path('encode/file/original/', views.EncodeOriginalFileView.as_view()),
    # path('encode/file/', views.EncodeFileView.as_view()),
]