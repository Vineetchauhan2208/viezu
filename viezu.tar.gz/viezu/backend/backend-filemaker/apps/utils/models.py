from django.db import models
from django.utils.text import slugify

from apps.account.constants import USER_TYPE_CHOICES


class BaseModelManager(models.Manager):

    def activeinactive(self, **kwargs):
        return self.filter(deleted=False, **kwargs)

    def available(self, **kwargs):
        return self.filter(active=True, deleted=False, **kwargs)

    def inactive(self, **kwargs):
        return self.filter(active=False, deleted=False, **kwargs)

    def deleted(self, **kwargs):
        return self.filter(deleted=True, **kwargs)


class BaseModel(models.Model):
    """ BaseModel for common database fields."""

    active = models.BooleanField("Active", default=True, blank=True)
    deleted = models.BooleanField("Delete", default=False, blank=True)
    created_at = models.DateTimeField("Created Date", auto_now_add=True)
    updated_at = models.DateTimeField("Updated Date", auto_now=True)

    objects = BaseModelManager()

    class Meta:
        abstract = True

    @property
    def active_not_deleted(self) -> bool:
        return True if self.active and not self.deleted else False

    @property
    def is_active(self) -> bool:
        return True if self.active else False

    @property
    def is_deleted(self) -> bool:
        return True if self.deleted else False

class InternalErrorLog(BaseModel):

    error = models.TextField(max_length=2000, null=True, blank=True) 
    action = models.CharField(max_length=255, null=True, blank=True)
    module = models.CharField(max_length=255, null=True, blank=True)
    has_error = models.BooleanField(default=False, null=True, blank=True)

    class Meta:
        verbose_name = 'Internal Error Log'
        verbose_name_plural = 'Internal Error Log'


class ZOHOKnowledgeBaseArticles(models.Model):
    """ Model schema for ZOHO knowledgebase articles."""
    slug = models.SlugField(max_length=255,default="", null=False)
    article_id = models.CharField(max_length=100, null=True, blank=True)
    title = models.TextField( null=False, blank=False)
    category = models.CharField(max_length=100, null=True, blank=True)
    category_id = models.CharField(max_length=100, null=True, blank=True)
    root_category_id = models.CharField(max_length=100, null=True, blank=True)
    status = models.CharField(max_length=100, null=False, blank=False)
    summary = models.TextField( null=True, blank=True)
    owner_name = models.CharField(max_length=255, null=True, blank=True)
    owner_id = models.CharField(max_length=100, null=True, blank=True)
    answer = models.TextField(null=True, blank=True)
    tags = models.TextField(null=True, blank=True)
    perma_link = models.URLField(max_length=1000, null=True, blank=True)
    user_type = models.PositiveSmallIntegerField(choices=USER_TYPE_CHOICES, default=3)
    updated_at = models.DateTimeField("Updated Date", auto_now=True)

    def save(self, *args, **kwargs):
        self.slug = slugify(self.title)
        super(ZOHOKnowledgeBaseArticles, self).save(*args, **kwargs)

    class Meta:
        verbose_name = 'Articles'
        verbose_name_plural = 'Articles'
