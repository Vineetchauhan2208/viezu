from django.urls import path
from .consumers import NotificationConsumer,ConversationConsumer


websocket_urlpatterns = [
    path('notification/<str:uuid>', NotificationConsumer.as_asgi()),

    path('conversation/<str:ids>/<str:sender_id>', ConversationConsumer.as_asgi()),

]