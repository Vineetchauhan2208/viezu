import requests
from apps.account.models import MyUser
from apps.zoho.models import ZOHOToken
import json
from rest_framework.response import Response
from rest_framework import status
import logging

logger = logging.getLogger(__name__)

def generate_zoho_access_refresh_token(token_for=1):
    """ Generate zoho acccess token.

    Returns:
        json response: json response from zoho api.
    """
    obj = ZOHOToken.objects.filter(token_for = token_for)[0]
    url = "https://accounts.zoho.eu/oauth/v2/token"

    params = {
        "code": obj.code,
        "client_id": obj.client_id,
        "client_secret": obj.client_secret,
        "grant_type": "authorization_code"
    }
    response = requests.request("POST", url, params=params)
    return json.loads(response.text) 

def validate_update_tokens(response, obj, token_for=1):
    """ Validate if token in response.

    Validate if access and refresh token in response 
    if present then update in the database.

    Args:
        response (json): json response form zoho api.
        obj (object): ZOHOToken model object.

    Returns:
        Response: Json response for the action.
    """

    if response.get("access_token") is not None:
        access_token = response.get("access_token")
        refresh_token = response.get("refresh_token")
        update_zoho_tokens_in_db(access_token, refresh_token, token_for)
        return Response({'is_success':True,'message':"data saved successfully."},
                        status=status.HTTP_201_CREATED)
    else:
        obj.is_valid_tokens = False
        obj.save()
        return Response({
                            'detail':"Invalid credentials added."
                        },
                        status=status.HTTP_400_BAD_REQUEST)

def update_zoho_tokens_in_db(access_token, refresh_token, token_for=1):
    """ Update access and refresh_token in the database.

    Args:
        access_token (str): zoho access token
        refresh_token (str): zoho refresh token

    Returns:
        object: ZOHOToken model object after save.
    """
    obj = ZOHOToken.objects.filter(token_for = token_for)[0]
    obj.access_token = access_token
    obj.refresh_token = refresh_token
    obj.is_valid_tokens = True
    obj.save()
    return obj

def generate_zoho_access_with_refresh_token(token_for = 1):
    """ Generate new access token from refresh_token.

    Generate new access_token from refresh_token
    exists in the db.

    Returns:
        JSON: JSON response from the API.
    """
    logger.info("------------ INSIDE generate zoho refresh token-------------")
    url ="https://accounts.zoho.eu/oauth/v2/token"
    obj = ZOHOToken.objects.filter(token_for = token_for)[0]

    params = {
        "refresh_token": obj.refresh_token,
        "client_id": obj.client_id,
        "client_secret": obj.client_secret,
        "grant_type": "refresh_token"
    }

    response = requests.request("POST", url, params=params)
    return json.loads(response.text) 