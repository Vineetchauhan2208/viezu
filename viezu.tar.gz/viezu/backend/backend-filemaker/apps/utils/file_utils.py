
def convert_to_n_size_block(hexadata, size):
    hexadata_list = [hexadata[i:i + size] for i in range(0, len(hexadata), size)]
    return hexadata_list


def generate_blocks(df):
    for row in df.itertuples(index=False):
        yield convert_to_n_size_block(row.hex_dump, 8)


def get_ticket_description(file_request_obj):
    additional_function = get_upper_additional_function(file_request_obj.additional_function)
    tuning_required = file_request_obj.tuning_required
    search_terms = ''
    if tuning_required == "VBLUE/ECO":
        search_terms = "ECONOMY"
    elif tuning_required == "VBLEND/STAGE 0.5":
        search_terms = "BLEND"
    elif tuning_required == "VPERF/STAGE 1":
        search_terms = "PERFORMANCE"
    elif tuning_required == "VRACE/STAGE 2":
        search_terms = "VRACE"
    elif tuning_required == "NO TUNE":
        search_terms = 'NO TUNE'
    filename = 'tuning request details - ' + search_terms
    if len(additional_function) > 0:
        filename += ' / ' + ' '.join(additional_function)
    if file_request_obj.additional_info is not None:
        filename += ' / ' + file_request_obj.additional_info
    return filename


def get_upper_additional_function(additional_function):
    """ Get uppercase additional function.  """

    if additional_function is not None:
        additional_function = additional_function.split(",")
        additional_function = list(map(lambda function_name: function_name.upper().strip(), additional_function))
    else:
        additional_function = []

    return additional_function
