from django.core.management.base import BaseCommand
from rest_framework import status
from rest_framework.response import Response
from rest_framework.views import APIView

from apps.utils.tasks import migrate_data_to_vehicle_management

class Command(BaseCommand):
    help = 'Migrate data to VehicleManagement'

    def handle(self, *args, **kwargs):
        migrate_data_to_vehicle_management.delay()
        self.stdout.write(self.style.SUCCESS('Successfully migrated data to VehicleManagement'))


class MigrateVehicleDataView(APIView):
    def get(self, request):
        try:
            migrate_data_to_vehicle_management.delay()
            return Response({'message': 'Migration successfully completed.'}, status=status.HTTP_200_OK)
        except Exception as e:
            return Response({'error': str(e)}, status=status.HTTP_500_INTERNAL_SERVER_ERROR)

