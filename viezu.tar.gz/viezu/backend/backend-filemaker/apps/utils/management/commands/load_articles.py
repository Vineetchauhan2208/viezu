import requests
import json
from decouple import config
from datetime import datetime
from django.core.management.base import BaseCommand
from apps.utils.models import ZOHOKnowledgeBaseArticles
from apps.zoho.models import ZOHOToken

token = ZOHOToken.objects.get(token_for=1)
print(token)
headers = {
    'orgId': config('ZOHO_ORGID'),
    'Authorization': 'Zoho-oauthtoken '+token.access_token
}
payload={}


def get_article_data(article_id_list):
    """Saving article details by article id.

    Args:
        article_id_list (_type_): _description_
    """
    for article_id in article_id_list:
        url = "https://desk.zoho.eu/api/v1/articles/"+article_id
        response = requests.request("GET", url, headers=headers, data=payload)
        data = json.loads(response.text)
        
        article = ZOHOKnowledgeBaseArticles.objects.get(article_id=article_id)
        article.answer = data['answer']
        article.tags = ",".join(data['tags'])
        article.save()
        print("Article id: {0} data saved successfully".format(article_id))
    
    return "All articles data saved in DB."

def load_zoho_articles(start, article_list):
    print("Uploading KnowledgeBase data please wait it will take some time......\n")
    limit = 10
    url = "https://desk.zoho.eu/api/v1/articles?from={0}&limit=10".format(start)
    response = requests.request("GET", url, headers=headers, data=payload)
    print(response.text)
    data = json.loads(response.text)

    for article in data['data']:

        article_obj = ZOHOKnowledgeBaseArticles(
            article_id = article['id'],
            title = article['title'],
            category = article['category']['name'],
            category_id = int(article['category']['id']),
            root_category_id = int(article['rootCategoryId']),
            status = article['status'],
            # create_time = datetime.fromisoformat(article['createdTime'][:-1]),
            # modified_time = datetime.fromisoformat(article['modifiedTime'][:-1]),
            summary = article['summary'],
            owner_name = article['author']['name'],
            owner_id = article['author']['id'],
            perma_link = article['portalUrl']
        )
        article_list.append(article_obj)

    is_data_exist = len(data['data'])
    if is_data_exist == 0:
        ZOHOKnowledgeBaseArticles.objects.bulk_create(article_list)
        article_id_list = ZOHOKnowledgeBaseArticles.objects.all().values_list('article_id', flat=True)
        get_article_data(article_id_list)
        return
    else:
        start =start + limit
        load_zoho_articles(start, article_list)

class Command(BaseCommand):
    
    help = 'Loading articles into Database.'

    def handle(self, *args, **kwargs):
        start = 1
        article_list = []
        load_zoho_articles(start, article_list)