import configparser
CONFIG_PATH = 'https://filemaker-stage.s3.amazonaws.com/Main/folder1/WinOLS+(DESKTOP-78VPINJ_15795.ini'  
CONFIG = configparser.RawConfigParser()
CONFIG.read(CONFIG_PATH)

def read_config(key):
    try:
       value =  CONFIG.get('WinOLS', key)
    except Exception as error:
        value = None
    
    return value

data = read_config('VehicleType')
print(data)
