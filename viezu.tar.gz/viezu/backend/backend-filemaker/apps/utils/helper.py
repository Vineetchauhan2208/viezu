import json
import random
import string
import requests
from decouple import config

from asgiref.sync import async_to_sync
from channels.layers import get_channel_layer
from django.conf import settings
from django.core.mail import EmailMessage


def filename_path(folder, instance, filename) -> str:
    """
    :param folder: the folder path
    :param instance: the instance of the the file will be upload to
    :param filename: the original file name
    :return: Path string to the file location
    """
    return '{folder_name}/{file_name}.{ext}'.format(
        folder_name=folder,
        file_name=filename.split('.')[0].lower(),
        ext=filename.split('.')[-1].lower(),
    )


def filename_attach_path(folder, instance, filename) -> str:
    """
    :param folder: the folder path
    :param instance: the instance of the file will be uploaded to
    :param filename: the original file name
    :return: Path string to the file location
    """
    # Split the file name and extension
    parts = filename.split('.')

    # If there is an extension (more than one part after splitting by '.')
    if len(parts) > 1:
        file_name = '.'.join(parts[:-1]).lower()  # Join all parts except the last one (extension)
        ext = parts[-1].lower()  # The last part is the extension
        return f'{folder}/{file_name}.{ext}'
    else:
        # No extension provided, return the filename without appending the extension again
        return f'{folder}/{filename.lower()}'


def file_request_path(folder, instance, filename) -> str:
    """
    :param folder: the folder path
    :param instance: the instance of the the file will be upload to
    :param filename: the original file name
    :return: Path string to the file location
    """

    ext = filename.split('.')[-1].lower()
    file_name = filename.split('.')[0].lower()
    if file_name == ext:
        filename_path = '{folder_name}/{file_name}'.format(
            folder_name=folder, file_name=filename.split('.')[0].lower())
    else:
        filename_path = '{folder_name}/{file_name}.{ext}'.format(
            folder_name=folder, file_name=filename.split('.')[0].lower(),
            ext=ext)

    return filename_path


def triger_socket(data):
    channel_layaer = get_channel_layer()
    async_to_sync(channel_layaer.group_send)(
        'notification_%s' % data['uuid'], {
            'type': 'send_notification_cosumer',
            'payload': json.dumps(data)
        }
    )


def triger_conversation_socket(response):
    channel_layaer = get_channel_layer()
    async_to_sync(channel_layaer.group_send)(
        'order_%s' % response['ticket_id'], {
            'type': 'send_notification',
            'payload': json.dumps(response)
        }
    )


# def get_random_password(id):
#     letters = string.ascii_lowercase
#     result_str = ''.join(random.choice(letters) for i in range(5))
#     return result_str+str(id)+'@file'

def get_random_password():
    # Define character sets
    upper_case_chars = string.ascii_uppercase
    lower_case_chars = string.ascii_lowercase
    digits = string.digits
    special_chars = '@'

    # Choose one upper case, one lower case, one digit, and one special character
    password = random.choice(upper_case_chars) \
               + random.choice(lower_case_chars) \
               + random.choice(digits) \
               + special_chars

    # Choose remaining characters randomly
    remaining_chars = upper_case_chars + lower_case_chars + digits + special_chars
    password += ''.join(random.choice(remaining_chars) for _ in range(4))

    # Shuffle the password to randomize the order of characters
    password_list = list(password)
    random.shuffle(password_list)
    password = ''.join(password_list)

    return password


class SendMail(object):
    ''' Common Email Setting '''

    @staticmethod
    def mail(subject, email, email_html):
        try:
            to = email if type(email) == list else [email]
            from_email = settings.EMAIL_EMAIL_ID
            msg = EmailMessage(
                subject, email_html, to=to,
                from_email="{}".format(from_email)
            )
            msg.content_subtype = "html"
            msg.send()
            return True
        except Exception as e:
            print("Error in sending mail", e)
            return False


def validate_google_recaptcha(response):
    url = 'https://www.google.com/recaptcha/api/siteverify'
    data = {
        'secret': config('CAPTCHA_SECRET_KEY'),
        'response': response
    }
    try:
        r = requests.post(url, data=data)
        data = r.json()
        return True if data['success'] else False
    except:
        return False


def create_notification(recipient, title, message, sender=None, ticket=None, file=None):
    from apps.admin_management.models import Notification
    from apps.account.serializer import NotificationSerializer

    instance = Notification.objects.create(
        recipient=recipient,
        title=title,
        message=message,
        sender=sender,
        ticket=ticket,
        file=file
    )
    serializer = NotificationSerializer(instance).data
    serializer['un_seen_message_count'] = instance.recipient.notification_recipient.filter(is_seen=False).count()
    triger_socket({
        'uuid': str(instance.recipient.uuid),
        'type': 'admin_new_notification' if instance.recipient.user_type in [1, 2, 5] else 'new_notification',
        'data': serializer,
        'message': ""
    })
