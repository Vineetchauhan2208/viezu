from woocommerce import API
from decouple import config
import requests
import json

class WoocommerceShop:

    def __init__(self):
        self.__consumer_key = config('WOOCOMMERCE_CONSUMER_KEY')
        self.__consumer_secret = config('WOOCOMMERCE_CONSUMER_SECRET')
        self.__url = config('WOOCOMMERCE_URL')
        super().__init__()

    def connect_woocommerce(self):
        """ Connect to woocommerce to use APIs.

        Returns:
            wcapi: Woocommerce connection object.
        """
        try:
            wcapi = API(
                url=self.__url,
                consumer_key = self.__consumer_key,
                consumer_secret= self.__consumer_secret,
                version="wc/v3"
            )
        except Exception as error:
            print("Cannot connect to woocommerce.")
            print(error)

        return wcapi

    def list_products(self, wcapi, page=1):
        """ Get products from woocommerce API.

        By default 10 records per page, page parameter for get the 
        product from particular page.

        Args:
            wcapi (woocommerce connect object): Woocommerce connection object.
            page (int, optional): page number to get products. Defaults to 1.

        Returns:
            JSON : Products json.
        """
        resp = wcapi.get("products",params={"per_page": 10, "page":page})
        return resp.json()
    
    def get_product_by_id(self, wcapi, id):
        """ Get product by it id.

        Args:
            wcapi (woocommerce connect object): Woocommerce connection object.
            id (str): Id of the product to get information.

        Returns:
            JSON: Product data JSON.
        """
        return wcapi.get("products/"+str(id)).json()

    def list_categories(self, wcapi, page=1):
        """ Get product by it id.

        Args:
            wcapi (woocommerce connect object): Woocommerce connection object.
            id (str): Id of the product to get information.

        Returns:
            JSON: Product data JSON.
        """
        resp = wcapi.get("products/categories", params={"per_page": 10, "page":page})
        return resp.json()

    def create_category(self, wcapi, data):
        """ Create a product category.

        Create a product category on woocommerece.
        Args:
            wcapi (woocommerce connect object): Woocommerce connection object.
            data (dict): Data to save on woocommerce.

        Returns:
            JSON: Product data JSON.
        """
        return wcapi.post("products/categories", data).json()

    def retrieve_category(self, wcapi, id):
        """ retrive a product category.

        retrive a product category on woocommerece.
        Args:
            wcapi (woocommerce connect object): Woocommerce connection object.
            data (dict): Data to save on woocommerce.

        Returns:
            JSON: category data JSON.
        """
        return wcapi.get("products/categories/"+str(id)).json()

    def update_category(self, wcapi, id, data):
        """ Update a product category.

        Update a product category on woocommerece.
        Args:
            wcapi (woocommerce connect object): Woocommerce connection object.
            data (dict): Data to save on woocommerce.

        Returns:
            JSON: category data JSON.
        """
        return wcapi.get("products/categories/"+str(id), data).json()

    def delete_category(self, wcapi, id):
        """ Delete a product category.

        delete a product category on woocommerece.
        Args:
            wcapi (woocommerce connect object): Woocommerce connection object.
            data (dict): Data to save on woocommerce.

        Returns:
            JSON: category data JSON.
        """
        return wcapi.delete("products/categories/"+str(id), params={"force": True}).json()

    def list_tags(self, wcapi, page=1):
        resp = wcapi.get("products/tags", params={"per_page": 10, "page":page})
        return resp.json()

    def create_tag(self, wcapi, data):
        """ Create a product tag.

        Create a product tag on woocommerece.
        Args:
            wcapi (woocommerce connect object): Woocommerce connection object.
            data (dict): Data to save on woocommerce.

        Returns:
            JSON: tag data JSON.
        """
        return wcapi.post("products/tags", data).json()

    def retrieve_tag(self, wcapi, id):
        """ retrive a product tag.

        retrive a product tag on woocommerece.
        Args:
            wcapi (woocommerce connect object): Woocommerce connection object.
            data (dict): Data to save on woocommerce.

        Returns:
            JSON: tag data JSON.
        """
        return wcapi.get("products/tags/"+str(id)).json()

    def update_tag(self, wcapi, id,data):
        """ Update a product tag.

        Update a product tag on woocommerece.
        Args:
            wcapi (woocommerce connect object): Woocommerce connection object.
            data (dict): Data to save on woocommerce.

        Returns:
            JSON: tag data JSON.
        """
        return wcapi.put("products/tags/"+str(id), data).json()

    def delete_tag(self, wcapi, id):
        """ Delete a product tag.

        delete a product tag on woocommerece.
        Args:
            wcapi (woocommerce connect object): Woocommerce connection object.
            data (dict): Data to save on woocommerce.

        Returns:
            JSON: tag data JSON.
        """
        return wcapi.delete("products/tags/"+str(id), params={"force": True}).json()


    def list_shipping_zones(self, wcapi,):
        resp = wcapi.get("shipping/zones")
        return resp.json()

    def filter(self, wcapi, category_id=None, page=1):

        if category_id is not None:
            return wcapi.get("products", params={"category": str(category_id),"page": page, "per_page": 10}).json()
        
        return []

    def list_orders(self, wcapi, page=1):
        """ List orders.

        list orders from woocommerece.
        Args:
            wcapi (woocommerce connect object): Woocommerce connection object.
            data (dict): Data to save on woocommerce.

        Returns:
            JSON: tag data JSON.
        """
        resp = wcapi.get("orders", params={"per_page": 10, "page":page})
        return resp.json()

    def retrieve_orders(self, wcapi, id):
        """ Reterive a order.

        Reterive a order from woocommerece.
        Args:
            wcapi (woocommerce connect object): Woocommerce connection object.
            data (dict): Data to save on woocommerce.

        Returns:
            JSON: tag data JSON.
        """
        return wcapi.get("orders/"+str(id)).json()

    def crate_order(self, wcapi, data):
        """ Reterive a order.

        Reterive a order from woocommerece.
        Args:
            wcapi (woocommerce connect object): Woocommerce connection object.
            data (dict): Data to save on woocommerce.

        Returns:
            JSON: tag data JSON.
        """
        return wcapi.post("orders", data).json()

    def get_tax_rate(self, wcapi):
        r = wcapi.get("taxes").json()
        rate = {}
        rate['rate'] = r[0]['rate']
        rate['name'] = r[0]['name']
        rate['country'] = r[0]['country']

        return rate


def create_order(payload):
    url = "https://ai-remap.com/wp-json/wc/v3/orders"

    payload = json.dumps(payload)
    headers = {
        'Authorization': 'Basic Y2tfNjY0MThiZWUxZDBiNjkzYzBiMDJlZThjMzBmYmRmYzFhNTcxZTJiZDpjc18yZTE3YzIyYmIzYmZjMDkwZjhmYTg4MDk3NTNhYWI5YjIxZDgxM2I3',
        'Content-Type': 'application/json'
    }
    response = requests.request("POST", url, headers=headers, data=payload)
    return response.json()



def update_order(order_id):
    url = "https://ai-remap.com/wp-json/wc/v3/orders/{}".format(order_id)
    payload = json.dumps({
        "status": "completed"
    })
    headers = {
        'Authorization': 'Basic Y2tfNjY0MThiZWUxZDBiNjkzYzBiMDJlZThjMzBmYmRmYzFhNTcxZTJiZDpjc18yZTE3YzIyYmIzYmZjMDkwZjhmYTg4MDk3NTNhYWI5YjIxZDgxM2I3',
        'Content-Type': 'application/json'
    }
    response = requests.request("PUT", url, headers=headers, data=payload)
    return response



import time
import stripe

stripe.api_key = config('STRIPE_SECRET_KEY')


class Payment:
    def __init__(self) -> None:
        pass
    
    def checkout_session(
            self,
            success_url, cancel_url,
            order,biling_address
        ):

        line_items = []
        for each in order.order_item.all():
            line_items.append({
                'price_data':{
                    'currency':'GBP',
                    'product_data':{
                        'name':each.product_name,
                        'images': [each.product_image if each.product_image else 'https://ai-remap.com/wp-content/uploads/2022/01/AI-REMAP-TUNING-CREDITS-150x150.png'],
                    },
                    'unit_amount':int(float(each.price) + float(each.vat)/each.quantity)*100
                },
                'quantity':each.quantity
            })
        checkout_session = stripe.checkout.Session.create(
            payment_method_types=["card"],
            line_items=line_items,
            mode='payment',
            payment_intent_data ={
                'capture_method': 'automatic',
                'description': 'Viezu Files - Order Number :: ' + order.ids,
            },
            # automatic_tax={
            #     'enabled': True,
            # },
            # customer_update={
            #     'address': 'auto',
            # },
            customer_email=order.user.email,    # default is None
            # customer="cus_Ni6DWbEVUiqnNw",
            billing_address_collection = 'auto',
            success_url=success_url+'?trx_id={}'.format(order.ids),
            cancel_url=cancel_url+'?trx_id={}'.format(order.ids),
            expires_at = int(time.time()) + 1800 
        )
        # print(checkout_session)
        return checkout_session

    def get_checkout_session_details(self,id):
        return stripe.checkout.Session.retrieve(
                id
            )