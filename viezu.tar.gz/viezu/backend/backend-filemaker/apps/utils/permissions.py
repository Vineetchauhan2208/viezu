from django.contrib.contenttypes.models import ContentType
from rest_framework.permissions import BasePermission
import apps.utils.response_message as utils_resp_mesg

class IsUser(BasePermission):
    """ Authorize the customer in APIs.

    Args:
        BasePermission (class): To authorize and unauthorize if customer or not.

    Returns:
        bool: true or false
    """
    message = utils_resp_mesg.UNAUTHORIZED_ACCESS

    def has_permission(self, request, view):
        if request.user.user_type  == 3:
            return True
        return False

class IsAdmin(BasePermission):
    """ Authorize the admin in APIs.

    Args:
        BasePermission (class): To authorize and unauthorize if admin user or not.

    Returns:
        bool: true or false
    """
    message = utils_resp_mesg.UNAUTHORIZED_ACCESS

    def has_permission(self, request, view):
        if request.user.user_type  == 2:
            return True
        return False

class IsCustomerCreateOnly(BasePermission):
    """ To validate cutomer only.

    Args:
        BasePermission (class): Django permission class

    Returns:
        boolean: true or false
    """

    message = "Only customer can create file request."

    def has_permission(self, request, view):
        if (request.user.user_type == 3 or
            request.user.user_type == 4 or
            request.user.user_type == 6 or
            request.user.user_type == 7):
            return True

        return False

class CanAdminDeleteOnly(BasePermission):
    """ Authorize the admin in APIs.

    Args:
        BasePermission (class): To authorize and unauthorize if admin user or not.

    Returns:
        bool: true or false
    """
    message = utils_resp_mesg.ADMIN_ONLY_DELETE_ACCESS

    def has_permission(self, request, view):
        if (request.user.user_type  == 5 or
            request.user.user_type  == 2):
            return True
        return False