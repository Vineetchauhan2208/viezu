from django.contrib import admin
from apps.utils.models import ZOHOKnowledgeBaseArticles, InternalErrorLog

# Register your models here.
@admin.register(ZOHOKnowledgeBaseArticles)
class ZOHOKnowledgeBaseArticlesAdmin(admin.ModelAdmin):
    list_display = ("article_id","slug","title",
                    "category", "status","category_id",
                    "root_category_id")
    search_fields =['article_id',]


@admin.register(InternalErrorLog)
class InternalErrorLogAdmin(admin.ModelAdmin):
    list_display = ("error","action", "module",)
