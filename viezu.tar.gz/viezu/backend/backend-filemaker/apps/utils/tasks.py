import binascii
import re

import pandas as pd
from celery import shared_task
from django.core.files.storage import default_storage

from apps.admin_management.models import TicketCategory, TicketHistory, TicketStatus, Directory
from apps.alientech.models import DecodeFiles, EncodeFiles, ManualFile
from apps.customer.models import OrderList
from apps.customer.utils import create_stripe_customer
from apps.file_request.slave_file_request_matching_time import slave_kess3_file_matching_flow
from apps.utils.ecode_decode import FileOperation
from apps.utils.file_utils import get_ticket_description
from apps.utils.helper import SendMail, triger_socket, create_notification
from file_maker_system.celery import app
import os
from datetime import datetime
import json
from google.cloud import bigquery, storage
from apps.account.models import (
    AccessLogsModel, EVCCredentials, MyUser,
    RolesAndPermissions, ZOHOInvoices, ZOHOUser
)
from apps.file_request.models import (
    FileFormScheduleTaskLog, FileRequest,
    FileRequestHistory, FileRequestTime, RequestDownloadFiles, VehicleControl, DataEcuVersion, VehicleManagement
)
import logging
logger = logging.getLogger('django')

from apps.file_request.master_file_request_big_query_flow import master_file_flow
from apps.file_request.slave_file_request_big_query_flow import (
    decode_resubmit_slave_file,
    slave_kess3_file_flow,
    slave_kesv2_file_flow,
    slave_ktag_file_flow,
    # slave_magic_flex_file_flow,
    close_file_slot,
)
from apps.file_request.slave_file_request_flow import resubmit_file
from apps.utils.directory_utils import read_ini_file
from apps.admin_management.models import (Notification)
from django.template.loader import render_to_string
import boto3
from pymongo import MongoClient
from django.conf import settings
from gridfs import GridFS
from apps.utils.models import InternalErrorLog
from apps.utils.zoho_books_utils import (
    create_customer_to_zohobook,
    create_zoho_invoice,
    record_zoho_invoice_payment,
    update_customer_to_zohobook,
    zoho_approve_invoice,
    zoho_email_invoice
)
from apps.utils.mailer import (
    file_request_status_change,
    files_uploaded_to_secondary_database,
    send_zoho_invoice_approve_fail_mail,
    send_zoho_invoice_create_fail_mail,
    send_zoho_fail_mail,
    send_zoho_invoice_email_fail_mail,
    send_zoho_invoice_record_fail_mail,
    send_zoho_update_user_fail_mail
)
session = boto3.Session(
    aws_access_key_id=settings.AWS_ACCESS_KEY_ID,
    aws_secret_access_key=settings.AWS_SECRET_ACCESS_KEY,
    region_name=settings.AWS_S3_REGION_NAME
)
s3_client = session.client('s3')
import logging

logger = logging.getLogger('django')

#------------- ZOHO ARTICLE UPDATION CODE --------------
import requests
import json
from decouple import config
from apps.utils.models import ZOHOKnowledgeBaseArticles
from apps.zoho.models import ZOHOToken
from apps.utils.zoho_utils import (
    generate_zoho_access_with_refresh_token, update_zoho_tokens_in_db
)
from django.db import transaction


@shared_task
def load_zoho_articles_celery(category_id, access_token, user_type, start=1):
    #---
    """Fetch and save Zoho articles from API."""
    logger.info(f"Inside load zoho articles ------------ ")
    limit = 10
    url = f"https://desk.zoho.eu/api/v1/articles?categoryId={category_id}&from={start}&limit={limit}"
    headers = {
        'orgId': config('ZOHO_ORGID'),
        'Authorization': 'Zoho-oauthtoken ' + access_token
    }
    response = requests.request("GET", url, headers=headers)
    data = response.json()

    if "errorCode" in data:
        print("in error")
        response = generate_zoho_access_with_refresh_token(token_for=1)
        access_token = response["access_token"]
        obj = ZOHOToken.objects.filter(token_for=1)[0]
        refresh_token = obj.refresh_token
        update_zoho_tokens_in_db(access_token, refresh_token, token_for=1)
        return load_zoho_articles_celery(category_id, access_token, user_type, start)
    else:
        print("in success")
        with transaction.atomic():
            for article in data['data']:
                url = f"https://desk.zoho.eu/api/v1/articles/{article['id']}"
                response = requests.request("GET", url, headers=headers)
                if response.status_code == 200:
                    result = response.json()
                    ZOHOKnowledgeBaseArticles.objects.get_or_create(
                        article_id=article['id'],
                        title=article['title'],
                        status=article['status'],
                        category=article['category']['name'],
                        category_id=int(article['category']['id']),
                        root_category_id=int(article['rootCategoryId']),
                        summary=article['summary'],
                        owner_name=article['author']['name'],
                        owner_id=article['author']['id'],
                        perma_link=article['portalUrl'],
                        user_type=user_type,
                        answer=result.get('answer', ''),
                        tags=",".join(result.get('tags', []))
                    )
                    print(f"Article id: {article['id']} data saved successfully")
                else:
                    print(f"Failed to fetch article id: {article['id']}")

            if len(data['data']) == 0:
                return True
            start += limit
            return load_zoho_articles_celery(category_id, access_token, user_type, start)
#----

@app.task
def notify_permission_change(role_id):
    """Triger Tasks"""
    users = MyUser.objects.filter(roles__id=role_id)
    instance = RolesAndPermissions.objects.get(id=role_id)
    print('notify_permission_change accessed', role_id)

    for each in users:
        triger_socket({
            'uuid': str(each.uuid),
            'type': 'admin_permission_update',
            'data': instance.permissions,
            'message': "Roles and permission has been updated."
        })


@app.task
def send_logs_on_email(id):
    """Triger Tasks"""
    print("send_logs_on_email")
    instance = AccessLogsModel.objects.get(sys_id=id)
    if instance.user:
        context = {
            'name': "{} {}".format(instance.user.first_name, instance.user.last_name),
            'email': instance.user.email,
            "module": instance.module.module,
            "ip": instance.ip_address,
            "event": instance.event,
            "timestamp": instance.timestamp,
            'frontend_url': 'www.viezu-files.com',
        }
        get_template = render_to_string('email_template/logs_template.html', context)
        SendMail.mail("Log report| {}".format(instance.module.module), instance.module.emails.split(','), get_template)


@app.task
def import_individual_customer(params):
    """Triger Tasks"""
    print("import_individual_customer")


@app.task
def import_business_customer(params):
    """Triger Tasks"""
    print("import_business_customer")


@shared_task
def task_algo_master_file_matching(file_request_id):
    """Triger Tasks"""
    file_request = FileRequest.objects.get(request_id=file_request_id)
    schedule_obj = FileFormScheduleTaskLog.objects.create(
        file_request_id=file_request,
        is_running=True,
        is_master=True if file_request.file_type == "Master" else False
    )

    file_time = FileRequestTime.objects.create(
        file_request=file_request,
        start_time=datetime.now()
    )

    try:
        is_file_match_success, matching_found_in_path, random_generated_path = master_file_flow(file_request_id)
        schedule_obj.is_running = False
        schedule_obj.has_error = False

        if is_file_match_success and matching_found_in_path != "" and random_generated_path != "":
            task_upload_file_to_directory.delay(file_request_id, matching_found_in_path,
                                                random_generated_path)
    except Exception as error:
        schedule_obj.is_running = False
        schedule_obj.has_error = True
        schedule_obj.error = str(error)

        # Sent for manual handling if any issue occures.
        error = "Error:" + str(error)
        sent_for_manual_handling(file_request, error)
        file_request.status = "Manual handle"
        file_request.is_error = True

    schedule_obj.save()

    file_after_status = FileRequest.objects.get(request_id=file_request_id)
    if file_request.status == "OPEN" and file_after_status.status == "Manual handle":
        file_request.status = "Manual handle"
    else:
        file_request.status = "CLOSED"

    file_request.save()

    # File time save
    file_time.end_time = datetime.now()
    file_time.save()
    second_diff = file_time.end_time - file_time.start_time
    file_time.second_diff = second_diff.seconds
    file_time.save()

    if not schedule_obj.has_error:
        triger_socket({
            'uuid': str(file_request.user.uuid),
            'type': 'master_file_status',
            'ids': str(file_request.request_id),
            'created_at': str(file_request.created_at),
            'message': str(file_request.status)
        })

        file_request_status_change(file_request.user, file_request)

    else:

        triger_socket({
            'uuid': str(file_request.user.uuid),
            'type': 'master_file_status',
            'ids': str(file_request.request_id),
            'created_at': str(file_request.created_at),
            'message': "Manual handle"
        })

        file_request.status = "Manual handle"
        file_request.save()

    if file_request.status == "CLOSED":
        create_notification(file_request.user, "{} Status Update".format(file_request.request_id),
                            "File Request has been successfully completed",
                            sender=file_request.user, ticket=None, file=None)
    else:
        create_notification(file_request.user, "{} Status Update".format(file_request.request_id),
                            "File submission request sent for manual handle",
                            sender=file_request.user, ticket=None, file=None)


@shared_task
def task_algo_slave_file_matching(file_request_id):
    """Triger Tasks"""
    logger.info(f"{file_request_id} | inside task algo slave file matching ------------ ")
    
    file_request = FileRequest.objects.get(request_id=file_request_id)
    logger.info(f"file_request = {file_request}")
    schedule_obj = FileFormScheduleTaskLog.objects.create(
        file_request_id=file_request,
        is_running=True,
        is_master=False
    )
    logger.info(f"{file_request_id} | schedule_obj for file request")

    file_time = FileRequestTime.objects.create(
        file_request=file_request,
        start_time=datetime.now()
    )
    logger.info(f"{file_request_id} | file_time for = {file_time}")

    tool_used = file_request.tuning_tool_used
    logger.info(f"{file_request_id} | tool_used = {tool_used}")

    if tool_used == "KESS v2":
        try:
            matching_found_in_path = ""  # latest code
            random_generated_path = ""  # latest code
            logger.info(f"{file_request_id} | Inside kess v2 condition : Call slave_kesv2_file_flow")
            is_file_match_success, matching_found_in_path, random_generated_path = slave_kesv2_file_flow(
                file_request_id)
            schedule_obj.is_running = False
            schedule_obj.has_error = False
            
            if is_file_match_success and matching_found_in_path != "" and random_generated_path != "":
                task_upload_file_to_directory.delay(file_request_id, matching_found_in_path,
                                                    random_generated_path, is_master=False)
        except Exception as error:
            print(f"Exception error is ---------------------------: {error}")
            schedule_obj.is_running = False
            schedule_obj.has_error = True
            schedule_obj.error = str(error)

            error = "Error:" + str(error)
            print(f"Call sent for manual handling Exception CASE-------- {error}")
            #----
            try:
                decode_instance = DecodeFiles.objects.get(file_request_id=file_request_id)
                print(f"decode_instance are : {decode_instance}")
                close_file_slot(decode_instance, file_request)
            except Exception as e:
                print(f"New Error during decoding response : {e}")
            #----
            sent_for_manual_handling(file_request, error)
            file_request.is_error = True

        schedule_obj.save()

        file_request = FileRequest.objects.get(request_id=file_request_id)

        # File time save
        file_time.end_time = datetime.now()
        file_time.save()
        second_diff = file_time.end_time - file_time.start_time
        file_time.second_diff = second_diff.seconds
        file_time.save()
        logger.info(f"File time : {file_time}")

    #---
    # elif tool_used == "MAGIC FLEX":
    #     logger.info("inside magic api -------------------- TASK.PY")
    #     try:
    #         logger.info("Call slave_magic_flex_file_flow function ----------- ")
    #         is_file_match_success, matching_found_in_path, random_generated_path = slave_magic_flex_file_flow(
    #             file_request_id)
    #         schedule_obj.is_running = False
    #         schedule_obj.has_error = False
    #         if is_file_match_success and matching_found_in_path != "" and random_generated_path != "":
    #             task_upload_file_to_directory.delay(file_request_id, matching_found_in_path,
    #                                                 random_generated_path, is_master=False)
    #     except Exception as error:
    #         schedule_obj.is_running = False
    #         schedule_obj.has_error = True
    #         schedule_obj.error = str(error)

    #         error = "Error:" + str(error)
    #         sent_for_manual_handling(file_request, error)
    #         file_request.is_error = True

    #     schedule_obj.save()
    #     file_request = FileRequest.objects.get(request_id=file_request_id)
    #     # File time save
    #     file_time.end_time = datetime.now()
    #     file_time.save()
    #     second_diff = file_time.end_time - file_time.start_time
    #     file_time.second_diff = second_diff.seconds
    #     file_time.save()
    # ---
    elif tool_used == "KESS3":

        try:
            logger.info(f"{file_request_id} | Inside kess3 condition : Call slave_kesv3_file_flow")
            is_file_match_success, matching_found_in_path, random_generated_path = slave_kess3_file_flow(
                file_request_id)
            schedule_obj.is_running = False
            schedule_obj.has_error = False
            if is_file_match_success and matching_found_in_path != "" and random_generated_path != "":
                task_upload_file_to_directory.delay(file_request_id, matching_found_in_path,
                                                    random_generated_path, is_master=False)
        except Exception as error:
            schedule_obj.is_running = False
            schedule_obj.has_error = True
            schedule_obj.error = str(error)

            error = "Error:" + str(error)
            #----
            try:
                decode_instance = DecodeFiles.objects.get(file_request_id=file_request_id)
                print(f"decode_instance are : {decode_instance}")
                close_file_slot(decode_instance, file_request)
            except Exception as e:
                print(f"New Error during decoding response : {e}")
            #----
            sent_for_manual_handling(file_request, error)
            file_request.is_error = True

        schedule_obj.save()
        file_request = FileRequest.objects.get(request_id=file_request_id)
        # File time save
        file_time.end_time = datetime.now()
        file_time.save()
        second_diff = file_time.end_time - file_time.start_time
        file_time.second_diff = second_diff.seconds
        file_time.save()

    elif tool_used == "KTAG":
        try:
            is_file_match_success, matching_found_in_path, random_generated_path = slave_ktag_file_flow(file_request_id)
            schedule_obj.is_running = False
            schedule_obj.has_error = False

            if is_file_match_success and matching_found_in_path != "" and random_generated_path != "":
                task_upload_file_to_directory.delay(file_request_id, matching_found_in_path,
                                                    random_generated_path, is_master=False)
        except Exception as error:
            schedule_obj.is_running = False
            schedule_obj.has_error = True
            schedule_obj.error = str(error)

            error = "Error:" + str(error)
            sent_for_manual_handling(file_request, error)
            file_request.is_error = True

        schedule_obj.save()
        file_request = FileRequest.objects.get(request_id=file_request_id)
        # File time save
        file_time.end_time = datetime.now()
        file_time.save()
        second_diff = file_time.end_time - file_time.start_time
        file_time.second_diff = second_diff.seconds
        file_time.save()

    else:
        print("iside else ------------------------- ")
        logger.info("Step X: Sent for manual handling.")
        print("comign here 3 ----")
        is_manual_handle = TicketCategory.objects.filter(name="Manual Handle").exists()
        if not is_manual_handle:
            TicketCategory.objects.create(name="Manual Handle")
        # check if ticket is already exist for file request id:
        if not TicketHistory.objects.filter(request_id=file_request_id).exists():
            ticket = TicketHistory.objects.create(
                created_by=file_request.user,
                assigned_to=MyUser.objects.get(email='technical@viezu.com') if MyUser.objects.filter(
                    email='technical@viezu.com').exists() else None,
                category=TicketCategory.objects.get(name='Processing') if TicketCategory.objects.filter(
                    name='Processing').exists() else None,
                file_request=file_request,
                request_id=file_request.request_id,
                description=get_ticket_description(file_request),
                subject=file_request.request_id + ' - ' + file_request.vehicle_registration if file_request.vehicle_registration is not None else "File Request to be manually handle.",
                ticket_status=TicketStatus.objects.get(team_status="New")
            )
            ticket.update_ids()
            now = datetime.now()
            date = now.strftime("%d-%m-%Y")
            Notification.objects.create(
                recipient=ticket.assigned_to,
                ticket=ticket,
                title="Ticket has been created.",
                message="Ticket created by user on {0}.".format(date)
            )
        file_request.status = "Manual handle"
        file_request.save()
        schedule_obj.is_running = False
        schedule_obj.has_error = False
        schedule_obj.save()
        title = "File sent to manual handle."
        description = "File sent to Manual handle as {0} tool not available for decoding.".format(tool_used)
        save_flow(file_request, title, description, is_success=True)

    if (tool_used != "KESS v2" and tool_used != "KESS3" and tool_used != "KTAG"):
        triger_socket({
            'uuid': str(file_request.user.uuid),
            'type': 'slave_file_status',
            'ids': str(file_request.request_id),
            'created_at': str(file_request.created_at),
            'message': "Manual handle"
        })
    else:
        if not schedule_obj.has_error:
            triger_socket({
                'uuid': str(file_request.user.uuid),
                'type': 'slave_file_status',
                'ids': str(file_request.request_id),
                'created_at': str(file_request.created_at),
                'message': str(file_request.status)
            })
            file_request_status_change(file_request.user, file_request)

        else:
            triger_socket({
                'uuid': str(file_request.user.uuid),
                'type': 'slave_file_status',
                'ids': str(file_request.request_id),
                'created_at': str(file_request.created_at),
                'message': "Manual handle"
            })
    if file_request.status == "CLOSED":
        create_notification(file_request.user, "{} Status Update".format(file_request.request_id),
                            "File Request has been successfully completed",
                            sender=file_request.user, ticket=None, file=None)
    else:
        create_notification(file_request.user, "{} Status Update".format(file_request.request_id),
                            "File submission request sent for manual handle",
                            sender=file_request.user, ticket=None, file=None)


@app.task
def process_file_request_history(data):
    """Triger Tasks"""
    file_request_id = data.get('file_request_id')
    file_request = FileRequest.objects.get(request_id='FR' + str(file_request_id))
    schedule_obj = FileFormScheduleTaskLog.objects.filter(file_request_id=file_request_id).first()
    file_time = FileRequestTime.objects.filter(file_request_id=file_request_id).first()
    tool_used = file_request.tuning_tool_used
    if tool_used == "KESS v2":
        try:
            is_file_match_success, matching_found_in_path, random_generated_path = resubmit_file(data)
            schedule_obj.is_running = False
            schedule_obj.has_error = False

            if is_file_match_success and matching_found_in_path != "" and random_generated_path != "":
                task_re_upload_file_to_directory.delay(file_request_id, matching_found_in_path,
                                                       random_generated_path, is_master=False)
        except Exception as error:
            schedule_obj.is_running = False
            schedule_obj.has_error = True
            schedule_obj.error = str(error)

            error = "Error:" + str(error)
            logger.info(f"Error == {error}")
            sent_for_manual_handling(file_request, error)
            file_request.is_error = True

        schedule_obj.save()

        file_request = FileRequest.objects.get(request_id='FR' + str(file_request_id))

        # File time save
        file_time.end_time = datetime.now()
        file_time.save()
        second_diff = datetime.now() - file_time.start_time
        file_time.second_diff = second_diff.seconds
        file_time.save()

    elif tool_used == "KESS3":
        try:
            is_file_match_success, matching_found_in_path, random_generated_path = resubmit_file(data)
            schedule_obj.is_running = False
            schedule_obj.has_error = False
            if is_file_match_success and matching_found_in_path != "" and random_generated_path != "":
                task_re_upload_file_to_directory.delay(file_request_id, matching_found_in_path,
                                                       random_generated_path, is_master=False)
        except Exception as error:
            schedule_obj.is_running = False
            schedule_obj.has_error = True
            schedule_obj.error = str(error)

            error = "Error:" + str(error)
            sent_for_manual_handling(file_request, error)
            file_request.is_error = True

        schedule_obj.save()
        file_request = FileRequest.objects.get(request_id='FR' + str(file_request_id))
        # File time save
        file_time.end_time = datetime.now()
        file_time.save()
        second_diff = datetime.now() - file_time.start_time
        file_time.second_diff = second_diff.seconds
        file_time.save()

    elif tool_used == "KTAG":
        try:
            is_file_match_success, matching_found_in_path, random_generated_path = resubmit_file(data)
            schedule_obj.is_running = False
            schedule_obj.has_error = False

            if is_file_match_success and matching_found_in_path != "" and random_generated_path != "":
                task_re_upload_file_to_directory.delay(file_request_id, matching_found_in_path,
                                                       random_generated_path, is_master=False)
        except Exception as error:
            schedule_obj.is_running = False
            schedule_obj.has_error = True
            schedule_obj.error = str(error)

            error = "Error:" + str(error)
            sent_for_manual_handling(file_request, error)
            file_request.is_error = True

        schedule_obj.save()
        file_request = FileRequest.objects.get(request_id='FR' + str(file_request_id))
        # File time save
        file_time.end_time = datetime.now()
        file_time.save()
        second_diff = datetime.now() - file_time.start_time
        file_time.second_diff = second_diff.seconds
        file_time.save()

    else:
        logger.info("Step X: Sent for manual handling.")
        print("comign here 4 ----")
        is_manual_handle = TicketCategory.objects.filter(name="Manual Handle").exists()
        if not is_manual_handle:
            TicketCategory.objects.create(name="Manual Handle")
        ticket = TicketHistory.objects.create(
            created_by=file_request.user,
            assigned_to=MyUser.objects.get(email='technical@viezu.com') if MyUser.objects.filter(
                email='technical@viezu.com').exists() else None,
            category=TicketCategory.objects.get(name='Processing') if TicketCategory.objects.filter(
                name='Processing').exists() else None,
            file_request=file_request,
            request_id=file_request.request_id,
            description=get_ticket_description(file_request),
            subject=file_request.request_id + ' - ' + file_request.vehicle_registration if file_request.vehicle_registration is not None else "File Request to be manually handle.",
            ticket_status=TicketStatus.objects.get(team_status="New")
        )
        ticket.update_ids()
        now = datetime.now()
        date = now.strftime("%d-%m-%Y")
        Notification.objects.create(
            recipient=ticket.assigned_to,
            ticket=ticket,
            title="Ticket has been created.",
            message="Ticket created by user on {0}.".format(date)
        )
        file_request.status = "Manual handle"
        file_request.save()
        schedule_obj.is_running = False
        schedule_obj.has_error = False
        schedule_obj.save()
        title = "File sent to manual handle."
        description = "File sent to Manual handle as {0} tool not available for decoding.".format(tool_used)
        save_flow(file_request, title, description, is_success=True)

    if (tool_used != "KESS v2" and tool_used != "KESS3" and tool_used != "KTAG"):
        triger_socket({
            'uuid': str(file_request.user.uuid),
            'type': 'slave_file_status',
            'ids': str(file_request.request_id),
            'created_at': str(file_request.created_at),
            'message': "Manual handle"
        })
    else:
        if not schedule_obj.has_error:
            triger_socket({
                'uuid': str(file_request.user.uuid),
                'type': 'slave_file_status',
                'ids': str(file_request.request_id),
                'created_at': str(file_request.created_at),
                'message': str(file_request.status)
            })

            file_request_status_change(file_request.user, file_request)

        else:
            triger_socket({
                'uuid': str(file_request.user.uuid),
                'type': 'slave_file_status',
                'ids': str(file_request.request_id),
                'created_at': str(file_request.created_at),
                'message': "Manual handle"
            })
    if file_request.status == "CLOSED":
        create_notification(file_request.user, "{} Status Update".format(file_request.request_id),
                            "File Request has been successfully completed",
                            sender=file_request.user, ticket=None, file=None)
    else:
        create_notification(file_request.user, "{} Status Update".format(file_request.request_id),
                            "File submission request sent for manual handle",
                            sender=file_request.user, ticket=None, file=None)


@shared_task
def task_algo_slave_file_matching_time(file_request_id, decoded_file_path, submit_file_path):
    """Triger Tasks"""
    decoded_file = default_storage.open(decoded_file_path)
    submit_file = default_storage.open(submit_file_path) if submit_file_path else None
    slave_kess3_file_matching_flow(file_request_id, decoded_file, submit_file)


@app.task
def task_sync_main_dir(uuid):
    read_ini_file(uuid)


@app.task
def task_sync_main_dir_bigquery():
    os.environ['GOOGLE_CLOUD_PROJECT'] = 'bigquery-project-437912'
    os.environ['GOOGLE_APPLICATION_CREDENTIALS'] = 'file-matching-43da45e9f9b8.json'
    retrieve_and_prepare_file_from_directory()


@app.task
def close_file_slots_task(tool_used, slot_guids):
    evc_instance = EVCCredentials.objects.all().last()
    for slot_guid in slot_guids:
        if not slot_guid:
            logger.warning("Encountered a None slot_guid, skipping...")
            continue
        if evc_instance:
            if tool_used == "KESS v2":
                file_type = "kessv2"
            elif tool_used == "KESS3":
                file_type = "kess3"
            else:
                file_type = "ktag"

            is_closed = FileOperation().close_file_slot(evc_instance.alientechauttoken, slot_guid, file_type)
            if is_closed:
                logger.info(f"Successfully closed slot {slot_guid} for {tool_used}.")
            else:
                logger.error(f"Failed to close slot {slot_guid} for {tool_used}.")


def get_existing_files_from_bigquery(dataset, table):
    client = bigquery.Client()
    query = f"SELECT directory_name, file_name FROM `{dataset}.{table}`"
    query_job = client.query(query)
    results = query_job.result()
    return set((row.directory_name, row.file_name) for row in results)


def retrieve_and_prepare_file():
    s3 = session.resource('s3')
    bucket = s3.Bucket('filemaker-stage')

    # files = get_existing_files_from_bigquery('filemaker_directory', 'file_hex_data')

    total_count = sum(1 for obj in bucket.objects.filter(Prefix='Main/') if
                      str(obj.key) != "Main/" and ".ini" not in str(obj.key) and (
                              len(obj.key.split('/')) == 2))
    print(f"Total files under 'Main/': {total_count}")

    count = 0

    for obj in bucket.objects.filter(Prefix='Main/'):

        if str(obj.key) != "Main/" and ".ini" not in str(obj.key) and (
                len(obj.key.split('/')) == 2):
            key = obj.key
            print(key)
            file_obj = key.split("/")

            # Keep the full file name including parentheses
            file_name = file_obj[-1]

            # Clean the directory name by removing parentheses and their content
            directory_name = re.sub(r'\(.*?\)', '', file_obj[-2]).strip()

            if file_exists_in_bigquery('filemaker_directory', 'file_hex_data', directory_name, file_name):
                print(f"File already exists in BigQuery: {file_name}")
                continue

            try:
                file_data = obj.get()['Body'].read()
                hex_blocks = convert_binary_to_hex_blocks(file_data)
                row = [{
                    'directory_name': directory_name,
                    'file_name': file_name,
                    'hex_block': hex_blocks
                }]
                insert_into_bigquery('filemaker_directory', 'file_hex_data', row)
                count += 1
                print(f"{count} files prepared and inserted")

            except Exception as e:
                print(f"Error processing file {key}: {e}")


def get_existing_directories_from_bigquery(dataset, table):
    client = bigquery.Client()
    query = f"""
    SELECT DISTINCT(directory_name) FROM `{dataset}.{table}`
    """
    query_job = client.query(query)
    results = query_job.result()
    return [row['directory_name'] for row in results]


def retrieve_and_prepare_file_from_directory():
    s3 = session.resource('s3')
    bucket = s3.Bucket('filemaker-stage')

    # Fetch existing directory paths from the database
    queryset = Directory.objects.values_list('directory_path', flat=True)
    count = 0
    existing_dirs_in_bigquery = get_existing_directories_from_bigquery('filemaker_directory', 'file_data')
    filtered_directories = [directory for directory in queryset if
                            directory.replace('Main/', '') not in existing_dirs_in_bigquery]
    print(f"Number of directories to be processed: {len(filtered_directories)}")
    for prefix in filtered_directories:
        for obj in bucket.objects.filter(Prefix=prefix):
            if ".ini" not in str(obj.key) and obj.key.split("/")[-1] != "":
                file_name = obj.key.split("/")[-1]
                directory_name = prefix.replace('Main/', '')
                print(f"Processing file: {file_name}, Directory: {directory_name}")

                if file_exists_in_bigquery('filemaker_directory', 'file_data', directory_name, file_name):
                    print(f"File already exists in BigQuery: {file_name}")
                    continue

                try:
                    file_data = obj.get()['Body'].read()
                    file_size_bytes = len(file_data)
                    hex_blocks = convert_binary_to_hex_blocks(file_data)

                    row = [{
                        'directory_name': directory_name,
                        'file_name': file_name,
                        'hex_block': hex_blocks,
                        'file_size_bytes': file_size_bytes
                    }]

                    # Insert data into BigQuery
                    insert_into_bigquery('filemaker_directory', 'file_data', row)
                    count += 1
                    print(f"{count} files prepared and inserted")

                except Exception as e:
                    print(f"Error processing file {obj.key}: {e}")


def file_exists_in_bigquery(dataset_id, table_id, directory_name, file_name):
    client = bigquery.Client()
    query = f"""
    SELECT COUNT(*) as count
    FROM `{dataset_id}.{table_id}`
    WHERE directory_name = @directory_name AND file_name = @file_name
    """
    job_config = bigquery.QueryJobConfig(
        query_parameters=[
            bigquery.ScalarQueryParameter("directory_name", "STRING", directory_name),
            bigquery.ScalarQueryParameter("file_name", "STRING", file_name)
        ]
    )
    query_job = client.query(query, job_config=job_config)
    result = query_job.result()
    for row in result:
        return row.count > 0
    return False


def convert_binary_to_hex_blocks(binary_data):
    hex_data = binascii.hexlify(binary_data).decode()
    return convert_to_n_size_block(hex_data, 20)


def convert_to_n_size_block(hexadata, size):
    hexadata_list = [hexadata[i:i + size] for i in range(0, len(hexadata), size)]
    return hexadata_list


def insert_into_bigquery(dataset_id, table_id, rows_to_insert):
    client = bigquery.Client()
    table_ref = client.dataset(dataset_id).table(table_id)

    errors = client.insert_rows_json(table_ref, rows_to_insert)

    if errors:
        logger.error(f"Error inserting batch into BigQuery: {errors}")
    else:
        logger.info("Inserted BigQuery successfully")


def read_s3_files_to_mongo():
    s3 = session.resource('s3')
    bucket = s3.Bucket(settings.AWS_STORAGE_BUCKET_NAME)

    client = MongoClient(settings.MONGO_HOST, 27017)
    db = client['filemaker_directory']
    fs = GridFS(db)
    coll = db['directory']

    count = 0
    for obj in bucket.objects.filter(Prefix='Main/'):
        key = obj.key
        if str(key) == "Main/" or ".ini" in str(key):
            continue
        else:
            file_obj = key.split("/")
            directory = {}
            directory["directory_name"] = file_obj[-2]
            directory["file_name"] = file_obj[-1]
            is_file_in_dir = bool(coll.find_one({'file_name': {"$in": [file_obj[-1]]}}))
            if not is_file_in_dir:
                coll.insert_one(directory)
                print("instering dir", file_obj[-1])

            is_file_in_fs = fs.find_one({'filename': {"$in": [file_obj[-1]]}})
            if not is_file_in_fs:
                fs.put(obj.get()['Body'].read(), filename=file_obj[-1], metadata={"directory_name": file_obj[-2]})
                print("instering fs", file_obj[-1])

            print("===============")
            count += 1
            print("{} files inserted".format(count))
    client.close()
    print("All files inserted in database.")

    files_uploaded_to_secondary_database()


@app.task
def task_create_zoho_customer(user_uuid):
    logger.info(f"inside create zoho customer function:-----------")
    user = MyUser.objects.get(uuid=user_uuid)
    logger.info(f"user : {user}")
    log_instance = InternalErrorLog.objects.create(
        module="Zoho books",
        action="Create customer",
        has_error=False,
        error=None
    )
    logger.info(f"log_instance = {log_instance}")
    try:
        logger.info(f"Call Create customer to zohobook function--------------")
        is_zoho_user_created, error = create_customer_to_zohobook(user)
        if is_zoho_user_created and error is None:
            log_instance.has_error = False
            log_instance.error = None
        else:
            log_instance.has_error = True
            log_instance.error = error
        log_instance.save()
    except Exception as error:
        print(str(error))
        error = str(error)

        log_instance.has_error = True
        log_instance.error = error
        log_instance.save()
        is_zoho_user_created = False

    if log_instance.has_error:
        logger.info(f"if log_instance has error ---- Send zoho fail mail")
        send_zoho_fail_mail(user, error)
        return is_zoho_user_created


@app.task
def task_update_zoho_customer(user_uuid):
    is_zoho_user_updated = False
    user = MyUser.objects.get(uuid=user_uuid)
    log_instance = InternalErrorLog.objects.create(
        module="Zoho books",
        action="Update customer",
        has_error=False,
        error=None
    )

    try:
        is_zoho_user_updated, error = update_customer_to_zohobook(user)
        if is_zoho_user_updated and error is None:
            log_instance.has_error = False
            log_instance.error = None
        else:
            log_instance.has_error = True
            log_instance.error = error
        log_instance.save()
    except Exception as error:
        print(str(error))
        error = str(error)

        log_instance.has_error = True
        log_instance.error = error
        log_instance.save()
        is_zoho_user_created = False

    if log_instance.has_error:
        send_zoho_update_user_fail_mail(user, error)
        return is_zoho_user_updated


@app.task
def task_create_zoho_invoice(checkout_session_id):
    """ A four step process for zoho invoice..

    Step 1: Create invoice at zoho.
    Step 2: Approve invoice at zoho.
    Step 1: Record invoice payment at zoho.
    Step 1: Email invoice to user.

    These four task will run as soon as an order is purchased 
    through shop from portal.

    An email will be sent if any error arise in any of the 
    four tasks to admin user.

    This task is step 1:
    To create invoice at ZOHO. 

    Args:
        checkout_session_id (str): stripe checkout session id.

    Returns:
        _type_: _description_
    """
    logger.info("Code come inside function name - task_create_zoho_invoice")
    error = None
    is_zoho_invoice_created = False
    order_list = OrderList.objects.get(stripe_id=checkout_session_id)
    logger.info(f"{order_list.ids} - Fetch order list details : {order_list}")
    log_instance = InternalErrorLog.objects.create(
        module="Zoho books",
        action="Create Invoice",
        has_error=False,
        error=None
    )
    logger.info(f"{order_list.ids} - Create logs in Internal Error table logs")
    try:
        logger.info(f"{order_list.ids} - inside Try block --------------- ")
        is_zoho_invoice_created, error, invoice = create_zoho_invoice(order_list)
        if (is_zoho_invoice_created and
                error is None and
                invoice is not None):
            log_instance.has_error = False
            log_instance.error = None
            is_zoho_invoice_created = True
            logger.info(f"{order_list.ids} - inside if condition--> if zoho invoice created - {is_zoho_invoice_created}")
            logger.info(f"{order_list.ids} - Call task approve invoice function")
            task_approve_invoice.delay(invoice.invoice_id)
        else:
            logger.info(f"{order_list.ids} - inside else if zoho invoice created False : {is_zoho_invoice_created}")
            log_instance.has_error = True
            log_instance.error = error
            is_zoho_invoice_created = False
        log_instance.save()
    except Exception as error:
        logger.info(f"{order_list.ids} - inside Exception block if error occur in Try block : {str(error)}")
        print(str(error))
        error = str(error)

        log_instance.has_error = True
        log_instance.error = error
        log_instance.save()
        logger.info(f"{order_list.ids} - Error update in internal Error log table-----------")
        is_zoho_invoice_created = False

    if log_instance.has_error:
        logger.info(f"{order_list.ids} - send zoho invoice create fail mail --------------- ")
        send_zoho_invoice_create_fail_mail(order_list.user, error)
        return is_zoho_invoice_created
    else:
        pass
@app.task
def task_approve_invoice(invoice_id):
    """ Approve and invoice at zoho.

    This is step number 2:Approving the zoho invoice.

    Args:
        invoice_id (str): Invoice id of the zoho

    Returns:
        _type_: _description_
    """
    logger.info("Approve invoice.-----------")
    is_zoho_invoice_approved = False
    log_instance = InternalErrorLog.objects.create(
        module="Zoho books",
        action="Approve invoice",
        has_error=False,
        error=None
    )
    logger.info(f"log instance created with invoice id : {invoice_id}")

    zoho_invoice_object = ZOHOInvoices.objects.get(invoice_id=invoice_id)
    logger.info(f"zoho_invoice_object == {zoho_invoice_object}")
    try:
        logger.info(f"Calling zoho approve invoice function with invoice is : {invoice_id}")
        is_zoho_invoice_approved, error, invoice = zoho_approve_invoice(invoice_id)
        if (is_zoho_invoice_approved and
                error is None and
                invoice is not None):
            log_instance.has_error = False
            log_instance.error = None
            is_zoho_invoice_approved = True
            task_record_invoice_payment.delay(zoho_invoice_object.invoice_id)
        else:
            log_instance.has_error = True
            log_instance.error = error
            is_zoho_invoice_approved = False
        log_instance.save()
    except Exception as error:
        print(str(error))
        error = str(error)

        log_instance.has_error = True
        log_instance.error = error
        log_instance.save()
        is_zoho_invoice_approved = False

    if log_instance.has_error:
        send_zoho_invoice_approve_fail_mail(zoho_invoice_object.user.user, error)
        return is_zoho_invoice_approved
    else:
        pass


@app.task
def task_record_invoice_payment(invoice_id):
    """ Record payment for invoice at zoho.

    This is step number 3:Record payment for invoice at zoho.

    Args:
        invoice_id (str): Invoice id of the zoho

    Returns:
        _type_: _description_
    """
    print("in task record invoice payment")
    is_payment_recorded = False
    log_instance = InternalErrorLog.objects.create(
        module="Zoho books",
        action="Record Invoice Payment",
        has_error=False,
        error=None
    )
    logger.info(f"log_instance created for Record invoice payment with invoice id : {invoice_id}")
    zoho_invoice_object = ZOHOInvoices.objects.get(invoice_id=invoice_id)

    try:
        is_payment_recorded, error, invoice = record_zoho_invoice_payment(zoho_invoice_object)
        if (is_payment_recorded and
                error is None and
                invoice is not None):
            log_instance.has_error = False
            log_instance.error = None
            is_payment_recorded = True
            task_email_zoho_invoice.delay(zoho_invoice_object.invoice_id)
        else:
            log_instance.has_error = True
            log_instance.error = error
            is_payment_recorded = False
        log_instance.save()
    except Exception as error:
        print(str(error))
        error = str(error)

        log_instance.has_error = True
        log_instance.error = error
        log_instance.save()
        is_payment_recorded = False

    if log_instance.has_error:
        send_zoho_invoice_record_fail_mail(zoho_invoice_object.user.user, error)
        return is_payment_recorded
    else:
        pass


@app.task
def task_email_zoho_invoice(invoice_id):
    """ Record payment for invoice at zoho.

    This is step number 4:Email invoice to customer.

    Args:
        invoice_id (str): Invoice id of the zoho

    Returns:
        _type_: _description_
    """
    is_invoice_emailed = False
    log_instance = InternalErrorLog.objects.create(
        module="Zoho books",
        action="Email Invoice.",
        has_error=False,
        error=None
    )

    zoho_invoice_object = ZOHOInvoices.objects.get(invoice_id=invoice_id)

    try:
        is_invoice_emailed, error = zoho_email_invoice(zoho_invoice_object)
        if is_invoice_emailed and error is None:
            log_instance.has_error = False
            log_instance.error = None
            is_invoice_emailed = True
        else:
            log_instance.has_error = True
            log_instance.error = error
            is_invoice_emailed = False
        log_instance.save()
    except Exception as error:
        print(str(error))
        error = str(error)

        log_instance.has_error = True
        log_instance.error = error
        log_instance.save()
        is_invoice_emailed = False

    if log_instance.has_error:
        send_zoho_invoice_email_fail_mail(zoho_invoice_object.user.user, error)
        return is_invoice_emailed
    else:
        pass


@app.task
def task_create_customer_stripe(uuid):
    customer_object = MyUser.objects.get(uuid=uuid)
    log_instance = InternalErrorLog.objects.create(
        module="Stripe customer",
        action="Create customer.",
        has_error=False,
        error=None
    )
    try:
        create_stripe_customer(customer_object)
        log_instance.has_error = False
        log_instance.error = None
    except Exception as error:
        logger.error(str(error))
        log_instance.has_error = True
        log_instance.error = str(error)

    log_instance.save()


def upload_file_to_s3(local_path, bucket_path):
    myfile = local_path
    logger.info("file to upload path %s", myfile)
    logger.info("Bucket path to upload %s", bucket_path)

    client = boto3.client(
        's3',
        region_name='us-east-1',
        aws_access_key_id=settings.AWS_ACCESS_KEY_ID,
        aws_secret_access_key=settings.AWS_SECRET_ACCESS_KEY
    )
    try:
        response = client.upload_file(
            myfile,
            settings.AWS_STORAGE_BUCKET_NAME,
            bucket_path,
            ExtraArgs={'ACL': 'public-read'}
        )
        url = "https://{}.s3.us-east-1.amazonaws.com/{}".format(
            settings.AWS_STORAGE_BUCKET_NAME, bucket_path)
        return True, url
    except Exception as e:
        logger.error("S3", e)
        return False, None


@app.task
def task_upload_file_to_directory(file_request_id, matching_found_in_path,
                                  random_generated_path, is_master=True):
    """ Upload files after final completion.

    Upload usersubmitted file and file got from algorithm to a s3 directory.  
    """
    logger.info("task_upload_file_to_directory")
    file_request_obj = FileRequest.objects.get(request_id=file_request_id)
    tuning_file = file_request_obj.tuning_file

    folder_name = random_generated_path.split("/")[-1]
    path_to_create_at_local = "media/{}".format(folder_name)

    logger.info("path to create")
    logger.info(path_to_create_at_local)
    isExist = os.path.exists(path_to_create_at_local)
    if not isExist:
        logger.info("in not exist")
        os.mkdir(path_to_create_at_local)

    folder_prefix = tuning_file.url.split("/")
    folder_prefix = "/".join(folder_prefix[3:])

    s3 = session.resource('s3')
    bucket = s3.Bucket(settings.AWS_STORAGE_BUCKET_NAME)
    if is_master == False:
        files_to_upload_path = 'media/{}'.format(file_request_id)

        for root, dirs, files in os.walk(files_to_upload_path):
            for filename in files:
                local_file = os.path.join(root, filename)
                logger.info("first local_file %s", local_file)
                logger.info("first folder_name %s", folder_name)
                logger.info("first filename %s", filename)
                upload_file_to_s3(local_file, "{}/{}".format('Main/' + folder_name, filename))

    logger.info("++++download folder prefix++++")
    logger.info(folder_prefix)
    logger.info("******random generated path******")
    logger.info(random_generated_path)

    for s3_file in bucket.objects.filter(Prefix=folder_prefix):
        file_object = s3_file.key
        file_name = str(file_object.split('/')[-1])
        bucket.download_file(file_object, '{}/{}'.format(
            path_to_create_at_local, file_name))

    for root, dirs, files in os.walk(path_to_create_at_local):
        for filename in files:
            intial_file_name = file_name
            splited = filename.split(".")
            if 'ols' in splited:
                filename = splited[0] + '.' + splited[1]
            else:
                filename = splited[0]
            local_file = os.path.join(root, intial_file_name)
            logger.info("second local_file %s", local_file)
            logger.info("second folder_name %s", folder_name)
            logger.info("second filename %s", filename)
            upload_file_to_s3(local_file, "{}/{}".format('Main/' + folder_name, filename))

    import shutil
    shutil.rmtree(path_to_create_at_local)
    if is_master == False:
        shutil.rmtree(files_to_upload_path)

    return True


@app.task
def task_re_upload_file_to_directory(file_request_id, matching_found_in_path,
                                     random_generated_path, is_master=True):
    """ Upload files after final completion.

    Upload usersubmitted file and file got from algorithm to a s3 directory.
    """
    logger.info("task_upload_file_to_directory")
    folder_name = random_generated_path.split("/")[-1]
    path_to_create_at_local = "media/{}".format(folder_name)

    logger.info("path to create")
    logger.info(path_to_create_at_local)
    isExist = os.path.exists(path_to_create_at_local)
    if not isExist:
        logger.info("in not exist")
        os.mkdir(path_to_create_at_local)
    s3 = boto3.resource(
        's3',
        region_name='us-east-1',
        aws_access_key_id=settings.AWS_ACCESS_KEY_ID,
        aws_secret_access_key=settings.AWS_SECRET_ACCESS_KEY
    )
    bucket = s3.Bucket(settings.AWS_STORAGE_BUCKET_NAME)
    request_files = RequestDownloadFiles.objects.filter(fil_request_id=file_request_id)
    if not request_files.exists():
        logger.error("No files found for file_request_id: %s", file_request_id)
        return
    for request_file in request_files:
        s3_url = request_file.url
        bucket_name = 'filemaker-stage'
        region_name = 'us-east-1'
        if 'tuning' in s3_url:
            base_url = f'https://{bucket_name}.s3.amazonaws.com/'
        else:
            base_url = f'https://{bucket_name}.s3.{region_name}.amazonaws.com/'
        s3_key = s3_url.replace(base_url, '')
        local_file_path = os.path.join(path_to_create_at_local, os.path.basename(s3_key))
        try:
            bucket.download_file(s3_key, local_file_path)
            logger.info("Downloaded %s to %s", s3_key, local_file_path)
        except Exception as e:
            logger.error("Failed to download %s: %s", s3_key, e)
    for root, dirs, files in os.walk(path_to_create_at_local):
        for filename in files:
            local_file = os.path.join(root, filename)
            s3_target_key = f'Main/{folder_name}/{filename}'
            re_upload_file_to_s3(local_file, s3_target_key)
            logger.info("Uploaded %s to %s", local_file, s3_target_key)

    import shutil
    shutil.rmtree(path_to_create_at_local)
    return True


# Manual handle code:

def re_upload_file_to_s3(file_path, s3_path):
    s3 = boto3.client(
        's3',
        region_name='us-east-1',
        aws_access_key_id=settings.AWS_ACCESS_KEY_ID,
        aws_secret_access_key=settings.AWS_SECRET_ACCESS_KEY
    )
    try:
        s3.upload_file(file_path, settings.AWS_STORAGE_BUCKET_NAME, s3_path)
        logger.info(f"Successfully uploaded {file_path} to {s3_path}")
    except Exception as e:
        logger.error(f"Error uploading file {file_path}: {e}")


def save_flow(file_request_obj, title,
              description, is_success,
              additional_information=''):
    logger.info(f"save flow: title:{title}|description : {description}|additional:{additional_information}|success : {is_success}")
    FileRequestHistory.objects.create(
        file_request_id=file_request_obj,
        title=title,
        description=description,
        is_success=is_success,
        additional_information=additional_information
    )

    return True


def sent_for_manual_handling(file_obj, description):
    """Check cases to sent for manual handling.

    Args:
        file_obj (file request object): _description_
        description (str): description to be set for filerequesthistory.
    """
    logger.info("Step X: Sent for manual handling.")
    print("comign here 5 verma ji ----")
    logger.info(f"description as error argument : {description}")
    sent_for_handle = True
    print(f"file_obj.user : {file_obj.user}")
    admin_user = MyUser.objects.get(email='airemap14@gmail.com')
    print(f"Admin : {admin_user}")

    #-------
    # admin_user = MyUser.objects.filter(user_type=2)
    # for tech_user in admin_user:
    #     create_notification(tech_user, "{} Error occur while file Processing".format(file_obj.request_id),
    #                         f"{description}",
    #                         sender=file_obj.user, ticket=None, file=None)
    # print("notification send successfully ---------------- ")
    #-------
    
    is_manual_handle = TicketCategory.objects.filter(name="Manual Handle").exists()
    if not is_manual_handle:
        TicketCategory.objects.create(name="Manual Handle")

    if not TicketHistory.objects.filter(request_id=file_obj.file_request_id).exists():
        ticket = TicketHistory.objects.create(
            created_by=file_obj.user,
            assigned_to=MyUser.objects.get(email='technical@viezu.com'
                                        ) if MyUser.objects.filter(email='technical@viezu.com'
                                                                    ).exists() else None,
            category=TicketCategory.objects.get(name='Processing') if TicketCategory.objects.filter(
                name='Processing').exists() else None,
            file_request=file_obj,
            request_id=file_obj.request_id,
            description=get_ticket_description(file_obj),
            subject=file_obj.request_id + ' - ' + file_obj.vehicle_registration if file_obj.vehicle_registration is not None else "File Request to be manually handle.",
            ticket_status=TicketStatus.objects.get(team_status="New")
        )
        logger.info(f"{file_obj} | ticket is Created")
        ticket.update_ids()

        from datetime import datetime
        now = datetime.now()
        date = now.strftime("%d-%m-%Y")

        Notification.objects.create(
            recipient=ticket.assigned_to,
            ticket=ticket,
            title="Ticket has been created.",
            message="Ticket created by user on {0}.".format(date)
        )

    file_obj.status = "Manual Handle"
    file_obj.save()

    title = "Sent to manual handling."
    logger.info("Call last save flow function-----")
    save_flow(file_obj, title,
              description, is_success=False)

    admin_user = MyUser.objects.get(email='technical@viezu.com')
    triger_socket({
        'uuid': str(admin_user.uuid),
        'type': 'admin_file_assigned',
        'ids': str(file_obj.request_id),
        'message': "File is assigned for manual handle:{}.".format(file_obj.request_id)
    })

    return sent_for_handle


@app.task
def task_manual_file_download(ids):
    logger.info("======== TASK manual_file_download ======================")
    is_in_encode = False

    encode = EncodeFiles.objects.filter(ids=ids)
    if encode.exists():
        encode_instance = encode.first()
        is_in_encode = True

    if is_in_encode:
        decode_obj = encode_instance.decode
        async_response = encode_instance.async_response
    else:
        decode_obj = DecodeFiles.objects.get(ids=ids)
        async_response = decode_obj.async_response

    if isinstance(async_response, str):
        result_json = json.loads(async_response)
    else:
        result_json = async_response

    decode_id = str(decode_obj.ids)
    decode_path_local = f"media/{decode_id}"

    if not os.path.exists(decode_path_local):
        try:
            logger.info("Path does not exist. Creating path.")
            os.makedirs(decode_path_local)
        except Exception as e:
            logger.error(e)

    for file_name, url in result_json['result'].items():
        if isinstance(url, str) and "https:" in url:
            if "URL" in file_name:
                file_name = file_name.replace("URL", "")
                if "obdDecodedFile" in file_name:
                    file_name = file_name + ".dec"
                elif "idFile" in file_name:
                    file_name = file_name + ".id"
            is_file_save_local = save_any_file(decode_path_local, url, file_name)
            if is_file_save_local:
                file_path = f"{decode_path_local}/{file_name}"
                bucket_path = f'encode_decode/{decode_id}/{file_name}'
                is_success, file_url = upload_file_to_s3(file_path, bucket_path)
                try:
                    ManualFile.objects.create(
                        decode=decode_obj,
                        dir_name=str(decode_id),
                        file_name=file_name,
                        file_url=file_url
                    )
                except Exception as error:
                    logger.error(error)


def save_any_file(path, url, file_name):
    logger.info("######################save file####################################")
    evc_instance = EVCCredentials.objects.all().last()
    from apps.utils.ecode_decode import FileOperation

    is_sucess, response = FileOperation().download_file(
        evc_instance.alientechauttoken,
        url
    )
    if is_sucess and response:
        import base64
        file_content = base64.b64decode(response['data'])
        if not os.path.exists(path):
            os.makedirs(path)
        filename = path + '/' + file_name
        with open(filename, 'wb') as f:
            f.write(file_content)
        is_file_save_local = True
    else:
        logger.info("Error while downloading file: {}".format(file_name))
        is_file_save_local = False

    return is_file_save_local


@app.task
def remove_duplicate_dir():
    from apps.admin_management.models import Directory
    from django.db.models import Count
    duplicate_paths = Directory.objects.values('directory_path').annotate(count=Count('id')).filter(count__gt=1)
    for duplicate in duplicate_paths:
        duplicates = Directory.objects.filter(directory_path=duplicate['directory_path'])
        to_keep = duplicates.first()
        to_delete = duplicates.exclude(id=to_keep.id)
        to_delete.delete()

    return "Duplicate dir removed."


# @app.task
# def read_s3_files_to_mongo():

#     s3 = session.resource('s3')
#     bucket = s3.Bucket(config('AWS_STORAGE_BUCKET_NAME'))

#     client = MongoClient(settings.MONGO_HOST, 27017)
#     db = client['filemaker_directory']
#     fs = GridFS(db)
#     coll = db['directory']

#     count = 0
#     for obj in bucket.objects.filter(Prefix='Main/'):
#         key = obj.key
#         if str(key) == "Main/" or ".ini" in str(key):
#             continue
#         else:
#             file_obj = key.split("/")
#             directory = {}
#             directory["directory_name"] = file_obj[-2]
#             directory["file_name"] = file_obj[-1] 
#             is_file_in_dir = bool(coll.find_one({'file_name':{ "$in": [file_obj[-1]]}}))
#             if not is_file_in_dir:
#                 coll.insert_one(directory)
#                 print("instering dir",file_obj[-1])


#             is_file_in_fs = fs.find_one({'filename':{ "$in": [file_obj[-1]]}})
#             if not is_file_in_fs:
#                 fs.put(obj.get()['Body'].read(), filename=file_obj[-1],metadata={"directory_name":file_obj[-2]})
#                 print("instering fs",file_obj[-1])

#             print("===============")
#             count += 1
#             print("{} files inserted".format(count))
#     client.close()

#     context = {
#         'link': "{}/{}/{}".format(
#             settings.FRONTEND_BASE_URL,
#             settings.FRONTEND_EMAIL_VERIFY_URL,
#         ),
#     }
#     get_template = render_to_string('email_template/welcome.html', context)
#     SendMail.mail("All files inserted in secondary database.", 'akshay.sharma@oodles.io', get_template)
#     print("All files inserted in database.")

# import gridfs
# from bson.json_util import dumps
# client = MongoClient(settings.MONGO_HOST, 27017)
# db = client['filemaker_directory']
# collection = db['fs.files']
# query = {
#     "filename": { "$regex": "Original", "$options": "i" },
#     "length": { "$gte": 4 * 1024 * 1024, "$lte": 8 * 1024 * 1024},
# }

# projection = {
#     "_id": 1,
#     "filename": 1,
#     "length":1,
# }

# cursor = collection.find(query, projection)

# for result in cursor:
#     print(result)

# @app.task
# def read_s3_files_insert_to_csv():

#     import pandas as pd
#     from pymongo import MongoClient
#     import io

#     # Connect to MongoDB
#     client = MongoClient(settings.MONGO_HOST, 27017)
#     db = client['filemaker_directory']
#     collection = db['fs.files']

#     fs_files_data = db.fs.files.find({}, {'filename': 1, 'metadata.directory_name': 1})

#     # Prepare data for DataFrame
#     data = []
#     count = 1
#     for file_data in fs_files_data:
#         file_name = file_data['filename']
#         directory_name = file_data['metadata']['directory_name']

#         # Retrieve data from fs.chunks collection
#         file_id = file_data['_id']
#         binary_data = b''
#         for chunk in db.fs.chunks.find({'files_id': file_id}):
#             binary_data += chunk['data']

#         # Convert binary data to hexadecimal
#         hex_data = binascii.hexlify(binary_data).decode()
#         hex_data = convert_to_n_size_block(hex_data,8)

#         # Append to data list
#         data.append({'directory_name': directory_name, 'file_name': file_name, 'hex': hex_data})
#         count += 1
#         print("Files done:{}".format(count))
#     # print(data)
#     df = pd.DataFrame(data)

#     # Write DataFrame to CSV
#     df.to_csv('output.csv', index=False)
# read_s3_files_insert_to_csv()

@shared_task
def task_decode_slave_file_from_resubmit(file_request_id):
    logger.info(f"{file_request_id} | Running Slave other decode process.")
    try:
        file_request = FileRequest.objects.get(request_id=file_request_id)
        tool_used = file_request.tuning_tool_used
        if (tool_used != "KESS v2" and tool_used != "KESS3" and tool_used != "KTAG"):
            logger.info(f"Step X: {file_request_id} | Sent for manual handling.")
            print("comign here 6 ----")
            is_manual_handle = TicketCategory.objects.filter(name="Manual Handle").exists()
            if not is_manual_handle:
                TicketCategory.objects.create(name="Manual Handle")
            ticket = TicketHistory.objects.create(
                created_by=file_request.user,
                assigned_to=MyUser.objects.get(email='technical@viezu.com') if MyUser.objects.filter(
                    email='technical@viezu.com').exists() else None,
                category=TicketCategory.objects.get(name='Processing') if TicketCategory.objects.filter(
                    name='Processing').exists() else None,
                file_request=file_request,
                request_id=file_request.request_id,
                description=get_ticket_description(file_request),
                subject=file_request.request_id + ' - ' + file_request.vehicle_registration if file_request.vehicle_registration is not None else "File Request to be manually handle.",
                ticket_status=TicketStatus.objects.get(team_status="New")
            )
            ticket.update_ids()
            now = datetime.now()
            date = now.strftime("%d-%m-%Y")
            Notification.objects.create(
                recipient=ticket.assigned_to,
                ticket=ticket,
                title="Ticket has been created.",
                message="Ticket created by user on {0}.".format(date)
            )
            file_request.status = "Manual handle"
            file_request.save()
            title = "File sent to manual handle."
            description = "File sent to Manual handle as {0} tool not available for decoding.".format(tool_used)
            save_flow(file_request, title, description, is_success=True)
        else:
            logger.info(f"{file_request_id} | call decode resubmit slave file----")
            decode_resubmit_slave_file(file_request_id)
        if file_request.status == "CLOSED":
            create_notification(file_request.user, "{} Status Update".format(file_request.request_id),
                                "File Request has been successfully completed",
                                sender=file_request.user, ticket=None, file=None)
        else:
            create_notification(file_request.user, "{} Status Update".format(file_request.request_id),
                                "File submission request sent for manual handle",
                                sender=file_request.user, ticket=None, file=None)
    except Exception as error:
        logger.info(error)
        print(f"Exception error is ---------------------------: {error}")
        # schedule_obj.is_running = False
        # schedule_obj.has_error = True
        # schedule_obj.error = str(error)

        error = "Error:" + str(error)
        print(f"Call sent for manual handling Exception CASE-------- {error}")
        #----
        try:
            decode_instance = DecodeFiles.objects.get(file_request_id=file_request_id)
            print(f"decode_instance are : {decode_instance}")
            close_file_slot(decode_instance, file_request)
        except Exception as e:
            print(f"New Error during decoding response : {e}")
        #----
        sent_for_manual_handling(file_request, error)
        file_request.is_error = True


@app.task
def migrate_data_to_vehicle_management():
    for vehicle_control in VehicleControl.objects.all():
        vehicle_model = vehicle_control.vehicle_model
        vehicle_brand = vehicle_model.vehicle_brand
        vehicle_type = vehicle_brand.vehicle_type

        ecu_version_queryset = DataEcuVersion.objects.filter(
            brand__brand_name=vehicle_control.ecu_brand,
            ecu_version_name=vehicle_control.ecu_version
        )

        # Check if queryset is not empty and get the first result
        if ecu_version_queryset.exists():
            ecu_version = ecu_version_queryset.first()
            percentage = ecu_version.percentage
        else:
            percentage = None

        # Check if the record already exists
        exists = VehicleManagement.objects.filter(
            vehicle_type=vehicle_type.name,
            brand_name=vehicle_brand.brand_name,
            model_name=vehicle_model.model_name,
            ecu_brand=vehicle_control.ecu_brand,
            ecu_version=vehicle_control.ecu_version,
            fuel_type=vehicle_control.fuel_type,
            ecu_type=vehicle_control.ecu_type
        ).exists()

        if not exists:
            VehicleManagement.objects.create(
                vehicle_type=vehicle_type.name,
                brand_name=vehicle_brand.brand_name,
                model_name=vehicle_model.model_name,
                file_key_credit=vehicle_model.file_key_credit,
                ecu_brand=vehicle_control.ecu_brand,
                ecu_version=vehicle_control.ecu_version,
                fuel_type=vehicle_control.fuel_type,
                ecu_type=vehicle_control.ecu_type,
                percentage=percentage
            )

    print("Data migration completed!")