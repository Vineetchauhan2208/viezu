from django.conf import settings

from apps.utils.helper import SendMail
from django.template.loader import render_to_string
import logging

logger = logging.getLogger("django")


def send_zoho_fail_mail(user, error):
    if user.user_type == 3:
        user_type = "business"
    elif user.user_type == 4:
        user_type = "individual"
    else:
        user_type = None

    context = {
        'name': user.first_name + ' ' + user.last_name,
        'issue_account_email': user.email,
        'issue_account_type': user_type,
        'error': error,
        'event': 'Create a user at zoho.',
        'message': "Something went wrong while creating user at zoho.",
        'frontend_url': 'www.viezu-files.com',
    }
    get_template = render_to_string('email_template/zoho/zoho_create_user_fail.html', context)
    SendMail.mail("Zoho User creation failed.", "shiv.kumar@foreignerds.com", get_template)


def send_zoho_update_user_fail_mail(user, error):
    if user.user_type == 3:
        user_type = "business"
    elif user.user_type == 4:
        user_type = "individual"
    else:
        user_type = None

    context = {
        'name': user.first_name + ' ' + user.last_name,
        'issue_account_email': user.email,
        'issue_account_type': user_type,
        'error': error,
        'event': 'Create a user at zoho.',
        'message': "Something went wrong while creating user at zoho.",
        'frontend_url': 'www.viezu-files.com',
    }
    get_template = render_to_string('email_template/zoho/zoho_create_user_fail.html', context)
    SendMail.mail("Zoho User updated failed.", "shiv.kumar@foreignerds.com", get_template)


def send_zoho_invoice_create_fail_mail(user, error):
    if user.user_type == 3:
        user_type = "business"
    elif user.user_type == 4:
        user_type = "individual"
    else:
        user_type = None

    context = {
        'name': user.first_name + ' ' + user.last_name,
        'issue_account_email': user.email,
        'issue_account_type': user_type,
        'error': error,
        'event': 'Create Invoice.',
        'message': "Something went wrong while creating invoice at zoho.",
        'frontend_url': 'www.viezu-files.com',
    }
    get_template = render_to_string('email_template/zoho/zoho_create_user_fail.html', context)
    SendMail.mail("Zoho User creation failed.", "shiv.kumar@foreignerds.com", get_template)


def send_zoho_invoice_record_fail_mail(user, error):
    if user.user_type == 3:
        user_type = "business"
    elif user.user_type == 4:
        user_type = "individual"
    else:
        user_type = None

    context = {
        'name': user.first_name + ' ' + user.last_name,
        'issue_account_email': user.email,
        'issue_account_type': user_type,
        'error': error,
        'event': 'Create a user at zoho.',
        'message': "Something went wrong while creating user at zoho.",
        'frontend_url': 'www.viezu-files.com',
    }
    get_template = render_to_string('email_template/zoho/zoho_create_user_fail.html', context)
    SendMail.mail("Zoho User creation failed.", "shiv.kumar@foreignerds.com", get_template)


def send_zoho_invoice_email_fail_mail(user, error):
    if user.user_type == 3:
        user_type = "business"
    elif user.user_type == 4:
        user_type = "individual"
    else:
        user_type = None

    context = {
        'name': user.first_name + ' ' + user.last_name,
        'issue_account_email': user.email,
        'issue_account_type': user_type,
        'error': error,
        'event': 'Invoice Email.',
        'message': "Something went wrong while emailing zoho invoice.",
        'frontend_url': 'www.viezu-files.com',
    }
    get_template = render_to_string('email_template/zoho/zoho_create_user_fail.html', context)
    SendMail.mail("Zoho User creation failed.", "shiv.kumar@foreignerds.com", get_template)


def send_zoho_invoice_approve_fail_mail(user, error):
    if user.user_type == 3:
        user_type = "business"
    elif user.user_type == 4:
        user_type = "individual"
    else:
        user_type = None

    context = {
        'name': user.first_name + ' ' + user.last_name,
        'issue_account_email': user.email,
        'issue_account_type': user_type,
        'error': error,
        'event': 'Invoice Approve.',
        'message': "Something went wrong while approving zoho invoice.",
        'frontend_url': 'www.viezu-files.com',
    }
    get_template = render_to_string('email_template/zoho/zoho_create_user_fail.html', context)
    SendMail.mail("Zoho User creation failed.", "shiv.kumar@foreignerds.com", get_template)


def purchase_mail(user, order_list):
    print("In purchase mail.")
    from django.conf import settings
    line_items = order_list.checkout_data['line_items']
    item_list = []
    for item in line_items:
        item_data = {}
        item_data['name'] = item['name']
        item_data['quantity'] = item['quantity']
        item_data['total'] = item['total']
        item_list.append(item_data)

    context = {
        'name': user.first_name + ' ' + user.last_name,
        'email': user.email,
        'date': order_list.created_at.strftime('%d %B %Y'),
        'vat': order_list.tax_price,
        'total_price': order_list.total_price + order_list.tax_price,
        'line_items': order_list.checkout_data['line_items'],
        'billing': order_list.checkout_data['billing'],
        'shipping': order_list.checkout_data['shipping'],
        'order_img': 'https://filemaker-stage.s3.amazonaws.com/assets/proimg.png',
        'order_number': order_list.ids,
        'frontend_url': 'www.viezu-files.com',
    }

    get_template = render_to_string('email_template/order_completed_customer.html', context)
    SendMail.mail("Thank you for your order:{0}.".format(order_list.ids),
                  user.email, get_template)

    get_template = render_to_string('email_template/order_completed_viezu.html', context)
    SendMail.mail("Order purchased by a customer, order:{0}.".format(order_list.ids),
                  settings.ORDER_PURCHASE_EMAIL, get_template)


def file_request_status_change(user, file_request):
    from datetime import datetime
    now = datetime.now()
    logger.info("final file status %s", file_request.status)
    status = "In progress" if file_request.status == "Manual Handle" else file_request.status
    context = {
        'request_id': file_request.request_id,
        'status': status,
        'date_and_time': now.strftime('%d %B %Y %H:%M:%S'),
        'download_url': None,
        'frontend_url': 'www.viezu-files.com',
    }
    logger.info("status %s", status)
    if file_request.status == "CLOSED":
        context['download_url'] = "https://www.viezu-files.com/file-service/file-services"
    get_template = render_to_string('email_template/Filerequest/file_request_status.html', context)
    # SendMail.mail("File request status changed: {}.".format(file_request.request_id), user.email, get_template)
    SendMail.mail("File Request Submitted and File Status: {}.".format(file_request.request_id), user.email, get_template)
    logger.info("*****************END********************")


def file_request_created_with_another(user, previous_fr,
                                      previous_fr_id_status, file_request):
    status = "In progress" if file_request.status == "Manual Handle" else file_request.status
    context = {
        'previous_fr': previous_fr,
        'previous_fr_status': previous_fr_id_status,
        'request_id': file_request.request_id,
        'status': status,
        'first_name': file_request.user.first_name,
        'last_name': file_request.user.last_name,
        'date_and_time': file_request.created_at.strftime('%d %B %Y %H:%M:%S'),
        'frontend_url': 'www.viezu-files.com',
    }
    get_template = render_to_string('email_template/Filerequest/resubmitt_fr.html', context)
    SendMail.mail("File resubmitted by the internal team: {}.".format(file_request.request_id), user.email,
                  get_template)


def sample_email(sample=1):
    from django.conf import settings
    context = {
        'name': "{} {}".format("Akshay", "sharma"),
        'link': "{}/{}/{}".format(
            settings.FRONTEND_BASE_URL,
            settings.FRONTEND_EMAIL_VERIFY_URL,
            str("xyz")
        ),
        'frontend_url': 'www.viezu-files.com',
    }
    print("context", context)
    sample = int(sample)
    if sample == 1:
        get_template = render_to_string('email_template/sample1.html', context)
    elif sample == 2:
        get_template = render_to_string('email_template/sample2.html', context)
    elif sample == 3:
        get_template = render_to_string('email_template/sample3.html', context)
    elif sample == 4:
        get_template = render_to_string('email_template/sample4.html', context)
    else:
        get_template = render_to_string('email_template/sample5.html', context)

    SendMail.mail("sample email" + str(sample), "testing123@yopmail.com", get_template)


def files_uploaded_to_secondary_database():
    from datetime import datetime
    now = datetime.now()

    context = {
        'date_and_time': now.strftime('%d %B %Y %H:%M:%S'),
        'frontend_url': 'www.viezu-files.com',
    }
    get_template = render_to_string('email_template/database_sync_done.html', context)
    SendMail.mail("Files uploaded to secondary database.", 'support@viezu.com', get_template)
    SendMail.mail("Files uploaded to secondary database.", 'shiv.kumar@foreignerds.com', get_template)
