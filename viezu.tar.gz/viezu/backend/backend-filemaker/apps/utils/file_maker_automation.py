
import os
import sys
import json
import time
import queue
import datetime
import requests
import threading
from datetime import timedelta
from django.conf import settings
from apps.file_request.master_file_request_big_query_flow import master_file_flow

from apps.file_request.models import FileFormScheduleTaskLog, FileRequest
from apps.utils.helper import triger_socket



class ListenerMixin(object):
    def __init__(self):
        super(ListenerMixin, self).__init__()
        self.queue = queue.Queue()

    def notify(self, data):
        self.queue.put(data)

    def wait_for_data(self, timeout):
        return self.queue.get(timeout=timeout)


class PublishThread(ListenerMixin, threading.Thread):

    def __init__(self):
        super(PublishThread, self).__init__()

    def run(self):
        print('main')
        message = self.wait_for_data(0.5)
        self.__request_id = message.get('request_id')

        file_request = FileRequest.objects.get(request_id = self.__request_id)
        schedule_obj = FileFormScheduleTaskLog.objects.create(
            file_request_id = file_request,
            is_running = True,
            is_master = True if file_request.file_type == "Master" else False
        )
        try:
            master_file_flow(self.__request_id)
            schedule_obj.is_running = False
            schedule_obj.has_error = False
            file_request.status = "CLOSED"
        except Exception as error:
            schedule_obj.is_running = False
            schedule_obj.has_error = True
            schedule_obj.error = str(error)

        schedule_obj.save()
        file_request.save()

        triger_socket({
            'uuid':str(file_request.user.uuid),
            'type':'file_submission_completed',
            'message':"File submission request completed for request id:{}.".format(file_request.request_id)
        })
        

class AdvancedOrderManager(object):

    def __init__(self):
        self.script_threads = {}

    def get_user_thread(self, obj):
        print("Thread",obj)
        if obj in self.script_threads and self.script_threads[obj].isAlive():
            publish_thread = self.script_threads[obj]
        else:
            publish_thread = PublishThread()
            publish_thread.daemon = True
            publish_thread.start()
            self.script_threads[obj] = publish_thread
        return publish_thread


class FilerequestScriptPublish(object):
    def __init__(self, request_id):
        self.__request_id = request_id

    
    def publish(self):
        print("Published")
        advanced = AdvancedOrderManager()
        publish_thread = advanced.get_user_thread(self.__request_id)
        publish_thread.notify({
            "request_id": self.__request_id,
        })


# user = AutobaitUser.objects.get(email='aftab.hussain@oodles.io')
# campign = Campaign.objects.all().last()
#FilerequestLinkdinScriptPublish(
#     user, campign,'connection_list'
# )
# obj.publish()
# time.sleep(5)
# obj1 = LinkdinScriptPublish(
#     user, campign,'leads'
# )
# obj1.publish()