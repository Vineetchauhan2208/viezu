from django.urls import path
from apps.shop import views

app_name = 'shop'

urlpatterns = [
    path('products/list', views.WooCommerceProductsView.as_view()),
    path('products/<int:id>', views.get_product),
    path('category', views.WooCommerceCategoryView.as_view()),
    path('tags', views.WooCommerceTagsView.as_view()),
    path('shipping/zones/list', views.WooCommerceShippingZonesView.as_view()),
    path('products/filter', views.WooCommerceProductsFilterView.as_view()),
    path('orders', views.WooCommerceOrdersView.as_view()),
    path('orders/search', views.SearchOrdersView.as_view()),
    path('orders/create', views.CreateOrder.as_view()),
    path('orders/status', views.CreateStatusView.as_view()),

    path('stripe-webhook', views.StripeWebhookView.as_view()),
    path('tax-rate', views.WooCommerceTAXRateView.as_view()),

    path('products/list/viezu', views.ViezuProductsView.as_view()),
]