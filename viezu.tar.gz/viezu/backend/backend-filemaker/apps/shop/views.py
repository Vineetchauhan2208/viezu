from datetime import datetime

import stripe
from apps.utils.mailer import purchase_mail
from apps.utils.tasks import task_create_zoho_invoice
from decouple import config
from rest_framework.views import APIView
from rest_framework.response import Response
from rest_framework import status
from rest_framework.permissions import IsAuthenticated
from rest_framework.authentication import TokenAuthentication
from rest_framework.filters import SearchFilter
from django_filters import rest_framework as filters

from drf_yasg.utils import swagger_auto_schema
from apps.account.models import EVCCredentials, AccessLogsModel, EmailLogSettings

from apps.customer.models import Cart, CustomerCredit, OrderItem, OrderList, ResellerDistributeCredit
from apps.utils.evc_apis import add_remove_account_balance
from apps.utils.woocommerce_shop import WoocommerceShop, update_order
import apps.shop.response_messages as shop_resp
from rest_framework.decorators import api_view
from .serializer import (CategorySerializer, TagSerializer,OrderListSerializer )

from apps.utils.woocommerce_shop import Payment, create_order
from .schema import checkout_schema, order_status_schema
from apps.utils.evc_apis import is_evc_customer_exist
import logging
import pdb

logger = logging.getLogger('django')

stripe.api_key = config('STRIPE_SECRET_KEY')


# Create your views here.
class WooCommerceProductsView(APIView):

    def get(self, request):
        page = self.request.query_params.get('page', 1)
        obj = WoocommerceShop()
        wcapi = obj.connect_woocommerce()
        data = obj.list_products(wcapi, page)

        return Response({
            'data': data,
            'message': shop_resp.DATA_FETCHED_SUCCESSFULLY.format("Products")
        }, status=status.HTTP_200_OK)


@api_view(['GET'])
def get_product(request, id=None):
    obj = WoocommerceShop()
    wcapi = obj.connect_woocommerce()
    data = obj.get_product_by_id(wcapi, id)
    return Response({
        'data': data,
        'message': shop_resp.DATA_FETCHED_SUCCESSFULLY.format("Product")
    }, status=status.HTTP_200_OK)


class WooCommerceCategoryView(APIView):

    def get(self, request):
        page = self.request.query_params.get('page', 1)
        category_id = self.request.query_params.get('category_id', 1)
        obj = WoocommerceShop()
        wcapi = obj.connect_woocommerce()

        if page == str(1):
            data = obj.list_categories(wcapi, page)
        elif category_id is not None and category_id != "":
            data = obj.retrieve_category(wcapi, category_id)

        return Response({
            'data': data,
            'message': shop_resp.DATA_FETCHED_SUCCESSFULLY.format("Category")
        }, status=status.HTTP_200_OK)

    def post(self, request):
        obj = WoocommerceShop()
        wcapi = obj.connect_woocommerce()
        serializer = CategorySerializer(data=request.data)
        if serializer.is_valid():
            data = {
                "name": serializer.validated_data.get('category_name'),
                "image": {
                    "src": serializer.validated_data.get('img_src')
                }
            }
            data = obj.create_category(wcapi, data)
            return Response({
                'data': data,
                'message': shop_resp.CREATED_SUCCESSFULLY.format("Woocommerce Category")
            }, status=status.HTTP_200_OK)
        return Response({
            "detail": serializer.errors
        }, status=status.HTTP_400_BAD_REQUEST)

    def put(self, request):
        obj = WoocommerceShop()
        wcapi = obj.connect_woocommerce()
        serializer = CategorySerializer(data=request.data)
        if serializer.is_valid():
            data = {
                "description": serializer.validated_data.get('description'),
                "image": {
                    "src": serializer.validated_data.get('img_src')
                }
            }
            data = obj.update_category(wcapi, data)
            return Response({
                'data': data,
                'message': shop_resp.UPDATED_SUCCESSFULLY.format("Woocommerce Category")
            }, status=status.HTTP_200_OK)
        return Response({
            "detail": serializer.errors
        }, status=status.HTTP_400_BAD_REQUEST)

    def delete(self, request):
        category_id = self.request.query_params.get('category_id', 1)
        obj = WoocommerceShop()
        wcapi = obj.connect_woocommerce()
        data = obj.delete_category(wcapi, category_id)
        return Response({
            'data': data,
            'message': shop_resp.DATA_DELETED_SUCCESSFULLY.format("Category")
        }, status=status.HTTP_200_OK)


class WooCommerceTagsView(APIView):

    def get(self, request):
        page = self.request.query_params.get('page', 1)
        tag_id = self.request.query_params.get('tag_id', 1)
        obj = WoocommerceShop()
        wcapi = obj.connect_woocommerce()
        if page == str(page):
            data = obj.list_tags(wcapi, page)
        elif tag_id is not None and tag_id != "":
            data = obj.retrieve_tag(wcapi, tag_id)

        return Response({
            'data': data,
            'message': shop_resp.DATA_FETCHED_SUCCESSFULLY.format("Tags")
        }, status=status.HTTP_200_OK)

    def post(self, request):
        obj = WoocommerceShop()
        wcapi = obj.connect_woocommerce()
        serializer = TagSerializer(data=request.data)
        if serializer.is_valid():

            description = serializer.validated_data.get('description')
            if description is not None or description != "":
                data = {
                    "name": serializer.validated_data.get('tag_name'),
                    "description": serializer.validated_data.get('description')
                }
            else:
                data = {"name": serializer.validated_data.get('tag_name')}

            data = obj.create_tag(wcapi, data)
            return Response({
                'data': data,
                'message': shop_resp.CREATED_SUCCESSFULLY.format("Woocommerce Tag")
            }, status=status.HTTP_200_OK)
        return Response({
            "detail": serializer.errors
        }, status=status.HTTP_400_BAD_REQUEST)

    def put(self, request):
        obj = WoocommerceShop()
        wcapi = obj.connect_woocommerce()
        serializer = TagSerializer(data=request.data)
        if serializer.is_valid():
            id = serializer.validated_data.get('id')
            description = serializer.validated_data.get('description')
            if description is not None or description != "":
                data = {"description": serializer.validated_data.get('description')}
            else:
                return Response({
                    "detail": "Description required."
                }, status=status.HTTP_400_BAD_REQUEST)
            data = obj.update_tag(wcapi, id, data)
            return Response({
                'data': data,
                'message': shop_resp.UPDATED_SUCCESSFULLY.format("Woocommerce Tag")
            }, status=status.HTTP_200_OK)
        return Response({
            "detail": serializer.errors
        }, status=status.HTTP_400_BAD_REQUEST)

    def delete(self, request):
        tag_id = self.request.query_params.get('tag_id', 1)
        obj = WoocommerceShop()
        wcapi = obj.connect_woocommerce()
        data = obj.delete_tag(wcapi, tag_id)
        return Response({
            'data': data,
            'message': shop_resp.DATA_DELETED_SUCCESSFULLY.format("Tag")
        }, status=status.HTTP_200_OK)


class WooCommerceShippingZonesView(APIView):

    def get(self, request):
        obj = WoocommerceShop()
        wcapi = obj.connect_woocommerce()
        data = obj.list_shipping_zones(wcapi)

        return Response({
            'data': data,
            'message': shop_resp.DATA_FETCHED_SUCCESSFULLY.format("Shipping zones")
        }, status=status.HTTP_200_OK)


class WooCommerceProductsFilterView(APIView):
    permission_classes = [IsAuthenticated, ]
    authentication_classes = [TokenAuthentication, ]

    def get(self, request):
        category_id = self.request.query_params.get('category_id', 136)
        obj = WoocommerceShop()
        wcapi = obj.connect_woocommerce()
        if category_id is not None and category_id != '':
            data = obj.filter(wcapi, category_id)
            for each in data:
                try:
                    card = Cart.objects.get(user=request.user, product=each['id'])
                    each['cart'] = {
                        'product_id': each['id'],
                        'price': each['price'],
                        'quantity': card.quantity,
                        'type': card.type,

                    }
                except:
                    each['cart'] = {
                        'product_id': each['id'],
                        'price': each['price'],
                        'quantity': 0,
                        'type': '',

                    }

                    pass
            return Response({
                'data': data,
                'message': shop_resp.DATA_FETCHED_SUCCESSFULLY.format("Products")
            }, status=status.HTTP_200_OK)

        return Response({
            'data': [],
            'message': "Invalid Parameters."
        }, status=status.HTTP_400_BAD_REQUEST)

class SearchOrdersView(APIView):
    
    def get(self, request):
        order_id = request.query_params.get('order_id')
        try:
            order = OrderList.objects.get(ids=order_id)
            serialized_data = OrderListSerializer(order).data
        except OrderList.DoesNotExist as e:
            return Response({
                "message":f"Order Id does not Exists - {e}",
            }, status=status.HTTP_400_BAD_REQUEST)

        return Response({
            "message":"success",
            "data":serialized_data,
        }, status=status.HTTP_200_OK)

class WooCommerceOrdersView(APIView):

    def get(self, request):
        page = self.request.query_params.get('page', 1)
        order_id = self.request.query_params.get('order_id')

        obj = WoocommerceShop()
        wcapi = obj.connect_woocommerce()
        if page == str(page):
            data = obj.list_orders(wcapi, page)
        elif order_id is not None and order_id != "":
            data = obj.retrieve_orders(wcapi, order_id)

        if isinstance(data, list):
            for order in data:
                if 'total' in order:
                    total = float(order.get('total', 0))
                    billing_country = order.get('billing', {}).get('country', '')
                    if billing_country == 'United Kingdom':
                        total_tax = total * 0.20  # Apply 20% tax
                        order['total_tax'] = f"{total_tax:.2f}"
                    else:
                        order['total_tax'] = '0.00'
                wo_order_id = order.get('id')
                try:
                    order_instance = OrderList.objects.get(wo_order_id=wo_order_id)
                    order['number'] = order_instance.ids  # Replace 'number' with 'ids' from OrderList
                except OrderList.DoesNotExist:
                    order['number'] = wo_order_id
        elif isinstance(data, dict):
            if 'total' in data:
                total = float(data.get('total', 0))
                billing_country = data.get('billing', {}).get('country', '')
                if billing_country == 'United Kingdom':
                    total_tax = total * 0.20  # Apply 20% tax
                    data['total_tax'] = f"{total_tax:.2f}"
                else:
                    data['total_tax'] = '0.00'
                wo_order_id = data.get('id')
                try:
                    order_instance = OrderList.objects.get(wo_order_id=wo_order_id)
                    data['number'] = order_instance.ids  # Replace 'number' with 'ids' from OrderList
                except OrderList.DoesNotExist:
                    data['number'] = wo_order_id

        return Response({
            'data': data,
            'message': shop_resp.DATA_FETCHED_SUCCESSFULLY.format("orders")
        }, status=status.HTTP_200_OK)


class CreateOrder(APIView):
    permission_classes = [IsAuthenticated, ]
    authentication_classes = [TokenAuthentication, ]

    @swagger_auto_schema(request_body=checkout_schema)
    def post(self, request):
        params = request.data
        logger.info(f"params order list : {params}")
        data = {}
        params['set_paid'] = False
        line_items = []
        total_tunning_credit = 0
        file_credit = 0
        function_credit = 0
        evc_credit = 0
        cart_total_tax = 0
        order_tax_with_product = {}
        tax_rate_id = 1
        if request.user.address_user.country == "United Kingdom":
            apply_vat = True
        else:
            apply_vat = False
        cart_item = request.user.cart.all()
        logger.info(f"cart_items == {cart_item}")

        for each in request.user.cart.all():
            item_tax_total = each.vat
            if 174 in each.category_list:
                logger.info("inside 174 -------")
                evc_credit += each.quantity * each.tunning_credit
                category_id = 174
            elif 175 in each.category_list:
                logger.info("inside 175 -------")
                file_credit += each.quantity * each.tunning_credit
                category_id = 175
            elif 176 in each.category_list:
                logger.info("inside 176 -------")
                function_credit += each.quantity * each.tunning_credit
                category_id = 176
            # For Reseller
            elif 177 in each.category_list:
                logger.info("inside 177 -------")
                file_credit += each.quantity * each.tunning_credit
                category_id = 177
            elif 178 in each.category_list:
                logger.info("inside 178 -------")
                function_credit += each.quantity * each.tunning_credit
                category_id = 178
            '''
            if each.type == 'file_credit':
                file_credit += each.quantity * each.tunning_credit
                category_id = 175
            elif each.type == 'function_credit':
                function_credit += each.quantity * each.tunning_credit
                category_id = 176
            elif each.type == 'evc_credit':
                evc_credit += each.quantity * each.tunning_credit
                category_id = 174
            '''
            line_item = {
                "product_id": each.product,
                "quantity": each.quantity,
                "taxes": []
            }
            if apply_vat:
                line_item['taxes'] = [{
                    "id": tax_rate_id,
                    "total": f"{item_tax_total:.2f}",
                    "subtotal": f"{item_tax_total:.2f}"
                }]
            cart_total_tax += each.vat
            order_tax_with_product[each.product] = each.vat
            line_items.append(line_item)
            total_tunning_credit += each.tunning_credit

        address = request.user.address_user
        shipping_and_billing_address = {'country': address.country if address.country else '',
                                        'state': address.state if address.state else '',
                                        'city': address.city if address.city else '',
                                        'postcode': address.zip if address.zip else '',
                                        'address_1': address.address if address.address else '',
                                        'address_2': address.address_2 if address.address_2 else '',
                                        'first_name': request.user.first_name, 'last_name': request.user.last_name,
                                        'email': request.user.email}

        data['line_items'] = line_items
        data['shipping'] = shipping_and_billing_address
        data['billing'] = shipping_and_billing_address
        if apply_vat:
            data['tax_lines'] = [
                {
                    "rate_code": "UK VAT",
                    "rate_id": tax_rate_id,
                    "label": "UK VAT",
                    "compound": False,
                    "tax_total": f"{cart_total_tax:.2f}"
                }
            ]
        else:
            data['tax_lines'] = []
        order = create_order(data)

        order_instance = OrderList.objects.create(
            user=request.user,
            checkout_data=order,
            wo_order_id=order['id'],
            file_credit=file_credit,
            function_credit=function_credit,
            evc_credit=evc_credit,
            category_id=category_id
        )
        logger.info(f"order_instance == {order_instance}")
        total_price = 0
        for each in order['line_items']:
            logger.info(f"EACH == {each}")
            total_price += float(each['total'])
            item = request.user.cart.get(product=each['product_id'])
            logger.info(f"item == {item}")
            key_credit = 0

            if 174 in item.category_list:
                logger.info("inside 174 -------")
                key_credit += item.quantity * item.tunning_credit
                category_id = 174
            elif 175 in item.category_list:
                logger.info("inside 175 -------")
                key_credit += item.quantity * item.tunning_credit
                category_id = 175
            elif 176 in item.category_list:
                logger.info("inside 176 -------")
                key_credit += item.quantity * item.tunning_credit
                category_id = 176
            # For Reseller
            elif 177 in item.category_list:
                logger.info("inside 177 -------")
                key_credit += item.quantity * item.tunning_credit
                category_id = 177
            elif 178 in item.category_list:
                logger.info("inside 178 -------")
                key_credit += item.quantity * item.tunning_credit
                category_id = 178
            '''
            if item.type == 'file_credit':
                key_credit += item.quantity * item.tunning_credit
                category_id = 175
            elif item.type == 'function_credit':
                key_credit += item.quantity * item.tunning_credit
                category_id = 176
            elif item.type == 'evc_credit':
                key_credit += item.quantity * item.tunning_credit
                category_id = 174
            '''
            order_item = OrderItem.objects.create(
                order_list=order_instance,
                user=request.user,
                product=each['product_id'],
                quantity=each['quantity'],
                price=each['price'],
                product_name=each['name'],
                product_image=each['image']['src'] if 'image' in each else '',
                is_dealer_credit=item.is_dealer_credit,
                dealer_credit_type=item.dealer_credit_type,
                tunning_credit=key_credit,
                category_id=category_id
            )
            logger.info(f"order_item == {order_item}")
            for key, values in order_tax_with_product.items():
                if key == int(order_item.product):
                    order_item.vat = values
                    order_item.save()

        order_instance.total_price = total_price
        order_instance.tax_price = cart_total_tax
        order_instance.update_ids()
        order_instance.save()
        chekout_id = Payment().checkout_session(
            params['success_url'],
            params['cancel_url'],
            order_instance,
            data['billing']
        )
        order_instance.stripe_id = chekout_id['id']
        order_instance.save()
        request.user.cart.all().delete()
        logger.info(f"payment url : {chekout_id['url']}")
        return Response({
            'payment_url': chekout_id['url'],
            'message': shop_resp.CREATED_SUCCESSFULLY.format("order")
        }, status=status.HTTP_200_OK)


class StripeWebhookView(APIView):

    def post(self, request):
        old_file_key_credit=0
        old_function_key_credit=0
        old_evc_key_credit=0

        params = request.data
        logger.info(f"web hook params : {params}")
        checkout_session_id = params['data']['object']['id']
        logger.info(f"checkout_session_id == {checkout_session_id}")
        # checkout_session_id = "cs_test_a1e9erncL0Zs7e2lhurZbSlutOBESE9NJXxAVCOcfrY9kKt9VANPwDFlAs"
        try:
            order_list = OrderList.objects.get(stripe_id=checkout_session_id)
            logger.info(f"order_list == {order_list.ids}")
        except Exception as e:
            print(e)
            return Response({
                "detail": "ok"
            })
        dealer_file_key, dealer_function_key, dealer_evc_key = 0, 0, 0
        customer_file_key, customer_function_key, customer_evc_key = 0, 0, 0
        is_dealer_credit_available, is_customer_credit_available = False, False
        
        all_items = order_list.order_item.all()
        logger.info(f"All order list item == {all_items}")

        for each in order_list.order_item.all():
            # dealer credit
            if each.is_dealer_credit:
                logger.info(f"if ------------- ")
                if each.category_id==177:
                    dealer_file_key += each.tunning_credit
                elif each.category_id==178:
                    dealer_function_key += each.tunning_credit
                elif each.category_id==175:
                    dealer_file_key += each.tunning_credit
                elif each.category_id==176:
                    dealer_function_key += each.tunning_credit
                '''
                # old code:
                if each.dealer_credit_type == 1:
                    dealer_file_key += each.tunning_credit
                elif each.dealer_credit_type == 2:
                    dealer_function_key += each.tunning_credit
                # elif each.dealer_credit_type == 3 and order_list.file_credit:
                #     dealer_file_key += each.tunning_credit
                else:
                    dealer_evc_key += each.tunning_credit
                '''
                is_dealer_credit_available = True
            else:
                logger.info("Else ------------- ")
                if each.category_id==174:
                    customer_evc_key += each.tunning_credit
                if each.category_id==175:
                    customer_file_key += each.tunning_credit
                if each.category_id==176:
                    customer_function_key += each.tunning_credit
                '''
                #old code:
                if each.dealer_credit_type == 1:
                    customer_file_key += each.tunning_credit
                elif each.dealer_credit_type == 2:
                    customer_function_key += each.tunning_credit
                # elif each.dealer_credit_type == 3 and order_list.file_credit:
                #     customer_file_key += each.tunning_credit
                else:
                    customer_evc_key += each.tunning_credit
                '''
                is_customer_credit_available = True
        if is_customer_credit_available:
            logger.info("---------Customer credits----------")
            logger.info(f"customer_file_key = {customer_file_key}")
            logger.info(f"customer_function_key = {customer_function_key}")
            logger.info(f"customer_evc_key = {customer_evc_key}")
            logger.info("----------------------------")

        if is_dealer_credit_available:
            logger.info("---------Customer credits----------")
            logger.info(f"dealer_file_key = {dealer_file_key}")
            logger.info(f"dealer_function_key = {dealer_function_key}")
            logger.info(f"dealer_evc_key = {dealer_evc_key}")
            logger.info("----------------------------")

        checkout_status = params['type']
        evc_cred = EVCCredentials.objects.all().first()
        # try:
        #     order_list.payment_method = params['data']['object']['payment_method_types'][0]
        # except:
        #     pass

        user_credit, dealer_credit = None, None
        if is_customer_credit_available:
            user_credit, _ = CustomerCredit.objects.get_or_create(
                user=order_list.user
            )
        if is_dealer_credit_available:
            dealer_credit, _ = ResellerDistributeCredit.objects.get_or_create(
                user=order_list.user
            )
        if checkout_status in ['checkout.session.async_payment_failed', 'checkout.session.expired']:
            order_list.status = 3
            order_list.save()
        elif checkout_status in ['checkout.session.async_payment_succeeded', 'checkout.session.completed']:
            update_order(order_list.wo_order_id)
            order_list.status = 2
            if order_list.is_credit_added is not True:
                if is_customer_credit_available:
                    logger.info(f"is_customer_credit_available --- {is_customer_credit_available}")
                    old_file_key_credit = user_credit.file_key_credit
                    old_function_key_credit = user_credit.function_credit
                    old_evc_key_credit = user_credit.evc_credit

                    user_credit.file_key_credit += customer_file_key
                    user_credit.function_credit += customer_function_key
                    user_credit.evc_credit += customer_evc_key
                    user_credit.save()

                    new_file_key_credit = user_credit.file_key_credit
                    new_function_key_credit = user_credit.function_credit
                    new_evc_key_credit = user_credit.evc_credit
                    order_list.is_credit_added=True

                    old_details={
                        "file_key_credit":old_file_key_credit,
                        "function_key_credit":old_function_key_credit,
                        "evc_key_credit":old_evc_key_credit
                    }
                    new_details={
                        "file_key_credit":new_file_key_credit,
                        "function_key_credit":new_function_key_credit,
                        "evc_key_credit":new_evc_key_credit
                    }

                if is_dealer_credit_available:
                    logger.info(f"is_dealer_credit_available ----- {is_dealer_credit_available}")
                    old_file_key_credit = dealer_credit.file_key_credit
                    old_function_key_credit = dealer_credit.function_credit
                    old_evc_key_credit = dealer_credit.evc_credit

                    dealer_credit.file_key_credit += dealer_file_key
                    dealer_credit.function_credit += dealer_function_key
                    dealer_credit.evc_credit += dealer_evc_key
                    dealer_credit.save()

                    new_file_key_credit = dealer_credit.file_key_credit
                    new_function_key_credit = dealer_credit.function_credit
                    new_evc_key_credit = dealer_credit.evc_credit
                    order_list.is_credit_added=True
                    
                    old_details={
                        "file_key_credit":old_file_key_credit,
                        "function_key_credit":old_function_key_credit,
                        "evc_key_credit":old_evc_key_credit
                    }
                    new_details={
                        "file_key_credit":new_file_key_credit,
                        "function_key_credit":new_function_key_credit,
                        "evc_key_credit":new_evc_key_credit
                    }
            order_list.save()
            try:
                x_forwarded_for = request.META.get('HTTP_X_FORWARDED_FOR')
                customer_detail = order_list.user.first_name + ' ' + order_list.user.last_name + '(' + order_list.user.email + ')'
                file_key_credit_needed = order_list.file_credit
                function_credit_needed = order_list.function_credit
                evc_credit_needed = order_list.evc_credit
                if order_list.is_logs_added is not True:
                    admin_log = AccessLogsModel.objects.create(
                        user=order_list.user,
                        timestamp=datetime.now(),
                        ip_address=x_forwarded_for.split(',')[0] if x_forwarded_for else request.META.get('REMOTE_ADDR'),
                        method='Update',
                        event='Credit Update while purchasing product',
                        module=EmailLogSettings.objects.filter(module='Customer credit').last(),
                        title='Purchased Credits',
                        # description='File credit: {0}, Function credit: {1} and EVC credit {2} for {3} by {4}.'.format(
                        #     file_key_credit_needed, function_credit_needed, evc_credit_needed,
                        #     customer_detail, customer_detail),
                        # description=f"File Credits updated from {old_file_key_credit} to {new_file_key_credit}, Function Credit updated From {old_function_key_credit} to {new_function_key_credit}, EVC Credit updated from {old_evc_key_credit} to {new_evc_key_credit}",
                        old_details=old_details,
                        new_details=new_details,
                        customer=order_list.user,
                    )
                    admin_log.credit_update_type = "Other"
                    admin_log.save()
                    logger.info(f"Admin logs created == {admin_log}")

                    customer_log = AccessLogsModel.objects.create(
                        user=order_list.user,
                        timestamp=datetime.now(),
                        ip_address=x_forwarded_for.split(',')[0] if x_forwarded_for else request.META.get('REMOTE_ADDR'),
                        method='Update',
                        event='Credit Update while purchasing product',
                        module=EmailLogSettings.objects.filter(module='Customer credit').last(),
                        title='Purchasd Credits',
                        # description='File credit: {0}, Function credit: {1} and EVC credit {2} in your account by {3}.'.format(
                        #     file_key_credit_needed, function_credit_needed, evc_credit_needed, customer_detail),
                        description=f"File Credits updated from {old_file_key_credit} to {new_file_key_credit}, Function Credit updated From {old_function_key_credit} to {new_function_key_credit}, EVC Credit updated from {old_evc_key_credit} to {new_evc_key_credit}",
                        old_details=old_details,
                        new_details=new_details,
                        customer=order_list.user,
                        to_customer_only=True,
                    )
                    customer_log.credit_update_type = "Other"
                    customer_log.save()
                    logger.info(f"customer logs created == {customer_log}")
                    order_list.is_logs_added=True
            except:
                logger.info(f"Logs not created due to something went")

            logger.info(f"{order_list.ids} - Ready to call task create zoho invoice function ----- ")
            task_create_zoho_invoice.delay(str(checkout_session_id))
            # task_create_zoho_invoice(str(checkout_session_id))
            logger.info(f"{order_list.ids} - Purchase mail")
            purchase_mail(order_list.user, order_list)
            logger.info(f"{order_list.ids} - purchase mail has been sent")
            if order_list.evc_credit and evc_cred:
                add_remove_account_balance(evc_cred.apiid, evc_cred.username, evc_cred.password, '33333',
                                           int(order_list.evc_credit))
        order_list.save()
        return Response({
            "detail": "ok"
        })


class CreateStatusView(APIView):
    permission_classes = [IsAuthenticated, ]
    authentication_classes = [TokenAuthentication, ]

    @swagger_auto_schema(request_body=order_status_schema)
    def post(self, request):
        params = request.data
        try:
            instance = OrderList.objects.get(ids=params['ids'])
            return Response({
                'status': instance.get_status_display(),
                # 'credit':request.user.customer_credit.tunning_credit if hasattr(request.user,'customer_credit') else 0,
                'stripe_id': instance.stripe_id,
                'amount': instance.total_price + instance.tax_price,
                'message': "Order Status fatched successfully."
            }, status=status.HTTP_200_OK)
        except Exception as e:
            return Response({
                "detail": e.args[0]
            }, status=status.HTTP_400_BAD_REQUEST)


class WooCommerceTAXRateView(APIView):

    def get(self, request):
        obj = WoocommerceShop()
        wcapi = obj.connect_woocommerce()
        data = obj.get_tax_rate(wcapi)

        return Response({
            'data': data,
            'message': shop_resp.DATA_FETCHED_SUCCESSFULLY.format("Tax rate")
        }, status=status.HTTP_200_OK)


# class WooCommerceProductsFilterView(APIView):
#     permission_classes = [IsAuthenticated,]
#     authentication_classes = [TokenAuthentication, ]

#     def get(self, request):
#         category_id = self.request.query_params.get('category_id', 136)
#         obj = WoocommerceShop()
#         wcapi = obj.connect_woocommerce()
#         if request.user.user_type == 4:
#             data = obj.filter(wcapi, category_id)
#         elif request.user.user_type == 3:
#             file_credit = obj.filter(wcapi, 175)
#             function_credit = obj.filter(wcapi, 176)
#             evc_credit = obj.filter(wcapi, 174)
#             tuning_tool = obj.filter(wcapi, 140)


#         return Response({
#             'data':data,
#             'message':shop_resp.DATA_FETCHED_SUCCESSFULLY.format("Products")
#         }, status=status.HTTP_200_OK)

class ViezuProductsView(APIView):
    permission_classes = [IsAuthenticated, ]
    authentication_classes = [TokenAuthentication, ]

    def get(self, request):
        obj = WoocommerceShop()
        wcapi = obj.connect_woocommerce()
        page = self.request.query_params.get('page', 1)

        # business user
        if request.user.user_type == 3:
            product_category = 180
        # individual user
        elif request.user.user_type == 4:
            product_category = 179
        # reseller user    
        elif request.user.user_type == 6:
            product_category = 181
        elif request.user.user_type == 7:
            product_category = 181

        if request.user.user_type != 7:
            data = obj.filter(wcapi, product_category, page)
        else:
            data = []
        filtered_data = data
        instance = EVCCredentials.objects.all().last()
        is_evc_customer = False
        if instance is not None and hasattr(request.user,
                                            'business_user') and request.user.business_user.win_ols_license_number:
            is_evc_customer = is_evc_customer_exist(instance.apiid, request.user.business_user.win_ols_license_number,
                                                    instance.username, instance.password)
            logger.info("is_evc_customer exists %s", is_evc_customer)
        if not is_evc_customer:
            filtered_data = [item for item in data if "EVC Credit" not in item['name']]
        return Response({
            'data': filtered_data,
            'message': shop_resp.DATA_FETCHED_SUCCESSFULLY.format("Products")
        }, status=status.HTTP_200_OK)
