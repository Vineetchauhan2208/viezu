DATA_FETCHED_SUCCESSFULLY = "{0} fetched successfully."
CREATED_SUCCESSFULLY = "{0} created successfully."
DATA_DELETED_SUCCESSFULLY = "{0} deleted successfully."
UPDATED_SUCCESSFULLY = "{0} updated successfully."
