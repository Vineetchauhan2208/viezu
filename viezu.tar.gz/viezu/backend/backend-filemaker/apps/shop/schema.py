from drf_yasg import openapi


checkout_schema = openapi.Schema(
 title =("Checkout"),
    type=openapi.TYPE_OBJECT,
    properties={
        'billing': openapi.Schema(type=openapi.TYPE_OBJECT, description=('Billing Address'), 
            properties={
                'first_name': openapi.Schema(type=openapi.TYPE_STRING,example="Aftab"),
                'last_name': openapi.Schema(type=openapi.TYPE_STRING,example="Hussain"),
                'address_1': openapi.Schema(type=openapi.TYPE_STRING,example="Okhla Phase 1"),
                'address_2': openapi.Schema(type=openapi.TYPE_STRING,example=""),
                'city': openapi.Schema(type=openapi.TYPE_STRING,example="New Delhi"),
                'state': openapi.Schema(type=openapi.TYPE_STRING,example="New Delhi"),
                'postcode': openapi.Schema(type=openapi.TYPE_STRING,example="110020"),
                'country': openapi.Schema(type=openapi.TYPE_STRING,example="IN"),
                'email': openapi.Schema(type=openapi.TYPE_STRING,example="aftab@gmail.com"),
                'phone': openapi.Schema(type=openapi.TYPE_STRING,example="9685748574"),
            }
        ),
        'shipping': openapi.Schema(type=openapi.TYPE_OBJECT, description=('Shipping Address'), 
            properties={
                'first_name': openapi.Schema(type=openapi.TYPE_STRING,example="Aftab"),
                'last_name': openapi.Schema(type=openapi.TYPE_STRING,example="Hussain"),
                'address_1': openapi.Schema(type=openapi.TYPE_STRING,example="Okhla Phase 1"),
                'address_2': openapi.Schema(type=openapi.TYPE_STRING,example=""),
                'city': openapi.Schema(type=openapi.TYPE_STRING,example="New Delhi"),
                'state': openapi.Schema(type=openapi.TYPE_STRING,example="New Delhi"),
                'postcode': openapi.Schema(type=openapi.TYPE_STRING,example="110020"),
                'country': openapi.Schema(type=openapi.TYPE_STRING,example="IN"),
            }
        ),
        'success_url': openapi.Schema(type=openapi.TYPE_STRING,example="https://www.viezu-files.com/"),
        'cancel_url': openapi.Schema(type=openapi.TYPE_STRING,example="https://www.viezu-files.com/"),
        
    },
)




order_status_schema = openapi.Schema(
 title =("Order Status"),
    type=openapi.TYPE_OBJECT,
    properties={
        'ids': openapi.Schema(type=openapi.TYPE_STRING,example="order Id"),
    },
)
