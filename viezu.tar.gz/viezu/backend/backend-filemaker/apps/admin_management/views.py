import ast
import re

import boto3
from botocore.exceptions import ClientError
from django.core.cache import cache
from django.utils.decorators import method_decorator
from django.views.decorators.cache import cache_page

import apps.utils.directory_utils
from apps.account.serializer import LogedInUserDetailsSerializer
from apps.utils.mailer import file_request_status_change
from rest_framework.response import Response
from rest_framework.filters import SearchFilter
from django_filters import rest_framework as filters
from django.conf import settings
from rest_framework.views import APIView
from rest_framework import status, generics, viewsets

from rest_framework.authentication import TokenAuthentication
from rest_framework.permissions import IsAuthenticated
from django.db.models import Q, Count, IntegerField, When, Case, F
from rest_framework.parsers import FormParser, MultiPartParser
from django.shortcuts import get_object_or_404
from drf_yasg.utils import swagger_auto_schema
from apps.file_request.models import (
    FileRequestFormData, VehicleBrand,
    VehicleControl, VehicleModel,
    VehicleType
)
from apps.utils.decorator import required_fields
from apps.utils.models import ZOHOKnowledgeBaseArticles
from apps.utils.zoho_articles_utils import load_zoho_articles
from apps.account.models import (
    AccessLogsModel, Address, BusinessCustomer,
    IndividualCustomer, MyUser, ResellerAndSubDealer, RolesAndPermissions,
    UserProfile, AlienTechToken, EncodeDecodeFile
)
from apps.customer.models import CustomerCredit

from apps.admin_management.filters import (
    AdminTicketFilter, LogsFilter,
    RoleFilter, TemplateCategoryFilter
)
import apps.admin_management.response_message as resp_msg
from apps.admin_management.serializer import (
    AccessLogsModelSerializers, AdminBusinessRegisterSerializer,
    AdminIndividualRegisterSerializer, AdminProfileSerializers,
    AdminStatusCountSerializer, CreateRoleSerializer, CustomFilterSerializers,
    CustomerSerializers, DealerSerializer, DirectoryModelSerializers, DirectorySerializer,
    EmailLogSettingsSerializers, GetInternalTeamViewSerializer,
    PhoneNumberSerializer, ResellerSerializer, RolesAndPermissionsSerializers,
    TemplateCategorySerializers, TemplateSerializers,
    TicketCategorySerializers, TicketGroupSerializer, TicketNoteSerializers, TicketStatusSerializers,
    VehicleListControlSerializer,
    ViezuProductSerializers, S3FileUploadSerializer, ManageDashboardSerializer,
    UserStatusFilterBackend
)
from django.conf import settings
from django.template.loader import render_to_string

from apps.customer.serializer import TicketHistorySerializer
from apps.utils.helper import SendMail, create_notification, triger_socket
from apps.utils.pagination import SetPagination
from apps.utils.tasks import notify_permission_change, read_s3_files_to_mongo, task_sync_main_dir_bigquery, \
    close_file_slots_task
from apps.admin_management.models import (
    Directory, Template, TemplateCategory, TicketActiveFilter,
    TicketCategory, TicketGroup, TicketHistory, TicketNote,
    TicketStatus, UpdateCloseTicketOpen, ViezuProduct, CustomFilter,
    ManageDashboard, Conversation
)
from apps.account.models import EmailLogSettings
from .constants import USER_TECKET_STATUS, USER_STATUS_MAP, validate_user_ticket, validate_user_is_admin
from .schema import (
    ticket_status_schema,
    ticket_assign_schema, download_s3_schema,
    rename_s3_file_schema, get_sub_dir_schema, ecu_version_schema,
    reseller_schema, update_reseller_schema
)
import apps.utils.directory_utils as directory_utils
from apps.utils.ecode_decode import FileOperation
import string
import random

from ..alientech.models import DecodeFiles

N = 7
from apps.utils.tasks import task_sync_main_dir
from rest_framework import mixins, generics
from datetime import datetime

from django.utils.timezone import now

class CreateRoleView(viewsets.ModelViewSet):
    """ Create and list roles for users view.
    
    Create Internal team roles, only accessible to super-administrator.
    """
    permission_classes = [IsAuthenticated]
    authentication_classes = [TokenAuthentication, ]
    queryset = MyUser.objects.filter(
        Q(user_type=2) |
        Q(user_type=5)
    ).order_by('id')
    serializer_class = CreateRoleSerializer
    pagination_class = SetPagination
    search_fields = ['first_name', 'last_name', 'email', 'roles__name']
    parser_classes = (FormParser, MultiPartParser)
    filter_backends = (filters.DjangoFilterBackend, SearchFilter,)

    # filterset_class = RoleFilter

    def get_queryset(self):
        queryset = super().get_queryset()
        search_query = self.request.query_params.get('search', '')
        if search_query.lower() == 'active':
            queryset = queryset.filter(is_active=True)
        elif search_query.lower() == 'inactive':
            queryset = queryset.filter(is_active=False)
        else:
            # Allow other search fields to work as intended
            search_filter = SearchFilter()
            queryset = search_filter.filter_queryset(self.request, queryset, self)
        return queryset

    def destroy(self, request, *args, **kwargs):
        return Response({
            'message': "This method is not allowed"
        }, status=status.HTTP_405_METHOD_NOT_ALLOWED)

    # @required_fields(field_list=['name','message','category','availability'])
    def create(self, request, *args, **kwargs):
        super(CreateRoleView, self).create(request, *args, **kwargs)
        return Response({"message": resp_msg.CREATED_SUCCESSFULLY.format('Role')})

    def list(self, request, *args, **kwargs):
        field_to_sort = request.query_params.get('field')
        order_in = request.query_params.get('order_in')
        roles = request.query_params.get('roles')

        queryset = self.get_queryset()

        if order_in == 'asc':
            queryset = queryset.order_by(field_to_sort)
        elif order_in == 'dec':
            queryset = queryset.order_by('-' + field_to_sort)
        if roles is not None and roles.isdigit():
            queryset = queryset.filter(roles=roles)

        page = self.request.query_params.get('page', None)
        page_size = self.request.query_params.get('page_size', None)

        if page is None and page_size is None:
            serializer = CreateRoleSerializer(queryset, many=True)
            return Response({
                'data': serializer.data,
                'message': resp_msg.RECORD_FETCHED_SUCCESSFULLY
            }, status=status.HTTP_200_OK)

        page = self.paginate_queryset(queryset)
        if page is not None:
            serializer = CreateRoleSerializer(page, many=True)
            paginated_response = self.get_paginated_response(serializer.data)
            return Response({
                'data': paginated_response.data,
                'message': resp_msg.RECORD_FETCHED_SUCCESSFULLY
            }, status=status.HTTP_200_OK)

    def get_serializer_context(self):
        return {'request': self.request}

    def update(self, request, *args, **kwargs):
        try:
            params = request.data
            user = MyUser.objects.get(id=self.kwargs['pk'])
            serializer = self.get_serializer(user, data=params, partial=True)
            serializer.is_valid(raise_exception=True)
            serializer.save()
            return Response({
                'message': 'Role updated successfully.',
                'profile_image': request.user.image.url if request.user.image else None
            }, status=status.HTTP_200_OK)
        except Exception as error:
            return Response({
                'detail': str(error)
            }, status=status.HTTP_400_BAD_REQUEST)


class DeleteRoleView(APIView):
    permission_classes = [IsAuthenticated]
    authentication_classes = [TokenAuthentication, ]

    def delete(self, request, *args, **kwargs):
        role_id = self.kwargs['id']
        if role_id:
            if MyUser.objects.filter(roles__id=role_id).exists():
                return Response({
                    'message': "Role cannot be deleted as it is associated with users"
                }, status=status.HTTP_200_OK)
            else:
                RolesAndPermissions.objects.filter(id=role_id).delete()
                return Response({
                    'message': "Roles and Permissions deleted successfully"
                }, status=status.HTTP_200_OK)
        return Response({
            'message': "Role ID not provided"
        }, status=status.HTTP_400_BAD_REQUEST)


class CustomerViews(viewsets.ModelViewSet):
    permission_classes = [IsAuthenticated]
    serializer_class = CustomerSerializers
    queryset = MyUser.objects.filter(
        Q(user_type=3) |
        Q(user_type=6) |
        Q(user_type=4) |
        Q(user_type=7)
    ).order_by('-id')
    pagination_class = SetPagination
    search_fields = ['first_name', 'last_name', 'email', 'parent__first_name', 'parent__last_name',
                     'parent__email', 'business_user__bussness_name', 'reseller_sub_dealer__bussness_name']
    filter_backends = (filters.DjangoFilterBackend, SearchFilter)
# 'reseller_sub_dealer__bussness_name'
    # filterset_class = RoleFilter

    def get_queryset(self):
        queryset = super().get_queryset()
        search_query = self.request.query_params.get('search', '')
        if search_query.lower() == 'active':
            queryset = queryset.filter(is_active=True)
        elif search_query.lower() == 'inactive':
            queryset = queryset.filter(is_active=False)
        else:
            # Allow other search fields to work as intended
            search_filter = SearchFilter()
            queryset = search_filter.filter_queryset(self.request, queryset, self)
        return queryset

    def list(self, request, *args, **kwargs):
        field_to_sort = request.query_params.get('field')
        order_in = request.query_params.get('order_in')
        user_type = request.query_params.get('user_type')

        queryset = self.get_queryset()

        if order_in == 'asc':
            queryset = queryset.order_by(field_to_sort)
        elif order_in == 'dec':
            queryset = queryset.order_by('-' + field_to_sort)
        if user_type is not None and user_type.isdigit():
            queryset = queryset.filter(user_type=user_type)

        page = self.paginate_queryset(queryset)
        if page is not None:
            serializer = CustomerSerializers(page, many=True)
            paginated_response = self.get_paginated_response(serializer.data)
            return Response({
                'data': paginated_response.data,
                'message': resp_msg.RECORD_FETCHED_SUCCESSFULLY
            }, status=status.HTTP_200_OK)

        serializer = CustomerSerializers(queryset, many=True)
        return Response({
            'data': serializer.data,
            'message': resp_msg.RECORD_FETCHED_SUCCESSFULLY
        }, status=status.HTTP_200_OK)

    def get_object(self):
        return get_object_or_404(CustomerViews)

    def retrieve(self, request, *args, **kwargs):
        try:
            instance = MyUser.objects.get(uuid=self.kwargs['uuid'])
            return Response({
                "message": resp_msg.RECORD_FETCHED_SUCCESSFULLY,
                "data": CustomerSerializers(instance).data
            })
        except Exception as e:
            return Response({
                'detail': e.args[0]
            }, status=status.HTTP_400_BAD_REQUEST)

    def update(self, request, *args, **kwargs):
        params = request.data
        instance = MyUser.objects.get(uuid=self.kwargs['uuid'])

        if instance.user_type == 3:
            #---
            user = MyUser.objects.get(uuid=self.kwargs['uuid'])
            old_details = {
                "id":user.id,
                "first_name":user.first_name,
                "last_name":user.last_name,
                "email":user.email,
                "phone_no":user.phone_no,
                "is_active":user.is_active,
                "address":user.address_user.address,
                "address_2":user.address_user.address_2,
                "city":user.address_user.city,
                "state":user.address_user.state,
                "country":user.address_user.country,
                "zip":user.address_user.zip,
                "tax_number":user.business_user.tax_number,
                "company_number":user.business_user.company_number,
                "bussness_name":user.business_user.bussness_name,
                "win_ols_license_number":user.business_user.win_ols_license_number
            }
            #---
            country_code = params['business'].get('country_code', '')
            phone_no = params['business'].get('phone_no', '')
            is_phone_exist_another = MyUser.objects.filter(phone_no=phone_no, country_code=country_code).exclude(
                uuid=instance.uuid)
            if len(is_phone_exist_another) > 0:
                return Response({
                    "success": False,
                    "message": "This phone number already exists.",
                })
            serializer = AdminBusinessRegisterSerializer(instance, data=params, context={'request': request},
                                                         partial=True)
            serializer.is_valid(raise_exception=True)
            serializer.save()
            #---
            print()
            new_details = {
                "id":instance.id,
                "first_name":instance.first_name,
                "last_name":instance.last_name,
                "email":instance.email,
                "phone_no":instance.phone_no,
                "is_active":instance.is_active,
                "address":instance.address_user.address,
                "address_2":instance.address_user.address_2,
                "city":instance.address_user.city,
                "state":instance.address_user.state,
                "country":instance.address_user.country,
                "zip":instance.address_user.zip,
                "tax_number":instance.business_user.tax_number,
                "company_number":instance.business_user.company_number,
                "bussness_name":instance.business_user.bussness_name,
                "win_ols_license_number":instance.business_user.win_ols_license_number
            }
            #---
            #--- admin log----
            x_forwarded_for = request.META.get('HTTP_X_FORWARDED_FOR')
            admin_log = AccessLogsModel.objects.create(
                user=request.user,
                timestamp=datetime.now(),
                ip_address=x_forwarded_for.split(',')[0] if x_forwarded_for else request.META.get('REMOTE_ADDR'),
                method='Update',
                event='Bussness Profile updated',
                module=EmailLogSettings.objects.filter(module='Bussness Customer Profile Updated').last(),
                title='Admin Update Bussness Profile',
                # description=f"User profile updated from {old_details} to {new_details}",
                old_details=old_details,
                new_details=new_details,
                customer_id=instance.id,
                to_customer_only=False,
            )
            #--- end admin log----akshay.sharma@foreignerds.com
        elif instance.user_type == 4:
            #---
            user = MyUser.objects.get(uuid=self.kwargs['uuid'])
            old_details = {
                "id":user.id,
                "first_name":user.first_name,
                "last_name":user.last_name,
                "email":user.email,
                "phone_no":user.phone_no,
                "country_code":user.country_code,
                "is_active":user.is_active,
                "address":user.address_user.address,
                "address_2":user.address_user.address_2,
                "city":user.address_user.city,
                "state":user.address_user.state,
                "country":user.address_user.country,
                "zip":user.address_user.zip,
                "product_name":user.individual_user.product_name,
                "tool_serial_number":user.individual_user.tool_serial_number,
            }
            print(f"old details : {old_details}")
            #---
            country_code = params['individual'].get('country_code', '')
            phone_no = params['individual'].get('phone_no', '')
            is_phone_exist_another = MyUser.objects.filter(phone_no=phone_no, country_code=country_code).exclude(
                uuid=instance.uuid)
            if len(is_phone_exist_another) > 0:
                return Response({
                    "success": False,
                    "message": "This phone number already exists.",
                })
            serializer = AdminIndividualRegisterSerializer(instance, data=params, context={'request': request},
                                                           partial=True)
            serializer.is_valid(raise_exception=True)
            serializer.save()
            print()
            #---
            user = MyUser.objects.get(uuid=self.kwargs['uuid'])
            new_details = {
                "id":instance.id,
                "first_name":instance.first_name,
                "last_name":instance.last_name,
                "email":instance.email,
                "phone_no":instance.phone_no,
                "country_code":instance.country_code,
                "is_active":instance.is_active,
                "address":instance.address_user.address,
                "address_2":instance.address_user.address_2,
                "city":instance.address_user.city,
                "state":instance.address_user.state,
                "country":instance.address_user.country,
                "zip":instance.address_user.zip,
                "product_name":instance.individual_user.product_name,
                "tool_serial_number":instance.individual_user.tool_serial_number,
            }
            print(f"New details : {new_details}")
            #---

            #--- admin log----
            x_forwarded_for = request.META.get('HTTP_X_FORWARDED_FOR')
            admin_log = AccessLogsModel.objects.create(
                user=request.user,
                timestamp=datetime.now(),
                ip_address=x_forwarded_for.split(',')[0] if x_forwarded_for else request.META.get('REMOTE_ADDR'),
                method='Update',
                event='Admin Update Individual customer Profile',
                module=EmailLogSettings.objects.filter(module='Bussness Customer Profile Updated').last(),
                title='Admin Update Individual customer Profile',
                description=f"Individual customer Profile Updated by Admin",
                old_details=old_details,
                new_details=new_details,
                customer_id=instance.id,
                to_customer_only=False,
            )
            print(f"Admin log : {admin_log}")
            #----
        # socket code
        serializer = LogedInUserDetailsSerializer(instance).data

        triger_socket({
            'uuid': str(instance.uuid),
            'type': 'user_detail_update',
            'data': serializer
        })

        return Response({
            "success": False,
            "message": "Customer profile updated successfully.",
        })


class ProfileView(generics.CreateAPIView):
    permission_classes = [IsAuthenticated]
    authentication_classes = [TokenAuthentication, ]
    parser_classes = (FormParser, MultiPartParser)
    queryset = MyUser.objects.all().order_by('id')
    serializer_class = AdminProfileSerializers

    def get_serializer_context(self):
        return {'request': self.request}

    def post(self, request, *args, **kwargs):
        params = request.data
        serializer = self.get_serializer(request.user,
                                         data=params, context={'request': request},
                                         partial=True)
        serializer.is_valid(raise_exception=True)
        serializer.save()
        return Response({
            'image': request.user.image.url if request.user.image else None,
            'message': 'Profile updated successfully.',
        }, status=status.HTTP_200_OK)


class RolesAndPermissionsViews(viewsets.ModelViewSet):
    """Role and permission module viewsets. """
    permission_classes = [IsAuthenticated]
    serializer_class = RolesAndPermissionsSerializers
    queryset = RolesAndPermissions.objects.all()
    pagination_class = SetPagination

    def create(self, request, *args, **kwargs):
        super(RolesAndPermissionsViews, self).create(request, *args, **kwargs)
        return Response({"message": resp_msg.CREATED_SUCCESSFULLY.format('Roles and Permissions')})

    def list(self, request, *args, **kwargs):
        results = super(RolesAndPermissionsViews, self).list(request, *args, **kwargs)
        return Response({
            'data': results.data,
            'message': resp_msg.RECORD_FETCHED_SUCCESSFULLY
        }, status=status.HTTP_200_OK)

    def get_object(self):
        return get_object_or_404(RolesAndPermissions, id=self.kwargs['pk'])

    def destroy(self, request, *args, **kwargs):
        RolesAndPermissions.objects.filter(id=self.kwargs['pk']).delete()
        return Response({
            'message': "Roles and Permissions deleted successfully"
        }, status=status.HTTP_200_OK)

    def retrieve(self, request, *args, **kwargs):
        try:
            instance = RolesAndPermissions.objects.get(id=self.kwargs['pk'])

            return Response({
                "message": resp_msg.RECORD_FETCHED_SUCCESSFULLY,
                "data": RolesAndPermissionsSerializers(instance).data
            })
        except Exception as e:
            return Response({
                'detail': e.args[0]
            }, status=status.HTTP_400_BAD_REQUEST)

    def update(self, request, *args, **kwargs):

        notify_permission_change.delay(self.kwargs['pk'])
        super(RolesAndPermissionsViews, self).update(request, *args, **kwargs)
        return Response({
            "message": 'Role and Permissions updated successfully',
        })


class ViezuProductView(viewsets.ModelViewSet):
    queryset = ViezuProduct.objects.all().order_by('-id')
    serializer_class = ViezuProductSerializers
    pagination_class = SetPagination
    search_fields = ['product_name', ]
    filter_backends = (filters.DjangoFilterBackend, SearchFilter,)

    def list(self, request, *args, **kwargs):
        results = super(ViezuProductView, self).list(request, *args, **kwargs)
        return Response({
            'data': results.data,
            'message': resp_msg.RECORD_FETCHED_SUCCESSFULLY
        }, status=status.HTTP_200_OK)

    def create(self, request, *args, **kwargs):
        params = request.data
        if ViezuProduct.objects.filter(product_name=params['product_name']).exists():
            return Response({
                "detail": resp_msg.PRODUCT_ALREADY_EXISTS
            }, status=status.HTTP_400_BAD_REQUEST)
        serializer = self.get_serializer(data=params, context={'request': request})
        serializer.is_valid(raise_exception=True)
        serializer.save()
        return Response({"message": "Product created successfully"})

    def update(self, request, *args, **kwargs):
        params = request.data
        instance = ViezuProduct.objects.get(id=self.kwargs['pk'])
        if instance.product_name == params['product_name']:
            return Response({
                "message": resp_msg.UPDATED_SUCCESSFULLY.format("Product")
            })
        elif ViezuProduct.objects.filter(product_name=params['product_name']).exists():
            return Response({
                "detail": resp_msg.PRODUCT_ALREADY_EXISTS
            }, status=status.HTTP_400_BAD_REQUEST)
        serializer = self.get_serializer(instance, data=params, context={'request': request}, partial=True)
        serializer.is_valid(raise_exception=True)
        serializer.save()
        return Response({"message": resp_msg.UPDATED_SUCCESSFULLY.format("Product")})

    def destroy(self, request, *args, **kwargs):
        ViezuProduct.objects.filter(id=self.kwargs['pk']).delete()
        return Response({"message": resp_msg.DELETED_SUCCESSFULLY.format("Product")})


class TicketStatusView(viewsets.ModelViewSet):
    permission_classes = [IsAuthenticated]
    authentication_classes = [TokenAuthentication, ]
    queryset = TicketStatus.objects.all().order_by('-id')
    serializer_class = TicketStatusSerializers
    pagination_class = SetPagination
    filter_backends = (UserStatusFilterBackend,)

    def list(self, request, *args, **kwargs):
        results = super(TicketStatusView, self).list(request, *args, **kwargs)
        return Response({
            'data': results.data,
            'message': resp_msg.RECORD_FETCHED_SUCCESSFULLY
        }, status=status.HTTP_200_OK)

    def create(self, request, *args, **kwargs):
        params = request.data
        if TicketStatus.objects.filter(team_status=params['team_status']).exists():
            return Response({
                "detail": "Ticket Status already exist"
            }, status=status.HTTP_400_BAD_REQUEST)
        serializer = self.get_serializer(data=params, context={'request': request})
        serializer.is_valid(raise_exception=True)
        serializer.save()
        return Response({"message": resp_msg.CREATED_SUCCESSFULLY.format("Ticket status")})

    def update(self, request, *args, **kwargs):
        params = request.data
        instance = TicketStatus.objects.get(id=self.kwargs['pk'])
        if instance.team_status == params['team_status']:
            instance.user_status = params['user_status']
            instance.save()
            return Response({
                "message": resp_msg.UPDATED_SUCCESSFULLY.format("Ticket status")
            })
        elif TicketStatus.objects.filter(team_status=params['team_status']).exists():
            return Response({
                "detail": "Ticket Status already exist"
            }, status=status.HTTP_400_BAD_REQUEST)
        serializer = self.get_serializer(instance, data=params,
                                         context={'request': request}, partial=True)
        serializer.is_valid(raise_exception=True)
        serializer.save()
        return Response({"message": resp_msg.UPDATED_SUCCESSFULLY.format("Ticket status")})

    def destroy(self, request, *args, **kwargs):
        TicketStatus.objects.filter(id=self.kwargs['pk']).delete()
        return Response({"message": resp_msg.DELETED_SUCCESSFULLY.format("Ticket status")})


class TemplateCategoryView(viewsets.ModelViewSet):
    permission_classes = [IsAuthenticated]
    authentication_classes = [TokenAuthentication, ]
    queryset = TemplateCategory.objects.all().order_by('-id')
    serializer_class = TemplateCategorySerializers
    pagination_class = SetPagination
    search_fields = ['name', ]
    filter_backends = (filters.DjangoFilterBackend, SearchFilter,)

    def list(self, request, *args, **kwargs):
        results = super(TemplateCategoryView, self).list(request, *args, **kwargs)
        return Response({
            'data': results.data,
            'message': resp_msg.RECORD_FETCHED_SUCCESSFULLY
        }, status=status.HTTP_200_OK)

    def create(self, request, *args, **kwargs):
        params = request.data
        if TemplateCategory.objects.filter(name=params['name']).exists():
            return Response({
                "detail": "Category already exist"
            }, status=status.HTTP_400_BAD_REQUEST)
        serializer = self.get_serializer(data=params, context={'request': request})
        serializer.is_valid(raise_exception=True)
        serializer.save()
        return Response({"message": resp_msg.CREATED_SUCCESSFULLY.format("Template category")})

    def update(self, request, *args, **kwargs):
        params = request.data
        instance = TemplateCategory.objects.get(id=self.kwargs['pk'])
        if instance.name == params['name']:
            return Response({
                "message": resp_msg.UPDATED_SUCCESSFULLY.format("Template category")
            })
        elif TemplateCategory.objects.filter(name=params['name']).exists():
            return Response({
                "detail": "Template Category already exist"
            }, status=status.HTTP_400_BAD_REQUEST)
        serializer = self.get_serializer(instance, data=params, context={'request': request}, partial=True)
        serializer.is_valid(raise_exception=True)
        serializer.save()
        return Response({"message": "Template Category updated successfully"})

    def destroy(self, request, *args, **kwargs):
        TemplateCategory.objects.filter(id=self.kwargs['pk']).delete()
        return Response({"message": resp_msg.DELETED_SUCCESSFULLY.format("Template category")})


class TicketCategoryView(viewsets.ModelViewSet):
    permission_classes = [IsAuthenticated]
    authentication_classes = [TokenAuthentication, ]
    queryset = TicketCategory.objects.all()
    serializer_class = TicketCategorySerializers
    pagination_class = SetPagination
    search_fields = ['name', ]
    filter_backends = (filters.DjangoFilterBackend, SearchFilter,)

    def list(self, request, *args, **kwargs):
        results = super(TicketCategoryView, self).list(request, *args, **kwargs)
        return Response({
            'data': results.data,
            'message': resp_msg.RECORD_FETCHED_SUCCESSFULLY
        }, status=status.HTTP_200_OK)

    def create(self, request, *args, **kwargs):
        params = request.data
        if TicketCategory.objects.filter(name=params['name']).exists():
            return Response({
                "detail": "Ticket Category already exist"
            }, status=status.HTTP_400_BAD_REQUEST)
        serializer = self.get_serializer(data=params, context={'request': request})
        serializer.is_valid(raise_exception=True)
        serializer.save()
        return Response({"message": resp_msg.CREATED_SUCCESSFULLY.format("Ticket category")})

    def update(self, request, *args, **kwargs):
        params = request.data
        instance = TicketCategory.objects.get(id=self.kwargs['pk'])
        if instance.name == params['name']:
            return Response({
                "message": resp_msg.UPDATED_SUCCESSFULLY.format("Ticket category")
            })
        elif TicketCategory.objects.filter(name=params['name']).exists():
            return Response({
                "detail": "Ticket Category already exist"
            }, status=status.HTTP_400_BAD_REQUEST)
        serializer = self.get_serializer(instance, data=params,
                                         context={'request': request}, partial=True)
        serializer.is_valid(raise_exception=True)
        serializer.save()
        return Response({"message": resp_msg.UPDATED_SUCCESSFULLY.format("Ticket category")})

    def destroy(self, request, *args, **kwargs):
        TicketCategory.objects.filter(id=self.kwargs['pk']).delete()
        return Response({"message": resp_msg.DELETED_SUCCESSFULLY.format("Ticket category")})


class TemplateView(viewsets.ModelViewSet):
    permission_classes = [IsAuthenticated]
    authentication_classes = [TokenAuthentication, ]
    queryset = Template.objects.all().order_by('-id')
    serializer_class = TemplateSerializers
    pagination_class = SetPagination
    search_fields = ['subject', 'ids']
    filter_backends = (filters.DjangoFilterBackend, SearchFilter,)
    filterset_class = TemplateCategoryFilter

    def list(self, request, *args, **kwargs):

        field_to_sort = request.query_params.get('field')
        order_in = request.query_params.get('order_in')

        if order_in == 'asc':
            order_by_str = field_to_sort
        elif order_in == 'dec':
            order_by_str = '-' + field_to_sort
        else:
            order_by_str = ''

        if field_to_sort is not None and order_by_str is not None:
            queryset = self.get_queryset().order_by(order_by_str)
            serializer = TemplateSerializers(queryset, many=True)
            page = self.paginate_queryset(serializer.data)
            data = dict(self.get_paginated_response(page).data)
        else:
            data = super(TemplateView, self).list(request, *args, **kwargs).data

        return Response({
            'data': data,
            'message': resp_msg.RECORD_FETCHED_SUCCESSFULLY
        }, status=status.HTTP_200_OK)

    def create(self, request, *args, **kwargs):
        params = request.data
        # if Template.objects.filter(template_type = params['template_type']).exists():
        #     return Response({
        #         "detail":"This Template Category is already exist."
        #     },status=status.HTTP_400_BAD_REQUEST)
        serializer = self.get_serializer(data=params, context={'request': request})
        serializer.is_valid(raise_exception=True)
        template = serializer.save()
        template.update_ids()
        return Response({"message": resp_msg.CREATED_SUCCESSFULLY.format("Template")})

    def update(self, request, *args, **kwargs):
        params = request.data
        instance = Template.objects.get(id=self.kwargs['pk'])
        if instance.template_type == params['template_type']:
            instance.body = params['body']
            instance.subject = params['subject']
            instance.save()
            return Response({
                "message": resp_msg.UPDATED_SUCCESSFULLY.format("Template")
            })
        elif Template.objects.filter(template_type=params['template_type']).exists():
            return Response({
                "detail": "This Template Category is already exist."
            }, status=status.HTTP_400_BAD_REQUEST)
        serializer = self.get_serializer(instance, data=params, context={'request': request}, partial=True)
        serializer.is_valid(raise_exception=True)
        serializer.save()
        return Response({"message": resp_msg.UPDATED_SUCCESSFULLY.format("Template")})

    def destroy(self, request, *args, **kwargs):
        Template.objects.filter(id=self.kwargs['pk']).delete()
        return Response({"message": resp_msg.DELETED_SUCCESSFULLY.format("Template")})


class TemplateShareView(APIView):
    permission_classes = [IsAuthenticated]
    authentication_classes = [TokenAuthentication, ]
    queryset = Template.objects.all().order_by('-id')
    serializer_class = TemplateSerializers

    def get_status(self, status_number):

        USER_TECKET_STATUS = {1: 'Pending', 2: 'On Hold', 3: 'Closed',
                              4: 'In progress', 5: 'New', 6: 'Pending reply', 7: 'In Development',
                              8: 'Escalated', 9: 'Awaiting feedback', 10: 'ECU Booked in'}

        if status_number == "":
            status_number = 5
        if status_number is None:
            status_number = 5

        if status_number != "" and status_number is not None:
            status_number = int(status_number)
        status = USER_TECKET_STATUS.get(int(status_number), '')
        return status

    def replace_content(self, ticket_data, template_body):

        template_body = template_body.replace("{{ticket_status}}", self.get_status(ticket_data.get('ticket_status')))
        template_body = template_body.replace("{{ticket_subject}}", ticket_data.get('ticket_subject'))
        template_body = template_body.replace("{{ticket_id}}", ticket_data.get('ticket_id'))
        template_body = template_body.replace("{{ticket_customer_name}}", ticket_data.get('ticket_customer_name'))

        return template_body

    def get(self, request, *args, **kwargs):
        params = self.request.query_params
        template_id = params['template_id']
        ticket_id = params['ticket_id']

        template = Template.objects.get(ids=template_id)
        template_body = template.body
        ticket = TicketHistory.objects.get(ids=ticket_id)

        ticket_data = {}
        ticket_data['ticket_status'] = ticket.ticket_status.user_status if ticket.ticket_status else None
        ticket_data['ticket_subject'] = ticket.subject
        ticket_data['ticket_id'] = ticket.ids
        ticket_data['ticket_customer_name'] = ticket.created_by.first_name + ' ' + ticket.created_by.last_name
        ticket_data = {k: v or '' for (k, v) in ticket_data.items()}

        template_body = self.replace_content(ticket_data, template_body)

        return Response({
            'data': template_body,
            'message': resp_msg.RECORD_FETCHED_SUCCESSFULLY
        }, status=status.HTTP_200_OK)

class CustomerLogsViews(viewsets.ModelViewSet):
    permission_classes = [IsAuthenticated]
    serializer_class = RolesAndPermissionsSerializers
    serializer_class = AccessLogsModelSerializers
    pagination_class = SetPagination

    def timeline(self,request, *args, **kwargs):
        try:
            object = MyUser.objects.get(uuid=self.kwargs['uuid'])
        except:
            return Response({
            'message': 'Invalid User id'
        }, status=status.HTTP_400_BAD_REQUEST)
        queryset = AccessLogsModel.objects.filter(to_customer_only=False,customer_id=object.id).order_by('-sys_id')
        page = self.paginate_queryset(queryset)
        if page is not None:
            serializer = self.get_serializer(page, many=True)
            paginated_response = self.get_paginated_response(serializer.data)
            return Response({
                'data': paginated_response.data,
                'message': resp_msg.RECORD_FETCHED_SUCCESSFULLY
            }, status=status.HTTP_200_OK)
        serializer = self.get_serializer(queryset, many=True)
        return Response({
            'data': serializer.data,
            'message': resp_msg.RECORD_FETCHED_SUCCESSFULLY
        }, status=status.HTTP_200_OK)
    
class LogsListView(generics.ListAPIView):
    permission_classes = [IsAuthenticated, ]
    authentication_classes = [TokenAuthentication, ]
    queryset = AccessLogsModel.objects.filter(to_customer_only=False).exclude(title__isnull=True).order_by('-sys_id')
    serializer_class = AccessLogsModelSerializers
    pagination_class = SetPagination
    search_fields = ['sys_id', 'user__first_name', 'user__last_name',
                     'user__email', 'module__module', 'description', 'title', 'credit_update_type'
        , 'credit_update_description', 'event', 'file_request']
    filter_backends = (filters.DjangoFilterBackend, SearchFilter,)
    filterset_class = LogsFilter

    def get_queryset(self):
        queryset = super().get_queryset()
        search_filter = SearchFilter()
        queryset = search_filter.filter_queryset(self.request, queryset, self)
        return queryset

    def list(self, request, *args, **kwargs):
        from_date = request.query_params.get('from_date')
        to_date = request.query_params.get('to_date')
        field_to_sort = request.query_params.get('field')
        order_in = request.query_params.get('order_in')

        if from_date and to_date:
            from_date = from_date + ' 00:00:00'
            to_date = to_date + ' 23:59:59'
            from_date = datetime.strptime(from_date, '%Y-%m-%d %H:%M:%S')
            to_date = datetime.strptime(to_date, '%Y-%m-%d %H:%M:%S')
            queryset = self.get_queryset().filter(timestamp__gte=from_date, timestamp__lte=to_date)
        else:
            queryset = self.get_queryset()
        if field_to_sort and order_in:
            if order_in == 'asc':
                order_by_str = field_to_sort
                queryset = queryset.order_by(order_by_str)
            elif order_in == 'dec':
                order_by_str = '-' + field_to_sort
                queryset = queryset.order_by(order_by_str)
        page = self.paginate_queryset(queryset)
        print(f"page == {page}")
        if page is not None:
            serializer = self.get_serializer(page, many=True)
            paginated_response = self.get_paginated_response(serializer.data)
            return Response({
                'data': paginated_response.data,
                'message': resp_msg.RECORD_FETCHED_SUCCESSFULLY
            }, status=status.HTTP_200_OK)

        serializer = self.get_serializer(queryset, many=True)
        return Response({
            'data': serializer.data,
            'message': resp_msg.RECORD_FETCHED_SUCCESSFULLY
        }, status=status.HTTP_200_OK)


class LogsDownloadListView(generics.ListAPIView):
    permission_classes = [IsAuthenticated, ]
    authentication_classes = [TokenAuthentication, ]
    queryset = AccessLogsModel.objects.all().order_by('-sys_id')
    serializer_class = AccessLogsModelSerializers
    filterset_class = LogsFilter

    def list(self, request, *args, **kwargs):
        params = self.request.query_params
        from_date = params['from_date'] + ' 00:00:00'
        to_date = params['to_date'] + ' 23:59:59'

        from_date = datetime.strptime(from_date, '%Y-%m-%d %H:%M:%S')
        to_date = datetime.strptime(to_date, '%Y-%m-%d %H:%M:%S')
        queryset = AccessLogsModel.objects.filter(
            created_at__gte=from_date, created_at__lte=to_date
        ).exclude(title__isnull=True).order_by('-sys_id')
        serializer = self.serializer_class(queryset, many=True)
        return Response({
            'data': serializer.data,
            'message': resp_msg.RECORD_FETCHED_SUCCESSFULLY
        }, status=status.HTTP_200_OK)


class GetUsersByRoleView(generics.ListAPIView):
    permission_classes = [IsAuthenticated, ]
    authentication_classes = [TokenAuthentication, ]
    queryset = MyUser.objects.all().order_by('-id')
    serializer_class = CreateRoleSerializer
    pagination_class = SetPagination
    search_fields = ['first_name', 'last_name', 'email']

    def get_queryset(self):
        return MyUser.objects.filter(roles__id=self.kwargs['id']).order_by('-id')

    def list(self, request, *args, **kwargs):
        results = super(GetUsersByRoleView, self).list(request, *args, **kwargs)
        return Response({
            'data': results.data,
            'message': resp_msg.RECORD_FETCHED_SUCCESSFULLY
        }, status=status.HTTP_200_OK)


class LogsRetriveView(APIView):
    permission_classes = [IsAuthenticated, ]
    authentication_classes = [TokenAuthentication, ]

    def get(self, request, id):
        instance = AccessLogsModel.objects.get(sys_id=id)
        serializer = AccessLogsModelSerializers(instance)
        return Response({
            'data': serializer.data,
            'message': resp_msg.RECORD_FETCHED_SUCCESSFULLY
        }, status=status.HTTP_200_OK)


class ResellerLogsListView(generics.ListAPIView):
    permission_classes = [IsAuthenticated, ]
    authentication_classes = [TokenAuthentication, ]
    serializer_class = AccessLogsModelSerializers
    pagination_class = SetPagination

    def get_queryset(self):
        params = self.request.query_params
        if 'from_date' in params and 'to_date' in params:
            from_date = params['from_date'] + ' 00:00:00'
            to_date = params['to_date'] + ' 23:59:59'
            from_date = datetime.strptime(from_date, '%Y-%m-%d %H:%M:%S')
            to_date = datetime.strptime(to_date, '%Y-%m-%d %H:%M:%S')
            return AccessLogsModel.objects.filter(
                user=self.request.user,
                created_at__gte=from_date,
                created_at__lte=to_date,
            ).order_by('-created_at')
        else:
            return AccessLogsModel.objects.filter(
                user=self.request.user).order_by('-created_at')

    def list(self, request, *args, **kwargs):

        field_to_sort = self.request.query_params.get('field')
        order_in = self.request.query_params.get('order_in')

        if order_in == 'asc':
            order_by_str = field_to_sort
        elif order_in == 'dec':
            order_by_str = '-' + field_to_sort
        else:
            order_by_str = ''

        if field_to_sort is not None and order_by_str is not None:
            queryset = self.get_queryset().order_by(order_by_str)
            serializer = AccessLogsModelSerializers(queryset, many=True)
            page = self.paginate_queryset(serializer.data)
            data = dict(self.get_paginated_response(page).data)
        else:
            data = super(ResellerLogsListView, self).list(request, *args, **kwargs).data
        return Response({
            'data': data,
            'message': resp_msg.RECORD_FETCHED_SUCCESSFULLY
        }, status=status.HTTP_200_OK)


class ResellerLogsReteriveView(generics.ListAPIView):
    permission_classes = [IsAuthenticated, ]
    authentication_classes = [TokenAuthentication, ]
    serializer_class = AccessLogsModelSerializers

    def get(self, request, id):
        instance = AccessLogsModel.objects.get(sys_id=id)
        serializer = AccessLogsModelSerializers(instance)
        return Response({
            'data': serializer.data,
            'message': resp_msg.RECORD_FETCHED_SUCCESSFULLY
        }, status=status.HTTP_200_OK)


class EmailLogSettingsView(viewsets.ModelViewSet):
    permission_classes = [IsAuthenticated]
    authentication_classes = [TokenAuthentication, ]
    queryset = EmailLogSettings.objects.all().order_by('-id')
    serializer_class = EmailLogSettingsSerializers
    pagination_class = SetPagination
    search_fields = ['module', 'emails']
    filter_backends = (filters.DjangoFilterBackend, SearchFilter,)

    def list(self, request, *args, **kwargs):
        results = super(EmailLogSettingsView, self).list(request, *args, **kwargs)
        return Response({
            'data': results.data,
            'message': resp_msg.RECORD_FETCHED_SUCCESSFULLY
        }, status=status.HTTP_200_OK)

    def create(self, request, *args, **kwargs):
        params = request.data
        serializer = self.get_serializer(data=params, context={'request': request})
        serializer.is_valid(raise_exception=True)
        serializer.save()
        return Response({"message": resp_msg.CREATED_SUCCESSFULLY.format("Email settings")})

    def update(self, request, *args, **kwargs):
        params = request.data
        instance = EmailLogSettings.objects.get(id=self.kwargs['pk'])
        if instance.module == params['module']:
            instance.emails = params['emails']
            instance.save()
            return Response({
                "message": resp_msg.UPDATED_SUCCESSFULLY.format("Email settings")
            })
        elif EmailLogSettings.objects.filter(module=params['module']).exists():
            return Response({
                "detail": "Email settings already exist"
            }, status=status.HTTP_400_BAD_REQUEST)
        instance = EmailLogSettings.objects.get(id=self.kwargs['pk'])
        serializer = self.get_serializer(instance, data=params, context={'request': request}, partial=True)
        serializer.is_valid(raise_exception=True)
        serializer.save()
        return Response({"message": resp_msg.UPDATED_SUCCESSFULLY.format("Email settings")})

    def destroy(self, request, *args, **kwargs):
        EmailLogSettings.objects.filter(id=self.kwargs['pk']).delete()
        return Response({"message": resp_msg.DELETED_SUCCESSFULLY.format("Email settings")})


class ResellerView(APIView):
    permission_classes = [IsAuthenticated]
    authentication_classes = [TokenAuthentication, ]
    queryset = MyUser.objects.all().order_by('-id')
    serializer_class = ResellerSerializer

    @swagger_auto_schema(request_body=reseller_schema)
    def post(self, request):
        params = request.data
        try:
            country_code = params['reseller'].get('country_code', '')
            phone_no = params['reseller'].get('phone_no', '')
            if MyUser.objects.filter(email=params['reseller']['email'].lower()).exists():
                return Response({
                    "detail": resp_msg.EMAIL_ALREADY_EXISTS
                }, status=status.HTTP_400_BAD_REQUEST)

            if phone_no:
                if MyUser.objects.filter(phone_no=phone_no, country_code=country_code).exclude(
                        phone_no__isnull=True).exists():
                    return Response({
                        "detail": resp_msg.PHONE_ALREADY_EXISTS
                    }, status=status.HTTP_400_BAD_REQUEST)
            serializer = ResellerSerializer(data=params, context={'request': request})
            serializer.is_valid(raise_exception=True)
            serializer.save()
            return Response({"message": resp_msg.RECORD_FETCHED_SUCCESSFULLY})
        except Exception as e:
            return Response({
                "detail": e.args[0] if e.args else str(e)
            }, status=status.HTTP_400_BAD_REQUEST)

    @swagger_auto_schema(request_body=update_reseller_schema)
    def put(self, request):
        params = request.data
        user = request.user
        #----
        if user.user_type==6:
            old_details = {
                "id":user.id,
                "first_name":user.first_name,
                "last_name":user.last_name,
                "email":user.email,
                "phone_no":user.phone_no,
                "address":user.address_user.address,
                "address_2":user.address_user.address_2,
                "tax_number":user.reseller_sub_dealer.tax_number,
                "company_number":user.reseller_sub_dealer.company_number,
                "win_ols_license_number":user.reseller_sub_dealer.win_ols_license_number
            }
        #----
        try:
            if user.user_type == 6:
                params['detail'].pop('bussness_name',None)
            country_code = params['reseller'].get('country_code', '')
            phone_no = params['reseller'].get('phone_no', '')
            if params['reseller']['phone_no'] != '':
                if MyUser.objects.exclude(email=params['reseller']['email']).filter(
                        phone_no=phone_no, country_code=country_code
                ).exclude(phone_no__isnull=True).exists():
                    return Response({
                        "detail": resp_msg.PHONE_ALREADY_EXISTS
                    }, status=status.HTTP_400_BAD_REQUEST)

            instance = MyUser.objects.get(uuid=params['uuid'])
            serializer = ResellerSerializer(instance, data=params, context={'request': request}, partial=True)
            serializer.is_valid(raise_exception=True)
            serializer.save()
            #---
            if user.user_type==6:
                new_details = {
                    "id":instance.id,
                    "first_name":instance.first_name,
                    "last_name":instance.last_name,
                    "email":instance.email,
                    "phone_no":instance.phone_no,
                    "address":instance.address_user.address,
                    "address_2":instance.address_user.address_2,
                    "tax_number":instance.reseller_sub_dealer.tax_number,
                    "company_number":instance.reseller_sub_dealer.company_number,
                    "win_ols_license_number":instance.reseller_sub_dealer.win_ols_license_number
                }
            #---
            #--- admin log----
            x_forwarded_for = request.META.get('HTTP_X_FORWARDED_FOR')

            ip_address=x_forwarded_for.split(',')[0] if x_forwarded_for else request.META.get('REMOTE_ADDR'),
            admin_log = AccessLogsModel.objects.create(
                user=request.user,
                timestamp=datetime.now(),
                ip_address=x_forwarded_for.split(',')[0] if x_forwarded_for else request.META.get('REMOTE_ADDR'),
                method='Update',
                event='Reseller Profile updated',
                module=EmailLogSettings.objects.filter(module='Buisness Customer Profile Updated').last(),
                title='Reseller Profile updated',
                description=f"Reseller profile updated",
                old_details=old_details if user.user_type==6 else None,
                new_details=new_details if user.user_type==6 else None,
                customer=user,
                to_customer_only=False,
            )
            #--- end admin log----
            return Response({"message": "User has been updated successfully."})
        except Exception as e:
            return Response({
                "detail": e.args[0] if e.args else str(e)
            }, status=status.HTTP_400_BAD_REQUEST)


class DealerView(APIView):
    permission_classes = [IsAuthenticated]
    authentication_classes = [TokenAuthentication, ]
    queryset = MyUser.objects.all().order_by('-id')
    serializer_class = DealerSerializer

    @swagger_auto_schema(request_body=reseller_schema)
    def post(self, request):
        params = request.data
        user = request.user
        try:
            if user.user_type == 7:
                params['detail'].pop('bussness_name',None)
            country_code = params['dealer'].get('country_code', '')
            phone_no = params['dealer'].get('phone_no', '')
            if MyUser.objects.filter(email=params['dealer']['email'].lower()).exists():
                return Response({
                    "detail": resp_msg.EMAIL_ALREADY_EXISTS
                }, status=status.HTTP_400_BAD_REQUEST)

            if MyUser.objects.filter(phone_no=phone_no, country_code=country_code).exclude(
                    phone_no__isnull=True).exists():
                return Response({
                    "detail": resp_msg.PHONE_ALREADY_EXISTS
                }, status=status.HTTP_400_BAD_REQUEST)
            serializer = DealerSerializer(data=params, context={'request': request})
            serializer.is_valid(raise_exception=True)
            serializer.save()
            return Response({"message": resp_msg.USER_CREATED})
        except Exception as e:
            return Response({
                "detail": e.args[0] if e.args else str(e)
            }, status=status.HTTP_400_BAD_REQUEST)

    def put(self, request):
        params = request.data
        #----
        user=request.user
        if user.user_type==7:
            old_details = {
                "id":user.id,
                "first_name":user.first_name,
                "last_name":user.last_name,
                "email":user.email,
                "phone_no":user.phone_no,
                "address":user.address_user.address,
                "address_2":user.address_user.address_2,
                "tax_number":user.reseller_sub_dealer.tax_number,
                "company_number":user.reseller_sub_dealer.company_number,
                "win_ols_license_number":user.reseller_sub_dealer.win_ols_license_number
            }
        #----
        try:
            country_code = params['dealer'].get('country_code', '')
            phone_no = params['dealer'].get('phone_no', '')
            if params['dealer']['phone_no'] != '':
                if MyUser.objects.exclude(email=params['dealer']['email']).filter(
                        phone_no=phone_no, country_code=country_code
                ).exclude(phone_no__isnull=True).exists():
                    return Response({
                        "detail": resp_msg.PHONE_ALREADY_EXISTS
                    }, status=status.HTTP_400_BAD_REQUEST)

            instance = MyUser.objects.get(uuid=params['uuid'])
            serializer = DealerSerializer(instance, data=params, context={'request': request}, partial=True)
            serializer.is_valid(raise_exception=True)
            serializer.save()
            #---
            if user.user_type==7:
                new_details = {
                    "id":instance.id,
                    "first_name":instance.first_name,
                    "last_name":instance.last_name,
                    "email":instance.email,
                    "phone_no":instance.phone_no,
                    "address":instance.address_user.address,
                    "address_2":instance.address_user.address_2,
                    "tax_number":instance.reseller_sub_dealer.tax_number,
                    "company_number":instance.reseller_sub_dealer.company_number,
                    "win_ols_license_number":instance.reseller_sub_dealer.win_ols_license_number
                }
            #---
            #--- admin log----
            x_forwarded_for = request.META.get('HTTP_X_FORWARDED_FOR')

            ip_address=x_forwarded_for.split(',')[0] if x_forwarded_for else request.META.get('REMOTE_ADDR'),
            admin_log = AccessLogsModel.objects.create(
                user=request.user,
                timestamp=datetime.now(),
                ip_address=x_forwarded_for.split(',')[0] if x_forwarded_for else request.META.get('REMOTE_ADDR'),
                method='Update',
                event='Subdealer Profile updated',
                module=EmailLogSettings.objects.filter(module='Buisness Customer Profile Updated').last(),
                title='subdealer Profile updated',
                description="subdealer profile updated",
                old_details=old_details if user.user_type==7 else None,
                new_details=new_details if user.user_type==7 else None,
                customer=user,
                to_customer_only=False,
            )
            #--- end admin log----
            return Response({"message": "User has been updated successfully."})
        except Exception as e:
            return Response({
                "detail": e.args[0] if e.args else str(e)
            }, status=status.HTTP_400_BAD_REQUEST)


class DealerListView(generics.ListAPIView):
    permission_classes = [IsAuthenticated, ]
    authentication_classes = [TokenAuthentication, ]
    queryset = MyUser.objects.filter(
        user_type=7
    ).order_by('id')
    serializer_class = CustomerSerializers
    pagination_class = SetPagination
    search_fields = ['first_name', 'last_name', 'email']
    filter_backends = (filters.DjangoFilterBackend, SearchFilter,)

    def get_queryset(self):
        return MyUser.objects.filter(
            parent__uuid=self.kwargs['uuid']
        ).order_by('-id')

    def list(self, request, *args, **kwargs):

        field_to_sort = request.query_params.get('field')
        order_in = request.query_params.get('order_in')

        if order_in == 'asc':
            order_by_str = field_to_sort
        elif order_in == 'dec':
            order_by_str = '-' + field_to_sort
        else:
            order_by_str = ''

        if field_to_sort is not None and order_by_str is not None:
            queryset = self.get_queryset().order_by(order_by_str)
            serializer = CustomerSerializers(queryset, many=True)
            page = self.paginate_queryset(serializer.data)
            data = dict(self.get_paginated_response(page).data)
        else:
            data = super(DealerListView, self).list(request, *args, **kwargs).data
        return Response({
            'data': data,
            'message': resp_msg.RECORD_FETCHED_SUCCESSFULLY
        }, status=status.HTTP_200_OK)


class TicketView(viewsets.ModelViewSet):
    permission_classes = [IsAuthenticated]
    authentication_classes = [TokenAuthentication]
    queryset = TicketHistory.objects.all().order_by('-updated_at')
    serializer_class = TicketHistorySerializer
    pagination_class = SetPagination
    search_fields = ['subject']
    parser_classes = (FormParser, MultiPartParser)
    filter_backends = (filters.DjangoFilterBackend, SearchFilter)

    # filterset_class = AdminTicketFilter

    def destroy(self, request, *args, **kwargs):
        return Response({
            'message': "This method is not allowed"
        }, status=status.HTTP_405_METHOD_NOT_ALLOWED)

    def create(self, request, *args, **kwargs):
        super(TicketView, self).create(request, *args, **kwargs)
        return Response({"message": resp_msg.CREATED_SUCCESSFULLY.format('Ticket')})

    def retrieve(self, request, *args, **kwargs):
        try:
            instance = self.get_object()
            from .constants import validate_user_ticket
            flag = validate_user_ticket(self.request.user, instance)
            if flag:
                return Response({
                    "message": resp_msg.RECORD_FETCHED_SUCCESSFULLY,
                    "data": TicketHistorySerializer(instance).data
                })
            else:
                return Response({
                    "message": resp_msg.UNAUTHORIZED_USER,
                    "data": None
                }, status=status.HTTP_401_UNAUTHORIZED)
        except Exception as e:
            return Response({
                'detail': e.args[0]
            }, status=status.HTTP_400_BAD_REQUEST)

    def list(self, request, *args, **kwargs):
        field_to_sort = request.query_params.get('field', 'updated_at')
        order_in = request.query_params.get('order_in', 'desc')
        start_date = request.query_params.get('start_date', '')
        end_date = request.query_params.get('end_date', '')
        filter_status = request.query_params.get('status', '')
        category = request.query_params.get('category', '')

        # Determine the order_by field
        order_by_str = '-' + field_to_sort if order_in == 'desc' else field_to_sort

        queryset = self.get_queryset()

        # Filter by date range if provided
        if start_date and end_date:
            queryset = queryset.filter(created_at__range=[start_date, end_date])

        if filter_status is not None and filter_status.isdigit():
            queryset = queryset.filter(ticket_status__id=status)

        if category is not None and category.isdigit():
            queryset = queryset.filter(category__id=category)

        # Filter based on active filter for the user
        is_custom_filter_queryset = TicketActiveFilter.objects.filter(user=request.user)
        if is_custom_filter_queryset.exists():
            active_filter_ids = [
                item['id'] for item in is_custom_filter_queryset.first().active_filter.filter if item['is_active']
            ]
            queryset = queryset.filter(ticket_status__in=active_filter_ids)

        # Annotate and order the queryset
        queryset = queryset.annotate(
            conversation_count=Count('ticket_history')
        ).order_by(order_by_str)

        # Paginate the results
        is_admin = validate_user_is_admin(self.request.user)
        queryset = queryset if is_admin else queryset.filter(ticket__created_by=self.request.user, ticket__assigned_to=self.request.user)
        page = self.paginate_queryset(queryset)
        if page is not None:
            serializer = self.get_serializer(page, many=True)
            paginated_response = self.get_paginated_response(serializer.data)
            return Response({
                'data': paginated_response.data,
                'message': resp_msg.RECORD_FETCHED_SUCCESSFULLY
            }, status=status.HTTP_200_OK)

        # Serialize the results
        serializer = self.get_serializer(queryset, many=True)
        return Response({
            'data': serializer.data,
            'message': resp_msg.RECORD_FETCHED_SUCCESSFULLY
        }, status=status.HTTP_200_OK)

    def get_serializer_context(self):
        return {'request': self.request, }

    def update(self, request, *args, **kwargs):
        return Response({
            'message': "This method is not allowed"
        }, status=status.HTTP_405_METHOD_NOT_ALLOWED)


class TicketCategoryCount(APIView):
    permission_classes = [IsAuthenticated]
    authentication_classes = [TokenAuthentication, ]

    def get_count_by_category(self):
        ticket_statuses = TicketStatus.objects.all()
        final_status = []
        if self.request.user.user_type == 1 or self.request.user.user_type == 5 or self.request.user.user_type == 2:
            status_dict = {status.id: status.team_status for status in ticket_statuses}
        else:
            status_dict = {status.id: status.user_status for status in ticket_statuses}
        if self.request.user.user_type == 1 or self.request.user.user_type == 5 or self.request.user.user_type == 2:
            ticket_counts = TicketHistory.objects.values('ticket_status').annotate(
                count=Count('ticket_status')
            )
        else:
            ticket_counts = TicketHistory.objects.filter(created_by=self.request.user).values('ticket_status').annotate(
                count=Count('ticket_status')
            )
        ticket_counts_dict = {item['ticket_status']: item['count'] for item in ticket_counts}
        if self.request.user.user_type == 1 or self.request.user.user_type == 5 or self.request.user.user_type == 2:
            for status_id, status_name in status_dict.items():
                count = ticket_counts_dict.get(status_id, 0)
                final_status.append({
                    'id': status_id,
                    'ticket_status': status_name,
                    'count': count
                })
        else:
            final_status_dict = {}
            for status_id, status_name in status_dict.items():
                count = ticket_counts_dict.get(status_id, 0)
                status_text = next((key for key, value in USER_STATUS_MAP.items() if value == status_name), None)
                if status_text:
                    if status_text in final_status_dict:
                        final_status_dict[status_text]['count'] += count
                    else:
                        final_status_dict[status_text] = {
                            'id': status_id,
                            'ticket_status': status_text,
                            'count': count
                        }

            final_status = list(final_status_dict.values())
        return final_status

    def get(self, request):
        return Response({
            'count_by_category': self.get_count_by_category(),
            'message': resp_msg.RECORD_FETCHED_SUCCESSFULLY
        }, status=status.HTTP_200_OK)


class AssignTicketHistoryView(APIView):
    permission_classes = [IsAuthenticated]
    authentication_classes = [TokenAuthentication, ]

    @swagger_auto_schema(request_body=ticket_assign_schema)
    @required_fields(field_list=['user_id', ])
    def post(self, request, ids):
        params = request.data
        assigned_to = MyUser.objects.get(id=params['user_id'])
        TicketHistory.objects.filter(ids=ids).update(assigned_to=assigned_to)
        ticket = TicketHistory.objects.get(ids=ids)
        ticket.save()
        context = {
            'name': "{} {}".format(assigned_to.first_name, assigned_to.last_name),
            'ticket': ticket,
            'status': ticket.ticket_status.team_status if ticket.ticket_status else 'New',
            'frontend_url': 'www.viezu-files.com',
        }
        ticket = TicketHistory.objects.get(ids=ids)
        conversation_count = Conversation.objects.filter(ticket=ticket).count()
        triger_socket({
            'uuid': str(ticket.created_by.uuid),
            'type': 'ticket_info_update',
            'ticket_id': str(ticket.ids),
            'ticket_status': str(ticket.ticket_status.get_user_status_display()),
            'ticket_conversation': str(conversation_count),
            'ticket_modified_time': str(ticket.updated_at.replace(tzinfo=None).isoformat() + 'Z'),
            'ticket_assigned': str(ticket.assigned_to.first_name + ' ' + ticket.assigned_to.last_name)
        })
        users = MyUser.objects.filter(
            Q(user_type=2) |
            Q(user_type=5) |
            Q(user_type=1)
        )
        for each in users:
            triger_socket({
                'uuid': str(each.uuid),
                'type': 'ticket_info_update',
                'ticket_id': str(ticket.ids),
                'ticket_status': str(ticket.ticket_status.team_status),
                'ticket_conversation': str(conversation_count),
                'ticket_modified_time': str(ticket.updated_at.replace(tzinfo=None).isoformat() + 'Z'),
                'ticket_assigned': str(ticket.assigned_to.first_name + ' ' + ticket.assigned_to.last_name)
            })
        get_template = render_to_string('email_template/ticket/internal_ticket_assign.html', context)
        SendMail.mail("{} Ticket Assignment".format(ticket.ids), assigned_to.email, get_template)
        create_notification(ticket.assigned_to, "Ticket Assigned: {}".format(ticket.ids),
                            "Ticket has been assigned to you by {} {}.".format(request.user.first_name,
                                                                               request.user.last_name),
                            sender=request.user, ticket=ticket, file=None)

        return Response({
            'message': "Ticket assigned  successfully"
        }, status=status.HTTP_200_OK)


class UpdateTicketHistoryView(APIView):
    permission_classes = [IsAuthenticated]
    authentication_classes = [TokenAuthentication, ]

    @swagger_auto_schema(request_body=ticket_status_schema)
    @required_fields(field_list=['ticket_status', ])
    def post(self, request, ids):
        params = request.data
        tk_status = 'New'
        ticket = TicketHistory.objects.get(ids=ids)
        if params['ticket_status'] == '0' or params['ticket_status'] == 0:
            TicketHistory.objects.filter(ids=ids).update(ticket_status=None)
        else:
            ticket_status = TicketStatus.objects.get(id=params['ticket_status'])
            TicketHistory.objects.filter(ids=ids).update(ticket_status=ticket_status)
            tk = TicketHistory.objects.get(ids=ids)
            tk.save()
            tk_status = ticket_status.get_user_status_display()

            if ticket.file_request and ticket.file_request is not None:
                if tk_status.lower() == 'closed':
                    ticket.file_request.status = 'CLOSED'
                    ticket.file_request.save()

        context = {
            'name': "{} {}".format(ticket.created_by.first_name, ticket.created_by.last_name),
            'status': tk_status,
            'ticket': ticket,
            'frontend_url': 'www.viezu-files.com'
        }
        ticket = TicketHistory.objects.get(ids=ids)
        conversation_count = Conversation.objects.filter(ticket=ticket).count()
        triger_socket({
            'uuid': str(ticket.created_by.uuid),
            'type': 'ticket_info_update',
            'ticket_id': str(ticket.ids),
            'ticket_status': str(ticket.ticket_status.get_user_status_display()),
            'ticket_conversation': str(conversation_count),
            'ticket_modified_time': str(ticket.updated_at.replace(tzinfo=None).isoformat() + 'Z'),
            'ticket_assigned': str(ticket.assigned_to.first_name + ' ' + ticket.assigned_to.last_name)
        })
        users = MyUser.objects.filter(
            Q(user_type=2) |
            Q(user_type=5) |
            Q(user_type=1)
        )
        for each in users:
            triger_socket({
                'uuid': str(each.uuid),
                'type': 'ticket_info_update',
                'ticket_id': str(ticket.ids),
                'ticket_status': str(ticket.ticket_status.team_status),
                'ticket_conversation': str(conversation_count),
                'ticket_modified_time': str(ticket.updated_at.replace(tzinfo=None).isoformat() + 'Z'),
                'ticket_assigned': str(ticket.assigned_to.first_name + ' ' + ticket.assigned_to.last_name)
            })
        get_template = render_to_string(
            'email_template/ticket/customer_ticket_closed.html' if tk_status == 'Closed' else 'email_template/ticket/customer_ticket_status_change.html',
            context)
        SendMail.mail("{} Status Update".format(ticket.ids), ticket.created_by.email, get_template)
        create_notification(ticket.created_by, "{} Status Update".format(ticket.ids),
                            "Ticket Status has been changed to {} by {} {}.".format(tk_status, request.user.first_name,
                                                                                    request.user.last_name),
                            sender=request.user, ticket=ticket, file=None)
        return Response({
            'message': "Ticket status updated successfully",
        }, status=status.HTTP_200_OK)


class GetInternalTeamView(generics.ListAPIView, generics.CreateAPIView):
    permission_classes = [IsAuthenticated, ]
    authentication_classes = [TokenAuthentication, ]
    queryset = MyUser.objects.filter(
        user_type=2
    ).order_by('id')
    serializer_class = GetInternalTeamViewSerializer
    pagination_class = SetPagination
    search_fields = ['first_name', 'last_name', 'email']
    filter_backends = (filters.DjangoFilterBackend, SearchFilter,)

    def get_queryset(self):
        return MyUser.objects.all().order_by('-id')

    def list(self, request, *args, **kwargs):
        results = super(GetInternalTeamView, self).list(request, *args, **kwargs)
        return Response({
            'data': results.data,
            'message': resp_msg.RECORD_FETCHED_SUCCESSFULLY
        }, status=status.HTTP_200_OK)

    def post(self, request, *args, **kwargs):
        params = request.data
        instance = TicketHistory.objects.get(ids=self.kwargs['ids'])
        # instance.tags.clear()
        for each in params['tags']:
            instance.tags.add(each)
        instance.save()
        return Response({
            'message': 'Tags added successfully.',
        }, status=status.HTTP_200_OK)


class CustomerImportIndividualViews(APIView):
    permission_classes = [IsAuthenticated, ]
    authentication_classes = [TokenAuthentication, ]

    def post(self, request):
        params = request.data
        email_error = []
        phone_no_error = []
        product_error = []

        for each in params['data']:
            is_email = MyUser.objects.filter(email=each['email'].lower())
            if is_email.exists():
                email_error.append(each['email'])
                each['email_msg'] = "Email Already exist."
                each['email_error'] = True
            else:
                each['email_msg'] = ""
                each['email_error'] = False
            country_code = each['country_code']
            phone_no = each['phone_no']
            is_phone = MyUser.objects.filter(phone_no=phone_no, country_code=country_code)
            if is_phone.exists():
                phone_no_error.append(each['phone_no'])
                each['phone_no_msg'] = "Phone No Already exist."
                each['phone_no_error'] = True

            if not ViezuProduct.objects.filter(product_name=each['product_name']).exists():
                each['product_name_msg'] = "Product doesn't exist."
                each['product_name_error'] = True
                product_error.append(each['product_name'])
        if phone_no_error or email_error or product_error:
            return Response({'data': params['data']}, status=status.HTTP_400_BAD_REQUEST)
        else:
            individual_users_email_list = []
            for each in params['data']:
                user = MyUser.objects.create(
                    user_type=4,
                    first_name=each['first_name'],
                    last_name=each['last_name'],
                    email=each['email'].lower(),
                    phone_no=each['phone_no'],
                    country_code=each['country_code'],
                )
                individual_users_email_list.append(each['email'].lower())
                UserProfile.objects.create(
                    user=user
                )
                Address.objects.create(
                    user=user,
                    country=each['country'],
                    state=each['state'],
                    city=each['city'],
                    zip=each['zip'],
                    address=each['address'],
                    address_2=each['address_2'],
                )
                IndividualCustomer.objects.create(
                    user=user,
                    product_name=each['product_name'],
                    tool_serial_number=each['tool_serial_number'],
                )
                CustomerCredit.objects.update_or_create(
                    user=user,
                    defaults={
                        'file_key_credit': each['file_key_credit'],
                        'function_credit': each['function_key_credit'],
                        'evc_credit': each['evc_key_credit'],
                    }
                )
                context = {
                    'name': "{} {}".format(user.first_name, user.last_name),
                    'link': "{}/{}/{}".format(
                        settings.FRONTEND_BASE_URL,
                        settings.FRONTEND_EMAIL_VERIFY_URL,
                        str(user.uuid)
                    ),
                    'frontend_url': 'www.viezu-files.com',
                }
                get_template = render_to_string('email_template/welcome.html', context)
                SendMail.mail(resp_msg.SUBJECT_NEW_USER_ONBOARD, user.email, get_template)

            x_forwarded_for = request.META.get('HTTP_X_FORWARDED_FOR')
            AccessLogsModel.objects.create(
                user=self.request.user,
                timestamp=datetime.now(),
                ip_address=x_forwarded_for.split(',')[0] if x_forwarded_for else request.META.get('REMOTE_ADDR'),
                method='created',
                event='created',
                module=EmailLogSettings.objects.filter(module='customer').last(),
                title='Bulk Individual users created.',
                description="Infividual user registered with emails {0}.".format(",".join(individual_users_email_list)),
                customer=self.request.user,
            )

            return Response({'message': "List imported successfully"})


class CustomerImportBusinessViews(APIView):
    permission_classes = [IsAuthenticated, ]
    authentication_classes = [TokenAuthentication, ]

    def post(self, request):
        params = request.data
        email_error = []
        phone_no_error = []
        for each in params['data']:
            is_email = MyUser.objects.filter(email=each['email'].lower())
            if is_email.exists():
                email_error.append(each['email'])
                each['email_msg'] = "Email Already exist."
                each['email_error'] = True
            else:
                each['email_msg'] = ""
                each['email_error'] = False
            country_code = each['country_code']
            phone_no = each['phone_no']
            is_phone = MyUser.objects.filter(phone_no=phone_no, country_code=country_code)
            if is_phone.exists():
                phone_no_error.append(each['phone_no'])
                each['phone_no_msg'] = "Phone No Already exist."
                each['phone_no_error'] = True
        if phone_no_error or email_error:
            return Response({'data': params['data']}, status=status.HTTP_400_BAD_REQUEST)
        else:
            business_users_email_list = []
            for each in params['data']:
                user = MyUser.objects.create(
                    user_type=3,
                    first_name=each['first_name'],
                    last_name=each['last_name'],
                    email=each['email'].lower(),
                    phone_no=each['phone_no'],
                    country_code=each['country_code'],
                )
                business_users_email_list.append(each['email'].lower())
                UserProfile.objects.create(
                    user=user
                )
                Address.objects.create(
                    user=user,
                    country=each['country'],
                    state=each['state'],
                    city=each['city'],
                    zip=each['zip'],
                    address=each['address'],
                    address_2=each['address_2'],
                )
                BusinessCustomer.objects.create(
                    user=user,
                    bussness_name=each['business_name'],
                    tax_number=each['tax_number'],
                    company_number=each['company_number'],
                    win_ols_license_number=each['win_ols_license_number'],
                )
                CustomerCredit.objects.update_or_create(
                    user=user,
                    defaults={
                        'file_key_credit': each['file_key_credit'],
                        'function_credit': each['function_key_credit'],
                        'evc_credit': each['evc_key_credit'],
                    }
                )
                context = {
                    'name': "{} {}".format(user.first_name, user.last_name),
                    'link': "{}/{}/{}".format(
                        settings.FRONTEND_BASE_URL,
                        settings.FRONTEND_EMAIL_VERIFY_URL,
                        str(user.uuid)
                    ),
                    'frontend_url': settings.FRONTEND_BASE_URL,
                }
                get_template = render_to_string('email_template/welcome.html', context)
                SendMail.mail(resp_msg.SUBJECT_NEW_USER_ONBOARD, user.email, get_template)

            x_forwarded_for = request.META.get('HTTP_X_FORWARDED_FOR')
            AccessLogsModel.objects.create(
                user=self.request.user,
                timestamp=datetime.now(),
                ip_address=x_forwarded_for.split(',')[0] if x_forwarded_for else request.META.get('REMOTE_ADDR'),
                method='created',
                event='created',
                module=EmailLogSettings.objects.filter(module='customer').last(),
                title='Bulk Business users created.',
                description="Business user registered with emails {0}.".format(",".join(business_users_email_list)),
                customer=self.request.user,
            )

            return Response({'message': "List imported successfully"})


class CustomerImportResellerViews(APIView):
    """ Create reseller user from admin side.

    The API is used in the customer management and used to
    bulk create resller from CSV file.
    """

    permission_classes = [IsAuthenticated, ]
    authentication_classes = [TokenAuthentication, ]

    def post(self, request):
        params = request.data
        email_error = []
        phone_no_error = []
        for each in params['data']:
            is_email = MyUser.objects.filter(email=each['email'].lower())
            if is_email.exists():
                email_error.append(each['email'])
                each['email_msg'] = "Email Already exist."
                each['email_error'] = True
            else:
                each['email_msg'] = ""
                each['email_error'] = False
            country_code = each['country_code']
            phone_no = each['phone_no']
            is_phone = MyUser.objects.filter(phone_no=phone_no, country_code=country_code)
            if is_phone.exists():
                phone_no_error.append(each['phone_no'])
                each['phone_no_msg'] = "Phone No Already exist."
                each['phone_no_error'] = True
        if phone_no_error or email_error:
            return Response({'data': params['data']}, status=status.HTTP_400_BAD_REQUEST)
        else:
            reseller_users_email_list = []
            for each in params['data']:
                user = MyUser.objects.create(
                    user_type=6,
                    first_name=each['first_name'],
                    last_name=each['last_name'],
                    email=each['email'].lower(),
                    phone_no=each['phone_no'],
                    country_code=each['country_code'],
                )
                reseller_users_email_list.append(each['email'].lower())
                UserProfile.objects.create(
                    user=user
                )
                Address.objects.create(
                    user=user,
                    country=each['country'],
                    state=each['state'],
                    city=each['city'],
                    zip=each['zip'],
                    address=each['address'],
                    address_2=each['address_2'],
                )
                ResellerAndSubDealer.objects.create(
                    user=user,
                    bussness_name=each['business_name'],
                    tax_number=each['tax_number'],
                    company_number=each['company_number'],
                    win_ols_license_number=each['win_ols_license_number'],
                )
                CustomerCredit.objects.update_or_create(
                    user=user,
                    defaults={
                        'file_key_credit': each['file_key_credit'],
                        'function_credit': each['function_key_credit'],
                        'evc_credit': each['evc_key_credit'],
                    }
                )
                context = {
                    'name': "{} {}".format(user.first_name, user.last_name),
                    'link': "{}/{}/{}".format(
                        settings.FRONTEND_BASE_URL,
                        settings.FRONTEND_EMAIL_VERIFY_URL,
                        str(user.uuid)
                    ),
                    'frontend_url': 'www.viezu-files.com',
                }
                get_template = render_to_string('email_template/welcome.html', context)
                SendMail.mail(resp_msg.SUBJECT_NEW_USER_ONBOARD, user.email, get_template)

            x_forwarded_for = request.META.get('HTTP_X_FORWARDED_FOR')
            AccessLogsModel.objects.create(
                user=self.request.user,
                timestamp=datetime.now(),
                ip_address=x_forwarded_for.split(',')[0] if x_forwarded_for else request.META.get('REMOTE_ADDR'),
                method='created',
                event='created',
                module=EmailLogSettings.objects.filter(module='customer').last(),
                title='Bulk Business users created.',
                description="Business user registered with emails {0}.".format(",".join(reseller_users_email_list)),
                customer=self.request.user,
            )
            return Response({'message': "List imported successfully"})


class CustomerImportSubDealerViews(APIView):
    """ Create sub-dealer user from admin side.

    The API is used in the customer management and used to
    bulk create resller from CSV file.
    """

    def post(self, request):
        params = request.data
        email_error = []
        phone_no_error = []
        for each in params['data']:
            is_email = MyUser.objects.filter(email=each['email'].lower())
            if is_email.exists():
                email_error.append(each['email'])
                each['email_msg'] = "Email Already exist."
                each['email_error'] = True
            else:
                each['email_msg'] = ""
                each['email_error'] = False
            country_code = each['country_code']
            phone_no = each['phone_no']
            is_phone = MyUser.objects.filter(phone_no=phone_no, country_code=country_code)
            if is_phone.exists():
                phone_no_error.append(each['phone_no'])
                each['phone_no_msg'] = "Phone No Already exist."
                each['phone_no_error'] = True
        if phone_no_error or email_error:
            return Response({'data': params['data']}, status=status.HTTP_400_BAD_REQUEST)
        else:
            sub_users_email_list = []
            for each in params['data']:

                is_reseller_exists = MyUser.objects.filter(email=each['reseller_email']).exists()
                if is_reseller_exists:
                    reseller = MyUser.objects.get(email=each['reseller_email'])
                    if reseller.user_type == 6:
                        user = MyUser.objects.create(
                            parent=reseller,
                            user_type=7,
                            first_name=each['first_name'],
                            last_name=each['last_name'],
                            email=each['email'].lower(),
                            phone_no=each['phone_no'],
                            country_code=each['country_code'],
                        )
                        sub_users_email_list.append(each['email'].lower())
                        UserProfile.objects.create(
                            user=user
                        )
                        Address.objects.create(
                            user=user,
                            country=each['country'],
                            state=each['state'],
                            city=each['city'],
                            zip=each['zip'],
                            address=each['address'],
                            address_2=each['address_2'],
                        )
                        ResellerAndSubDealer.objects.create(
                            user=user,
                            bussness_name=each['business_name'],
                            tax_number=each['tax_number'],
                            company_number=each['company_number'],
                            win_ols_license_number=each['win_ols_license_number'],
                        )
                        CustomerCredit.objects.update_or_create(
                            user=user,
                            defaults={
                                'file_key_credit': each['file_key_credit'],
                                'function_credit': each['function_key_credit'],
                                'evc_credit': each['evc_key_credit'],
                            }
                        )
                        context = {
                            'name': "{} {}".format(user.first_name, user.last_name),
                            'link': "{}/{}/{}".format(
                                settings.FRONTEND_BASE_URL,
                                settings.FRONTEND_EMAIL_VERIFY_URL,
                                str(user.uuid)
                            ),
                            'frontend_url': 'www.viezu-files.com',
                        }
                        get_template = render_to_string('email_template/welcome.html', context)
                        SendMail.mail(resp_msg.SUBJECT_NEW_USER_ONBOARD, user.email, get_template)

            x_forwarded_for = request.META.get('HTTP_X_FORWARDED_FOR')
            AccessLogsModel.objects.create(
                user=self.request.user,
                timestamp=datetime.now(),
                ip_address=x_forwarded_for.split(',')[0] if x_forwarded_for else request.META.get('REMOTE_ADDR'),
                method='created',
                event='created',
                module=EmailLogSettings.objects.filter(module='customer').last(),
                title='Bulk Business users created.',
                description="Business user registered with emails {0}.".format(",".join(sub_users_email_list)),
                customer=self.request.user,
            )

            return Response({'message': "List imported successfully"})


class VehicleEcuVersion(APIView):
    permission_classes = [IsAuthenticated, ]
    authentication_classes = [TokenAuthentication, ]

    def get(self, request):
        instance = FileRequestFormData.objects.all().last()

        if instance is not None:
            return Response({
                'message': 'Data fatched successfully.',
                'data': ast.literal_eval(instance.ecu_version)
            })
        return Response({
            'message': "Data not found."
        }, status=status.HTTP_400_BAD_REQUEST)

    @swagger_auto_schema(request_body=ecu_version_schema)
    def post(self, request):
        params = request.data
        instance = FileRequestFormData.objects.all().last()
        if instance is not None:
            ecu_version_list = ast.literal_eval(instance.ecu_version)
            if params['name'] in ecu_version_list:
                return Response({
                    'message': "ECU Version already exists."
                }, status=status.HTTP_400_BAD_REQUEST)

            ecu_version_list.append(params['name'])
            ecu_version_list = [x for x in ecu_version_list if x != '']
            instance.ecu_version = ecu_version_list
            instance.save()
            return Response({
                'message': 'Data save successfully.',
            })
        return Response({
            'message': "Something went wrong."
        }, status=status.HTTP_400_BAD_REQUEST)


class VehicleBrandVersion(APIView):
    permission_classes = [IsAuthenticated, ]
    authentication_classes = [TokenAuthentication, ]

    def get(self, request):
        instance = FileRequestFormData.objects.all().last()

        if instance is not None:
            return Response({
                'message': 'Data fatched successfully.',
                'data': ast.literal_eval(instance.ecu_brands)
            })
        return Response({
            'message': "Data not found."
        }, status=status.HTTP_400_BAD_REQUEST)

    @swagger_auto_schema(request_body=ecu_version_schema)
    def post(self, request):
        params = request.data
        instance = FileRequestFormData.objects.all().last()
        if instance is not None:
            ecu_brands_list = ast.literal_eval(instance.ecu_brands)
            if params['name'] in ecu_brands_list:
                return Response({
                    'message': "ECU brand already exists."
                }, status=status.HTTP_400_BAD_REQUEST)

            ecu_brands_list.append(params['name'])
            ecu_brands_list = [x for x in ecu_brands_list if x != '']
            instance.ecu_brands = ecu_brands_list
            instance.save()
            return Response({
                'message': 'Data save successfully.',
            })
        return Response({
            'message': "Something went wrong."
        }, status=status.HTTP_400_BAD_REQUEST)


class CreateNewVehicleView(APIView):
    permission_classes = [IsAuthenticated, ]
    authentication_classes = [TokenAuthentication, ]

    def post(self, request):
        params = request.data
        instaince_vehicle_type, _ = VehicleType.objects.get_or_create(name=params['vehicle_type'])
        instaince_brand, _ = VehicleBrand.objects.get_or_create(
            vehicle_type=instaince_vehicle_type,
            brand_name=params['brand_name'])
        instaince_model, _ = VehicleModel.objects.get_or_create(
            vehicle_brand=instaince_brand,
            model_name=params['model_name'])
        instaince_model, _ = VehicleControl.objects.get_or_create(
            vehicle_model=instaince_model,
            ecu_brand=params['ecu_version'],
            ecu_version=params['ecu_version'],
            fuel_type=params['fuel_type'])

        return Response({
            'message': 'New vehicle added successfully.',
        })

    # def put(self,request):
    #     params = request.data
    #     instaince_vehicle_type,_ = VehicleType.objects.get_or_create(name = params['vehicle_type'])
    #     instaince_brand,_  = VehicleBrand.objects.get_or_create(
    #                                         vehicle_type = instaince_vehicle_type,
    #                                         brand_name= params['brand_name'])
    #     instaince_model,_  = VehicleModel.objects.get_or_create(
    #                                         vehicle_brand = instaince_brand,
    #                                         model_name = params['model_name'])
    #     instaince_model,_  = VehicleControl.objects.get_or_create(
    #                                         vehicle_model = instaince_model,
    #                                         ecu_brand= params['ecu_version'],
    #                                         ecu_version = params['ecu_version'],
    #                                         fuel_type= params['fuel_type'])

    #     return Response({
    #         'message':'New vehicle added successfully.',
    #     })


class CreateUpdateKBView(APIView):

    def get(self, request):
        start = 1
        article_list = []
        is_articles_exists = ZOHOKnowledgeBaseArticles.objects.all()
        if len(is_articles_exists) == 0:
            message = "Articles added in the database."
        else:
            message = "Articles updated in the database."
        is_data_updated = load_zoho_articles(start, article_list)
        if is_data_updated:
            return Response({'message': message})


from google.cloud import bigquery
from google.cloud import bigquery_storage
import os
import pandas as pd


class ListMainDirectoryView(generics.ListAPIView):
    queryset = Directory.objects.all().order_by('-id')
    serializer_class = DirectoryModelSerializers
    pagination_class = SetPagination
    search_fields = [
        'directory_path', 'vehicle_type', 'ecu_producer', 'ecu_build', 'vehicle_producer', 'vehicle_model',
        'engine_displacement', 'engine_type', 'vehicle_model_year', 'vehicle_series'
    ]
    filter_backends = (filters.DjangoFilterBackend, SearchFilter,)

    def escape_special_chars(self, text):
        # Escape special characters for regex search
        return re.escape(text)

    def list(self, request, *args, **kwargs):
        search_by = request.query_params.get('search_by', 'directory')
        if search_by == 'directory':
            field_to_sort = request.query_params.get('field')
            order_in = request.query_params.get('order_in')

            if order_in == 'asc':
                order_by_str = field_to_sort
            elif order_in == 'dec':
                order_by_str = '-' + field_to_sort
            else:
                order_by_str = ''

            if field_to_sort is not None and order_by_str is not None:
                queryset = self.get_queryset().order_by(order_by_str)
                serializer = DirectoryModelSerializers(queryset, many=True)
                page = self.paginate_queryset(serializer.data)
                data = dict(self.get_paginated_response(page).data)
            else:
                serializer = self.serializer_class(self.get_queryset(), many=True)

            page = self.paginate_queryset(serializer.data)
            data = dict(self.get_paginated_response(page).data)
            message = resp_msg.RECORD_FETCHED_SUCCESSFULLY
        else:
            # BigQuery integration
            search_term = request.query_params.get('search', '')
            try:
                # Call the helper function to fetch the data from BigQuery
                data = self.get_gcp_files_by_search(search_term)
                message = resp_msg.RECORD_FETCHED_SUCCESSFULLY
            except Exception as error:
                return Response({
                    'data': [],
                    'message': str(error)
                }, status=status.HTTP_500_INTERNAL_SERVER_ERROR)

            page = self.paginate_queryset(data)
            if page is not None:
                return self.get_paginated_response(page)

        return Response({
            'data': data,
            'message': message
        }, status=status.HTTP_200_OK)

    def get_gcp_files_by_search(self, search_term):
        # Set GCP environment variables
        os.environ['GOOGLE_CLOUD_PROJECT'] = 'bigquery-project-437912'
        os.environ['GOOGLE_APPLICATION_CREDENTIALS'] = 'file-matching-43da45e9f9b8.json'

        client = bigquery.Client()
        dataset_id = 'filemaker_directory'
        table_id = 'file_data'

        # Query to fetch files based on the search term
        query = f"""
            SELECT directory_name, file_name
            FROM `{dataset_id}.{table_id}`
            WHERE lower(file_name) LIKE lower('%{search_term}%')
            LIMIT 25
        """

        query_job = client.query(query)
        data = []

        for row in query_job:
            directory_name = row['directory_name']
            file_name = row['file_name']
            dir_queryset = Directory.objects.filter(directory_path='Main/' + directory_name)
            if dir_queryset.exists():
                directory_data = self.serializer_class(dir_queryset.first()).data
                data.append({
                    'directory_path': directory_name,
                    'file_name': file_name,
                    'data': directory_data
                })
        if data:
            return data
        else:
            print("No data was fetched.")
            return []


class ListMainDirectoryKeysView(generics.ListAPIView):
    # permission_classes = [IsAuthenticated,]
    # authentication_classes = [TokenAuthentication, ]
    queryset = Directory.objects.all().order_by('-id')
    serializer_class = DirectoryModelSerializers
    pagination_class = SetPagination
    search_fields = [
        'directory_path', 'vehicle_type', 'ecu_producer', 'ecu_build', 'vehicle_producer', 'vehicle_model',
        'engine_displacement', 'engine_type', 'vehicle_model_year', 'vehicle_series', 'ecu_use'
    ]
    filter_backends = (filters.DjangoFilterBackend, SearchFilter,)

    def list(self, request, *args, **kwargs):

        field_to_sort = request.query_params.get('field')
        order_in = request.query_params.get('order_in')

        if order_in == 'asc':
            order_by_str = field_to_sort
        elif order_in == 'dec':
            order_by_str = '-' + field_to_sort
        else:
            order_by_str = ''

        if field_to_sort is not None and order_by_str is not None:
            print(1)
            queryset = self.get_queryset().order_by(order_by_str)
            serializer = DirectoryModelSerializers(queryset, many=True)
            page = self.paginate_queryset(serializer.data)
            data = dict(self.get_paginated_response(page).data)
        else:

            # serializer = self.serializer_class(self.get_queryset(), many=True)
            # page = self.paginate_queryset(serializer.data)
            # data = dict(self.get_paginated_response(page).data)
            data = super(ListMainDirectoryKeysView, self).list(request, *args, **kwargs).data
        return Response({
            'data': data,
            'message': "Data reterived successfully."
        }, status=status.HTTP_200_OK)


class SearchDirectoryNameView(generics.ListAPIView):
    # permission_classes = [IsAuthenticated,]
    # authentication_classes = [TokenAuthentication, ]
    queryset = Directory.objects.all().order_by('-id')
    serializer_class = DirectoryModelSerializers
    pagination_class = SetPagination

    def list(self, request, *args, **kwargs):
        dir_name = request.query_params.get('dir_name')
        queryset = Directory.objects.filter(directory_path__contains=dir_name)
        serializer = self.serializer_class(queryset, many=True)
        page = self.paginate_queryset(serializer.data)
        data = dict(self.get_paginated_response(page).data)
        message = resp_msg.RECORD_FETCHED_SUCCESSFULLY

        return Response({
            'data': data,
            'message': message
        }, status=status.HTTP_200_OK)


class FilterByVehicleDirectoryView(generics.ListAPIView):
    permission_classes = [IsAuthenticated, ]
    authentication_classes = [TokenAuthentication, ]
    queryset = Directory.objects.all().order_by('-id')
    serializer_class = DirectoryModelSerializers
    pagination_class = SetPagination

    def list(self, request, *args, **kwargs):
        vehicle_type = request.query_params.get('vehicle_type')
        vehicle_make = request.query_params.get('vehicle_make')
        vehicle_model = request.query_params.get('vehicle_model')

        if (vehicle_type is None) and \
                (vehicle_make is None) and \
                (vehicle_model is None):
            return Response({
                'success': False,
                'data': {},
                'message': "Please select atleast one filter."
            }, status=status.HTTP_400_BAD_REQUEST)

        queryset = Directory.objects.all()
        if vehicle_type is not None and vehicle_type != "":
            queryset = queryset.filter(vehicle_type=vehicle_type)
        if vehicle_make is not None and vehicle_make != "":
            queryset = queryset.filter(vehicle_producer=vehicle_make)
        if vehicle_model is not None and vehicle_model != "":
            queryset = queryset.filter(vehicle_model=vehicle_model)
        serializer = self.serializer_class(queryset, many=True)
        page = self.paginate_queryset(serializer.data)
        data = dict(self.get_paginated_response(page).data)
        return Response({
            'success': True,
            'data': data,
            'message': resp_msg.RECORD_FETCHED_SUCCESSFULLY
        }, status=status.HTTP_200_OK)


class FilterByECUView(generics.ListAPIView):
    permission_classes = [IsAuthenticated, ]
    authentication_classes = [TokenAuthentication, ]
    queryset = Directory.objects.all().order_by('-id')
    serializer_class = DirectoryModelSerializers
    pagination_class = SetPagination

    def list(self, request, *args, **kwargs):
        ecu_producer = request.query_params.get('ecu_producer')
        ecu_build = request.query_params.get('ecu_build')

        if (ecu_producer is None) and \
                (ecu_build is None):
            return Response({
                'success': False,
                'data': {},
                'message': "Please select atleast one filter."
            }, status=status.HTTP_400_BAD_REQUEST)

        queryset = Directory.objects.all()
        if ecu_producer is not None and ecu_producer != "":
            queryset = queryset.filter(ecu_producer=ecu_producer)
        if ecu_build is not None and ecu_build != "":
            queryset = queryset.filter(ecu_build=ecu_build)
        serializer = self.serializer_class(queryset, many=True)
        page = self.paginate_queryset(serializer.data)
        data = dict(self.get_paginated_response(page).data)
        return Response({
            'success': True,
            'data': data,
            'message': resp_msg.RECORD_FETCHED_SUCCESSFULLY
        }, status=status.HTTP_200_OK)


class ListSubDirectoryView(APIView):
    permission_classes = [IsAuthenticated, ]

    @swagger_auto_schema(request_body=get_sub_dir_schema)
    def post(self, request):
        params = request.data
        prefix = params.get('prefix', '')
        if not prefix.startswith("Main/"):
            prefix = "Main/" + prefix
        data = directory_utils.get_sub_files(prefix)
        return Response({'data': data, })


from itertools import chain


class DeleteDirectoryOrFileView(APIView):
    # permission_classes = [IsAuthenticated,]
    def get(self, request, id):
        instance = Directory.objects.get(id=id)
        print(instance.directory_path)
        is_directory_deleted = directory_utils.delete_directory(instance.directory_path)
        if is_directory_deleted:
            Directory.objects.filter(id=id).delete()
        return Response({
            'message': 'Directory deleted successfully.' if is_directory_deleted else 'Something went wrong please try again.'
        })


class ListDirectoryOrFileView(APIView):

    def get(self, request):
        prefix = request.query_params.get("prefix")

        ecu_producer = request.query_params.get("ecu_producer", '')
        ecu_build = request.query_params.get("ecu_build", '')
        ecu_prodnr = request.query_params.get("ecu_prodnr", '')

        data = []
        producer_instance, build_instance, prodnr_instance = [], [], []
        if ecu_producer or ecu_build or ecu_prodnr:
            is_folder = True
            instance = None
            if ecu_producer is not None and ecu_producer != '':
                producer_instance = Directory.objects.filter(
                    Q(ecu_producer__icontains=ecu_producer)
                )
            if ecu_build is not None and ecu_build != '':
                build_instance = Directory.objects.filter(
                    Q(ecu_build__icontains=ecu_build)
                )
            if ecu_prodnr is not None and ecu_prodnr != '':
                prodnr_instance = Directory.objects.filter(
                    Q(ecu_prodnr__icontains=ecu_prodnr)
                )

            instance = list(set(chain(producer_instance, build_instance, prodnr_instance)))
            serializer = DirectorySerializer(instance, many=True)
            data = serializer.data
        elif prefix is None:
            is_folder = True
            data = directory_utils.main_directory_folders()
        else:
            is_folder = False
            data = directory_utils.get_sub_files(prefix)
        return Response({'data': data, 'is_folder': is_folder})


class DownloadS3FileView(APIView):

    # permission_classes = [IsAuthenticated,]
    # authentication_classes = [TokenAuthentication, ]
    @swagger_auto_schema(request_body=download_s3_schema)
    def post(self, request):
        params = request.data
        prefix = params['prefix']
        if prefix.startswith("Main/"):
            prefix = prefix[len("Main/"):]
            pre_prefic = prefix.split("/")[0]
            post_prefic = prefix.split("/")[1]

        bucket_name = settings.AWS_STORAGE_BUCKET_NAME
        if directory_utils.check_s3_file_exists(bucket_name, "Main/" + pre_prefic + "/" + post_prefic):
            s3_link = "https://{}.s3.amazonaws.com/Main/{}".format(bucket_name, pre_prefic + "/" + post_prefic)
        # If not, check if it exists without the subfolder
        elif directory_utils.check_s3_file_exists(bucket_name, "Main/" + post_prefic):
            s3_link = "https://{}.s3.amazonaws.com/Main/{}".format(bucket_name, post_prefic)
        else:
            return Response({'error': 'File not found in S3'}, status=404)

        return Response({
            'link': s3_link,
            'message': resp_msg.S3_FILE_DOWNLOADED_SUCCESSFULLY
        })


class RenameS3FileView(APIView):
    @swagger_auto_schema(request_body=rename_s3_file_schema)
    def post(self, request):
        params = request.data
        is_file_renamed = directory_utils.rename_file(params['prefix'], params['file_name'])
        if is_file_renamed:
            return Response({
                'message': resp_msg.S3_FILE_RENAMED_SUCCESSFULLY
            })
        return Response({
            'message': resp_msg.S3_FILE_RENAMED_FAILED
        }, status=status.HTTP_400_BAD_REQUEST)


class DeleteS3FileView(APIView):
    permission_classes = [IsAuthenticated, ]
    authentication_classes = [TokenAuthentication, ]

    def get(self, request):
        filepath = request.query_params.get("filepath")
        if filepath is None or filepath == "":
            return Response({'is_success': False, 'message': resp_msg.FIELD_REQUIRED.format('filepath')})
        is_file_deleted = directory_utils.delete_file(filepath)
        if is_file_deleted:
            return Response({'is_success': is_file_deleted, 'message': resp_msg.S3_FILE_DELETED_SUCCESSFULLY})
        else:
            return Response({'is_success': is_file_deleted, 'message': resp_msg.S3_OPERATION_FAILED})


class UploadS3FileView(APIView):
    permission_classes = [IsAuthenticated, ]
    authentication_classes = [TokenAuthentication, ]
    parser_classes = (FormParser, MultiPartParser)

    def post(self, request):
        from io import BytesIO
        file = request.FILES['file']
        file_path = request.data['file_path']
        file_name = file.name
        file = BytesIO(file.read())
        is_file_uploaded = directory_utils.upload_file_to_s3(file, file_path, file_name)
        if is_file_uploaded:
            return Response({'is_success': is_file_uploaded, 'message': resp_msg.S3_FILE_UPLOADED_SUCCESSFULLY})
        else:
            return Response({'is_success': is_file_uploaded, 'message': resp_msg.S3_OPERATION_FAILED})


class CreateS3DirectoryView(APIView):
    permission_classes = [IsAuthenticated, ]
    authentication_classes = [TokenAuthentication, ]

    def get(self, request):
        folder_path = request.query_params.get("folder_path")
        is_folder_exist = directory_utils.IsObjectExists(folder_path)
        if is_folder_exist:
            return Response({'is_success': False, 'message': resp_msg.S3_FOLDER_EXISTS})
        if folder_path is None or folder_path == "":
            return Response({'is_success': False, 'message': resp_msg.FIELD_REQUIRED.format('folder_path')})

        is_file_uploaded = directory_utils.create_directory_s3(folder_path)
        if is_file_uploaded:
            return Response({'is_success': is_file_uploaded, 'message': resp_msg.S3_FOLDER_CREATED_SUCCESSFULLY})
        else:
            return Response({'is_success': is_file_uploaded, 'message': resp_msg.S3_OPERATION_FAILED})


class S3ZIPFilesUploadView(APIView):
    permission_classes = [IsAuthenticated, ]
    authentication_classes = [TokenAuthentication, ]
    parser_classes = (FormParser, MultiPartParser)

    def post(self, request):
        from io import BytesIO
        file = request.FILES['file']
        folder_path = request.data['folder_path']
        file = BytesIO(file.read())
        is_zip_uploaded = directory_utils.upload_zip_file(file, folder_path)
        if is_zip_uploaded:
            return Response({'is_success': is_zip_uploaded, 'message': resp_msg.S3_ZIP_UPLOAD_SUCCESS})
        else:
            return Response({'is_success': is_zip_uploaded, 'message': resp_msg.S3_ZIP_UPLOAD_FAILED})


class TestDecodeView(APIView):

    def post(self, request):

        decode_tool = request.data.get('decode_tool')
        decode_file = request.FILES['file']

        obj = AlienTechToken.objects.all().first()
        token = obj.access_token
        customer_code = obj.customer_code
        if decode_tool == "kessv2":
            response = FileOperation.decode_kessV2_file(token, decode_file, customer_code)
            EncodeDecodeFile.objects.create(
                unique_id=''.join(random.choices(string.ascii_uppercase +
                                                 string.digits, k=N)),
                tool=decode_tool,
                guid=response['guid'],
                client_application_guid=response['clientApplicationGUID'],
                slot_guid=response['slotGUID'],
                isSuccessful=response['isSuccessful'],
                hasFailed=response['hasFailed']
            )
            data = {}
            data['guid'] = response['guid'],
            data['client_application_guid'] = response['clientApplicationGUID'],
            data['slot_guid'] = response['slotGUID'],
            data['isSuccessful'] = response['isSuccessful'],
            data['hasFailed'] = response['hasFailed']
            return Response({'data': data,
                             'message': "File added for decode."})
        elif decode_tool == "ktag":
            response = FileOperation.decode_ktag_file(token, decode_file, customer_code)
            EncodeDecodeFile.objects.create(
                unique_id=''.join(random.choices(string.ascii_uppercase +
                                                 string.digits, k=N)),
                tool=decode_tool,
                guid=response['guid'],
                client_application_guid=response['clientApplicationGUID'],
                slot_guid=response['slotGUID'],
                isSuccessful=response['isSuccessful'],
                hasFailed=response['hasFailed']
            )
            data = {}
            data['guid'] = response['guid'],
            data['client_application_guid'] = response['clientApplicationGUID'],
            data['slot_guid'] = response['slotGUID'],
            data['isSuccessful'] = response['isSuccessful'],
            data['hasFailed'] = response['hasFailed']
            return Response({'data': data,
                             'message': "File added for decode."})
        else:
            response = FileOperation.decode_kess3_file(token, decode_file, customer_code)
            EncodeDecodeFile.objects.create(
                unique_id=''.join(random.choices(string.ascii_uppercase +
                                                 string.digits, k=N)),
                tool=decode_tool,
                guid=response['guid'],
                client_application_guid=response['clientApplicationGUID'],
                slot_guid=response['slotGUID'],
                isSuccessful=response['isSuccessful'],
                hasFailed=response['hasFailed']
            )
            data = {}
            data['guid'] = response['guid'],
            data['client_application_guid'] = response['clientApplicationGUID'],
            data['slot_guid'] = response['slotGUID'],
            data['isSuccessful'] = response['isSuccessful'],
            data['hasFailed'] = response['hasFailed']
            return Response({'data': data,
                             'message': "File added for decode."})


class SyncDirectoryView(APIView):
    permission_classes = [IsAuthenticated, ]
    authentication_classes = [TokenAuthentication, ]

    def get(self, request):
        print("inside sync func --------- ")
        task_sync_main_dir.delay(request.user.uuid)
        return Response({'message': "cloud data sync has been started."})


class SyncDirectoryBigQueryView(APIView):
    permission_classes = [IsAuthenticated, ]
    authentication_classes = [TokenAuthentication, ]

    def get(self, request):
        task_sync_main_dir_bigquery.delay()
        return Response({'message': "cloud data big query sync has been started."})


class TicketNoteCreateView(mixins.CreateModelMixin, generics.GenericAPIView):
    permission_classes = [IsAuthenticated, ]
    authentication_classes = [TokenAuthentication, ]
    serializer_class = TicketNoteSerializers

    def get_serializer_context(self):
        context = super().get_serializer_context()
        context.update({"request": self.request})
        return context

    def post(self, request, *args, **kwargs):
        serializer = self.get_serializer(data=request.data)
        serializer.is_valid(raise_exception=True)

        # Create the TicketNote instance
        ticket_note = serializer.save()

        # Once the note is successfully created, send the notification
        create_notification(
            ticket_note.ticket.assigned_to,
            "Ticket Note Added",
            f"A Note has been added to ticket {ticket_note.ticket.ids} by {request.user.first_name} {request.user.last_name}.",
            sender=request.user,
            ticket=ticket_note.ticket,
            file=None
        )

        # Return the response as usual
        return Response(serializer.data, status=status.HTTP_201_CREATED)


class TicketNoteListView(mixins.ListModelMixin,
                         generics.GenericAPIView):
    permission_classes = [IsAuthenticated, ]
    authentication_classes = [TokenAuthentication, ]
    serializer_class = TicketNoteSerializers
    pagination_class = SetPagination

    # def get_queryset(self):
    #     return TicketNote.objects.filter(ticket=self.kwargs['ticket']).order_by('-id')

    def get(self, request, *args, **kwargs):
        queryset = TicketNote.objects.filter(ticket=self.kwargs['ticket']).order_by('-id')
        serializer = TicketNoteSerializers(queryset, many=True)
        page = self.paginate_queryset(serializer.data)
        data = dict(self.get_paginated_response(page).data)
        return Response({
            'data': data,
            'message': resp_msg.RECORD_FETCHED_SUCCESSFULLY
        }, status=status.HTTP_200_OK)


class UploadDirectoryMongoView(APIView):

    def get(self, request, *args, **kwargs):
        print("in view.")
        read_s3_files_to_mongo.delay()
        return Response({
            'message': "Task started successfully."
        }, status=status.HTTP_200_OK)


class MongoFileSizeView(APIView):

    def get(self, request, *args, **kwargs):
        read_s3_files_to_mongo.delay()
        return Response({
            'message': "Task started successfully."
        }, status=status.HTTP_200_OK)


class RemoveDuplicateDir(APIView):

    def get(self, request, *args, **kwargs):
        from django.db.models import Count
        duplicate_paths = Directory.objects.values('directory_path').annotate(count=Count('id')).filter(count__gt=1)
        for duplicate in duplicate_paths:
            duplicates = Directory.objects.filter(directory_path=duplicate['directory_path'])
            to_keep = duplicates.first()
            to_delete = duplicates.exclude(id=to_keep.id)
            to_delete.delete()

        return Response({
            'message': "All duplicate dir removed successfully."
        }, status=status.HTTP_200_OK)


class AdminFilterView(APIView):
    permission_classes = [IsAuthenticated]
    authentication_classes = [TokenAuthentication, ]

    def get(self, request):
        params = self.request.query_params
        module_name = params['module_name']

        try:
            queryset = CustomFilter.objects.get(module_name=module_name, user=request.user)
            data = CustomFilterSerializers(queryset).data
        except Exception as error:
            data = {}

        return Response({
            'data': data,
            'message': "Data reterived successfully."
        }, status=status.HTTP_200_OK)


class TicketSearchView(viewsets.ModelViewSet):
    serializer_class = TicketHistorySerializer
    queryset = TicketHistory.objects.all().order_by('-id')
    queryset = queryset.annotate(
            conversation_count=Count('ticket_history')
        )
    filter_backends = (filters.DjangoFilterBackend, SearchFilter,)
    pagination_class = SetPagination
    search_fields = ['ids', 'subject', 'category__name',
                     'created_by__first_name','created_by__last_name','created_by__email',
                     'assigned_to__first_name', 'assigned_to__last_name','assigned_to__email',
                     'description', 'ticket_status__team_status', "file_request__request_id",
                     "file_request__vehicle_type", "file_request__vehicle_make",
                     "file_request__model", "file_request__vehicle_registration", "file_request__vehicle_year",
                     "file_request__vehicle_VIN", "file_request__engine_size", "file_request__transmission",
                     "file_request__fuel_type", "file_request__mileage_type", "file_request__mileage",
                     "file_request__ecu_brand", "file_request__customer_first_name", "file_request__customer_last_name",
                     "file_request__ecu_version", "file_request__control_unit", "file_request__file_type",
                     "file_request__country", "file_request__tuning_tool_used", "file_request__tuning_required",
                     "file_request__additional_info", "file_request__additional_function",]

    # search_fields = ['ids', 'subject', 'category__name',
    #     'created_by__first_name','created_by__last_name','created_by__email',
    #     'assigned_to__first_name', 'assigned_to__last_name','assigned_to__email',
    #     'ticket_status__team_status', "file_request__request_id",
    #     ]

    def get_queryset(self):
        """
        Override the default queryset to include annotation and optimize relationships.
        """
        print("inside this function ------------ ")
        return TicketHistory.objects.annotate(
            conversation_count=Count('ticket_history')
        ).select_related(
            'category', 'created_by', 'assigned_to', 'ticket_status', 'file_request'
        ).order_by('-id')
    
    def list(self, request, *args, **kwargs):
        print(f"inside list ------- ")
        # results = super(TicketSearchView, self).list(request, *args, **kwargs)
        #---
        search_query = self.request.query_params.get('search', '').strip().lower()
        print(f"Ticket search_query == {search_query}")
        results = super(TicketSearchView, self).list(search_query, *args, **kwargs)
        #---
        return Response({
            'data': results.data,
            'message': resp_msg.RECORD_FETCHED_SUCCESSFULLY
        }, status=status.HTTP_200_OK)


class TicketFilterByStatusView(generics.ListAPIView):
    permission_classes = [IsAuthenticated]
    authentication_classes = [TokenAuthentication, ]
    serializer_class = TicketHistorySerializer
    queryset = TicketHistory.objects.all().order_by('-id')
    filter_backends = (filters.DjangoFilterBackend, SearchFilter,)
    pagination_class = SetPagination

    def get_related_status_ids(self, status_id):
        """Given a status_id, return all status IDs that share the same display_user_status."""
        # Get the display_user_status for the given status ID
        ticket_status = TicketStatus.objects.get(id=status_id)
        user_status_value = ticket_status.user_status

        # Find all status IDs that share the same display_user_status
        related_statuses = TicketStatus.objects.filter(user_status=user_status_value).values_list('id', flat=True)

        return list(related_statuses)

    def get(self, request, *args, **kwargs):
        status = request.query_params.get("status", [])
        if len(status) > 0:
            status = status.split(",")
            status = [int(x) for x in status]
        if request.user.user_type == 1 or request.user.user_type == 5 or request.user.user_type == 2:
            if len(status) > 0:
                if 18 in status:
                    queryset = TicketHistory.objects.filter(Q(ticket_status__in=status) | Q(ticket_status__isnull=True))
                else:
                    queryset = TicketHistory.objects.filter(ticket_status__in=status)
            serializer = TicketHistorySerializer(queryset, many=True)
            page = self.paginate_queryset(serializer.data)
            data = dict(self.get_paginated_response(page).data)
        else:
            if len(status) > 0:
                related_statuses = []
                for status_id in status:
                    related_statuses.extend(self.get_related_status_ids(status_id))
                status = related_statuses
                if 18 in status:
                    queryset = TicketHistory.objects.filter(Q(ticket_status__in=status) | Q(ticket_status__isnull=True),
                                                            created_by=request.user)
                else:
                    queryset = TicketHistory.objects.filter(ticket_status__in=status, created_by=request.user)
            serializer = TicketHistorySerializer(queryset, many=True)
            page = self.paginate_queryset(serializer.data)
            data = dict(self.get_paginated_response(page).data)

        return Response({
            # 'count_by_category':self.get_count_by_category(),
            'data': data,
            'message': resp_msg.RECORD_FETCHED_SUCCESSFULLY
        })


class TicketFilterView(generics.ListAPIView):
    permission_classes = [IsAuthenticated]
    authentication_classes = [TokenAuthentication, ]
    serializer_class = TicketHistorySerializer
    queryset = TicketHistory.objects.all().order_by('-id')
    filter_backends = (filters.DjangoFilterBackend, SearchFilter,)
    pagination_class = SetPagination

    def calculate_dates(self, date):
        from datetime import datetime, timedelta
        print(date)
        today = datetime.today().date()
        if date == 'today':
            start_date = end_date = today
        elif date == 'yesterday':
            start_date = end_date = today - timedelta(days=1)
        elif date == 'week':
            end_date = today
            start_date = today - timedelta(days=6)
        elif date == 'month':
            start_date = today.replace(day=1)
            next_month = today.replace(day=28) + timedelta(days=4)
            end_date = next_month - timedelta(days=next_month.day)
        else:
            raise ValueError("Invalid date")

        print([start_date.strftime('%Y-%m-%d'), end_date.strftime('%Y-%m-%d')])
        return [start_date.strftime('%Y-%m-%d'), end_date.strftime('%Y-%m-%d')]

    def get_related_status_ids(self, status_id):
        """Given a status_id, return all status IDs that share the same display_user_status."""
        # Get the display_user_status for the given status ID
        ticket_status = TicketStatus.objects.get(id=status_id)
        user_status_value = ticket_status.user_status

        # Find all status IDs that share the same display_user_status
        related_statuses = TicketStatus.objects.filter(user_status=user_status_value).values_list('id', flat=True)

        return list(related_statuses)

    def get(self, request, *args, **kwargs):
        status = request.query_params.get("status", [])
        if len(status) > 0:
            status = status.split(",")
            status = [int(x) for x in status]
        category = request.query_params.get("category", "")
        created_at = request.query_params.get("created_at", "")
        if request.user.user_type == 1 or request.user.user_type == 5 or request.user.user_type == 2:
            if len(status) > 0:
                if 18 in status:
                    queryset = TicketHistory.objects.filter(Q(ticket_status__in=status) | Q(ticket_status__isnull=True))
                else:
                    queryset = TicketHistory.objects.filter(ticket_status__in=status)
            if category != '':
                queryset = TicketHistory.objects.filter(category=category)

            if created_at != '':
                range = self.calculate_dates(created_at)
                queryset = TicketHistory.objects.filter(created_at__date__range=range)

            serializer = TicketHistorySerializer(queryset, many=True)
            page = self.paginate_queryset(serializer.data)
            data = dict(self.get_paginated_response(page).data)
        else:
            if len(status) > 0:
                related_statuses = []
                for status_id in status:
                    related_statuses.extend(self.get_related_status_ids(status_id))
                status = related_statuses
                if 18 in status:
                    queryset = TicketHistory.objects.filter(Q(ticket_status__in=status) | Q(ticket_status__isnull=True),
                                                            created_by=request.user)
                else:
                    queryset = TicketHistory.objects.filter(ticket_status__in=status, created_by=request.user)
            if category != '':
                queryset = TicketHistory.objects.filter(category=category, created_by=request.user)

            if created_at != '':
                range = self.calculate_dates(created_at)
                queryset = TicketHistory.objects.filter(created_at__date__range=range, created_by=request.user)

            serializer = TicketHistorySerializer(queryset, many=True)
            page = self.paginate_queryset(serializer.data)
            data = dict(self.get_paginated_response(page).data)

        return Response({
            # 'count_by_category':self.get_count_by_category(),
            'data': data,
            'message': resp_msg.RECORD_FETCHED_SUCCESSFULLY
        })


class UpdateRequestInTicketView(APIView):

    def get(self, request, *args, **kwargs):
        ticket_history_with_file_request = TicketHistory.objects.filter(file_request__isnull=False)
        for t in ticket_history_with_file_request:
            tk = TicketHistory.objects.get(id=t.id)
            tk.request_id = tk.file_request.request_id
            tk.save()

        return Response({
            'message': "All tickets update with request ids."
        })


class UpdateTicketStatusView(APIView):

    def get(self, request, *args, **kwargs):
        ticket_history_with_none_status = TicketHistory.objects.filter(ticket_status__isnull=True)
        for t in ticket_history_with_none_status:
            t.ticket_status = TicketStatus.objects.get(team_status="New")
            t.save()

        return Response({
            'message': "All tickets with null updated with status new."
        })


class CloseSlotsView(APIView):
    permission_classes = [IsAuthenticated, ]
    authentication_classes = [TokenAuthentication, ]

    def get(self, request):
        params = self.request.query_params
        tool_used = params['tool_used']

        if not tool_used:
            return Response({'error': 'tool_used is a required field.'}, status=400)

        # Filter DecodeFiles based on the tool_used
        decode_files = DecodeFiles.objects.filter(tool_type=self.get_tool_type(tool_used))
        if not decode_files.exists():
            return Response({'message': 'No slots found for the specified tool.'}, status=404)
        slot_guids = list(decode_files.values_list('slot_guid', flat=True))
        # Trigger the Celery task to close the file slots
        close_file_slots_task.delay(tool_used, slot_guids)
        return Response({'message': 'Slot closure process has been started.'})

    def get_tool_type(self, tool_used):
        tool_map = {
            "KESS v2": 1,
            "KESS3": 2,
            "ktag": 3
        }
        return tool_map.get(tool_used)


class ResellerCustomerListViews(viewsets.ModelViewSet):
    serializer_class = CustomerSerializers
    queryset = MyUser.objects.filter(Q(user_type=6)).order_by('-id')
    search_fields = ['first_name', 'last_name', 'email']
    # parser_classes = (FormParser, MultiPartParser)
    filter_backends = (filters.DjangoFilterBackend, SearchFilter,)
    filterset_class = RoleFilter

    def list(self, request, *args, **kwargs):
        results = super(ResellerCustomerListViews, self).list(request, *args, **kwargs)
        return Response({
            'data': results.data,
            'message': resp_msg.RECORD_FETCHED_SUCCESSFULLY
        }, status=status.HTTP_200_OK)


class TemplateCustomView(APIView):
    permission_classes = [IsAuthenticated]
    authentication_classes = [TokenAuthentication, ]
    queryset = Template.objects.all().order_by('-id')
    serializer_class = TemplateSerializers

    def custom_filter_variables(self, body):

        splited_string = body.split('{{')
        data = [x for x in splited_string if "}}" in x]

        filters_list = []
        for i in data:
            split_data = i.split("}}")[0]
            filters_list.append(split_data)

        return filters_list

    def get(self, request, *args, **kwargs):

        params = self.request.query_params
        template_id = params['template_id']
        ticket_id = params['ticket_id']

        queryset = Template.objects.get(id=template_id)
        html_body = queryset.body
        ticket_queryset = TicketHistory.objects.get(ids=ticket_id)

        filters_list = self.custom_filter_variables(queryset.body)
        for variable in filters_list:
            if variable == "ticket_id":
                print(ticket_queryset.ids)
                html_body = html_body.replace("{{ticket_id}}", ticket_queryset.ids)

        return Response({
            'data': '',
            'message': resp_msg.RECORD_FETCHED_SUCCESSFULLY
        }, status=status.HTTP_200_OK)


class ManageDashboardView(APIView):
    permission_classes = [IsAuthenticated, ]
    authentication_classes = [TokenAuthentication, ]
    serializer_class = ManageDashboardSerializer
    queryset = ManageDashboard.objects.all()

    def get(self, request, *args, **kwargs):
        params = self.request.query_params
        role_name = params.get('role_name')
        if role_name is not None:
            queryset = ManageDashboard.objects.filter(role_name=role_name)
            serializer = ManageDashboardSerializer(queryset, many=True)
        else:
            queryset = ManageDashboard.objects.all()
            serializer = ManageDashboardSerializer(queryset, many=True)
        return Response({
            'data': serializer.data,
            'message': resp_msg.RECORD_FETCHED_SUCCESSFULLY
        }, status=status.HTTP_200_OK)

    def post(self, request, *args, **kwargs):
        data = request.data
        is_role_already_exist = ManageDashboard.objects.filter(role_name=data.get('role_name'))
        if len(is_role_already_exist) > 0:
            return Response({
                'success': False,
                'message': "This role for manage dashboard already exists."
            }, status=status.HTTP_200_OK)

        instance = ManageDashboard.objects.create(
            role_name=data.get('role_name'),
            dashboard_json=data.get('dashboard_json')
        )
        serializer = ManageDashboardSerializer(instance)
        return Response({
            'success': True,
            'data': serializer.data,
            'message': "Data created successfully."
        }, status=status.HTTP_200_OK)

    def put(self, request, *args, **kwargs):
        data = request.data
        params = self.request.query_params
        role_name = params.get('role_name')
        instance = ManageDashboard.objects.get(role_name=role_name)
        instance.dashboard_json = data.get('dashboard_json')
        instance.save()
        serializer = ManageDashboardSerializer(instance)
        return Response({
            'data': serializer.data,
            'message': "Data updated successfully."
        }, status=status.HTTP_200_OK)


class VehicleListView(generics.ListAPIView):
    permission_classes = [IsAuthenticated, ]
    authentication_classes = [TokenAuthentication, ]
    serializer_class = VehicleListControlSerializer
    pagination_class = SetPagination
    queryset = VehicleControl.objects.all()
    search_fields = ['ecu_brand', 'ecu_version', 'fuel_type', 'vehicle_model__model_name',
                     'vehicle_model__vehicle_brand__brand_name'
        , 'vehicle_model__vehicle_brand__vehicle_type__name']
    filter_backends = (filters.DjangoFilterBackend, SearchFilter,)

    def list(self, request, *args, **kwargs):
        field_to_sort = request.query_params.get('field')
        order_in = request.query_params.get('order_in')

        if order_in == 'asc':
            order_by_str = field_to_sort
        elif order_in == 'dec':
            order_by_str = '-' + field_to_sort
        else:
            order_by_str = ''

        if field_to_sort is not None and order_by_str is not None:
            queryset = self.get_queryset().order_by(order_by_str)
            serializer = VehicleListControlSerializer(queryset, many=True)
            page = self.paginate_queryset(serializer.data)
            data = dict(self.get_paginated_response(page).data)
        else:
            data = super(VehicleListView, self).list(request, *args, **kwargs).data
        return Response({
            'data': data,
            'message': resp_msg.RECORD_FETCHED_SUCCESSFULLY
        }, status=status.HTTP_200_OK)


class ImportVehicleCSVView(APIView):
    permission_classes = [IsAuthenticated, ]
    authentication_classes = [TokenAuthentication, ]

    def post(self, request):
        vehicle_data = request.data['data']
        if len(vehicle_data) == 0:
            return Response({
                'message': "No data in CSV file."
            }, status=status.HTTP_400_BAD_REQUEST)

        count = 2
        errors_list = []
        for params in vehicle_data:
            data = {}
            values = params.values()
            is_empty = [x for x in values if x == ""]
            if len(is_empty) > 0:
                data['row'] = count
                data['error'] = "Please verify the data in row {} for blank or invalid values.".format(count)
                errors_list.append(data)

        if len(errors_list) > 0:
            return Response({
                'success': False,
                'data': errors_list,
                'message': 'Error found in CSV file.',
            })

        for params in vehicle_data:
            instaince_vehicle_type, _ = VehicleType.objects.get_or_create(name=params['vehicle_type'])
            instaince_brand, _ = VehicleBrand.objects.get_or_create(
                vehicle_type=instaince_vehicle_type,
                brand_name=params['brand_name'])
            instaince_model, _ = VehicleModel.objects.get_or_create(
                vehicle_brand=instaince_brand,
                model_name=params['model_name'])
            instaince_model, _ = VehicleControl.objects.get_or_create(
                vehicle_model=instaince_model,
                ecu_brand=params['ecu_brand'],
                ecu_version=params['ecu_version'],
                fuel_type=params['fuel_type'])

            return Response({
                'success': True,
                'message': 'Vehicle data added successfully.',
            })


class CreateNewVehicleView(APIView):
    permission_classes = [IsAuthenticated, ]
    authentication_classes = [TokenAuthentication, ]

    def post(self, request):
        params = request.data
        instaince_vehicle_type, _ = VehicleType.objects.get_or_create(name=params['vehicle_type'])
        instaince_brand, _ = VehicleBrand.objects.get_or_create(
            vehicle_type=instaince_vehicle_type,
            brand_name=params['brand_name'])
        instaince_model, _ = VehicleModel.objects.get_or_create(
            vehicle_brand=instaince_brand,
            model_name=params['model_name'])
        instaince_model, _ = VehicleControl.objects.get_or_create(
            vehicle_model=instaince_model,
            ecu_brand=params['ecu_brand'],
            ecu_version=params['ecu_version'],
            fuel_type=params['fuel_type'])

        return Response({
            'message': 'New vehicle added successfully.',
        })

    def put(self, request):
        params = request.data
        instance_control = VehicleControl.objects.get(pk=params['id'])
        instance_control.ecu_brand = params['ecu_brand']
        instance_control.ecu_version = params['ecu_version']
        instance_control.fuel_type = params['fuel_type']
        instance_control.save()

        # instance_control.vehicle_model.model_name = params['model_name']
        vehicle_model = instance_control.vehicle_model
        vehicle_model.model_name = params['model_name']
        vehicle_model.save()

        return Response({
            'message': 'Vehicle updated successfully.',
        })


class TestingContorlUnit(APIView):

    def get(self, request):
        queryset2 = VehicleControl.objects.filter(Q(ecu_brand=""))
        queryset2.delete()

        queryset2 = VehicleControl.objects.filter(Q(ecu_brand=""))
        print(queryset2)
        return Response({
            'message': 'Vehicle reterived.',
        })


class FRStatusUpdateTicketView(APIView):
    """ Update FR status from Ticket."""

    permission_classes = [IsAuthenticated]
    authentication_classes = [TokenAuthentication, ]

    def get(self, request):
        params = self.request.query_params
        fr_status = params['fr_status']
        ticket_id = params['ticket_id']

        ticket = TicketHistory.objects.get(ids=ticket_id)

        file_request = ticket.file_request

        if fr_status == "Manual Handle":
            file_request.status = "Manual handle"
        else:
            file_request.status = fr_status
        file_request.save()

        create_notification(
            ticket.assigned_to,
            "{} Status Update".format(ticket.request_id),
            "File Request Status has been changed to {} by {} {}.".format(fr_status, request.user.first_name,
                                                                          request.user.last_name),
            sender=request.user,
            ticket=ticket,
            file=None
        )

        file_request_status_change(file_request.user, file_request)

        return Response({
            'message': "File request {} status has been udpated.".format(file_request.request_id)
        }, status=status.HTTP_200_OK)


class TicketGroupView(APIView):
    permission_classes = [IsAuthenticated, ]
    authentication_classes = [TokenAuthentication, ]
    serializer_class = TicketGroupSerializer
    queryset = TicketGroup.objects.all()

    # def get(self, request, *args, **kwargs):
    #     queryset = TicketGroup.objects.filter(role_id = request.query_params.get('role_id'))
    #     serializer = TicketGroupSerializer((queryset), many=True)
    #     return Response({
    #         'data': serializer.data,
    #         'message': resp_msg.RECORD_FETCHED_SUCCESSFULLY
    #     }, status=status.HTTP_200_OK)

    def get(self, request, *args, **kwargs):
        queryset = TicketGroup.objects.get(id=request.query_params.get('filter_id'))
        serializer = TicketGroupSerializer(queryset)
        return Response({
            "success": True,
            'data': serializer.data,
            'message': resp_msg.RECORD_FETCHED_SUCCESSFULLY
        }, status=status.HTTP_200_OK)

    def post(self, request, *args, **kwargs):
        instance = TicketGroup.objects.create(
            title=request.data.get('title'),
            created_by=request.user,
            role_id=1,
            filter=request.data.get('filter')
        )
        serializer = TicketGroupSerializer(instance)
        return Response({
            'success': True,
            'data': serializer.data,
            'message': "Ticket group created successfully."
        }, status=status.HTTP_200_OK)

    def put(self, request, *args, **kwargs):
        instance = TicketGroup.objects.filter(id=request.data.get('id')).update(
            title=request.data.get('title'),
            created_by=request.user,
            role_id=1,
            filter=request.data.get('filter')
        )
        queryset = TicketGroup.objects.get(id=request.data.get('id'))
        serializer = TicketGroupSerializer(queryset)
        return Response({
            'data': serializer.data,
            'message': "Data updated successfully."
        }, status=status.HTTP_200_OK)

    def delete(self, request, *args, **kwargs):
        queryset = TicketGroup.objects.get(id=request.query_params.get('filter_id'))
        queryset.delete()
        return Response({
            "success": True,
            'message': "Ticket group deleted successfully."
        }, status=status.HTTP_200_OK)


class TicketActiveFilterView(APIView):
    permission_classes = [IsAuthenticated, ]
    authentication_classes = [TokenAuthentication, ]

    def get(self, request, *args, **kwargs):
        user = request.user
        active_filter_id = request.query_params.get('active_filter_id')

        active_filter = TicketGroup.objects.get(id=active_filter_id)
        TicketActiveFilter.objects.update_or_create(
            user=user,
            defaults={'active_filter': active_filter}
        )

        return Response({
            'success': True,
        }, status=status.HTTP_200_OK)


class TicketActiveFilterForUserView(APIView):
    permission_classes = [IsAuthenticated]
    authentication_classes = [TokenAuthentication]

    def get_queryset(self):
        # Return the queryset for the current user
        return TicketActiveFilter.objects.filter(user=self.request.user)

    def get(self, request, *args, **kwargs):
        queryset = self.get_queryset()
        active_filter = queryset.first()  # Get the first active filter or None

        if active_filter:
            data = TicketGroupSerializer(active_filter.active_filter).data
        else:
            data = []  # Return an empty list if no active filter exists

        return Response({
            'data': data,
            'success': True,
        }, status=status.HTTP_200_OK)


class TicketGroupByroleView(APIView):
    permission_classes = [IsAuthenticated]
    authentication_classes = [TokenAuthentication]
    serializer_class = TicketGroupSerializer

    def get_queryset(self):
        return TicketGroup.objects.all()  # Define the queryset here

    def get(self, request, *args, **kwargs):
        queryset = self.get_queryset()  # Use the get_queryset method
        serializer = self.serializer_class(queryset, many=True)
        return Response({
            'data': serializer.data,
            'message': resp_msg.RECORD_FETCHED_SUCCESSFULLY
        }, status=status.HTTP_200_OK)


class DeleteFileMakerDirectory(APIView):

    def get(self, request, *args, **kwargs):
        queryset = Directory.objects.filter(created_by_filemaker=True)
        print(Directory.objects.all().count())
        print(queryset.count())
        # queryset.delete()
        # print(Directory.objects.all().count())
        for dir in queryset:
            directoryName = 'Main/' + dir.directory_path + '/'
            directoryWithout = dir.directory_path + '/'
            # print(directoryName)
            apps.utils.directory_utils.delete_s3_directory(directoryName)
            apps.utils.directory_utils.delete_s3_directory(directoryWithout)
            dir.delete()
        # apps.utils.directory_utils.delete_s3_directory("Main/DESKTOP-78VPINJ_12163/DESKTOP-78VPINJ_12163_DFR52C7/")
        return Response({
            'total_dir': Directory.objects.all().count(),
            'made_with_filemaker': queryset.count(),
            'message': 'Custom directory deleted successfully'
        }, status=status.HTTP_200_OK)
