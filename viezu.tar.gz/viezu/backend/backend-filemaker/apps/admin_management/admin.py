from django.contrib import admin

from apps.admin_management.models import (
    Conversation,
    TemplateCategory,
    Template,
    TicketActiveFilter,
    TicketAttachment,
    TicketCategory,
    TicketGroup,
    TicketHistory,
    UpdateCloseTicketOpen,ViezuProduct,TicketStatus,
    Notification,
    Directory,
    TicketNote,
    CustomFilter,
    ManageDashboard
)
# Register your models here.


admin.site.register(TicketCategory)
admin.site.register(Template)
admin.site.register(TemplateCategory)
admin.site.register(ViezuProduct)
admin.site.register(TicketAttachment)
admin.site.register(Conversation)
admin.site.register(Notification)
admin.site.register(TicketNote)
admin.site.register(ManageDashboard)


@admin.register(Directory)
class DirectoryAdmin(admin.ModelAdmin):
    list_display = (
        "directory_path", "created_by_filemaker",'ecu_producer','ecu_build',"vehicle_type")
    search_fields = ("directory_path", "created_by_filemaker",'ecu_producer','ecu_build',"vehicle_type")
    list_filter = (
        "directory_path", "created_by_filemaker",'ecu_producer','ecu_build',"vehicle_type")
    list_per_page = 20


@admin.register(CustomFilter)
class CustomFilterAdmin(admin.ModelAdmin):
    list_display = ("module_name","custom_filter","user",)


@admin.register(TicketHistory)
class TicketHistoryAdmin(admin.ModelAdmin):
    list_display = ("ids",'ticket_status','created_by','assigned_to','request_id',)
    readonly_fields = ('created_at',)


@admin.register(TicketStatus)
class TicketStatusAdmin(admin.ModelAdmin):
    list_display = ("team_status","user_status",)

@admin.register(TicketGroup)
class TicketGroupAdmin(admin.ModelAdmin):
    list_display = ("title","created_by","role_id",)

@admin.register(TicketActiveFilter)
class TicketActiveFilterAdmin(admin.ModelAdmin):
    list_display = ("user","active_filter",)

@admin.register(UpdateCloseTicketOpen)
class UpdateCloseTicketOpenAdmin(admin.ModelAdmin):
    list_display = ("ticket",)

