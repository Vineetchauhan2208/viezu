from apps.admin_management.constants import USER_STATUS_MAP
from apps.customer.serializer import TicketCretedByDetailsSerializer, CustomerCreditSerializer
from apps.file_request.models import VehicleControl
from apps.utils.evc_apis import is_evc_customer_exist, is_evc_reseller_customer_exist
from apps.utils.tasks import task_update_zoho_customer
from rest_framework import serializers

from django.conf import settings
from django.template.loader import render_to_string

from apps.account.models import (
    AccessLogsModel, Address, BusinessCustomer, EVCCredentials, IndividualCustomer,
    MyUser, ResellerAndSubDealer, RolesAndPermissions,
    UserProfile
)
from apps.utils.helper import SendMail
import apps.admin_management.response_message as resp_msg
from apps.utils.custom_exception import BaseCustomException
from apps.admin_management.models import (
    CustomFilter, Directory, ManageDashboard, Template, TemplateCategory,
    TicketCategory, TicketGroup, TicketNote, TicketStatus,
    ViezuProduct
)
from apps.account.models import EmailLogSettings
from datetime import datetime


class RolesAndPermissionsSerializers(serializers.ModelSerializer):
    name = serializers.CharField(max_length=255, required=True)
    permissions = serializers.JSONField(required=True)

    def validate_name(self, name):
        request = self.context.get('request')
        params = request.data

        if self.instance and 'name' in params and params['name'] != '':
            if self.instance.name != params['name'] and RolesAndPermissions.objects.filter(
                    name=params['name']).exists():
                raise BaseCustomException(detail=resp_msg.ROLE_ALREADY_EXISTS, code=400)
            return name

        is_name_exist = RolesAndPermissions.objects.filter(name=name).exists()
        if is_name_exist:
            raise BaseCustomException(detail=resp_msg.ROLE_ALREADY_EXISTS, code=400)
        return name

    def create(self, validated_data):
        request_user = self.context.get("request").user
        try:
            roles = RolesAndPermissions.objects.create(
                **validated_data
            )

            # x_forwarded_for = self.request.META.get('HTTP_X_FORWARDED_FOR')
            AccessLogsModel.objects.create(
                user=request_user,
                timestamp=datetime.now(),
                # ip_address = x_forwarded_for.split(',')[0] if x_forwarded_for else self.request.META.get('REMOTE_ADDR'),
                method='Created',
                event='Created',
                module=EmailLogSettings.objects.filter(module='permission').last(),
                title='Permission created.',
                description="New Permissions has been created for role {0}.".format(validated_data['name']),
            )
            return roles
        except Exception as e:
            raise BaseCustomException(detail=e.args[0], code=400)

    def update(self, instance, validated_data):
        request = self.context.get('request')
        params = request.data
        if 'name' in params:
            instance.name = params['name']
        if 'permissions' in params:
            instance.permissions = params['permissions']
        instance.save()
        request_user = self.context.get("request").user

        AccessLogsModel.objects.create(
            user=request_user,
            timestamp=datetime.now(),
            # ip_address = x_forwarded_for.split(',')[0] if x_forwarded_for else self.request.META.get('REMOTE_ADDR'),
            method='Updated',
            event='Updated',
            module=EmailLogSettings.objects.filter(module='permission').last(),
            title='Permission Updated.',
            description="Permission has been updated for role {0}.".format(validated_data['name']),
        )

        return instance

    class Meta:
        model = RolesAndPermissions
        fields = ("name", "permissions", "id")


class CreateRoleSerializer(serializers.Serializer):
    """ Create new roles serializer. """

    roles = RolesAndPermissionsSerializers(read_only=True)
    # role = serializers.CharField(source='get_user_type_display', read_only=True)
    status = serializers.CharField(source='is_active', read_only=True)
    user_id = serializers.CharField(source='id', read_only=True)
    first_name = serializers.CharField(max_length=255, required=True)
    last_name = serializers.CharField(max_length=255, required=True)
    email = serializers.EmailField(max_length=50, required=True)
    image = serializers.FileField(required=False)
    description = serializers.CharField(required=False)
    # roles = serializers.IntegerField(required=False,write_only=True)
    on_stop = serializers.BooleanField(read_only=True)

    def validate_phone_no(self, phone_no):
        is_phone_exist = MyUser.objects.filter(phone_no=phone_no)
        if len(is_phone_exist) > 0:
            raise BaseCustomException(detail=resp_msg.PHONE_ALREADY_EXISTS, code=400)
        return phone_no

    def validate_email(self, email):
        """ Validate if email already exist or not.

        Args:
            email (str)

        Raises:
            BaseCustomException: Email validation message.

        Returns:
            email (str)
        """
        request = self.context.get('request')
        params = request.data
        if self.instance and 'email' in params and params['email'] != '':
            if self.instance.email != params['email'] and MyUser.objects.filter(email=params['email']).exists():
                raise BaseCustomException(detail=resp_msg.EMAIL_ALREADY_EXISTS, code=400)
            return email

        is_email_exist = MyUser.objects.filter(email=email).exists()
        if is_email_exist:
            raise BaseCustomException(detail=resp_msg.EMAIL_ALREADY_EXISTS, code=400)
        return email

    def create(self, validated_data):
        request = self.context.get('request')
        params = request.data
        if 'roles' in validated_data:
            validated_data.pop('roles')
        try:
            user = MyUser.objects.create(
                created_by=request.user,
                user_type=2,
                roles=RolesAndPermissions.objects.get(id=params['roles']),
                **validated_data
            )
            if 'image' in request.FILES:
                user.image = request.FILES['image']
            UserProfile.objects.create(
                user=user
            )
            context = {
                'name': "{} {}".format(validated_data['first_name'], params['last_name']),
                'link': "{}/{}/{}".format(
                    settings.FRONTEND_BASE_URL,
                    settings.FRONTEND_EMAIL_VERIFY_URL,
                    str(user.uuid)
                ),
                'frontend_url': 'www.viezu-files.com',
            }
            get_template = render_to_string('email_template/welcome.html', context)
            SendMail.mail(resp_msg.SUBJECT_NEW_USER_ONBOARD, user.email, get_template)
            return user
        except Exception as e:
            raise BaseCustomException(detail=e.args[0], code=400)

    def update(self, instance, validated_data):
        request = self.context.get('request')
        params = request.data
        if 'first_name' in params:
            instance.first_name = params['first_name']
        if 'last_name' in params:
            instance.last_name = params['last_name']
        if 'email' in params:
            instance.email = params['email']
        if 'description' in params:
            instance.description = params['description']
        if 'status' in params:
            is_active = True if params['status'] == 'True' else False
            instance.is_active = is_active
        if 'roles' in params and params['roles'] != '':
            instance.roles = RolesAndPermissions.objects.get(id=params['roles'])
        # if 'user_type' in params:
        #     instance.user_type = params['user_type']
        if 'image' in request.FILES:
            instance.image = request.FILES['image']
        instance.save()
        return instance


class IndividualCustomerSerializers(serializers.ModelSerializer):
    class Meta:
        model = IndividualCustomer
        fields = "__all__"


class BusinessCustomerSerializers(serializers.ModelSerializer):
    class Meta:
        model = BusinessCustomer
        fields = "__all__"


class ResellerAndSubDealerSerializers(serializers.ModelSerializer):
    class Meta:
        model = ResellerAndSubDealer
        fields = "__all__"


class AddressSerializer(serializers.ModelSerializer):
    class Meta:
        model = Address
        fields = "__all__"


class CustomerSerializers(serializers.ModelSerializer):
    user_type = serializers.CharField(source='get_user_type_display')
    address_user = AddressSerializer()
    individual_user = IndividualCustomerSerializers()
    business_user = BusinessCustomerSerializers()
    reseller_sub_dealer = ResellerAndSubDealerSerializers()
    reseller_data = serializers.SerializerMethodField()

    def get_reseller_data(self, obj):
        if obj.parent:
            return {'first_name': obj.parent.first_name,
                    'last_name': obj.parent.last_name,
                    'email': obj.parent.email}
        return {}

    class Meta:
        model = MyUser
        fields = ("id", "uuid", "first_name",
                  "last_name", "email", "last_login",
                  "is_active", "image", "user_type", 'phone_no',
                  'address_user', "individual_user", "business_user",
                  "reseller_sub_dealer", "reseller_data", "on_stop", "country_code"
                  )


class CustomerListSerializers(serializers.ModelSerializer):
    user_type = serializers.CharField(source='get_user_type_display')
    individual_user = IndividualCustomerSerializers()
    business_user = BusinessCustomerSerializers()
    customer_credit = CustomerCreditSerializer()

    class Meta:
        model = MyUser
        fields = ("id", "uuid", "first_name",
                  "last_name", "email",
                  "image", "user_type",
                  "individual_user", "business_user",
                  "customer_credit",
                  )


class AdminProfileSerializers(serializers.ModelSerializer):
    """ Admin profile serilaizer for crating new admin. """

    first_name = serializers.CharField(max_length=255, required=True)
    last_name = serializers.CharField(max_length=255, required=True)
    phone_no = serializers.CharField(max_length=255, required=True)
    country = serializers.CharField(max_length=50, required=True)
    image = serializers.FileField(required=False)
    address = serializers.CharField(max_length=50, required=True)

    def update(self, instance, validated_data):
        request = self.context.get('request')
        params = request.data
        if 'first_name' in params:
            instance.first_name = params['first_name']
        if 'last_name' in params:
            instance.last_name = params['last_name']
        if 'phone_no' in params:
            instance.phone_no = params['phone_no']
        if 'image' in request.FILES:
            instance.image = request.FILES['image']
        address, _ = Address.objects.get_or_create(user=instance)
        if 'address' in params:
            address.address = params['address']
        if 'country' in params:
            address.country = params['country']
        address.save()
        instance.save()
        return instance

    class Meta:
        model = MyUser
        fields = ("first_name", "last_name", "country", "address", "phone_no", "image")


class ViezuProductSerializers(serializers.ModelSerializer):
    """ Product serializer for register page."""

    def validate_product_name(self, product_name):
        is_product_exist = ViezuProduct.objects.filter(product_name=product_name)
        if len(is_product_exist) > 0:
            raise BaseCustomException(detail=resp_msg.PRODUCT_ALREADY_EXISTS, code=400)
        return product_name

    class Meta:
        model = ViezuProduct
        fields = ('product_name', 'id')


class TemplateCategorySerializers(serializers.ModelSerializer):
    """ Category serializer for email template."""

    def validate_name(self, name):
        is_product_exist = TemplateCategory.objects.filter(name=name)
        if len(is_product_exist) > 0:
            raise BaseCustomException(detail=resp_msg.PRODUCT_ALREADY_EXISTS, code=400)
        return name

    class Meta:
        model = TemplateCategory
        fields = ('name', 'id')


class TicketCategorySerializers(serializers.ModelSerializer):
    """ Category serializer for email template."""

    def validate_name(self, name):
        is_product_exist = TicketCategory.objects.filter(name=name)
        if len(is_product_exist) > 0:
            raise BaseCustomException(detail=resp_msg.PRODUCT_ALREADY_EXISTS, code=400)
        return name

    class Meta:
        model = TicketCategory
        fields = ('name', 'id')


class TemplateSerializers(serializers.ModelSerializer):
    """ Email Template serializer. """

    # category_name = serializers.CharField(source='category',read_only=True)
    template_type_display = serializers.CharField(source='get_template_type_display', read_only=True)

    class Meta:
        model = Template
        fields = ('subject', 'template_type', 'template_type_display', 'body', 'id', 'ids')


class AccessLogsModelSerializers(serializers.ModelSerializer):
    user = serializers.SerializerMethodField()
    email = serializers.SerializerMethodField()
    module = serializers.SerializerMethodField()

    def get_module(self, obj):
        if obj.module:
            return obj.module.module
        return None

    def get_email(self, obj):
        if obj.user:
            return obj.user.email
        return None

    def get_user(self, obj):
        if obj.user:
            return "{} {}".format(obj.user.first_name, obj.user.last_name)
        return None

    class Meta:
        model = AccessLogsModel
        fields = "__all__"


class EmailLogSettingsSerializers(serializers.ModelSerializer):
    class Meta:
        model = EmailLogSettings
        fields = ("module", "emails", "path", "id")


class TicketStatusSerializers(serializers.ModelSerializer):
    display_user_status = serializers.CharField(source='get_user_status_display', read_only=True)

    class Meta:
        model = TicketStatus
        fields = ("team_status", "user_status", "display_user_status", "id")


from rest_framework import filters


class UserStatusFilterBackend(filters.BaseFilterBackend):
    def filter_queryset(self, request, queryset, view):
        search = request.query_params.get('search', None)
        if search:
            team_status_filtered_queryset = queryset.filter(team_status__icontains=search)

            if team_status_filtered_queryset.exists():
                queryset = team_status_filtered_queryset
            else:
                status_value = USER_STATUS_MAP.get(search)
                if status_value is not None:
                    queryset = queryset.filter(user_status=status_value)

        return queryset


from django.db.models import Q


class AdminStatusCountSerializer(serializers.ModelSerializer):
    id = serializers.SerializerMethodField()
    ticket_status = serializers.SerializerMethodField()
    count = serializers.SerializerMethodField()

    def get_id(self, obj):
        staus = self.context.get('tickets')
        return obj.id

    def get_ticket_status(self, obj):
        staus = self.context.get('tickets')
        return obj.team_status

    def get_count(self, obj):
        tickets = self.context.get('tickets')
        if obj.team_status == "New":
            return tickets.filter(Q(ticket_status__team_status="New") | Q(ticket_status__isnull=True)).count()
        else:
            return tickets.filter(ticket_status__team_status=obj.team_status).count()

    class Meta:
        model = TicketStatus
        fields = ('id', 'ticket_status', 'count')


class GetInternalTeamViewSerializer(serializers.ModelSerializer):
    class Meta:
        model = MyUser
        fields = ('id', 'first_name', 'last_name', 'image', 'email')


from phonenumber_field.serializerfields import PhoneNumberField
from rest_framework import renderers, serializers


class PhoneNumberSerializer(serializers.Serializer):
    number = PhoneNumberField()


class S3FileUploadSerializer(serializers.Serializer):
    filename = serializers.CharField(max_length=1000, required=True)
    file = serializers.FileField()


class DirectorySerializer(serializers.ModelSerializer):
    folder = serializers.SerializerMethodField()
    last_modified = serializers.SerializerMethodField()

    def get_last_modified(self, obj):
        return ''

    def get_folder(self, obj):
        return obj.directory_path.split('/')[-1]

    class Meta:
        model = Directory
        fields = ('folder', 'last_modified')


class DirectoryModelSerializers(serializers.ModelSerializer):
    class Meta:
        model = Directory
        fields = "__all__"


class AdminIndividualRegisterSerializer(serializers.ModelSerializer):
    """ Customer register serializer.

    Custom models serializer for Individual customer on platform.
    """

    def update(self, instance, validated_data):
        request = self.context.get('request')
        params = request.data
        if 'first_name' in params['individual']:
            instance.first_name = params['individual']['first_name']
        if 'last_name' in params['individual']:
            instance.last_name = params['individual']['last_name']
        if 'image' in request.FILES:
            instance.image = request.FILES['image']
        if 'is_active' in params['individual']:
            instance.is_active = True if params['individual']['is_active'] == True else False
        if 'phone_no' in params['individual']:
            instance.phone_no = params['individual']['phone_no']
        if 'country_code' in params['individual']:
            instance.country_code = params['individual']['country_code']
        instance.save()
        Address.objects.filter(
            user=instance,
        ).update(**params['address'])
        IndividualCustomer.objects.filter(
            user=instance,
        ).update(**params['individual_profile'])
        instance.save()
        task_update_zoho_customer.delay(str(instance.uuid))
        return instance

    class Meta:
        model = MyUser
        fields = ("id", "uuid", "first_name", "last_name", "is_active")


class AdminBusinessRegisterSerializer(serializers.ModelSerializer):
    """ Customer register serializer.

    Custom models serializer for Business customer on platform.
    """

    def update(self, instance, validated_data):
        request = self.context.get('request')
        params = request.data
        if 'first_name' in params['business']:
            instance.first_name = params['business']['first_name']
        if 'last_name' in params['business']:
            instance.last_name = params['business']['last_name']
        if 'phone_no' in params['business']:
            instance.phone_no = params['business']['phone_no']
        if 'image' in request.FILES:
            instance.image = request.FILES['image']
        if 'is_active' in params['business']:
            instance.is_active = True if params['business']['is_active'] == True else False
        if 'phone_no' in params['business']:
            instance.phone_no = params['business']['phone_no']
        if 'country_code' in params['business']:
            instance.country_code = params['business']['country_code']
        instance.save()
        Address.objects.filter(
            user=instance,
        ).update(**params['address'])
        BusinessCustomer.objects.filter(
            user=instance,
        ).update(**params['business_profile'])
        instance.save()
        task_update_zoho_customer.delay(str(instance.uuid))
        return instance

    class Meta:
        model = MyUser
        fields = ("id", "uuid", "first_name", "last_name", "is_active")


class TicketNoteSerializers(serializers.ModelSerializer):
    user = TicketCretedByDetailsSerializer(read_only=True)

    class Meta:
        model = TicketNote
        fields = "__all__"

    def create(self, validated_data):
        request = self.context.get('request')

        try:
            instance = TicketNote.objects.create(
                user=request.user,
                **validated_data
            )
            return instance
        except Exception as e:
            raise BaseCustomException(detail=e.args[0], code=400)


class ResellerSerializer(serializers.ModelSerializer):

    # additional = serializers.SerializerMethodField()

    def update(self, instance, validated_data):
        request = self.context.get('request')
        params = request.data

        evc_number = params['detail']['win_ols_license_number']
        if evc_number != '':
            is_business_evc_customer = BusinessCustomer.objects.filter(win_ols_license_number=evc_number).exclude(
                user=request.user)
            if len(is_business_evc_customer):
                raise BaseCustomException(detail="EVC number already exists.", code=400)
            is_reseller_evc_customer = ResellerAndSubDealer.objects.filter(win_ols_license_number=evc_number).exclude(
                user=request.user)
            if len(is_reseller_evc_customer):
                raise BaseCustomException(detail="EVC number already exists.", code=400)

        if 'first_name' in params['reseller']:
            instance.first_name = params['reseller']['first_name']
        if 'last_name' in params['reseller']:
            instance.last_name = params['reseller']['last_name']
        if 'phone_no' in params['reseller']:
            instance.phone_no = params['reseller']['phone_no']
        if 'country_code' in params['reseller']:
            instance.country_code = params['reseller']['country_code']
        if 'image' in request.FILES:
            instance.image = request.FILES['image']
        if 'is_active' in params['reseller']:
            instance.is_active = True if params['reseller']['is_active'] == True else False
        Address.objects.filter(
            user=instance,
        ).update(**params['address'])

        user = ResellerAndSubDealer.objects.filter(
            user=instance,
        ).update(**params['detail'])

        evc_cred = EVCCredentials.objects.all().last()
        if evc_cred is not None and 'detail' in params and 'win_ols_license_number' \
                in params['detail'] and params['detail']['win_ols_license_number'] != '':
            is_evc_customer = is_evc_customer_exist(
                evc_cred.apiid, params['detail']['win_ols_license_number'],
                evc_cred.username, evc_cred.password)
            instance.is_evc_customer = is_evc_customer
            if is_evc_customer:
                instance.is_evc_customer = is_evc_reseller_customer_exist(
                    evc_cred.apiid, params['detail']['win_ols_license_number'],
                    evc_cred.username, evc_cred.password)
            instance.save()
            if instance.is_evc_customer:
                user = MyUser.objects.get(email=params['reseller']['email'])
                user.is_evc_reseller_customer = True
                user.save()
        else:
            instance.is_evc_customer = False
            instance.is_evc_reseller_customer = False
            instance.save()

        instance.save()

        # x_forwarded_for = request.META.get('HTTP_X_FORWARDED_FOR')
        # reseller = MyUser.objects.get(email=params['reseller']['email'])
        # AccessLogsModel.objects.create(
        #     user=self.context.get('request').user,
        #     timestamp=datetime.now(),
        #     # ip_address = x_forwarded_for.split(',')[0] if x_forwarded_for else request.META.get('REMOTE_ADDR'),
        #     method='Updated',
        #     event='Updated',
        #     module=EmailLogSettings.objects.filter(module='customer').last(),
        #     title='Reseller user Updated.',
        #     description="Reseller user updated email {0}.".format(reseller.email.lower()),
        #     customer=reseller,
        # )
        return instance

    def create(self, validated_data):
        request = self.context.get('request')
        params = request.data

        evc_number = params['detail']['win_ols_license_number']
        if evc_number != '':
            is_business_evc_customer = BusinessCustomer.objects.filter(win_ols_license_number=evc_number).exclude(
                user=request.user)
            if len(is_business_evc_customer):
                raise BaseCustomException(detail="This winols number already exists.", code=400)
            is_reseller_evc_customer = ResellerAndSubDealer.objects.filter(win_ols_license_number=evc_number).exclude(
                user=request.user)
            if len(is_reseller_evc_customer):
                raise BaseCustomException(detail="This winols number already exists.", code=400)

        params['reseller']['email'] = params['reseller'].get('email').lower()

        user = MyUser.objects.create(
            user_type=6,
            **params['reseller']
        )
        UserProfile.objects.create(
            user=user
        )
        Address.objects.create(
            user=user,
            **params['address']
        )

        ResellerAndSubDealer.objects.create(
            user=user,
            **params['detail']
        )

        evc_cred = EVCCredentials.objects.all().last()
        if evc_cred is not None and 'detail' in params and 'win_ols_license_number' \
                in params['detail'] and params['detail']['win_ols_license_number'] != '':
            is_evc_customer = is_evc_customer_exist(evc_cred.apiid, params['detail']['win_ols_license_number'],
                                                    evc_cred.username, evc_cred.password)
            user.is_evc_customer = is_evc_customer
            if is_evc_customer:
                user.is_evc_customer = is_evc_reseller_customer_exist(
                    evc_cred.apiid, params['detail']['win_ols_license_number'],
                    evc_cred.username, evc_cred.password)
            if user.is_evc_customer:
                user = MyUser.objects.get(email=params['reseller']['email'])
                user.is_evc_reseller_customer = True
                user.save()
            user.save()
        else:
            user.is_evc_customer = False
            user.is_evc_reseller_customer = False
            user.save()

        context = {
            'name': "{} {}".format(user.first_name, user.last_name),
            'link': "{}/{}/{}".format(
                settings.FRONTEND_BASE_URL,
                settings.FRONTEND_EMAIL_VERIFY_URL,
                str(user.uuid)
            ),
            'frontend_url': 'www.viezu-files.com',
        }
        get_template = render_to_string('email_template/welcome.html', context)
        SendMail.mail(resp_msg.SUBJECT_NEW_USER_ONBOARD, user.email, get_template)

        x_forwarded_for = request.META.get('HTTP_X_FORWARDED_FOR')
        AccessLogsModel.objects.create(
            user=self.context.get('request').user,
            timestamp=datetime.now(),
            # ip_address = x_forwarded_for.split(',')[0] if x_forwarded_for else request.META.get('REMOTE_ADDR'),
            method='created',
            event='Reseller user registered',
            module=EmailLogSettings.objects.filter(module='customer').last(),
            title='Reseller user registered.',
            description="Reseller user registered with email {0}.".format(params['reseller'].get('email').lower()),
            customer=user,
        )

        return user

    # def get_additional(self,obj):
    #     additional = {}
    #     if obj.get_user_type_display() == "RESELLER":
    #         data = ResellerAndSubDealer.objects.get(user=obj)
    #         additional["bussness_name"] = data.bussness_name
    #         additional["tax_number"] = data.tax_number
    #         additional["company_number"] = data.company_number
    #         additional["win_ols_license_number"] = data.win_ols_license_number
    #     return additional

    class Meta:
        model = MyUser
        fields = ("id", "uuid", "first_name", "last_name", "email", "phone_no", "country_code")


class DealerSerializer(serializers.ModelSerializer):
    def create(self, validated_data):
        request = self.context.get('request')
        params = request.data

        evc_number = params['detail']['win_ols_license_number']
        if evc_number != '':
            is_business_evc_customer = BusinessCustomer.objects.filter(win_ols_license_number=evc_number).exclude(
                user=request.user)
            if len(is_business_evc_customer):
                raise BaseCustomException(detail="EVC number already exists.", code=400)
            is_reseller_evc_customer = ResellerAndSubDealer.objects.filter(win_ols_license_number=evc_number).exclude(
                user=request.user)
            if len(is_reseller_evc_customer):
                raise BaseCustomException(detail="EVC number already exists.", code=400)

        user = request.user
        if 'parent' in params and params['parent'] != '':
            user = MyUser.objects.get(id=params['parent'])

        params['dealer']['email'] = params['dealer'].get('email').lower()

        user = MyUser.objects.create(
            parent=user,
            user_type=7,
            **params['dealer']
        )
        UserProfile.objects.create(
            user=user
        )
        Address.objects.create(
            user=user,
            **params['address']
        )

        ResellerAndSubDealer.objects.create(
            user=user,
            **params['detail']
        )

        evc_cred = EVCCredentials.objects.all().last()
        user = MyUser.objects.get(email=params['dealer']['email'])
        if evc_cred is not None and 'detail' in params and 'win_ols_license_number' \
                in params['detail'] and params['detail']['win_ols_license_number'] != '':
            is_evc_customer = is_evc_customer_exist(evc_cred.apiid, params['detail']['win_ols_license_number'],
                                                    evc_cred.username, evc_cred.password)
            user.is_evc_customer = is_evc_customer
            if is_evc_customer:
                user.is_evc_customer = is_evc_reseller_customer_exist(
                    evc_cred.apiid, params['detail']['win_ols_license_number'],
                    evc_cred.username, evc_cred.password)
            if user.is_evc_customer:
                user = MyUser.objects.get(email=params['dealer']['email'])
                user.is_evc_reseller_customer = True
                user.save()
            user.save()
        else:
            user.is_evc_customer = False
            user.is_evc_reseller_customer = False
            user.save()

        context = {
            'name': "{} {}".format(user.first_name, user.last_name),
            'link': "{}/{}/{}".format(
                settings.FRONTEND_BASE_URL,
                settings.FRONTEND_EMAIL_VERIFY_URL,
                str(user.uuid)
            ),
            'frontend_url': 'www.viezu-files.com',
        }
        get_template = render_to_string('email_template/welcome.html', context)
        SendMail.mail(resp_msg.SUBJECT_NEW_USER_ONBOARD, user.email, get_template)

        x_forwarded_for = request.META.get('HTTP_X_FORWARDED_FOR')
        AccessLogsModel.objects.create(
            user=self.context.get('request').user,
            timestamp=datetime.now(),
            # ip_address = x_forwarded_for.split(',')[0] if x_forwarded_for else request.META.get('REMOTE_ADDR'),
            method='created',
            event='Dealer user created',
            module=EmailLogSettings.objects.filter(module='customer').last(),
            title='Dealer user registered.',
            description="Dealer user registered with email {0}.".format(params['dealer'].get('email').lower()),
            customer=user,
        )

        return user

    def update(self, instance, validated_data):
        request = self.context.get('request')
        params = request.data

        evc_number = params['detail']['win_ols_license_number']
        if evc_number != '':
            is_business_evc_customer = BusinessCustomer.objects.filter(win_ols_license_number=evc_number).exclude(
                user=request.user)
            if len(is_business_evc_customer):
                raise BaseCustomException(detail="EVC number already exists.", code=400)
            is_reseller_evc_customer = ResellerAndSubDealer.objects.filter(win_ols_license_number=evc_number).exclude(
                user=request.user)
            if len(is_reseller_evc_customer):
                raise BaseCustomException(detail="EVC number already exists.", code=400)

        if 'first_name' in params['dealer']:
            instance.first_name = params['dealer']['first_name']
        if 'last_name' in params['dealer']:
            instance.last_name = params['dealer']['last_name']
        if 'phone_no' in params['dealer']:
            instance.phone_no = params['dealer']['phone_no']
        if 'country_code' in params['dealer']:
            instance.country_code = params['dealer']['country_code']
        if 'image' in request.FILES:
            instance.image = request.FILES['image']
        if 'is_active' in params['dealer']:
            instance.is_active = True if params['dealer']['is_active'] == True else False
        Address.objects.filter(
            user=instance,
        ).update(**params['address'])

        user = ResellerAndSubDealer.objects.filter(
            user=instance,
        ).update(**params['detail'])

        evc_cred = EVCCredentials.objects.all().last()
        user = MyUser.objects.get(email=params['dealer']['email'])
        if evc_cred is not None and 'detail' in params and 'win_ols_license_number' \
                in params['detail'] and params['detail']['win_ols_license_number'] != '':
            is_evc_customer = is_evc_customer_exist(
                evc_cred.apiid, params['detail']['win_ols_license_number'],
                evc_cred.username, evc_cred.password)
            user.is_evc_customer = is_evc_customer
            if is_evc_customer:
                user.is_evc_customer = is_evc_reseller_customer_exist(
                    evc_cred.apiid, params['detail']['win_ols_license_number'],
                    evc_cred.username, evc_cred.password)
            if user.is_evc_customer:
                print("in exists")
                user = MyUser.objects.get(email=params['dealer']['email'])
                user.is_evc_customer = True
                user.is_evc_reseller_customer = True
                user.save()
            user.save()
        else:
            user.is_evc_customer = False
            user.is_evc_reseller_customer = False
            user.save()

        instance.save()

        x_forwarded_for = request.META.get('HTTP_X_FORWARDED_FOR')
        # subdealer = MyUser.objects.get(email=params['dealer']['email'])
        # AccessLogsModel.objects.create(
        #     user=self.context.get('request').user,
        #     timestamp=datetime.now(),
        #     # ip_address = x_forwarded_for.split(',')[0] if x_forwarded_for else request.META.get('REMOTE_ADDR'),
        #     method='Updated',
        #     event='Updated',
        #     module=EmailLogSettings.objects.filter(module='customer').last(),
        #     title='Sub-dealer user Updated.',
        #     description="Sub-dealer user updated email {0}.".format(subdealer.email.lower()),
        #     customer=subdealer,
        # )
        return instance

    class Meta:
        model = MyUser
        fields = ("id", "uuid", "first_name", "last_name", "email", "phone_no", "mobile_no", "country_code")


class CustomFilterSerializers(serializers.ModelSerializer):
    class Meta:
        model = CustomFilter
        fields = "__all__"


class VehicleListControlSerializer(serializers.ModelSerializer):
    # vehicle_type_pk = serializers.SerializerMethodField()
    vehicle_type = serializers.SerializerMethodField()
    vehicle_brand = serializers.SerializerMethodField()
    vehicle_model = serializers.SerializerMethodField()

    class Meta:
        model = VehicleControl
        fields = "__all__"

    # def get_vehicle_type_pk(self, obj):
    #     return obj.vehicle_model.vehicle_brand.vehicle_type.pk

    def get_vehicle_type(self, obj):
        return obj.vehicle_model.vehicle_brand.vehicle_type.name

    def get_vehicle_brand(self, obj):
        return obj.vehicle_model.vehicle_brand.brand_name

    def get_vehicle_model(self, obj):
        return obj.vehicle_model.model_name


class ManageDashboardSerializer(serializers.ModelSerializer):
    class Meta:
        model = ManageDashboard
        fields = "__all__"


class TicketGroupSerializer(serializers.ModelSerializer):
    class Meta:
        model = TicketGroup
        fields = "__all__"
