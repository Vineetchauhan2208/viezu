import django_filters
from django.db.models import Avg, F, Count
from apps.account.models import MyUser,AccessLogsModel
from .models import Template, TicketHistory



class LogsFilter(django_filters.FilterSet):
    created_at = django_filters.DateFromToRangeFilter()

    class Meta:
        model = AccessLogsModel
        fields = ('created_at', )


class RoleFilter(django_filters.FilterSet):

    roles = django_filters.CharFilter(field_name='roles', method='filter_roles')
    def filter_roles(self, queryset, name, value):
        return queryset.filter(roles=value)
    
    user_type = django_filters.CharFilter(field_name='user_type', method='filter_user_type')
    def filter_user_type(self, queryset, name, value):
        return queryset.filter(user_type=value)

    class Meta:
        model = MyUser
        fields = ('roles', 'user_type')


class TemplateCategoryFilter(django_filters.FilterSet):
    name = django_filters.CharFilter(field_name='name', method='filter_name')
    def filter_name(self, queryset, name, value):
        return queryset.filter(category__id=value)

    class Meta:
        model = Template
        fields = ('name', )


class AdminTicketFilter(django_filters.FilterSet):
    created_at = django_filters.DateRangeFilter()

    status = django_filters.CharFilter(field_name='status', method='filter_status')

    category = django_filters.CharFilter(field_name='category', method='filter_category')
    def filter_category(self, queryset, name, value):
        return queryset.filter(category__id=value)

    def filter_status(self, queryset, name, value):
        list_of_ids = value.split(',')
        if '0' in list_of_ids:
            null_queryset =  queryset.filter(ticket_status__isnull=True)
            queryset =  queryset.filter(ticket_status__id__in=list_of_ids)
            return queryset | null_queryset
        return  queryset.filter(ticket_status__id__in=list_of_ids)
    

    class Meta:
        model = TicketHistory
        fields = ('status', 'category','created_at')