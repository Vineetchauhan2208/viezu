from django.urls import include, path
from rest_framework.routers import DefaultRouter
from apps.admin_management import views

app_name = 'admin'

router = DefaultRouter()
router.register(r'roles', views.CreateRoleView)
router.register(r'role-and-permissions', views.RolesAndPermissionsViews)
router.register(r'product', views.ViezuProductView)
router.register(r'template', views.TemplateView)
router.register(r'ticket-status', views.TicketStatusView)

router.register(r'template-category', views.TemplateCategoryView)
router.register(r'ticket-category', views.TicketCategoryView)

router.register(r'email-log-settings', views.EmailLogSettingsView)
router.register(r'ticket', views.TicketView)
# router.register(r'reseller', views.ResellerView)


common_urlpatterns = [
    path('', include(router.urls)),
    path('profile', views.ProfileView.as_view()),
    path('template/share', views.TemplateShareView.as_view()),
    path('ticket/custom/data', views.TemplateCustomView.as_view()),
    path('dashboard/manage', views.ManageDashboardView.as_view()),
    path('ticket/status/count', views.TicketCategoryCount.as_view()),
    path('roles/delete/<int:id>', views.DeleteRoleView.as_view())
]

log_urlpatterns = [
    path('logs', views.LogsListView.as_view()),
    path('customer/timeline/<str:uuid>', views.CustomerLogsViews.as_view({"get": 'timeline'})),
    path('logs/csv/download', views.LogsDownloadListView.as_view()),
    path('logs/<int:id>', views.LogsRetriveView.as_view()),
    path('reseller/logs', views.ResellerLogsListView.as_view()),
    path('reseller/logs/<int:id>', views.ResellerLogsReteriveView.as_view()),
]

ticket_urlpatterns = [
    path('assign-ticket-history/<str:ids>', views.AssignTicketHistoryView.as_view()),
    path('update-ticket-history/<str:ids>', views.UpdateTicketHistoryView.as_view()),
    path('ticket/note/create', views.TicketNoteCreateView.as_view()),
    path('ticket/note/list/<int:ticket>', views.TicketNoteListView.as_view()),
    path('custom/filter', views.AdminFilterView.as_view()),
    path('ticket/status_update/file_request', views.FRStatusUpdateTicketView.as_view()),
    path('ticket/search', views.TicketSearchView.as_view({'get': 'list',})),
    path('ticket/filter_by_status', views.TicketFilterByStatusView.as_view()),
    path('ticket/filter_ticket', views.TicketFilterView.as_view()),
    path('ticket/update/request_id', views.UpdateRequestInTicketView.as_view()),
    path('ticket/update/status', views.UpdateTicketStatusView.as_view()),
    path('close-slots', views.CloseSlotsView.as_view()),

]

internal_team_urlpatterns = [
    path('users-by-role/<int:id>', views.GetUsersByRoleView.as_view()),
    path('internal-team/<str:ids>', views.GetInternalTeamView.as_view()),
]

customer_url_patterns = [
    path('customer', views.CustomerViews.as_view({'get': 'list',})),
    path('customer/<str:uuid>', views.CustomerViews.as_view({
        "get": 'retrieve', 'put': 'update', 'patch': 'update'
    })),
    path('customer/import/individual/', views.CustomerImportIndividualViews.as_view()),
    path('customer/import/business/', views.CustomerImportBusinessViews.as_view()),
    path('customer/import/reseller/', views.CustomerImportResellerViews.as_view()),
    path('customer/import/sub_dealer/', views.CustomerImportSubDealerViews.as_view()),

    path('reseller/', views.ResellerView.as_view()),
    path('dealer', views.DealerView.as_view()),
    path('dealer/<str:uuid>/', views.DealerListView.as_view()),
    path('reseller/customer/list', views.ResellerCustomerListViews.as_view({'get': 'list',})),
]

vehicle_patterns = [
    path('vehicle/ecu-version', views.VehicleEcuVersion.as_view()),
    path('vehicle/ecu-brand', views.VehicleBrandVersion.as_view()),
    path('vehicle/create/new', views.CreateNewVehicleView.as_view()),
    path('vehicle/list', views.VehicleListView.as_view()),
    path('vehicle/import/csv', views.ImportVehicleCSVView.as_view()),
    path('vehicle/testing/control', views.TestingContorlUnit.as_view()),
]

kb_patterns = [
    path('articles/add-update', views.CreateUpdateKBView.as_view()),
]

directory_patterns = [
    path('main/directory/', views.ListMainDirectoryView.as_view()),
    path('main/directory/keys', views.ListMainDirectoryKeysView.as_view()),
    path('main/directory/search_by_dir_name', views.SearchDirectoryNameView.as_view()),
    path('main/directory/filter/vehicle', views.FilterByVehicleDirectoryView.as_view()),
    path('main/directory/filter_by_ecu', views.FilterByECUView.as_view()),
    path('sub/directory/', views.ListSubDirectoryView.as_view()),

    path('main/directory/delete/<str:id>', views.DeleteDirectoryOrFileView.as_view()),

    path('main/directory/list', views.ListDirectoryOrFileView.as_view()),
    path('main/directory/file/download', views.DownloadS3FileView.as_view()),
    path('main/directory/file/rename', views.RenameS3FileView.as_view()),

    path('main/directory/file/delete', views.DeleteS3FileView.as_view()),
    path('main/directory/file/upload', views.UploadS3FileView.as_view()),
    path('main/directory/create', views.CreateS3DirectoryView.as_view()),
    path('main/directory/zip_upload', views.S3ZIPFilesUploadView.as_view()),
    path('main/directory/sync', views.SyncDirectoryView.as_view()),
    path('main/directory/sync-bigquery', views.SyncDirectoryBigQueryView.as_view()),
    path('main/directory/mongo', views.UploadDirectoryMongoView.as_view()),
    path('main/directory/mongo/filesize', views.MongoFileSizeView.as_view()),
    path('main/remove/duplicate', views.RemoveDuplicateDir.as_view()),
]

ticket_grouping = [
    path('ticket/group', views.TicketGroupView.as_view()),
    path('ticket/group/list_by_role', views.TicketGroupByroleView.as_view()),
    path('ticket/active/filter', views.TicketActiveFilterView.as_view()),
    path('ticket/active/filter_for_user', views.TicketActiveFilterForUserView.as_view()),
]

data_clean_api = [
    path('directory/delete_by_filemaker', views.DeleteFileMakerDirectory.as_view()),
]

urlpatterns = (
    common_urlpatterns + ticket_urlpatterns + internal_team_urlpatterns +
    customer_url_patterns + log_urlpatterns + kb_patterns+directory_patterns +
    vehicle_patterns + ticket_grouping + data_clean_api
)
