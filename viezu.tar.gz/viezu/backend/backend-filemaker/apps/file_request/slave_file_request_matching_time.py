import os
import numpy as np
import requests
from google.cloud import bigquery, storage, bigquery_storage

N = 7
import boto3
import pandas as pd
from django.db.models import Q
import binascii, ast
from apps.admin_management.models import (
    Directory
)
from apps.file_request.models import (
    DataEcuVersion, FileRequest
)
from django.conf import settings

from apps.file_request.utils import read_user_file_request
from apps.utils.file_utils import convert_to_n_size_block
import logging

logger = logging.getLogger('django')

session = boto3.Session(
    aws_access_key_id=settings.AWS_ACCESS_KEY_ID,
    aws_secret_access_key=settings.AWS_SECRET_ACCESS_KEY,
    region_name=settings.AWS_S3_REGION_NAME
)
s3_client = session.client('s3')


def slave_kess3_file_matching_flow(file_request_id, file, submit_file):
    uploaded_file_name = submit_file
    file_size_byte = submit_file.size
    file_request_obj = FileRequest.objects.get(request_id=file_request_id)
    data = read_user_file_request(file_request_id)
    decoded_file_hexa_dump = binascii.hexlify(file.read()).decode()
    decoded_file_hexa_dump_list = convert_to_n_size_block(decoded_file_hexa_dump, 20)
    directories_to_search = search_based_on_form_data(file_request_obj, data)
    matching_original_data = []
    if len(directories_to_search) > 0:
        df = get_gcp_original_files(directories_to_search, file_size_byte)
        if len(df) > 0:
            try:
                matching_original_data = get_matching_ratio_df(
                    df,
                    decoded_file_hexa_dump_list)
            except Exception as error:
                logger.error("get matching ratio error:{}".format(error))
    else:
        print("Empty directories_to_search")
    if len(matching_original_data) == 0:
        print("Empty matching_original_data")
    else:
        print(matching_original_data)
        df = get_gcp_version_files(matching_original_data['matching_directory'], file_request_obj)
        version_data = []
        if len(df) > 0:
            version_data = match_version_files(matching_original_data, df)
        if len(version_data) == 0:
            print("Empty version_data")
        else:
            print(version_data)
            version_file_hexa_list = version_data['version_file_hexa_list']
            original_file_hexa_list = matching_original_data['matching_original_file_hexa_list']
            # decoded file hexadump.
            similar_original_file_hexadump_list = decoded_file_hexa_dump_list
            updated_similar_hexa_bytes = add_diff_to_similar_original_index_bytes(
                version_file_hexa_list, original_file_hexa_list,
                similar_original_file_hexadump_list, file_request_obj)
            try:
                additional_function = file_request_obj.additional_function
                if additional_function is not None:
                    additional_function = additional_function.split(",")
                    additional_function = list(
                        map(lambda function_name: function_name.upper().strip(), additional_function))
                else:
                    additional_function = []
                tuning_required = file_request_obj.tuning_required
                search_terms = ''
                if tuning_required == "VBLUE/ECO":
                    search_terms = "ECONOMY"
                elif tuning_required == "VBLEND/STAGE 0.5":
                    search_terms = "BLEND"
                elif tuning_required == "VPERF/STAGE 1":
                    search_terms = "PERFORMANCE"
                elif tuning_required == "VRACE/STAGE 2":
                    search_terms = "vrace"
                elif tuning_required == "NO TUNE":
                    search_terms = ''
                print(uploaded_file_name)
                uploaded_file_name_str = uploaded_file_name.name.upper()
                filename = uploaded_file_name_str + ' ' + search_terms
                if additional_function:
                    filename += ' ' + ' '.join(additional_function)
                print(filename)
            except Exception as error:
                logger.error(error)
            print("done")


def search_based_on_form_data(file_request_obj, data):
    logger.info("Step 9: Search ECU brand and ECU version from the files on cloud.")
    directories_to_search = []
    vehicle_type = file_request_obj.vehicle_type
    queryset = Directory.objects.filter(
        ecu_producer__exact=data['ecu_brand'],
        ecu_build__exact=data['ecu_version'],
        vehicle_type__exact=vehicle_type,
        created_by_filemaker=False
    ).values('directory_path')

    # Get the latest directory if available
    if len(queryset) != 0:
        directories_to_search = [dir['directory_path'] for dir in queryset]
    return directories_to_search


def get_gcp_original_files(prefix_list, file_size_byte):
    logger.info("Step 10: Search for all related original files in the database")
    os.environ['GOOGLE_CLOUD_PROJECT'] = 'bigquery-project-437912'
    os.environ['GOOGLE_APPLICATION_CREDENTIALS'] = 'file-matching-43da45e9f9b8.json'
    client = bigquery.Client()
    dataset_id = 'filemaker_directory'
    table_id = 'file_data'
    prefix_without_main = [prefix.replace('Main/', '') for prefix in prefix_list]
    query = f"""
        SELECT directory_name, file_name, hex_block
        FROM `{dataset_id}.{table_id}`
        WHERE directory_name IN UNNEST(@prefixes)
        AND lower(file_name) LIKE lower('%original%')
        AND file_size_bytes between @lower_file_size AND @submitted_file_size_bytes
        """

    job_config = bigquery.QueryJobConfig(
        query_parameters=[
            bigquery.ArrayQueryParameter("prefixes", "STRING", prefix_without_main),
            bigquery.ScalarQueryParameter("lower_file_size", "INT64", file_size_byte - 200000),
            bigquery.ScalarQueryParameter("submitted_file_size_bytes", "INT64", file_size_byte)
        ]
    )
    query_job = client.query(query, job_config=job_config)
    bqstorageclient = bigquery_storage.BigQueryReadClient()
    all_dataframes = query_job.to_dataframe(bqstorage_client=bqstorageclient)
    if not all_dataframes.empty:
        print("Total original files fetched", all_dataframes.count())
        return all_dataframes
    else:
        print("No data was fetched.")
        return pd.DataFrame()


def get_matching_ratio_df(df, decoded_file_hexa_dump_list):
    logger.info("Step 12: calculate percentage match of original files.")
    original_data = {}
    try:
        df["percentage"] = df.apply(
            lambda row: get_matching_ratio4(row["hex_block"], decoded_file_hexa_dump_list), axis=1
        )
        max_percentage_row = df.loc[df['percentage'].idxmax()]
    except Exception as error:
        logger.error(f"Error during matching: {error}")
        return {}

    if max_percentage_row['percentage'] == 0 or max_percentage_row['percentage'] <= 7.0:
        logger.info("No version file found or found with percentage zero.")
    else:
        original_data['matching_directory'] = max_percentage_row['directory_name']
        original_data['matching_file_name'] = max_percentage_row['file_name']
        original_data['matching_percentage'] = max_percentage_row['percentage']
        original_data['matching_original_file_hexa_list'] = max_percentage_row['hex_block']
    return original_data


def get_matching_ratio5(hexdata1, hexdata2, segment_size=20):
    def break_into_segments(hexdata, segment_size):
        segments = []
        for block in hexdata:
            segments.extend([block[i:i + segment_size] for i in range(0, len(block), segment_size)])
        return segments

    # Break down large blocks into smaller segments
    segments1 = break_into_segments(hexdata1, segment_size)
    segments2 = break_into_segments(hexdata2, segment_size)

    # Calculate the percentage match between the two sets of segments
    total_common_items = len(set(segments1) & set(segments2))
    total_distinct_items = float(len(set(segments1) | set(segments2)))

    percentage_diff = (total_common_items / total_distinct_items) * 100 if total_distinct_items != 0 else 0.0
    return percentage_diff


def get_matching_ratio4(hexdata1, hexdata2):
    total_common_items = len(set(hexdata1) & set(hexdata2))
    total_distinct_items = float(len(set(hexdata1) | set(hexdata2)))
    percentage_diff = (total_common_items / total_distinct_items) * 100
    return percentage_diff


def get_gcp_version_files(prefix_list, file_request_obj):
    prefix_list_array = [prefix_list]
    logger.info("Step 10: Search for all related version files in the database")
    os.environ['GOOGLE_CLOUD_PROJECT'] = 'bigquery-project-437912'
    os.environ['GOOGLE_APPLICATION_CREDENTIALS'] = 'file-matching-43da45e9f9b8.json'
    client = bigquery.Client()
    dataset_id = 'filemaker_directory'
    table_id = 'file_data'

    tuning_required = file_request_obj.tuning_required
    additional_function = file_request_obj.additional_function
    additional_function = get_upper_additional_function(additional_function)
    print(additional_function)
    search_terms = get_search_terms(tuning_required)
    tuning_term = search_terms.upper()
    print(tuning_term)

    if len(additional_function) > 0 and (tuning_term != '' or tuning_term == ''):
        combinations, _ = get_combinations(tuning_term, additional_function)
        print(combinations)
        files_to_search = additional_search(tuning_term, combinations)
        print(files_to_search)
    elif len(additional_function) == 0 and tuning_term != '':
        updated_tuning_term = tuning_term
        files_to_search = [updated_tuning_term]
    else:
        files_to_search = prefix_list_array

    query = f"""
            SELECT directory_name, file_name, hex_block
            FROM `{dataset_id}.{table_id}`
            WHERE directory_name IN UNNEST(@prefixes)
            AND ({" OR ".join([f"LOWER(file_name) LIKE @file_search_{i}" for i in range(len(files_to_search))])})
        """

    # Add the query parameters
    query_params = [
        bigquery.ArrayQueryParameter("prefixes", "STRING", prefix_list_array)
    ]
    query_params += [
        bigquery.ScalarQueryParameter(f"file_search_{i}", "STRING", f"%{file_search.lower()}%")
        for i, file_search in enumerate(files_to_search)
    ]
    job_config = bigquery.QueryJobConfig(
        query_parameters=query_params
    )
    query_job = client.query(query, job_config=job_config)
    bqstorageclient = bigquery_storage.BigQueryReadClient()
    all_dataframes = query_job.to_dataframe(bqstorage_client=bqstorageclient)
    if not all_dataframes.empty:
        return all_dataframes
    else:
        print("No version data was fetched.")
        return pd.DataFrame()


def match_version_files(data, df):
    logger.info("Step 14: Match version files (percentage match) form the directory of original.")
    version_data = {}
    similar_original_file_hexadump_list = data['matching_original_file_hexa_list']
    try:
        df["percentage"] = df.apply(
            lambda row: get_matching_ratio4(row["hex_block"], similar_original_file_hexadump_list), axis=1
        )
        max_percentage_row = df.loc[df["percentage"].idxmax()]
    except Exception as error:
        logger.error(f"Error during matching: {error}")
        return {}
    if max_percentage_row['percentage'] == 0:
        logger.info("No version file found or found with percentage zero.")
    else:
        version_data['version_matching_directory'] = max_percentage_row['directory_name']
        version_data['version_matching_file_name'] = max_percentage_row['file_name']
        version_data['version_matching_percentage'] = max_percentage_row['percentage']
        version_data['version_file_hexa_list'] = max_percentage_row['hex_block']

    return version_data


def add_diff_to_similar_original_index_bytes(
        version_hexa, new_version_hexa,
        similar_hexa, file_request_obj):
    logger.info("Step 15: Copy the content onto another file and create.")

    version_hexa_str = "".join(version_hexa)
    version_bytes = binascii.unhexlify(version_hexa_str)

    new_file_version_str = "".join(new_version_hexa)
    new_file_version_bytes = binascii.unhexlify(new_file_version_str)

    similar_file_version_str = "".join(similar_hexa)
    similar_file_version_bytes = binascii.unhexlify(similar_file_version_str)
    similar_file_version_bytes_array = list(similar_file_version_bytes)

    min_len = min(len(version_bytes), len(new_file_version_bytes), len(similar_file_version_bytes_array))
    count = 0
    for i in range(min_len):  # use smaller length
        if i >= len(similar_file_version_bytes_array):
            logger.warning(f"Index {i} out of range for similar_file_version_bytes_array")
            break
        if (version_bytes[i] != new_file_version_bytes[i]):
            similar_file_version_bytes_array[i] = version_bytes[i]
            count += 1
    result = bytes(similar_file_version_bytes_array)
    return result


def get_combinations(tuning_term: str, additional_function: list):
    from itertools import permutations

    tuning_list = [tuning_term]
    combinations_to_list = tuning_list + additional_function
    combinations = permutations(combinations_to_list, 2)
    return combinations, combinations_to_list


def additional_search(tuning_term: str, combinations: object):
    files_to_search = []

    for comb in combinations:
        if tuning_term != '' and tuning_term in comb:
            str = " ".join(list(comb))
            files_to_search.append(str)
        if tuning_term == '' and '' not in comb:
            str = " ".join(list(comb))
            files_to_search.append(str)
        if tuning_term == '' and '' in comb:
            str = " ".join(list(comb)).strip()
            files_to_search.append(str)

    return files_to_search


def get_upper_additional_function(additional_function):
    """ Get uppercase additional function.  """

    if additional_function is not None:
        additional_function = additional_function.split(",")
        additional_function = list(map(lambda function_name: function_name.upper().strip(), additional_function))
    else:
        additional_function = []

    return additional_function


def get_search_terms(tuning_required):
    if tuning_required == "VBLUE/ECO":
        search_terms = "vblue"
    elif tuning_required == "VBLEND/STAGE 0.5":
        search_terms = "vblend"
    elif tuning_required == "VPERF/STAGE 1":
        search_terms = "vperf"
    elif tuning_required == "VRACE/STAGE 2":
        search_terms = "vrace"
    elif tuning_required == "NO TUNE":
        search_terms = ''
    return search_terms
