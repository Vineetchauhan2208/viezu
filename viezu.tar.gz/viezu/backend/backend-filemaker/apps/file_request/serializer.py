from apps.account.models import MyUser
from apps.admin_management.models import TicketCategory, TicketHistory, TicketStatus
from apps.customer.models import CustomerSpentHistory
from apps.utils.mailer import file_request_created_with_another, file_request_status_change
from rest_framework import serializers
from apps.utils.custom_exception import BaseCustomException
from .models import (FileRequest, FileRequestFormData, RefrenceMadeFile,
                     VehicleType, VehicleBrand,
                     VehicleModel, VehicleControl, FileRequestHistory,
                     DataEcuBrand, DataEcuVersion, VehicleManagement
                     )
from apps.account.serializer import UserDetailSerializer
from apps.account.models import BusinessCustomer
import apps.file_request.master_file_stages_flow as file_stage
from apps.utils.tasks import task_algo_master_file_matching, task_decode_slave_file_from_resubmit
from apps.utils.tasks import task_algo_slave_file_matching
from apps.file_request.models import RequestDownloadFiles
from apps.utils.custom_exception import BaseCustomException
from urllib.parse import quote
from apps.utils.helper import create_notification
import logging
logger = logging.getLogger('django')

def clean_user_uploaded_file_name(file_name):
    # Handle "original" in the file name
    if "original" in file_name:
        f = file_name.replace("original", "(original)")
    else:
        f = file_name

    # Split the file name into the name and extension
    upper_file_name = f.upper()
    splitted_file_name = upper_file_name.rsplit(".", 1)  # Use rsplit to split into name and extension

    # Rebuild the file name based on the conditions
    if "OLS" in splitted_file_name[0]:
        file_name = splitted_file_name[0].replace("OLS", ".ols")
    else:
        file_name = splitted_file_name[0]  # This is the part before the extension

    return file_name


class VehicleRequestSerializer(serializers.Serializer):
    customer_first_name = serializers.CharField(max_length=100, required=False)
    customer_last_name = serializers.CharField(max_length=100, required=False)
    vehicle_type = serializers.CharField(max_length=100, required=True)
    vehicle_make = serializers.CharField(max_length=100, required=True)
    model = serializers.CharField(max_length=100, required=True)
    vehicle_registration = serializers.CharField(max_length=100, required=True)
    vehicle_year = serializers.IntegerField()
    vehicle_VIN = serializers.CharField(max_length=100)
    engine_size = serializers.CharField(max_length=100)
    transmission = serializers.CharField(max_length=100)
    fuel_type = serializers.CharField(max_length=100)
    mileage_type = serializers.CharField()
    mileage = serializers.FloatField()
    ecu_brand = serializers.CharField(max_length=100)
    ecu_version = serializers.CharField(max_length=100)
    control_unit = serializers.CharField(max_length=100)

    tuning_tool_used = serializers.CharField(max_length=255)
    tuning_required = serializers.CharField(max_length=255)
    country = serializers.CharField(max_length=100)
    file_type = serializers.CharField(max_length=100)

    additional_info = serializers.CharField(max_length=2000, required=False)
    tuning_file = serializers.FileField(required=False)
    request_id = serializers.CharField(max_length=100, required=False)
    request_type = serializers.CharField(max_length=100, required=False)
    file_key_credit = serializers.IntegerField(required=False)
    function_credit = serializers.IntegerField(required=False)
    additional_function = serializers.CharField(max_length=255, required=False)
    ticket_id = serializers.CharField(max_length=255, required=False)
    other_fields = serializers.CharField(max_length=255, required=False)

    def create(self, validated_data):
        try:
            logger.info("Inside create function for create file request")
            ticket_id = None
            tk=None
            send_email_for_fr = False
            request = self.context.get('request')
            original_file_hexadump = self.context.get('original_file_hexadump')
            original_file_hexadump_list = self.context.get('original_file_hexadump_list')
            file_size_mb = self.context.get('file_size_mb')

            user = request.user
            logger.info(f"User : {user}")
            if 'file_key_credit' in validated_data:
                validated_data.pop('file_key_credit')

            if 'function_credit' in validated_data:
                validated_data.pop('function_credit')

            if 'ticket_id' in validated_data:
                send_email_for_fr = True
                tk = TicketHistory.objects.get(ids=validated_data['ticket_id'])
                tk.ticket_status = TicketStatus.objects.get(team_status="Re-submitted - File Maker")
                tk.save()

                user = tk.file_request.user

            if 'ticket_id' in validated_data:
                ticket_id = validated_data['ticket_id']
                validated_data.pop('ticket_id')

            file_request = FileRequest.objects.create(**validated_data, user=user, file_size=file_size_mb)
            file_request.generate_unique_id()
            logger.info(f"file_request : {file_request}")

            if tk:
                file_history = FileRequestHistory.objects.create(
                    file_request_id=file_request,
                    title="File request details updated.",
                    description=f"File request update from ticket : {tk.ids} | Original File request: {file_request.request_id}",
                    is_success=True,
                    url=file_request.tuning_file.url if file_request.tuning_file else None
                )
                logger.info(f"file_history = {file_history}")
                assigned_to = tk.created_by if tk.assigned_to.id == request.user.id else tk.assigned_to
                create_notification(assigned_to,
                    "Ticket is Re-submitted with new File request Generated : {}".format(file_request.request_id),
                    "Ticket Re-submitted by {} {}.".format(request.user.first_name,
                                                                            request.user.last_name),
                    sender=request.user,
                    ticket=tk, file=None)
            else:
                file_history = FileRequestHistory.objects.create(
                    file_request_id=file_request,
                    title="File submitted by user.",
                    description=file_stage.MASTER_FILE_STAGE_1,
                    is_success=True,
                    url=file_request.tuning_file.url if file_request.tuning_file else None
                )
                logger.info(f"file_history = {file_history}")

            # if file submitted save content to database.
            file_request.file_hexa_content = original_file_hexadump
            file_request.file_hexa_content_list = original_file_hexadump_list
            file_request.save()
            logger.info(f"if file request id generate {file_request} than save hexadump file list in file request object")
            
            if ticket_id is not None:
                ticket_instance = TicketHistory.objects.get(ids=ticket_id)
                ticket_instance.admin_ticket.add(file_request)

            file_name = file_request.tuning_file.url.split('/')[-1]
            logger.info(f"file_name for file request {file_request} : {file_name}")

            file_name = clean_user_uploaded_file_name(file_name)
            logger.info(f"Clean user uploaded file_name for file request {file_request} : {file_name}")
            
            file_request_download_file = RequestDownloadFiles.objects.create(
                fil_request_id=file_request,
                title=file_name,
                url=file_request.tuning_file.url,
                sent_to_user=True
            )
            logger.info(f"file_request_download_file for file request {file_request} : {file_request_download_file}\n Call file request status change")
            
            file_request_status_change(user, file_request)

            if send_email_for_fr:
                old_fr = FileRequest.objects.get(request_id=tk.file_request.request_id)
                old_fr.status = 'CANCELLED'
                old_fr.save()
                previous_fr_id = tk.file_request.request_id
                previous_fr_id_status = tk.file_request.status
                file_request_created_with_another(user, previous_fr_id, previous_fr_id_status, file_request)

            is_master_file = file_request.file_type
            logger.info(f"is_master_file : {is_master_file}")

            if is_master_file == "Master":
                print("master task")
                task_algo_master_file_matching.delay(file_request.request_id)
            elif is_master_file == "Client/Slave":
                print(f"Inside slave task for file request {file_request}")
                task_algo_slave_file_matching.delay(file_request.request_id)
                # task_algo_slave_file_matching(file_request.request_id)

            return file_request
        except Exception as e:
            raise BaseCustomException(detail=e.args[0], code=400)


class FileRequestMatchingTimeSerializer(serializers.Serializer):
    # Define your fields here
    decoded_file = serializers.FileField()
    submit_file = serializers.FileField(required=False)
    file_request_id = serializers.IntegerField()


class VehicleRequestReSubmitSerializer(serializers.Serializer):
    customer_first_name = serializers.CharField(max_length=100, required=False)
    customer_last_name = serializers.CharField(max_length=100, required=False)
    vehicle_type = serializers.CharField(max_length=100, required=True)
    vehicle_make = serializers.CharField(max_length=100, required=True)
    model = serializers.CharField(max_length=100, required=True)
    vehicle_registration = serializers.CharField(max_length=100, required=True)
    vehicle_year = serializers.IntegerField()
    vehicle_VIN = serializers.CharField(max_length=100)
    engine_size = serializers.CharField(max_length=100)
    transmission = serializers.CharField(max_length=100)
    fuel_type = serializers.CharField(max_length=100)
    mileage_type = serializers.CharField()
    mileage = serializers.FloatField()
    ecu_brand = serializers.CharField(max_length=100)
    ecu_version = serializers.CharField(max_length=100)
    control_unit = serializers.CharField(max_length=100)

    tuning_tool_used = serializers.CharField(max_length=255)
    tuning_required = serializers.CharField(max_length=255)
    country = serializers.CharField(max_length=100)
    file_type = serializers.CharField(max_length=100)

    additional_info = serializers.CharField(max_length=2000, required=False)
    tuning_file = serializers.FileField(required=False)
    request_id = serializers.CharField(max_length=100, required=False)
    request_type = serializers.CharField(max_length=100, required=False)
    additional_function = serializers.CharField(max_length=255, required=False)
    ticket_id = serializers.CharField(max_length=255, required=False)
    other_fields = serializers.CharField(max_length=255, required=False)

    def create(self, validated_data):
        ticket_id = None
        request = self.context.get('request')
        original_file_hexadump = self.context.get('original_file_hexadump')
        original_file_hexadump_list = self.context.get('original_file_hexadump_list')
        file_size_mb = self.context.get('file_size_mb')

        if 'other_fields' not in validated_data:
            raise BaseCustomException(detail="No other fields found in submission.", code=400)

        if 'other_fields' in validated_data:
            if validated_data['other_fields'] is None or validated_data['other_fields'] == '':
                raise BaseCustomException(detail="No other fields found in submission.", code=400)

        user = request.user
        if 'ticket_id' in validated_data:
            tk = TicketHistory.objects.get(ids=validated_data['ticket_id'])
            user = tk.file_request.user

        if 'ticket_id' in validated_data:
            ticket_id = validated_data['ticket_id']
            validated_data.pop('ticket_id')

        try:
            file_request = FileRequest.objects.create(**validated_data, user=user, file_size=file_size_mb)
            file_request.generate_unique_id()

            FileRequestHistory.objects.create(
                file_request_id=file_request,
                title="File submitted by user.",
                description=file_stage.MASTER_FILE_STAGE_1,
                is_success=True,
                url=file_request.tuning_file.url if file_request.tuning_file else None
            )

            # if file submitted save content to database.
            file_request.file_hexa_content = original_file_hexadump
            file_request.file_hexa_content_list = original_file_hexadump_list
            file_request.save()

            if ticket_id is not None:
                ticket_instance = TicketHistory.objects.get(ids=ticket_id)
                ticket_instance.admin_ticket.add(file_request)

            file_name = file_request.tuning_file.url.split('/')[-1]
            file_name = clean_user_uploaded_file_name(file_name)

            RequestDownloadFiles.objects.create(
                fil_request_id=file_request,
                title=file_name,
                url=file_request.tuning_file.url,
                sent_to_user=True
            )

            ai_admin = MyUser.objects.get(email='technical@viezu.com') if MyUser.objects.filter(
                email='technical@viezu.com').exists() else None
            ticket = TicketHistory.objects.create(
                created_by=user,
                assigned_to=ai_admin,
                category=TicketCategory.objects.get(name="Support"),
                file_request=file_request if file_request is not None else None,
                request_id=file_request.request_id if file_request is not None else None,
                ticket_status=TicketStatus.objects.get(team_status="New"),
            )
            ticket.update_ids()

            task_decode_slave_file_from_resubmit.delay(file_request.request_id)

            return file_request
        except Exception as e:
            raise BaseCustomException(detail=e.args[0], code=400)


class VehicleRequestSlaveOtherSerializer(serializers.Serializer):
    customer_first_name = serializers.CharField(max_length=100, required=False)
    customer_last_name = serializers.CharField(max_length=100, required=False)
    vehicle_type = serializers.CharField(max_length=100, required=True)
    vehicle_make = serializers.CharField(max_length=100, required=True)
    model = serializers.CharField(max_length=100, required=True)
    vehicle_registration = serializers.CharField(max_length=100, required=True)
    vehicle_year = serializers.IntegerField()
    vehicle_VIN = serializers.CharField(max_length=100)
    engine_size = serializers.CharField(max_length=100)
    transmission = serializers.CharField(max_length=100)
    fuel_type = serializers.CharField(max_length=100)
    mileage_type = serializers.CharField()
    mileage = serializers.FloatField()
    ecu_brand = serializers.CharField(max_length=100)
    ecu_version = serializers.CharField(max_length=100)
    control_unit = serializers.CharField(max_length=100)

    tuning_tool_used = serializers.CharField(max_length=255)
    tuning_required = serializers.CharField(max_length=255)
    country = serializers.CharField(max_length=100)
    file_type = serializers.CharField(max_length=100)

    additional_info = serializers.CharField(max_length=2000, required=False)
    tuning_file = serializers.FileField(required=False)
    request_id = serializers.CharField(max_length=100, required=False)
    request_type = serializers.CharField(max_length=100, required=False)
    additional_function = serializers.CharField(max_length=255, required=False)
    ticket_id = serializers.CharField(max_length=255, required=False)
    other_fields = serializers.CharField(max_length=255, required=False)

    def create(self, validated_data):
        try:
            logger.info("Inside create method--")
            ticket_id = None
            request = self.context.get('request')
            original_file_hexadump = self.context.get('original_file_hexadump')
            original_file_hexadump_list = self.context.get('original_file_hexadump_list')
            file_size_mb = self.context.get('file_size_mb')

            if 'other_fields' not in validated_data:
                raise BaseCustomException(detail="No other fields found in submission.", code=400)

            if 'other_fields' in validated_data:
                if validated_data['other_fields'] is None or validated_data['other_fields'] == '':
                    raise BaseCustomException(detail="No other fields found in submission.", code=400)

            user = request.user
        # try:
            file_request = FileRequest.objects.create(**validated_data, user=user, file_size=file_size_mb)
            file_request.generate_unique_id()

            logger.info(f"file request created : {file_request}")

            fr_history_created = FileRequestHistory.objects.create(
                file_request_id=file_request,
                title="File submitted by user.",
                description=file_stage.MASTER_FILE_STAGE_1,
                is_success=True,
                url=file_request.tuning_file.url if file_request.tuning_file else None
            )
            logger.info(f"fr_history_created : {fr_history_created}")

            # if file submitted save content to database.
            file_request.file_hexa_content = original_file_hexadump
            file_request.file_hexa_content_list = original_file_hexadump_list
            file_request.save()

            file_name = file_request.tuning_file.url.split('/')[-1]
            file_name = clean_user_uploaded_file_name(file_name)

            fr_download_file=RequestDownloadFiles.objects.create(
                fil_request_id=file_request,
                title=file_name,
                url=file_request.tuning_file.url,
                sent_to_user=True
            )
            logger.info(f"fr_download_file : {fr_download_file}")
            
            logger.info(f"Call Task decode slave file from resubmit function----")
            task_decode_slave_file_from_resubmit.delay(file_request.request_id)

            return file_request
        except Exception as e:
            raise BaseCustomException(detail=e.args[0], code=400)


class CustomerSpentFRSerializer(serializers.ModelSerializer):
    class Meta:
        model = CustomerSpentHistory
        fields = "__all__"


class VehicleRequestListSerializer(serializers.ModelSerializer):
    user = serializers.SerializerMethodField()
    credit_spent = serializers.SerializerMethodField()

    def get_credit_spent(self, obj):

        spent_history = CustomerSpentHistory.objects.filter(file_request_id=obj.request_id).first()

        if spent_history:
            return {
                'credit_type': spent_history.credit_type or None,  # Use dot notation
                'credit': spent_history.credit  # Use dot notation
            }

    def get_user(self, obj):
        if type(obj) == dict:
            user = MyUser.objects.get(id=obj['user'])
        else:
            user = obj.user
        company_name = None
        if user.user_type == 3 and hasattr(user, 'business_user'):
            company_name = user.business_user.bussness_name
        elif user.user_type in [6, 7] and hasattr(user, 'reseller_sub_dealer'):
            company_name = user.reseller_sub_dealer.bussness_name
        return {
            'first_name': user.first_name,
            'last_name': user.last_name,
            'email': user.email,
            'company_name': company_name
        }


    class Meta:
        model = FileRequest
        # fields = ('id','request_id','created_at', 'vehicle_type','vehicle_make','user','status',)
        fields = ("id", "request_id", "vehicle_type", "vehicle_make",
                  "model", "vehicle_registration", "vehicle_year",
                  "vehicle_VIN", "engine_size", "transmission",
                  "fuel_type", "mileage_type", "mileage",
                  "ecu_brand", "customer_first_name", "customer_last_name",
                  "ecu_version", "control_unit", "file_type",
                  "country", "tuning_tool_used", "tuning_required",
                  "additional_info", "tuning_file", "user", "status", "created_at", "credit_spent",
                  "other_fields", "additional_function")


class VehicleRequestDetailSerializer(serializers.ModelSerializer):
    user = UserDetailSerializer()

    credit_spent = serializers.SerializerMethodField()

    def get_credit_spent(self, obj):
        spent_history = CustomerSpentHistory.objects.filter(file_request_id=obj.request_id).first()

        if spent_history:
            return {
                'credit_type': spent_history.credit_type or None,  # Use dot notation
                'credit': spent_history.credit  # Use dot notation
            }

    class Meta:
        model = FileRequest
        fields = ("id", "request_id", "vehicle_type", "vehicle_make",
                  "model", "vehicle_registration", "vehicle_year",
                  "vehicle_VIN", "engine_size", "transmission",
                  "fuel_type", "mileage_type", "mileage",
                  "ecu_brand", "customer_first_name", "customer_last_name",
                  "ecu_version", "control_unit", "file_type",
                  "country", "tuning_tool_used", "tuning_required",
                  "additional_info", "additional_function", "tuning_file", "user", "credit_spent", "other_fields",)


class FileFormDatSerializer(serializers.ModelSerializer):
    class Meta:
        model = FileRequestFormData
        fields = "__all__"


class VehicleTyperSerializer(serializers.ModelSerializer):
    class Meta:
        model = VehicleType
        fields = "__all__"


class VehicleBrandSerializer(serializers.ModelSerializer):
    class Meta:
        model = VehicleBrand
        fields = "__all__"


class VehicleModelSerializer(serializers.ModelSerializer):
    class Meta:
        model = VehicleModel
        fields = "__all__"


class VehicleControlSerializer(serializers.ModelSerializer):
    class Meta:
        model = VehicleControl
        fields = "__all__"


class FileRequestHistorySerializer(serializers.ModelSerializer):
    class Meta:
        model = FileRequestHistory
        fields = "__all__"


from rest_framework import serializers
from urllib.parse import quote
import requests


class FileRequestFileDownloadSerializer(serializers.ModelSerializer):
    file_size = serializers.SerializerMethodField()

    class Meta:
        model = RequestDownloadFiles
        fields = "__all__"  # Include all fields, including file_size

    def to_representation(self, instance):
        representation = super().to_representation(instance)

        if instance.url:
            # Encode the URL to handle spaces and special characters
            encoded_url = quote(instance.url, safe=':/')
            representation['url'] = encoded_url

        # Add file size to the response
        representation['file_size'] = self.get_file_size(instance)
        representation['additional_function_list'] = self.get_additional_function(instance)
        return representation

    def get_file_size(self, obj):
        # Fetch the file size from the S3 URL using a HEAD request
        if obj.url:
            try:
                response = requests.head(obj.url)
                file_size = response.headers.get('Content-Length', None)
                if file_size:
                    return int(file_size)
            except Exception as e:
                return None
        return None

    def get_additional_function(self, obj):
        # Fetch the file request associated with the download
        file_request = obj.fil_request_id
        vehicle_make = file_request.vehicle_make
        ecu_brand = file_request.ecu_brand
        ecu_version = file_request.ecu_version
        file_request_additional_functions = file_request.additional_function or {}
        title = obj.title.lower()

        # Try to fetch the VehicleManagement entry
        try:
            vehicle_management = VehicleManagement.objects.filter(
                brand_name__iexact=vehicle_make,
                ecu_brand__iexact=ecu_brand,
                ecu_version__iexact=ecu_version
            ).first()

            # Add non-empty additional functions to a list only if they match with file_request
            additional_function_list = []

            if vehicle_management:
                if vehicle_management.dpf and "DPF" in file_request_additional_functions and "dpf" in title:
                    additional_function_list.append({"DPF": vehicle_management.dpf})
                if vehicle_management.egr and "EGR" in file_request_additional_functions and "egr" in title:
                    additional_function_list.append({"EGR": vehicle_management.egr})
                if vehicle_management.adblue and "Adblue" in file_request_additional_functions and "adblue" in title:
                    additional_function_list.append({"Adblue": vehicle_management.adblue})
                if vehicle_management.intake_flaps and "Intake Flaps" in file_request_additional_functions and "intake flaps" in title:
                    additional_function_list.append({"Intake Flaps": vehicle_management.intake_flaps})
                if vehicle_management.gpf_opf_ppf and "GPF/OPF/PPF" in file_request_additional_functions and "gpf/opf/ppf" in title:
                    additional_function_list.append({"GPF/OPF/PPF": vehicle_management.gpf_opf_ppf})

            # Return the matching additional functions
            return additional_function_list

        except VehicleManagement.DoesNotExist:
            return []


class EcuBrandSerializer(serializers.ModelSerializer):
    class Meta:
        model = DataEcuBrand
        fields = "__all__"


class EcuVersionSerializer(serializers.ModelSerializer):
    class Meta:
        model = DataEcuVersion
        fields = "__all__"

    def validate(self, validated_data):
        queryset = DataEcuVersion.objects.filter(
            brand=validated_data.get('brand'),
            ecu_version_name=validated_data.get('ecu_version_name'),
        ).exists()

        if queryset:
            raise BaseCustomException(detail="ECU version and brand already exists.", code=400)

        return validated_data

    def create(self, validated_data):
        instance, _ = DataEcuVersion.objects.get_or_create(
            brand=validated_data.get('brand'),
            ecu_version_name=validated_data.get('ecu_version_name'),
            percentage=validated_data.get('percentage')
        )
        return instance


class RefrenceMadeSerializer(serializers.ModelSerializer):
    class Meta:
        model = RefrenceMadeFile
        fields = "__all__"
