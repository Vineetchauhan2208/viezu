FILE_TYPE_CHOICES = (
    (1, 'MASTER'),
    (2, 'SLAVE'),
)

MILAGE_TYPE_CHOICES = (
    (1, 'KM'),
    (2, 'MILES'),
)
