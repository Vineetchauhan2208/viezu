from django.urls import include, path
from apps.file_request import views
from apps.file_request.additional_functions import update_vehicle_data
from apps.utils.management.commands.migrate_vehicle_management import migrate_data_to_vehicle_management, \
    MigrateVehicleDataView

app_name = 'file_request'


file_request_patterns = [
    path('request/create', views.FileRequestCreateView.as_view()),
    path('request/fr_close', views.FileRequestCloseSlot.as_view()),
    # path('request/magic-api', views.MagicFlexView.as_view()),
    path('request/create/re-submission/slave', views.FileRequestReSubmitSlaveView.as_view()),

    path('request/create/slave/other_field', views.FileRequestReSubmitSlaveOtherView.as_view()),

    path('request/history/<str:file_request_id>', views.FileRequestHistoryView.as_view()),
    path('request/resubmit/<str:file_request_id>', views.FileRequestHistoryView1.as_view()),
    path('request/list', views.FileRequestListView.as_view()),
    path('request/detail/<int:pk>', views.FileRequestDetailView.as_view()),
    path('request/files/download/<str:request_id>', views.FileRequestDownloadFilesView.as_view()),
    path('request/files/download/counter/<int:pk>', views.CounterIncreaseView.as_view()),
    path('request/files/search', views.RequestIdSearchView.as_view()),
    path('request/files/search/date', views.FileRequestDateSearchView.as_view()),
    path('request/files/error/list', views.FileRequestErrorView.as_view()),
    path('request/directory/<str:request_id>', views.FileRequestDirectoryView.as_view()),

    path('update/credit_truck_tractor', views.UpdateCreditView.as_view()),
    path('update/ecu/percentage', views.UpdateECUPercentageView.as_view()),

    path('file/refrence/list', views.RefrenceMadeListView.as_view()),
    path('file/matching-time-test', views.FileRequestMatchingTimeView.as_view()),
    path('update-vehicle-data/', update_vehicle_data, name='update_vehicle_data'),
    path('sync-vehicle-data/', MigrateVehicleDataView.as_view()),
    path('request/ticket/<str:request_id>', views.FileRequestTicketView.as_view()),
]

vehicle_patterns = [
    path('get/file_form_data', views.FileFormDataListView.as_view()),
    path('vehicle/type/list', views.VehicleTypeListView.as_view()),
    path('vehicle/brand/list/<int:pk>', views.ReteriveVehicleBrandView.as_view()),
    path('vehicle/model/list/<int:pk>', views.ReteriveVehicleModelView.as_view()),
    path('vehicle/control/list/<int:pk>', views.ReteriveVehicleControlView.as_view()),
    path('vehicle/model/create', views.CreateModelView.as_view()),
    path('vehicle/updatevehicle/', views.UpdateVehicleManagement.as_view()),
    path('vehicle/model/get_all_brands/<int:pk>', views.GetAllECUBrandByModelView.as_view()),
]

ecu_patterns = [

    path('vehicle/ecu/brand/list', views.EcuBrandListView.as_view()),
    path('vehicle/ecu/version/list/<int:pk>', views.EcuVersionListView.as_view()),
    path('vehicle/ecu/version/create', views.EcuVersionCreateView.as_view()),
    path('vehicle/ecu/version/update', views.EcuVersionUpdateView.as_view()),
]

credit_patterns = [
    path('file-credit/update', views.FileKeyUpateView.as_view()),
    path('file-request-credit/calculate', views.CreditCalculateView.as_view()),
]

urlpatterns = (
    file_request_patterns + ecu_patterns +
    vehicle_patterns + credit_patterns 
)
