import os

import pandas as pd
from django.http import JsonResponse
from django.views.decorators.csrf import csrf_exempt
from django.core.files.storage import default_storage

from file_maker_system.settings.base import BASE_DIR
from .models import VehicleManagement


@csrf_exempt
def update_vehicle_data(request):
    if request.method == 'POST':
        # Save the uploaded file
        excel_file = request.FILES['file']
        file_name = default_storage.save(f'{excel_file.name}', excel_file)
        file_path = os.path.join('media', file_name)

        # Read the Excel file into a Pandas DataFrame
        df = pd.read_excel(file_path)
        print(df.columns)

        # Iterate through each row in the DataFrame
        for index, row in df.iterrows():
            brand_name = row['brand name']
            ecu_brand = row['ecu brand']
            ecu_version = row['ecu version']

            if not brand_name or not ecu_brand or not ecu_version:
                continue

            try:
                def handle_nan(value):
                    return '' if pd.isna(value) else str(value).strip()

                cleaned_brand_name = handle_nan(brand_name)
                cleaned_ecu_brand = handle_nan(ecu_brand)
                cleaned_ecu_version = handle_nan(ecu_version)
                if cleaned_brand_name and cleaned_ecu_brand and cleaned_ecu_version:
                    vehicles = VehicleManagement.objects.filter(
                        brand_name__iexact=brand_name, ecu_brand__iexact=ecu_brand, ecu_version__iexact=ecu_version
                    )

                    if vehicles.exists():
                        for vehicle in vehicles:
                            print(vehicle.brand_name, vehicle.ecu_brand, vehicle.ecu_version)
                            vehicle.dpf = ', '.join(
                                filter(None, [handle_nan(row.get('DPF', '')), handle_nan(row.get('DPF.1', ''))]))
                            vehicle.egr = handle_nan(row.get('EGR ', ''))  # Handle the EGR field with trailing space
                            vehicle.adblue = ', '.join(filter(None, [handle_nan(row.get('Adblue', '')),
                                                                     handle_nan(row.get('Adblue.1', '')),
                                                                     handle_nan(row.get('Adblue.2', ''))]))
                            vehicle.intake_flaps = handle_nan(row.get('Intake flaps', ''))  # Handle intake flaps
                            vehicle.gpf_opf_ppf = ', '.join(filter(None, [handle_nan(row.get('Gpf opf ppf', '')),
                                                                          handle_nan(row.get('Gpf opf ppf.1', ''))]))

                            print(vehicle.dpf, vehicle.egr, vehicle.adblue, vehicle.intake_flaps, vehicle.gpf_opf_ppf)
                            vehicle.save()

            except VehicleManagement.DoesNotExist:
                pass
        return JsonResponse({'message': 'Vehicles data updated successfully'})

    return JsonResponse({'error': 'Invalid request method'}, status=400)
