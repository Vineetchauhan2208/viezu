import ast
import os

from google.cloud import bigquery, bigquery_storage

from apps.utils.file_utils import get_ticket_description
from apps.utils.mailer import file_request_status_change
import boto3
import binascii
import pandas as pd
from django.conf import settings
import apps.file_request.master_file_stages_flow as file_stage

from apps.file_request.models import (
    DataEcuVersion, FileRequest, FileRequestHistory,
    FileRequestAveragePerformance
)

from apps.admin_management.models import (
    Directory, TicketCategory, TicketHistory, TicketStatus
)

from apps.account.models import (MyUser, )
from apps.utils.helper import triger_socket
from apps.file_request.models import RequestDownloadFiles
from apps.file_request.utils import read_user_file_request
import logging

logger = logging.getLogger('django')
from datetime import datetime

session = boto3.Session(
    aws_access_key_id=settings.AWS_ACCESS_KEY_ID,
    aws_secret_access_key=settings.AWS_SECRET_ACCESS_KEY,
    region_name=settings.AWS_S3_REGION_NAME
)
s3_client = session.client('s3')


def upload_file_to_s3(local_path, bucket_path):
    myfile = local_path
    client = boto3.client(
        's3',
        region_name='us-east-1',
        aws_access_key_id=settings.AWS_ACCESS_KEY_ID,
        aws_secret_access_key=settings.AWS_SECRET_ACCESS_KEY
    )
    try:
        response = client.upload_file(
            myfile,
            settings.AWS_STORAGE_BUCKET_NAME,
            bucket_path,
            ExtraArgs={'ACL': 'public-read'}
        )
        url = "https://{}.s3.us-east-1.amazonaws.com/{}".format(
            settings.AWS_STORAGE_BUCKET_NAME, bucket_path)
        return True, url
    except Exception as e:
        print("S3", e)
        return False, None


def master_file_flow(file_request_id):
    """ Flow for master file submitted through file request form.

    Step 1: Read user's file submitted in the file request form.
    Step 2: Search ECU brand and ECU version from the directory model database.
    Step 3: Search for all realted original files in the database.
    Step 4: Get matching percentage from the original files.
    Step 5: calculate percentage match of original files.
    Step 6: Get version files form the directory of original.
    Step 7: Match version files (percentage match) form the directory of original.
    Step 8: Copy the content onto another file and create.
    Step 9: create the directory name.
    Step 10: create file at local in media folder to upload on s3.
    Step 11: Upload file on s3 cloud.

    Step X: Sent for manual handling.
    Args:
        file_request_id (file_request_id): str

    Returns:
        _type_: _description_
    """
    matching_found_in_path = ""
    random_generated_path = ""
    matching_files = []
    last_file_name = ""
    matching_original_data = []
    multipass_files_list = []

    is_file_match_success = True
    file_request_obj = FileRequest.objects.get(request_id=file_request_id)
    data = read_user_file_request(file_request_id)

    directories_to_search = search_based_on_form_data(file_request_obj, data)

    if len(directories_to_search) != 0:
        print("in original search")
        files_for_algorithm = get_gcp_original_files(directories_to_search, file_request_obj)
        if len(files_for_algorithm) == 0:
            description = "No original files found."
            sent_for_manual_handling(file_request_obj, description)
            is_file_match_success = False
            return is_file_match_success, matching_found_in_path, random_generated_path
        else:
            try:
                matching_original_data = get_matching_original_ratio_df(files_for_algorithm, file_request_obj)
            except Exception as error:
                logger.info("get matching ratio error:".format(error))
    else:
        # sent_for_manual_handling(file_request_obj)
        is_file_match_success = False
        return is_file_match_success, matching_found_in_path, random_generated_path

    if len(matching_original_data) == 0:
        description = file_stage.MASTER_FILE_STAGE_MANUAL_1
        sent_for_manual_handling(file_request_obj, description)
        is_file_match_success = False
        return is_file_match_success, matching_found_in_path, random_generated_path
    else:
        version_data = []
        original_data_final = []
        for original_data in matching_original_data:
            version_files_list = get_gcp_version_files(
                original_data['matching_directory'],
                file_request_obj)
            if len(version_files_list) > 0:
                print(version_files_list)
                version_data = get_matching_version_ratio_df(original_data, version_files_list, file_request_obj)
                original_data_final = original_data
                break
        if len(version_data) == 0:
            matching_files = single_directory_multipass(matching_original_data, file_request_obj)

        if len(version_data) == 0 and len(matching_files) == 0:
            multipass_files_list = multiple_directory_multipass(
                matching_original_data, file_request_obj
            )

    if (len(version_data) == 0 and
            len(matching_files) == 0 and
            len(multipass_files_list) == 0):
        logger.info("Manual handle.")
        description = file_stage.MASTER_FILE_STAGE_MANUAL_2
        sent_for_manual_handling(file_request_obj, description)
        is_file_match_success = False
        return is_file_match_success, matching_found_in_path, random_generated_path
    elif (len(version_data) > 0 and
          len(matching_files) == 0 and
          len(multipass_files_list) == 0):
        logger.info("Found in first pass.")
        version_file_hexa_list = version_data['version_file_hexa_list']
        original_file_hexa_list = original_data_final['matching_original_file_hexa_list']
        similar_original_file_hexadump_list = ast.literal_eval(file_request_obj.file_hexa_content_list)

        updated_similar_hexa_bytes = add_diff_to_similar_original_index_bytes(
            version_file_hexa_list, original_file_hexa_list,
            similar_original_file_hexadump_list, file_request_obj)

        dir_name_to_create = create_directory_name(version_data, file_request_obj)
        random_generated_path = dir_name_to_create
        matching_found_in_path = version_data['version_matching_directory']
        file_name_to_create = get_modified_file_name(file_request_obj)
        title = file_name_to_create

        last_file_name = create_version_file_at_local(file_name_to_create, updated_similar_hexa_bytes,
                                                       dir_name_to_create)
        is_sucess, url = upload_file_s3(last_file_name, dir_name_to_create,
                                        file_name_to_create, file_request_obj)

        if is_sucess:
            RequestDownloadFiles.objects.create(
                fil_request_id=file_request_obj,
                title=title,
                url=url
            )

        # Code for file name to give to user only.
        filename = get_encoded_file_name(file_request_obj)
        title = filename

        last_file_name = create_version_file_at_local(filename, updated_similar_hexa_bytes,
                                                       dir_name_to_create)
        is_sucess, url = upload_file_s3(last_file_name, dir_name_to_create,
                                        filename, file_request_obj)

        RequestDownloadFiles.objects.create(
            fil_request_id=file_request_obj,
            title=title,
            url=url,
            sent_to_user=True
        )

    elif (len(version_data) == 0 and
          len(matching_files) > 0 and
          len(multipass_files_list) == 0):
        logger.info("Single directory single pass.")
        dir_name_to_create = create_directory_name(version_data, file_request_obj)
        random_generated_path = dir_name_to_create
        user_uploaded_file_name = file_request_obj.tuning_file.url.split("/")[-1]
        user_uploaded_file_name = clean_user_uploaded_file_name(user_uploaded_file_name)

        # original_file =
        for key, file in matching_files.items():
            matching_file = file[0]['file_name']

            file_hex = get_file_with_hex_from_bigquery(matching_file)
            original_file_hex = get_original_file_with_hex_from_bigquery(file[0]['directory_name'])
            version_file_hexa_list = file_hex
            original_file_hexa_list = original_file_hex
            refrence_file_name = create_refrence_file_name(matching_file, user_uploaded_file_name, True)
            similar_original_file_hexadump_list = ast.literal_eval(file_request_obj.file_hexa_content_list)
            # else:
            #     user_uploaded_file_name = last_file_name
            #     refrence_file_name = create_refrence_file_name(matching_file, user_uploaded_file_name, False)
            #     with open(last_file_name, 'rb') as f:
            #         similar_original_file_hex = binascii.hexlify(f.read()).decode()
            #     similar_original_file_hexadump_list = convert_to_n_size_block(similar_original_file_hex, 20)

            # Save Flow.
            title = "copy difference onto User Submitted file."
            description = "Copy the difference between {0} and {1} \
                            onto user submitted file {2}.".format(
                matching_file, file[0]['directory_name'],
                user_uploaded_file_name
            )

            save_flow(file_request_obj, title, description, is_success=True)

            updated_similar_hexa_bytes = add_diff_to_similar_original_index_bytes(
                version_file_hexa_list, original_file_hexa_list,
                similar_original_file_hexadump_list, file_request_obj)
            last_file_name = create_version_file_at_local(refrence_file_name, updated_similar_hexa_bytes,
                                                          dir_name_to_create)

            matching_found_in_path = file[0]['directory_name']

            is_sucess, url = upload_file_s3(last_file_name, dir_name_to_create,
                                            matching_file, file_request_obj)

            if is_sucess:
                RequestDownloadFiles.objects.create(
                    fil_request_id=file_request_obj,
                    title=create_file_names(file_request_obj),
                    url=url
                )

        # Code for file name to give to user only.
        file_for_user = create_file_name_for_user(file_request_obj, refrence_file_name)
        last_file_name = create_version_file_at_local(file_for_user, updated_similar_hexa_bytes,
                                                      dir_name_to_create)
        is_sucess, url = upload_file_s3(last_file_name, dir_name_to_create,
                                        last_file_name, file_request_obj)
        RequestDownloadFiles.objects.create(
            fil_request_id=file_request_obj,
            title=file_for_user,
            url=url,
            sent_to_user=True
        )

    elif (len(version_data) == 0 and
          len(matching_files) == 0 and
          len(multipass_files_list) > 0):
        logger.info("Multiple directory multiple pass.")

        dir_name_to_create = create_directory_name(version_data, file_request_obj)
        random_generated_path = dir_name_to_create
        user_uploaded_file_name = file_request_obj.tuning_file.url.split("/")[-1]
        user_uploaded_file_name = clean_user_uploaded_file_name(user_uploaded_file_name)

        # print("================= Multipass directoriesssssssssss =============")
        # print(multipass_files_list)
        # print("================= Multipass directoriesssssssssss =============")

        for file in multipass_files_list:
            matching_file = file['file_name']

            file_hex = get_file_with_hex_from_bigquery(matching_file)
            original_file_hex = get_original_file_with_hex_from_bigquery(file['directory_name'])
            version_file_hexa_list = file_hex
            original_file_hexa_list = original_file_hex
            refrence_file_name = create_refrence_file_name(matching_file, user_uploaded_file_name, True)
            similar_original_file_hexadump_list = ast.literal_eval(file_request_obj.file_hexa_content_list)
            # else:
            #     user_uploaded_file_name = last_file_name
            #     refrence_file_name = create_refrence_file_name(matching_file, user_uploaded_file_name, False)
            #     with open(last_file_name, 'rb') as f:
            #         similar_original_file_hex = binascii.hexlify(f.read()).decode()
            #     similar_original_file_hexadump_list = convert_to_n_size_block(similar_original_file_hex, 20)

            # Save Flow.
            title = "copy difference onto User Submitted file."
            description = "Copy the difference between {0} and {1} \
                            onto user submitted file {2}.".format(
                matching_file, file['directory_name'],
                user_uploaded_file_name
            )
            # print("==========here ============")
            save_flow(file_request_obj, title, description, is_success=True)

            updated_similar_hexa_bytes = add_diff_to_similar_original_index_bytes(
                version_file_hexa_list, original_file_hexa_list,
                similar_original_file_hexadump_list, file_request_obj)
            last_file_name = create_version_file_at_local(refrence_file_name, updated_similar_hexa_bytes,
                                                          dir_name_to_create)

            matching_found_in_path = file['directory_name']

            is_sucess, url = upload_file_s3(last_file_name, dir_name_to_create,
                                            matching_file, file_request_obj)
            if is_sucess:
                RequestDownloadFiles.objects.create(
                    fil_request_id=file_request_obj,
                    title=create_file_names(file_request_obj),
                    url=url
                )

        # Code for file name to give to user only.
        file_for_user = create_file_name_for_user(file_request_obj, refrence_file_name)

        last_file_name = create_version_file_at_local(file_for_user, updated_similar_hexa_bytes,
                                                      dir_name_to_create)
        is_sucess, url = upload_file_s3(last_file_name, dir_name_to_create,
                                        last_file_name, file_request_obj)

        # print("===============Dir name to create ===============")
        # print(url)
        # print("===============Dir name to create ===============")

        RequestDownloadFiles.objects.create(
            fil_request_id=file_request_obj,
            title=file_for_user,
            url=url,
            sent_to_user=True
        )

        # creating new directory after file-maker process.
    Directory.objects.create(
        directory_path="Main/" + random_generated_path.split("/")[-1],
        ecu_producer=file_request_obj.ecu_brand,
        ecu_build=file_request_obj.ecu_version,
        created_by_filemaker=True,
        vehicle_type=file_request_obj.vehicle_type,
        vehicle_producer=file_request_obj.vehicle_make,
        vehicle_model=file_request_obj.model,
        vehicle_model_year=file_request_obj.vehicle_year,
        file_request=file_request_obj
     )

    title = "File is presented to the user."
    description = "File is present to the user to download with name {0}:".format(
        random_generated_path + '/' + last_file_name)
    save_flow(file_request_obj, title, description, True)
    return is_file_match_success, matching_found_in_path, random_generated_path


def search_based_on_form_data(file_request_obj, data):
    logger.info("Step 9: Search ECU brand and ECU version from the files on cloud.")
    directories_to_search = []
    vehicle_type = file_request_obj.vehicle_type
    if vehicle_type == "Car / LCV":
        vehicle_type = "Car"
    queryset = Directory.objects.filter(
        ecu_producer__exact=data['ecu_brand'],
        ecu_build__exact=data['ecu_version'],
        vehicle_type__exact=vehicle_type,
        created_by_filemaker=False
    ).values('directory_path')

    # Get the latest directory if available
    if len(queryset) != 0:
        directories_to_search = [dir['directory_path'] for dir in queryset]
    if len(directories_to_search) != 0:
        title = "Search similar original files and database."
        description = file_stage.MASTER_FILE_STAGE_4.format("yes")
        save_flow(file_request_obj, title, description, True)
    else:
        description = file_stage.MASTER_FILE_STAGE_MANUAL
        sent_for_manual_handling(file_request_obj, description)
    return directories_to_search


def get_gcp_original_files(prefix_list, file_request_obj):
    logger.info("Step 10: Search for all related original files in the database")
    os.environ['GOOGLE_CLOUD_PROJECT'] = 'bigquery-project-437912'
    os.environ['GOOGLE_APPLICATION_CREDENTIALS'] = 'file-matching-43da45e9f9b8.json'
    submitted_file_size_mb = file_request_obj.file_size
    submitted_file_size_bytes = submitted_file_size_mb * 1024 * 1024
    lower_file_size = submitted_file_size_bytes - 200000
    client = bigquery.Client()
    dataset_id = 'filemaker_directory'
    table_id = 'file_data'
    prefix_without_main = [prefix.replace('Main/', '') for prefix in prefix_list]
    query = f"""
        SELECT directory_name, file_name, hex_block
        FROM `{dataset_id}.{table_id}`
        WHERE directory_name IN UNNEST(@prefixes)
        AND lower(file_name) LIKE lower('%original%')
        AND file_size_bytes between @lower_file_size AND @submitted_file_size_bytes
        """
    logger.info(f'query for the big query data prefix without main {prefix_without_main} and lower_file_size {lower_file_size} and submitted_file_size {submitted_file_size_bytes}')
    logger.info(query)
    job_config = bigquery.QueryJobConfig(
        query_parameters=[
            bigquery.ArrayQueryParameter("prefixes", "STRING", prefix_without_main),
            bigquery.ScalarQueryParameter("lower_file_size", "INT64", lower_file_size),
            bigquery.ScalarQueryParameter("submitted_file_size_bytes", "INT64", submitted_file_size_bytes)
        ]
    )
    query_job = client.query(query, job_config=job_config)
    bqstorageclient = bigquery_storage.BigQueryReadClient()
    all_dataframes = query_job.to_dataframe(bqstorage_client=bqstorageclient)
    if not all_dataframes.empty:
        print("Total original files fetched", all_dataframes.count())
        return all_dataframes
    else:
        print("No data was fetched.")
        return pd.DataFrame()


def sent_for_manual_handling(file_obj, description):
    """Check cases to sent for manual handling.

    Args:
        file_obj (file request object): _description_
        description (str): description to be set for filerequesthistory.
    """
    logger.info("Step X: Sent for manual handling.")
    sent_for_handle = True

    is_manual_handle = TicketCategory.objects.filter(name="Manual Handle").exists()
    if not is_manual_handle:
        TicketCategory.objects.create(name="Manual Handle")

    if not TicketHistory.objects.filter(request_id=file_obj.file_request_id).exists():
        ticket = TicketHistory.objects.create(
            created_by=file_obj.user,
            assigned_to=MyUser.objects.get(email='technical@viezu.com'
                                        ) if MyUser.objects.filter(email='technical@viezu.com'
                                                                    ).exists() else None,
            category=TicketCategory.objects.get(name='Processing') if TicketCategory.objects.filter(
                name='Processing').exists() else None,
            file_request=file_obj,
            request_id=file_obj.request_id,
            description=get_ticket_description(file_obj),
            subject=file_obj.request_id + ' - ' + file_obj.vehicle_registration if file_obj.vehicle_registration is not None else "File Request to be manually handle.",
            ticket_status=TicketStatus.objects.get(team_status="New")
        )
        ticket.update_ids()

    file_obj.status = "Manual handle"
    file_obj.save()

    title = "Sent to manual handling."
    is_success = True

    save_flow(file_obj, title,
              description, is_success)

    file_request_status_change(file_obj.user, file_obj)

    admin_user = MyUser.objects.get(email='technical@viezu.com')
    triger_socket({
        'uuid': str(admin_user.uuid),
        'type': 'admin_file_assigned',
        'ids': str(file_obj.request_id),
        'created_at': str(file_obj.created_at),
        'message': "File is assigned for manual handle:{}.".format(file_obj.request_id)
    })

    return sent_for_handle


def get_matching_original_ratio_df(df, file_request_obj):
    logger.info("Step 12: calculate percentage match of original files.")
    start_time = datetime.now()
    similar_original_file_hexadump_list = ast.literal_eval(file_request_obj.file_hexa_content_list)
    ecu_brand = file_request_obj.ecu_brand
    ecu_version = file_request_obj.ecu_version
    ecu_matching_percentage = DataEcuVersion.objects.filter(
        brand__brand_name=ecu_brand,
        ecu_version_name=ecu_version)

    try:
        df["percentage"] = df.apply(
            lambda row: get_matching_ratio4(row["hex_block"], similar_original_file_hexadump_list), axis=1
        )
        threshold_percentage = ecu_matching_percentage[0].percentage
        df_filtered = df[df['percentage'] >= threshold_percentage]
        df_sorted = df_filtered.sort_values(by='percentage', ascending=False)
        if df_sorted.empty:
            logger.info("No version file found with percentage greater than or equal to the threshold.")
            original_data_list = []
        else:
            logger.info(df_sorted)
            df_renamed = df_sorted.rename(columns={
                'directory_name': 'matching_directory',
                'file_name': 'matching_file_name',
                'percentage': 'matching_percentage',
                'hex_block': 'matching_original_file_hexa_list'
            })
            original_data_list = df_renamed[['matching_directory', 'matching_file_name', 'matching_percentage',
                                             'matching_original_file_hexa_list']].to_dict(orient='records')
    except Exception as error:
        logger.error(f"Error during matching: {error}")
        return {}

    end_time = datetime.now()
    second_diff = end_time - start_time

    if len(original_data_list) > 0:
        FileRequestAveragePerformance.objects.create(
            file_request_obj=file_request_obj,
            file_type=file_request_obj.file_type,
            original_found=True,
            original_found_time=second_diff.seconds
        )
    else:
        FileRequestAveragePerformance.objects.create(
            file_request_obj=file_request_obj,
            file_type=file_request_obj.file_type,
            original_not_found=True,
            original_not_found_time=second_diff.seconds
        )

    return original_data_list


def get_matching_ratio5(hexdata1, hexdata2, segment_size=8):
    def break_into_segments(hexdata, segment_size):
        segments = []
        for block in hexdata:
            segments.extend([block[i:i + segment_size] for i in range(0, len(block), segment_size)])
        return segments

    # Break down large blocks into smaller segments
    segments1 = break_into_segments(hexdata1, segment_size)
    segments2 = break_into_segments(hexdata2, segment_size)

    # Calculate the percentage match between the two sets of segments
    total_common_items = len(set(segments1) & set(segments2))
    total_distinct_items = float(len(set(segments1) | set(segments2)))

    percentage_diff = (total_common_items / total_distinct_items) * 100 if total_distinct_items != 0 else 0.0
    return percentage_diff


def get_matching_ratio4(hexdata1, hexdata2):
    total_common_items = len(set(hexdata1) & set(hexdata2))
    total_distinct_items = float(len(set(hexdata1) | set(hexdata2)))
    percentage_diff = (total_common_items / total_distinct_items) * 100
    return percentage_diff


def file_naming(file_request_obj):
    tuning_required = file_request_obj.tuning_required
    additional_function = file_request_obj.additional_function

    if tuning_required == "VBLUE/ECO":
        search_terms = "(VBLUE "
    elif tuning_required == "VBLEND/STAGE 0.5":
        search_terms = "(VBLEND "
    elif tuning_required == "VPERF/STAGE 1":
        search_terms = "(VPERF "
    elif tuning_required == "VRACE/STAGE 2":
        search_terms = "(VRACE "
    elif tuning_required == "NO TUNE":
        search_terms = "("

    if additional_function is not None:
        if len(additional_function) > 0:
            additional_function = file_request_obj.additional_function.split(",")
            additional_function = list(map(lambda x: x.upper().strip(), additional_function))
    else:
        additional_function = []

    join_str = " ".join(additional_function)
    file_name = search_terms + join_str + ')'

    return file_name


def get_modified_file_name(file_request_obj):
    additional_function = get_upper_additional_function(file_request_obj.additional_function)
    tuning_required = file_request_obj.tuning_required
    search_terms = ''
    if tuning_required == "VBLUE/ECO":
        search_terms = "ECONOMY"
    elif tuning_required == "VBLEND/STAGE 0.5":
        search_terms = "BLEND"
    elif tuning_required == "VPERF/STAGE 1":
        search_terms = "PERFORMANCE"
    elif tuning_required == "VRACE/STAGE 2":
        search_terms = "VRACE"
    elif tuning_required == "NO TUNE":
        search_terms = ''
    filename = search_terms
    if len(additional_function) > 0:
        filename += ' ' + ' '.join(additional_function)
    return "(" + filename + ")"


def get_gcp_version_files(prefix_list, file_request_obj):
    prefix_list_array = [prefix_list]
    logger.info("Step 10: Search for all related version files in the database")
    os.environ['GOOGLE_CLOUD_PROJECT'] = 'bigquery-project-437912'
    os.environ['GOOGLE_APPLICATION_CREDENTIALS'] = 'file-matching-43da45e9f9b8.json'
    client = bigquery.Client()
    dataset_id = 'filemaker_directory'
    table_id = 'file_data'

    tuning_required = file_request_obj.tuning_required
    additional_function = file_request_obj.additional_function
    additional_function = get_upper_additional_function(additional_function)
    search_terms = get_search_terms(tuning_required)
    tuning_term = search_terms.upper()
    result_list = []
    if len(additional_function) > 0:
        result_list = additional_function
        if tuning_term != '':
            result_list.append(tuning_term)
    if len(result_list) > 0:
        combinations, _ = get_combinations(result_list)
        files_to_search = additional_search(tuning_term, combinations)
    elif len(additional_function) == 0 and tuning_term != '':
        updated_tuning_term = tuning_term
        files_to_search = [updated_tuning_term]
    else:
        files_to_search = prefix_list_array

    files_to_search_with_parentheses = [f"%({term.lower()})%" for term in files_to_search]

    query = f"""
            SELECT directory_name, file_name, hex_block
            FROM `{dataset_id}.{table_id}`
            WHERE directory_name IN UNNEST(@prefixes)
            AND ({" OR ".join([f"LOWER(file_name) LIKE @file_search_{i}" for i in range(len(files_to_search_with_parentheses))])})
        """

    # Add the query parameters
    query_params = [
        bigquery.ArrayQueryParameter("prefixes", "STRING", prefix_list_array)
    ]
    query_params += [
        bigquery.ScalarQueryParameter(f"file_search_{i}", "STRING", file_search)
        for i, file_search in enumerate(files_to_search_with_parentheses)
    ]
    job_config = bigquery.QueryJobConfig(
        query_parameters=query_params
    )
    query_job = client.query(query, job_config=job_config)
    bqstorageclient = bigquery_storage.BigQueryReadClient()
    all_dataframes = query_job.to_dataframe(bqstorage_client=bqstorageclient)
    if not all_dataframes.empty:
        title = "Search for version files."
        additional_str = ",".join(additional_function)
        description = "File found with {} {} in directory:{}".format(search_terms,
                                                                     additional_str, prefix_list)
        save_flow(file_request_obj, title=title,
                  description=description, is_success=True)
        title = "Search for version files."
        description = file_stage.MASTER_FILE_STAGE_6
        save_flow(file_request_obj, title=title,
                  description=description, is_success=True)
        return all_dataframes
    else:
        print("No data was fetched.")
        title = "Search for version files."
        additional_str = ",".join(additional_function)
        description = "No file found with {} {} in directory:{}".format(search_terms,
                                                                        additional_str, prefix_list)
        save_flow(file_request_obj, title=title,
                  description=description, is_success=True)
        return pd.DataFrame()


def get_matching_version_ratio_df(data, df, file_request_obj):
    logger.info("Step 14: Match version files (percentage match) form the directory of original.")
    start_time = datetime.now()
    version_data = {}
    similar_original_file_hexadump_list = data['matching_original_file_hexa_list']
    try:
        df["percentage"] = df.apply(
            lambda row: get_matching_ratio4(row["hex_block"], similar_original_file_hexadump_list), axis=1
        )
        df_sorted = df.sort_values(by='percentage', ascending=False)
        max_percentage_row = df_sorted.iloc[0]
    except Exception as error:
        logger.error(f"Error during matching: {error}")
        return {}
    end_time = datetime.now()
    second_diff = end_time - start_time
    if max_percentage_row['percentage'] == 0:
        FileRequestAveragePerformance.objects.create(
            file_request_obj=file_request_obj,
            file_type=file_request_obj.file_type,
            refrence_not_found=True,
            refrence_not_found_time=second_diff.seconds
        )
    else:
        version_data['version_matching_directory'] = max_percentage_row['directory_name']
        version_data['version_matching_file_name'] = max_percentage_row['file_name']
        version_data['version_matching_percentage'] = max_percentage_row['percentage']
        version_data['version_file_hexa_list'] = max_percentage_row['hex_block']
        FileRequestAveragePerformance.objects.create(
            file_request_obj=file_request_obj,
            file_type=file_request_obj.file_type,
            refrence_found=True,
            refrence_found_time=second_diff.seconds
        )
        title = file_stage.MASTER_FILE_STAGE_7
        description = "File name:{}, directory:{}, matching percentage:{}".format(
            version_data['version_matching_file_name'],
            version_data['version_matching_directory'],
            version_data['version_matching_percentage']
        )
        save_flow(file_request_obj, title=title,
                  description=description, is_success=True)

    return version_data


def add_diff_to_similar_original_index_bytes(
        version_hexa, new_version_hexa,
        similar_hexa, file_request_obj):
    logger.info("Step 8: Copy the content onto another file and create.")

    version_hexa_str = "".join(version_hexa)
    version_bytes = binascii.unhexlify(version_hexa_str)

    new_file_version_str = "".join(new_version_hexa)
    new_file_version_bytes = binascii.unhexlify(new_file_version_str)

    similar_file_version_str = "".join(similar_hexa)
    similar_file_version_bytes = binascii.unhexlify(similar_file_version_str)

    new_file_version_bytes_array = list(new_file_version_bytes)
    similar_file_version_bytes_array = list(similar_file_version_bytes)

    min_len = min(map(len, (version_bytes, new_file_version_bytes)))
    count = 0
    for i in range(min_len):  # use smaller length
        if (version_bytes[i] != new_file_version_bytes[i]):
            # print("index:{0} file1:{1} file2:{2}".format(
            #     i,version_bytes[i], new_file_version_bytes[i]))
            # new_file_version_bytes_array[i] = version_bytes[i]

            similar_file_version_bytes_array[i] = version_bytes[i]
            count += 1
    result = bytes(similar_file_version_bytes_array)

    title = "copying content onto another file."
    description = "copying content."
    save_flow(file_request_obj, title=title,
              description=description, is_success=True)

    return result


def save_flow(file_request_obj, title,
              description, is_success,
              additional_information=''):
    logger.info("save flow")
    FileRequestHistory.objects.create(
        file_request_id=file_request_obj,
        title=title,
        description=description,
        is_success=is_success,
        additional_information=additional_information
    )

    return True


def create_directory_name(version_data, file_request_obj):
    logger.info("Step 9: create the directory name.")
    import string
    import random
    N = 7
    res = ''.join(random.choices(string.ascii_uppercase +
                                 string.digits, k=N))

    if 'version_matching_directory' in version_data:
        split_dir = version_data['version_matching_directory'].split("/")
        final_dir_name = split_dir[0] + "/" + split_dir[-1] + "_" + res
    else:
        split_dir = file_request_obj.vehicle_registration if file_request_obj.vehicle_registration else ''
        final_dir_name = split_dir + "_" + res

    return final_dir_name


def create_file_name_for_user(file_request_obj, file_name):

    tuning_required = file_request_obj.tuning_required
    vehicle_registration = file_request_obj.vehicle_registration

    file_name = file_name.split("(")[-1]
    file_name = file_name.split(")")

    if tuning_required == "VBLUE/ECO":
        search_terms = "ECONOMY "
    elif tuning_required == "VBLEND/STAGE 0.5":
        search_terms = "BLEND "
    elif tuning_required == "VPERF/STAGE 1":
        search_terms = "PERFORMANCE "
    elif tuning_required == "NO TUNE":
        search_terms = "("

    final_file_name = vehicle_registration +' '+search_terms + ' '+file_name[0]
    return final_file_name

def create_version_file_at_local(file_name, file_content, dir_name_to_create):
    dir_to_create_at_local = dir_name_to_create.split("/")[-1]
    local_media_folder_name = 'media/{}'.format(dir_to_create_at_local)

    isExist = os.path.exists(local_media_folder_name)
    if not isExist:
        print("creating folder")
        os.makedirs(local_media_folder_name)

    logger.info("Step 10: create file at local in media folder to upload on s3.")
    local_file_name = 'media/{}/{}'.format(dir_to_create_at_local, file_name)
    file = open(local_file_name, 'wb')
    file.write(file_content)
    file.close()
    return local_file_name


def upload_file_s3(local_file_name, dir_name_to_create,
                   file_name_to_create, file_request_obj):
    logger.info("Step 11: Upload file on s3 cloud.")
    is_sucess, url = upload_file_to_s3(local_file_name, "{}/{}".format(dir_name_to_create, file_name_to_create))

    title = file_stage.MASTER_FILE_STAGE_8
    description = "File and directory created.:{}".format(dir_name_to_create)
    save_flow(file_request_obj, title=title,
              description=description, is_success=True)
    return is_sucess, url


def get_combinations(additional_function: list):
    from itertools import permutations
    combinations_to_list = additional_function
    combinations = permutations(combinations_to_list, len(combinations_to_list))
    return combinations, combinations_to_list


def multi_pass_files(combinations: object, combinations_to_list: list):
    files_to_search = []
    for comb in combinations:
        str = " ".join(list(comb))
        data = {}
        to_remove = str.split(" ")
        not_in_list = list(filter(lambda i: i not in to_remove, combinations_to_list))
        data['comb'] = str
        data['not_in_comb'] = not_in_list[0]
        files_to_search.append(data)

    return files_to_search


def additional_search(tuning_term: str, combinations: object):
    files_to_search = []

    for comb in combinations:
        if tuning_term != '' and tuning_term in comb:
            str = " ".join(list(comb))
            files_to_search.append(str)
        if tuning_term == '' and '' not in comb:
            str = " ".join(list(comb))
            files_to_search.append(str)
        if tuning_term == '' and '' in comb:
            str = " ".join(list(comb)).strip()
            files_to_search.append(str)

    return files_to_search


def get_version_file_match_or_not(files_to_search, json_data):
    # print("===========File to search ================")
    # print(files_to_search)
    # print("===========File to search ================")

    found_directory = None
    for file_name in files_to_search:

        for directory in json_data:
            if file_name in directory['file_name']:
                found_directory = directory
                break
    # print("==========Found directory ===============")
    # print(found_directory)
    # print("==========Found directory ===============")
    return found_directory


def get_upper_additional_function(additional_function):
    """ Get uppercase additional function.  """

    if additional_function is not None:
        additional_function = additional_function.split(",")
        additional_function = list(map(lambda function_name: function_name.upper().strip(), additional_function))
    else:
        additional_function = []

    return additional_function


def get_search_terms(tuning_required):
    """ Get search terms in str format.

    Args:
        tuning_required (str): _description_

    Returns:
        str: Search terms
    """
    search_terms = ''
    if tuning_required == "VBLUE/ECO":
        search_terms = "vblue"
    elif tuning_required == "VBLEND/STAGE 0.5":
        search_terms = "vblend"
    elif tuning_required == "VPERF/STAGE 1":
        search_terms = "vperf"
    elif tuning_required == "VRACE/STAGE 2":
        search_terms = "vrace"
    elif tuning_required == "NO TUNE":
        search_terms = ''

    return search_terms


def get_files_from_bigquery(version_directory):
    client = bigquery.Client()

    # Define the query to retrieve file names based on the directory name
    query = f"""
    SELECT file_name, directory_name
    FROM `filemaker_directory.file_data`
    WHERE directory_name = @version_directory
    """

    # Prepare a query job with parameterized input to prevent SQL injection
    job_config = bigquery.QueryJobConfig(
        query_parameters=[
            bigquery.ScalarQueryParameter("version_directory", "STRING", version_directory)
        ]
    )

    # Run the query
    query_job = client.query(query, job_config=job_config)

    # Fetch the results
    results = query_job.result()

    # Convert results to a list of dictionaries
    json_data = [
        {
            "file_name": row.file_name,
            "directory_name": row.directory_name
        }
        for row in results
    ]

    return json_data


def get_file_with_hex_from_bigquery(file_name):
    client = bigquery.Client()

    # Define the query to retrieve the file based on the file name
    query = f"""
    SELECT directory_name, file_name, hex_block
    FROM `filemaker_directory.file_data`
    WHERE file_name = @file_name
    LIMIT 1
    """

    # Prepare a query job with parameterized input to prevent SQL injection
    job_config = bigquery.QueryJobConfig(
        query_parameters=[
            bigquery.ScalarQueryParameter("file_name", "STRING", file_name)
        ]
    )

    # Run the query
    query_job = client.query(query, job_config=job_config)

    # Fetch the first result
    row = next(query_job.result(), None)

    if row:
        # Prepare the result as a dictionary
        return row.hex_block
    else:
        return None


def get_original_file_with_hex_from_bigquery(directory_name):
    client = bigquery.Client()

    # Define the query to retrieve the file based on the file name
    query = f"""
    SELECT directory_name, file_name, hex_block
    FROM `filemaker_directory.file_data`
    WHERE directory_name = @directory_name
    AND lower(file_name) LIKE lower('%original%')
    LIMIT 1
    """

    # Prepare a query job with parameterized input to prevent SQL injection
    job_config = bigquery.QueryJobConfig(
        query_parameters=[
            bigquery.ScalarQueryParameter("directory_name", "STRING", directory_name)
        ]
    )

    # Run the query
    query_job = client.query(query, job_config=job_config)

    # Fetch the first result
    row = next(query_job.result(), None)

    if row:
        # Prepare the result as a dictionary
        return row.hex_block
    else:
        return None


def single_directory_multipass(matching_original_data, file_request_obj):
    logger.info("In single directory multipass.")

    matching_files = {}

    tuning_required = file_request_obj.tuning_required
    additional_function = file_request_obj.additional_function

    additional_function = get_upper_additional_function(additional_function)
    search_terms = get_search_terms(tuning_required)
    search_terms = search_terms.upper()
    result_list = []
    combinations = []
    combinations_to_list = []
    if len(additional_function) > 0:
        result_list = additional_function
        if search_terms != '':
            result_list.append(search_terms)
    if len(result_list) == 0:
        return matching_files
    if len(result_list) > 0:
        combinations, combinations_to_list = get_combinations(result_list)
    for original_data in matching_original_data:
        json_data = get_files_from_bigquery(original_data['matching_directory'])
        for comb in combinations:
            to_search = " ".join(list(comb))
            print(to_search)
            not_in_list = list(filter(lambda i: i not in comb, combinations_to_list))
            print(not_in_list)
            if len(not_in_list) > 0:
                not_in_list = not_in_list[0]
                is_not_in_list_in_dir = [dir for dir in json_data if not_in_list in dir['file_name']]
                is_to_search_in_dir = [dir for dir in json_data if to_search in dir['file_name']]
            else:
                not_in_list = []
                is_not_in_list_in_dir = []
                is_to_search_in_dir = []

            if len(is_not_in_list_in_dir) > 0 and len(is_to_search_in_dir) > 0:
                title = "Searching and found different files in single directory."
                description = "Search for {} and {} file in {} directory.".format(
                    not_in_list, to_search,
                    original_data['matching_directory'])
                save_flow(file_request_obj, title, description, True)

                matching_files = {
                    'matching_ref_1': is_not_in_list_in_dir,
                    'matching_ref_2': is_to_search_in_dir
                }
                return matching_files

    title = "No file found in Single directory single pass."
    additional_str = ",".join(additional_function)
    description = "No file found with {} and  {} in same directory \
                    and  multiple files.".format(search_terms, additional_str)

    save_flow(file_request_obj, title, description, is_success=True)

    return matching_files


def clean_user_uploaded_file_name(file_name):
    if "original" in file_name:
        f = file_name.replace("original", "(original)")
    else:
        f = file_name

    upper_file_name = f.upper()
    splitted_file_name = upper_file_name.split(".")

    if "OLS" in splitted_file_name:
        file_name = "".join(splitted_file_name)
        file_name = file_name.replace("OLS", ".ols")

    if "OLS" not in splitted_file_name:
        file_name = splitted_file_name[-1]

    return file_name


def create_refrence_file_name(file_name, user_file_name,
                              is_initial_file=True):
    last_file_name = user_file_name
    if is_initial_file:
        file_name = file_name.split(")")
        file_name = file_name[0].split("(")
        file_name = file_name[-1]

        user_file_name = user_file_name.split(")")
        if user_file_name[-1] == '':
            user_file_name = user_file_name[0]
            if "(ORIGINAL" in user_file_name or "(original" in user_file_name:
                user_file_name = user_file_name.replace("(ORIGINAL", "")
                user_file_name = user_file_name.replace("(original", "")
        else:
            user_file_name = user_file_name[-1]

        final_file_name = "(" + file_name + ")" + user_file_name

    else:
        user_file_name = user_file_name.split(")")[0].split("(")[-1]
        previous_file_name_list = file_name.split("(")
        previous_file_name_list[0] = "(" + user_file_name + " "
        final_file_name = "".join(previous_file_name_list)
        final_file_name = final_file_name.split(")")
        last_file_name = last_file_name.split("/")[-1].split(")")[-1]
        final_file_name = final_file_name[0] + ")" + last_file_name

    return final_file_name


def create_functions_list(tuning_required, additional_functions):
    functions = {}
    for fun in additional_functions:
        functions[fun] = False

    functions.update({tuning_required: False})
    return functions


def multipass_get_combinations(additional_function,
                               comb_count=3, combinatons_list = []):
    from itertools import permutations

    combinations_to_list = additional_function
    combinations = permutations(combinations_to_list,comb_count)
    for comb in combinations:
        combinatons_list.append(comb)
    comb_count -= 1
    if comb_count == 0:
        return combinatons_list, combinations_to_list
    return multipass_get_combinations(additional_function,
                                      comb_count, combinatons_list)


def multiple_directory_multipass(matching_original_data, file_request_obj):
    logger.info("In multiple directory multipass.")
    multipass_files_list = []
    tuning_required = file_request_obj.tuning_required
    additional_function = file_request_obj.additional_function
    additional_function = get_upper_additional_function(additional_function)
    search_terms = get_search_terms(tuning_required)
    search_terms = search_terms.upper()
    result_list = []
    combinations_list = []
    if len(additional_function) > 0:
        result_list = additional_function
        if search_terms != '':
            result_list.append(search_terms)
    if len(result_list) == 0:
        return multipass_files_list
    if len(result_list) > 0:
        combinations_list, _ = multipass_get_combinations(result_list)
    functions = create_functions_list(search_terms, additional_function)
    str_combinations_list = ["(" + " ".join(list(comb)) + ")" for comb in combinations_list]
    str_combinations_list.reverse()

    files_list = []
    files_list.extend(get_files_from_bigquery(matching_original_data['matching_directory']))

    for comb in str_combinations_list:
        for file in files_list:
            replaced_comb = comb.replace("(", "")
            replaced_comb = replaced_comb.replace(")", "")
            replaced_comb_list = replaced_comb.split(" ")
            if comb in file['file_name'] and False in functions.values():
                multipass_files_list.append(file)

                if len(replaced_comb_list) == 1:
                    to_update = replaced_comb_list[0]
                if to_update in comb:
                    functions[to_update] = True

    if False in functions.values():
        multipass_files_list = []
        title = "No file found in multipass."
        additional_str = ",".join(additional_function)
        description = "No file found with {} {} in any directory \
                     during multi-pass.".format(search_terms, additional_str)

        save_flow(file_request_obj, title, description, is_success=True)
        return multipass_files_list
    else:
        return multipass_files_list


def create_file_names(file_request_obj):
    tuning_required = file_request_obj.tuning_required
    additional_function = file_request_obj.additional_function
    vehicle_registration = file_request_obj.vehicle_registration

    if tuning_required == "VBLUE/ECO":
        search_terms = "ECONOMY "
    elif tuning_required == "VBLEND/STAGE 0.5":
        search_terms = "BLEND "
    elif tuning_required == "VPERF/STAGE 1":
        search_terms = "PERFORMANCE "
    elif tuning_required == "NO TUNE":
        search_terms = "("

    if additional_function is not None:
        if len(additional_function) > 0:
            additional_function = file_request_obj.additional_function.split(",")
            additional_function = list(map(lambda x: x.upper().strip(), additional_function))
    else:
        additional_function = []

    join_str = " ".join(additional_function)
    file_name = vehicle_registration + ' ' + search_terms + ' ' + join_str

    return file_name


def get_encoded_file_name(file_request_obj):
    additional_function = get_upper_additional_function(file_request_obj.additional_function)
    tuning_required = file_request_obj.tuning_required
    vehicle_registration = file_request_obj.vehicle_registration
    search_terms = ''
    if tuning_required == "VBLUE/ECO":
        search_terms = "ECONOMY"
    elif tuning_required == "VBLEND/STAGE 0.5":
        search_terms = "BLEND"
    elif tuning_required == "VPERF/STAGE 1":
        search_terms = "PERFORMANCE"
    elif tuning_required == "VRACE/STAGE 2":
        search_terms = "VRACE"
    elif tuning_required == "NO TUNE":
        search_terms = ''
    vehicle_registration = vehicle_registration.upper()
    filename = vehicle_registration + ' ' + search_terms
    if len(additional_function) > 0:
        filename += ' ' + ' '.join(additional_function)
    return filename
