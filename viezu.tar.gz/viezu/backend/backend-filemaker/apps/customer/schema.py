from drf_yasg import openapi

encode_file_schema = openapi.Schema(
    title =("Update Email Request"),
    type=openapi.TYPE_OBJECT, 
    properties={
        'guid': openapi.Schema(type=openapi.TYPE_STRING,example="6d138d22-42b7-4ff3-8216-f462f7034294"),
        'is_correct_cvn': openapi.Schema(type=openapi.TYPE_BOOLEAN,example=True),

    },
    required=['guid','is_correct_cvn'],
)

encode_download_any_file_schema = openapi.Schema(
    title =("Download any File"),
    type=openapi.TYPE_OBJECT, 
    properties={
        'url': openapi.Schema(type=openapi.TYPE_STRING,example="https://encodingapi.alientech.to/api/ktag/file-slots/e4a445ed-011a-4f34-b217-a0af8b5d95e9/files/f78db5c4-6779-4826-acc9-2914238b1678"),
    },
    required=['url',],
)
