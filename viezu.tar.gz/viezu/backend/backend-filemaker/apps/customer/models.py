import datetime
from django.db import models

from apps.account.models import MyUser
from apps.utils.models import BaseModel
from apps.customer.constants import ORDER_STATUS, DEALER_CREDIT_TYPE


from apps.utils.helper import filename_path


def decode_attachment(instance, filename):
    return filename_path('decode', instance, filename)

def encode_attachment(instance, filename):
    return filename_path('encode/modified', instance, filename)

def encode_original_attachment(instance, filename):
    return filename_path('encode/original', instance, filename)



class Cart(BaseModel):
    user = models.ForeignKey(MyUser, on_delete=models.CASCADE,related_name='cart')
    product = models.PositiveIntegerField(default=0)
    quantity = models.IntegerField(default=0)
    price = models.DecimalField(max_digits=8, decimal_places=2,default=0)
    tunning_credit = models.PositiveIntegerField(default=0)
    type = models.CharField(max_length=255,null=True,blank=True)
    vat  = models.FloatField(null=True, blank=True, default=0.0)
    is_dealer_credit = models.BooleanField(default=False)
    dealer_credit_type = models.PositiveSmallIntegerField(
                        choices=DEALER_CREDIT_TYPE,default=1,
                        null=True,blank=True)
    category_list=models.JSONField(default=list, help_text="Category Id's")

    def subtotal(self):
        return self.quantity * self.price
    
class OrderList(BaseModel):
    ids = models.CharField(max_length=255,null=True,blank=True)
    wo_order_id = models.CharField(null=True,blank=True,max_length=255)
    stripe_id= models.CharField(max_length=255,null=True,blank=True)
    user = models.ForeignKey(MyUser, on_delete=models.CASCADE,related_name='order_list')
    total_price = models.DecimalField(max_digits=8, decimal_places=2,default=0.0)
    tax_price = models.DecimalField(max_digits=8, decimal_places=2,default=0.0)
    status = models.PositiveSmallIntegerField(choices=ORDER_STATUS,default=1)
    checkout_data = models.JSONField(default=dict)
    file_credit = models.PositiveIntegerField(default=0)
    function_credit = models.PositiveIntegerField(default=0)
    evc_credit = models.PositiveIntegerField(default=0)
    is_dealer_credit = models.BooleanField(default=False)
    dealer_credit_type = models.PositiveSmallIntegerField(
                        choices=DEALER_CREDIT_TYPE,default=1,
                        null=True,blank=True)
    is_credit_added = models.BooleanField(default=False)
    is_logs_added = models.BooleanField(default=False)
    category_id = models.PositiveIntegerField(default=0)

    def update_ids(self):
        self.ids = "OR{}{}".format(
            str(datetime.date.today()).replace('-',''),self.id
        )
        self.save()

class OrderItem(BaseModel):
    user = models.ForeignKey(MyUser, on_delete=models.CASCADE,related_name='user_order_item')
    order_list = models.ForeignKey(OrderList, on_delete=models.CASCADE,related_name='order_item')
    product = models.PositiveIntegerField(default=0)
    product_name = models.CharField(max_length=255,null=True,blank=True)
    product_image = models.CharField(max_length=255,null=True,blank=True)
    quantity = models.IntegerField(default=1)
    price = models.DecimalField(max_digits=8, decimal_places=2)
    tunning_credit = models.PositiveIntegerField(default=0)
    vat = models.FloatField(null=True, blank=True, default=0.0)
    is_dealer_credit = models.BooleanField(default=False)
    dealer_credit_type = models.PositiveSmallIntegerField(
                        choices=DEALER_CREDIT_TYPE,default=1,
                        null=True,blank=True)
    category_id = models.PositiveIntegerField(default=0)
                        
    def subtotal(self):
        return self.quantity * self.price
    
    def subtotal(self):
        return self.quantity * self.price

class CustomerCredit(BaseModel):

    user =  models.OneToOneField(MyUser, null=True, blank=True,on_delete=models.CASCADE, related_name='customer_credit')
    file_key_credit = models.PositiveIntegerField(null=True, blank=True, default=0)
    function_credit = models.PositiveIntegerField(null=True, blank=True, default=0)
    evc_credit = models.PositiveIntegerField(null=True, blank=True, default=0)

    def __str__(self):
        return self.user.email
    
    class Meta:
        verbose_name = 'CustomerCredit'
        verbose_name_plural = 'CustomerCredit'

class ResellerDistributeCredit(BaseModel):

    user =  models.OneToOneField(MyUser, null=True, blank=True, 
                                on_delete=models.CASCADE, 
                                related_name='reseller_dealer_credit')
    file_key_credit = models.PositiveIntegerField(null=True, blank=True, default=0)
    function_credit = models.PositiveIntegerField(null=True, blank=True, default=0)
    evc_credit = models.PositiveIntegerField(null=True, blank=True, default=0)

    def __str__(self):
        return self.user.email
    
    class Meta:
        verbose_name = 'Reseller Dealer Credit'
        verbose_name_plural = 'Reseller Dealer Credit'

class CustomerSpentHistory(BaseModel):

    CREDIT_TYPE = (
        (1, 'FILE_KEY_CREDIT'),
        (2, 'EVC_CREDIT'),
        (3, 'FUNCTION_CREDIT'),
    )


    user =  models.ForeignKey(MyUser, null=True, blank=True,on_delete=models.CASCADE, related_name='customer_spent')
    credit = models.PositiveSmallIntegerField(null=True, blank=True)
    credit_type = models.PositiveSmallIntegerField(choices=CREDIT_TYPE)
    file_request_id = models.CharField(max_length=255, null=True, blank=True)

    def __str__(self):
        return self.user.email
    
    class Meta:
        verbose_name = 'CustomerSpentHistory'
        verbose_name_plural = 'CustomerSpentHistory'

class ManualCreditHistory(BaseModel):

    CREDIT_TYPE = (
        (1, 'FILE_KEY_CREDIT'),
        (2, 'EVC_CREDIT'),
        (3, 'FUNCTION_CREDIT'),
    )


    user =  models.ForeignKey(MyUser, null=True, blank=True,on_delete=models.CASCADE, related_name='customer_manual_credit')
    file_key_credit = models.PositiveIntegerField(null=True, blank=True, default=0)
    function_credit = models.PositiveIntegerField(null=True, blank=True, default=0)
    evc_credit = models.PositiveIntegerField(null=True, blank=True, default=0)
    manual_update_to_user = models.ForeignKey(MyUser, null=True, blank=True, on_delete=models.CASCADE)

    def __str__(self):
        return self.user.email
    
    class Meta:
        verbose_name = 'ManualCreditHistory'
        verbose_name_plural = 'ManualCreditHistory'