from apps.account.serializer import UserDetailSerializer
from apps.admin_management.constants import validate_user_ticket
from apps.file_request.models import FileRequest, RequestDownloadFiles
from apps.utils.zoho_books_utils import download_zoho_invoice_pdf
from rest_framework.response import Response
from rest_framework.filters import SearchFilter
from django_filters import rest_framework as filters

from rest_framework.views import APIView
from rest_framework import status, generics, viewsets

from rest_framework.authentication import TokenAuthentication
from rest_framework.permissions import IsAuthenticated
from rest_framework.parsers import FormParser, MultiPartParser
from apps.account.models import (
    EmailLogSettings, MyUser,
    ZOHOInvoices, ZOHOUser
)
from apps.utils.permissions import CanAdminDeleteOnly
from apps.admin_management.models import (
    Conversation, Notification,
    TicketAttachment, TicketHistory,
    TicketStatus,TicketCategory
)
from apps.customer.filters import TicketFilter
from apps.customer.models import (
    Cart, CustomerCredit, CustomerSpentHistory,
    OrderList, ManualCreditHistory, ResellerDistributeCredit
)
from apps.admin_management.serializer import (CustomerListSerializers)
from apps.customer.serializer import (
    CartSerializer, ConversationListSerializers, CustomerFileRequestListSerializer,
    CustomerLogsModelSerializers,
    NotificationHistorySerializer, OrderListSerializer, SpentHistorySerializer,
    StatusCountSerializer, TicketAttachmentSerializer,
    TicketHistorySerializer, UpdateBusinessRegisterSerializer,
    UpdateIndividualRegisterSerializer, CustomerCreditSerializer,
    ZOHOInvoiceHistorySerializers, ResellerDealerCreditSerializer,
    CustomerResellerCreditSerializer
)
from django.db.models import Q
from apps.utils.ecode_decode import FileOperation
from apps.account.models import AccessLogsModel
from datetime import datetime

from apps.utils.helper import create_notification, triger_socket, triger_conversation_socket
from apps.utils.pagination import SetPagination
import apps.admin_management.response_message as resp_msg
from django.db.models import Count

from drf_yasg.utils import swagger_auto_schema
from apps.account.schema import (
    individual_register_register_schema,
    business_register_register_schema,
    update_credit_point_schema
)
import apps.utils.evc_apis as evc_utils
from apps.account.models import EVCCredentials
from apps.admin_management.filters import LogsFilter
from urllib.parse import unquote
import json
import logging
logger = logging.getLogger('django')

class TicketView(viewsets.ModelViewSet):
    permission_classes = [IsAuthenticated]
    authentication_classes = [TokenAuthentication]
    queryset = TicketHistory.objects.all().order_by('-updated_at')
    serializer_class = TicketHistorySerializer
    pagination_class = SetPagination
    search_fields = ['subject']
    parser_classes = (FormParser, MultiPartParser)
    filter_backends = (filters.DjangoFilterBackend, SearchFilter)
    filterset_class = TicketFilter

    def destroy(self, request, *args, **kwargs):
        return Response({
            'message': "This method is not allowed"
        }, status=status.HTTP_405_METHOD_NOT_ALLOWED)

    def create(self, request, *args, **kwargs):
        params = request.data
        fr = FileRequest.objects.get(
            request_id=params['file_request']) if 'file_request' in params and FileRequest.objects.filter(
            request_id=params['file_request']).exists() else None
        if fr:
            ticket_data = TicketHistory.objects.filter(request_id__exact=fr.request_id).exists()
            if ticket_data:
                return Response({
                    "message":"A ticket already exists for this file request."
                })
        return super(TicketView, self).create(request, *args, **kwargs)

    def get_queryset(self):
        params = self.request.query_params
        if 'status' in params:
            status = params['status'].split(",")
            int_status = [int(s) for s in status]
            return TicketHistory.objects.filter(ticket_status__in=int_status, created_by=self.request.user).order_by(
                '-updated_at')
        else:
            return self.request.user.ticket_created_by.all().order_by('-updated_at')

    def list(self, request, *args, **kwargs):
        field_to_sort = request.query_params.get('field')
        order_in = request.query_params.get('order_in')
        order_by_str = ''

        if field_to_sort and order_in:
            if order_in == 'asc':
                order_by_str = field_to_sort
            elif order_in == 'dec':
                order_by_str = '-' + field_to_sort

        queryset = self.get_queryset()

        if field_to_sort == 'ticket_status':
            from apps.admin_management.constants import USER_TECKET_STATUS
            from django.db.models import Case, Value, CharField, When

            CUSTOM_SORT_ORDER = {
                'Awaiting feedback': 1,
                'Closed': 2,
                'ECU Booked in': 3,
                'Escalated': 4,
                'In Development': 5,
                'In progress': 6,
                'New': 7,
                'On Hold': 8,
                'Pending': 9,
                'Pending reply': 10
            }

            case_expression = Case(
                *[When(ticket_status_id=status_id, then=Value(order)) for status_name, order in
                  CUSTOM_SORT_ORDER.items()
                  for status_id, name in USER_TECKET_STATUS if name == status_name],
                output_field=CharField(),
                default=Value(len(CUSTOM_SORT_ORDER) + 1)
            )

            if order_in == 'asc':
                queryset = queryset.order_by(case_expression)
            elif order_in == 'dec':
                queryset = queryset.order_by(case_expression).reverse()
        else:
            if order_by_str:
                queryset = queryset.order_by(order_by_str)

        page = self.paginate_queryset(queryset)
        if page is not None:
            serializer = self.get_serializer(page, many=True)
            return self.get_paginated_response(serializer.data)

        serializer = self.get_serializer(queryset, many=True)
        return Response({
            'data': serializer.data,
            'message': resp_msg.RECORD_FETCHED_SUCCESSFULLY
        }, status=status.HTTP_200_OK)

    def get_serializer_context(self):
        return {'request': self.request, }

    def update(self, request, *args, **kwargs):
        return Response({
            'message': "This method is not allowed"
        }, status=status.HTTP_405_METHOD_NOT_ALLOWED)

#--
class TicketUpdateView(viewsets.ModelViewSet):
    permission_classes = [IsAuthenticated]

    def update(self, request, *args, **kwargs):
        params = request.data
        try:
            # Retrieve the ticket object by ID
            ticket = TicketHistory.objects.get(ids=self.kwargs['ids'])
        except TicketHistory.DoesNotExist:
            return Response({'error': 'Ticket not found'}, status=status.HTTP_404_NOT_FOUND)
        try:
            old_details = {
                "subject":ticket.subject,
                "category":ticket.category,
                "description":ticket.description,
                "vehicle_details":ticket.vehicle_details
            }
            ticket.subject = params.get('subject')
            ticket.category = TicketCategory.objects.get(id=params.get('category'))
            
            ticket.description = params.get('description')
            ticket.vehicle_details = json.loads(params.get('vehicle_details'))
            ticket.save()
            new_details = {
                "subject":ticket.subject,
                "category":ticket.category,
                "description":ticket.description,
                "vehicle_details":ticket.vehicle_details
            }
            #--- ticket updateb Logs---
            x_forwarded_for = request.META.get('HTTP_X_FORWARDED_FOR')
            admin_log = AccessLogsModel.objects.create(
                user=request.user,
                timestamp=datetime.now(),
                ip_address=x_forwarded_for.split(',')[0] if x_forwarded_for else request.META.get('REMOTE_ADDR'),
                method='Update',
                event='Update',
                module=EmailLogSettings.objects.filter(module='ticket').last(),
                title=f'Ticket Update - {ticket.ids}',
                description=f'Ticket Updated by - {request.user}',
                customer=request.user,
                old_details=old_details,
                new_details=new_details,
            )
            print(f"Admin logs created : {admin_log}")

            # For customer side log.
            customer_log = AccessLogsModel.objects.create(
                user=request.user,
                timestamp=datetime.now(),
                ip_address=x_forwarded_for.split(',')[0] if x_forwarded_for else request.META.get('REMOTE_ADDR'),
                method='Update',
                event='Update',
                module=EmailLogSettings.objects.filter(module='ticket').last(),
                title=f'Ticket Update - {ticket.ids}',
                description=f'Ticket Updated by - {request.user}',
                customer=request.user,
                to_customer_only=True,
                old_details=old_details,
                new_details=new_details,
            )
            print(f"customer log created : {customer_log}")
            #---
        except:
            Response({
                'message': "Something Went wrong during updation"
            }, status=status.HTTP_400_BAD_REQUEST)
            
        return Response({
            # 'data':ticket,
            'message': "Ticket updated successfully"
        }, status=status.HTTP_200_OK)
#--
class TicketSearchView(viewsets.ModelViewSet):
    serializer_class = TicketHistorySerializer
    filter_backends = (filters.DjangoFilterBackend, SearchFilter,)
    pagination_class = SetPagination
    search_fields = ['ids', 'subject', 'category__name',
                     'assigned_to__first_name', 'assigned_to__last_name',
                     'description', 'ticket_status__team_status', "file_request__request_id",
                     "file_request__vehicle_type", "file_request__vehicle_make",
                     "file_request__model", "file_request__vehicle_registration", "file_request__vehicle_year",
                     "file_request__vehicle_VIN", "file_request__engine_size", "file_request__transmission",
                     "file_request__fuel_type", "file_request__mileage_type", "file_request__mileage",
                     "file_request__ecu_brand", "file_request__customer_first_name", "file_request__customer_last_name",
                     "file_request__ecu_version", "file_request__control_unit", "file_request__file_type",
                     "file_request__country", "file_request__tuning_tool_used", "file_request__tuning_required",
                     "file_request__additional_info", "file_request__additional_function", "created_by__first_name",
                     "created_by__last_name", "assigned_to__email", "created_by__email"]

    def get_queryset(self):
        params = self.request.query_params
        if 'status' in params:
            status = params['status'].split(",")
            int_status = [int(s) for s in status]
            return TicketHistory.objects.filter(ticket_status__in=int_status, created_by=self.request.user).order_by(
                '-id')
        else:
            return self.request.user.ticket_created_by.all().order_by('-id')

    def list(self, request, *args, **kwargs):
        results = super(TicketSearchView, self).list(request, *args, **kwargs)
        return Response({
            'data': results.data,
            'message': resp_msg.RECORD_FETCHED_SUCCESSFULLY
        }, status=status.HTTP_200_OK)


class ConversationListView(generics.ListAPIView):
    permission_classes = [IsAuthenticated]
    authentication_classes = [TokenAuthentication, ]
    pagination_class = SetPagination
    # Create your views here.
    serializer_class = ConversationListSerializers

    def get_queryset(self):
        from apps.admin_management.constants import validate_user_ticket
        ticket = TicketHistory.objects.get(ids=self.kwargs['ids'])
        flag = validate_user_ticket(self.request.user, ticket, ticket.assigned_to)
        if flag:
            return Conversation.objects.filter(ticket__ids=self.kwargs['ids']).order_by('-id')
        else:
            return Conversation.objects.filter(ticket__ids=self.kwargs['ids'], ticket__created_by=self.request.user, ticket__assigned_to=self.request.user).order_by('-id')

    def list(self, request, *args, **kwargs):
        recipient = None
        ticket = TicketHistory.objects.get(ids=self.kwargs['ids'])
        from apps.admin_management.constants import validate_user_ticket
        flag = validate_user_ticket(self.request.user, ticket, ticket.assigned_to)
        if not flag:
            return Response({
                'sender': None,
                'recipient': None,
                'message': resp_msg.UNAUTHORIZED_USER,
                'data': None
            }, status=status.HTTP_401_UNAUTHORIZED)
        if request.user.id == ticket.created_by.id and ticket.assigned_to:
            recipient = ticket.assigned_to.id
        elif request.user.id != ticket.created_by.id:
            recipient = ticket.created_by.id

        response = super(ConversationListView, self).list(request, *args, **kwargs)
        for result in response.data['results']:
            try:
                user_data = MyUser.objects.get(id=result['sender'])
                result['is_internal_user'] = True if user_data.user_type == 1 or user_data.user_type == 2 or user_data.user_type == 5 else False
            except:
                pass
        return Response({
            'sender': request.user.id,
            'recipient': recipient,
            'message': resp_msg.RECORD_FETCHED_SUCCESSFULLY,
            'data': response.data
        }, status=status.HTTP_200_OK)


class ConversationHistoryListView(generics.ListAPIView):
    permission_classes = [IsAuthenticated]
    authentication_classes = [TokenAuthentication, ]
    pagination_class = SetPagination
    serializer_class = NotificationHistorySerializer

    def get_queryset(self):
        ticket = TicketHistory.objects.get(ids=self.kwargs['ids'])
        flag = validate_user_ticket(self.request.user, ticket, ticket.assigned_to)
        if not flag:
            return Notification.objects.filter(ticket__ids=self.kwargs['ids'], ticket__created_by=self.request.user, ticket__assigned_to=self.request.user).order_by('id')
        return Notification.objects.filter(ticket__ids=self.kwargs['ids']).order_by('id')

    def list(self, request, *args, **kwargs):
        ticket = TicketHistory.objects.get(ids=self.kwargs['ids'])
        flag = validate_user_ticket(self.request.user, ticket, ticket.assigned_to)
        if not flag:
            return Response({
                'message': resp_msg.UNAUTHORIZED_USER,
                'data': None
            }, status=status.HTTP_401_UNAUTHORIZED)
        response = super(ConversationHistoryListView, self).list(request, *args, **kwargs)
        return Response({
            'message': resp_msg.RECORD_FETCHED_SUCCESSFULLY,
            'data': response.data
        }, status=status.HTTP_200_OK)


class ConversationAttachmentView(generics.CreateAPIView, generics.ListAPIView):
    permission_classes = [IsAuthenticated]
    authentication_classes = [TokenAuthentication]
    parser_classes = (FormParser, MultiPartParser)
    serializer_class = TicketAttachmentSerializer
    queryset = TicketAttachment.objects.all().order_by('-id')

    def get_serializer_context(self):
        return {'request': self.request}

    def post(self, request, *args, **kwargs):
        ticket = TicketHistory.objects.get(ids=self.kwargs['ids'])
        params = request.data
        flag = validate_user_ticket(self.request.user, ticket, ticket.assigned_to)
        if not flag:
            return Response({
                'message': resp_msg.UNAUTHORIZED_USER
            }, status=status.HTTP_401_UNAUTHORIZED)

        attachment_type = int(params['attachement_type'])
        attach = None
        if 'files' in request.FILES:
            for data in request.FILES.getlist('files'):
                attach = TicketAttachment.objects.create(
                    uploaded_by=request.user,
                    ticket=ticket,
                    file=data,
                    attachement_type=attachment_type,
                    attachement_name=params['attachement_name'],
                )

                obj = Conversation.objects.create(
                    ticket=ticket,
                    message_type="text",
                    text="A file has been uploaded by the support team with name : {}".format(
                        params['attachement_name']),
                    sender=request.user,
                    recipient=ticket.created_by,
                )
                response = ConversationListSerializers(obj).data
                active_users = UserDetailSerializer(obj.ticket.active_users.all(), many=True).data
                response['active_users'] = active_users
                response['ticket_id'] = obj.ticket.ids
                triger_conversation_socket(response)

                # triger_socket({
                #     'uuid': str(created_by.uuid),
                #     'type': 'user_attachment_refresh',
                #     'ids': str(ticket.ids),
                #     'message': "Attachment has been added."
                # })
                #
                # triger_socket({
                #     'uuid': str(assigned_to.uuid),
                #     'type': 'admin_attachment_refresh',
                #     'ids': str(ticket.ids),
                #     'message': "Attachment has been added."
                # })

            assigned_to = ticket.created_by if ticket.assigned_to.id == request.user.id else ticket.assigned_to

            file_request = ticket.file_request
            if file_request is None:
                file_request = FileRequest.objects.get(request_id=ticket.request_id)
            if (file_request is not None
                    and attach is not None):
                RequestDownloadFiles.objects.create(
                    fil_request_id=file_request,
                    title=params['attachement_name'],
                    url=attach.file.url,
                    sent_to_user=True,
                )

                if attachment_type == 1:
                    file_request.status = "CLOSED"
                    file_request.save()
                    ticket.ticket_status = TicketStatus.objects.get(team_status="File Completed")
                    ticket.save()

                if request.user.user_type in [3, 4, 6, 7]:
                    ticket.ticket_status = TicketStatus.objects.get(team_status="New")
                    ticket.save()


            create_notification(assigned_to,
                                "Ticket Attachment Uploaded: {}".format(ticket.ids),
                                "Ticket attachment has been uploaded by {} {}.".format(request.user.first_name,
                                                                                       request.user.last_name),
                                sender=request.user,
                                ticket=ticket, file=None)
        ticket_history = TicketHistory.objects.get(ids=ticket.ids)
        conversation_count = Conversation.objects.filter(ticket=ticket_history).count()
        triger_socket({
            'uuid':str(ticket_history.created_by.uuid),
            'type':'ticket_info_update',
            'ticket_id':str(ticket_history.ids),
            'ticket_status':str(ticket_history.ticket_status.get_user_status_display()),
            'ticket_conversation':str(conversation_count),
            'ticket_modified_time':str(ticket_history.updated_at.replace(tzinfo=None).isoformat() + 'Z'),
            'ticket_assigned':str(ticket_history.assigned_to.first_name + ' ' + ticket_history.assigned_to.last_name)
        })
        users = MyUser.objects.filter(
            Q(user_type=2) |
            Q(user_type=5) |
            Q(user_type=1)
        )
        for each in users:
            triger_socket({
                'uuid':str(each.uuid),
                'type':'ticket_info_update',
                'ticket_id':str(ticket_history.ids),
                'ticket_status':str(ticket_history.ticket_status.team_status),
                'ticket_conversation':str(conversation_count),
                'ticket_modified_time':str(ticket_history.updated_at.replace(tzinfo=None).isoformat() + 'Z'),
                'ticket_assigned':str(ticket_history.assigned_to.first_name + ' ' + ticket_history.assigned_to.last_name)
            })
        return Response({
            'message': 'Attachment saved successfully.',
        }, status=status.HTTP_200_OK)

    def get_queryset(self):
        ticket = TicketHistory.objects.get(ids=self.kwargs['ids'])
        flag = validate_user_ticket(self.request.user, ticket, ticket.assigned_to)
        if flag:
            return TicketAttachment.objects.filter(ticket__ids=self.kwargs['ids']).order_by('-id')
        else:
            return None

    def list(self, request, *args, **kwargs):
        print("inside list view ---------------------- ")
        ticket = TicketHistory.objects.get(ids=self.kwargs['ids'])
        flag = validate_user_ticket(self.request.user, ticket, ticket.assigned_to)
        if not flag:
            return Response({
                'message': resp_msg.UNAUTHORIZED_USER,
                'data': None
            }, status=status.HTTP_401_UNAUTHORIZED)
        response = super(ConversationAttachmentView, self).list(request, *args, **kwargs)
        response_data = response.data
        for data in response_data:
            url = data['file']
            print(f"url == {url}")
            decoded_url = unquote(url)
            if "https://" in decoded_url:
                corrected_url = decoded_url.split("https:/")[-1]
                corrected_url = "https://" + corrected_url
            data['file'] = corrected_url

        return Response({
            'message': resp_msg.RECORD_FETCHED_SUCCESSFULLY,
            'data': response.data
        }, status=status.HTTP_200_OK)
    
    def delete(self, request, *args, **kwargs):
        try:

            response = TicketAttachment.objects.get(id=kwargs['id'])
            flag = validate_user_ticket(self.request.user, response.ticket, response.ticket.assigned_to)
            if not flag:
                return Response({
                    'success': False,
                    'message': resp_msg.UNAUTHORIZED_USER
                }, status=status.HTTP_401_UNAUTHORIZED)
            response.delete() # delete ticket attachment
            
            request_id = response.ticket.request_id # get file request id from ticket attachment.
            queryset = RequestDownloadFiles.objects.filter(
                fil_request_id__request_id=request_id,
                sent_to_user=True)
            
            # check if ticket attachment file is available is file request download module then
            # also delete from it.
            for data in queryset:
                if response.file.url == data.url:
                    data.delete()
                    break

            assigned_to = response.ticket.created_by if response.ticket.assigned_to.id == request.user.id else response.ticket.assigned_to
            create_notification(assigned_to,
                "Attachment Deleted:",
                "Attachment has been deleted by {} {}.".format(request.user.first_name,
                                                        request.user.last_name),
                sender=request.user,
                ticket=response.ticket, file=None)
        except:
            pass
        return Response({
            'success': True,
            'message': 'Attachment Delete successfully'
        },status=status.HTTP_200_OK)

class AttachmentDownloadLogs(generics.CreateAPIView, generics.ListAPIView):
    permission_classes = [IsAuthenticated]
    authentication_classes = [TokenAuthentication]

    def get(self,request, **kwargs):
        try:
            response = TicketAttachment.objects.get(id=kwargs['id'])
            flag = validate_user_ticket(self.request.user, response.ticket, response.ticket.assigned_to)
            if not flag:
                return Response({
                    'success': False,
                    'message': resp_msg.UNAUTHORIZED_USER
                }, status=status.HTTP_401_UNAUTHORIZED)
            assigned_to = response.ticket.created_by if response.ticket.assigned_to.id == request.user.id else response.ticket.assigned_to
            create_notification(assigned_to,
                "Attachment Download:",
                "Attachment has been download by {} {}.".format(request.user.first_name,
                                                        request.user.last_name),
                sender=request.user,
                ticket=response.ticket, file=None)
        except:
            pass
        return Response({
            'success': True,
            'message': 'Attachment download successfully'
        }, status=status.HTTP_200_OK)

class CartView(generics.CreateAPIView, generics.ListAPIView):
    permission_classes = [IsAuthenticated]
    authentication_classes = [TokenAuthentication]
    serializer_class = CartSerializer
    queryset = Cart.objects.all().order_by('-id')

    def get_serializer_context(self):
        return {'request': self.request}

    def post(self, request, *args, **kwargs):
        params = request.data
        logger.info(f"Cart Payload == {params}")
        for each in params['cart']:
            if 'categoryIds' in each:
                if 177 in each['categoryIds']:
                    each['is_dealer_credit'] = True
                elif 178 in each['categoryIds']:
                    each['is_dealer_credit'] = True            
                elif 174 in each['categoryIds']: #evc
                    each['is_dealer_credit'] = False
                elif 175 in each['categoryIds']: # file
                    each['is_dealer_credit'] = False
                elif 176 in each['categoryIds']: # function
                    each['is_dealer_credit'] = False

        for each in params['cart']:
            if int(each['quantity'] == 0):
                Cart.objects.filter(
                    product=each['product_id'],
                ).delete()
            elif int(each['quantity'] > 0):
                instance, created = Cart.objects.get_or_create(
                    user=request.user,
                    product=each['product_id']
                )
                # if uk client:
                vat = 0
                if request.user.address_user.country == "United Kingdom":
                    vat = (int(each['quantity']) * float(each['price'])) * 0.2

                instance.quantity = each['quantity']
                instance.price = each['price']
                instance.type = each['type']
                instance.vat = vat
                instance.category_list=each['categoryIds']
                instance.tunning_credit = each['tunning_credit']
                if 'is_dealer_credit' in each:
                    instance.is_dealer_credit = each['is_dealer_credit']
                if 'dealer_credit_type' in each:
                    instance.dealer_credit_type = each['dealer_credit_type']
                instance.save()

        return Response({
            'message': 'Cart updated successfully.',
        }, status=status.HTTP_200_OK)

    def get_queryset(self):
        return Cart.objects.filter(user=self.request.user).order_by('-id')

    def list(self, request, *args, **kwargs):
        response = super(CartView, self).list(request, *args, **kwargs)
        return Response({
            'message': resp_msg.RECORD_FETCHED_SUCCESSFULLY,
            'data': response.data
        }, status=status.HTTP_200_OK)


class PurchaseHistoryView(generics.ListAPIView):
    permission_classes = [IsAuthenticated]
    authentication_classes = [TokenAuthentication]
    serializer_class = OrderListSerializer
    queryset = OrderList.objects.all().order_by('-id')
    pagination_class = SetPagination

    def get_serializer_context(self):
        return {'request': self.request}

    def get_queryset(self):
        return OrderList.objects.filter(user=self.request.user, status=2).order_by('-id')

    def list(self, request, *args, **kwargs):
        field_to_sort = request.query_params.get('field')
        order_in = request.query_params.get('order_in')

        if order_in == 'asc':
            order_by_str = field_to_sort
        elif order_in == 'dec':
            order_by_str = '-' + field_to_sort
        else:
            order_by_str = ''

        if field_to_sort is not None and order_by_str is not None:
            queryset = self.get_queryset().order_by(order_by_str)
            serializer = OrderListSerializer(queryset, many=True)
            page = self.paginate_queryset(serializer.data)
            data = dict(self.get_paginated_response(page).data)
        else:
            data = super(PurchaseHistoryView, self).list(request, *args, **kwargs).data

        return Response({
            'message': resp_msg.RECORD_FETCHED_SUCCESSFULLY,
            'data': data
        }, status=status.HTTP_200_OK)


class CustomerPurchaseHistoryAdminView(generics.ListAPIView):
    permission_classes = [IsAuthenticated]
    authentication_classes = [TokenAuthentication]
    serializer_class = OrderListSerializer
    queryset = OrderList.objects.all().order_by('-id')
    pagination_class = SetPagination

    def get_queryset(self):
        params = self.request.query_params
        uuid = params['uuid']
        user = MyUser.objects.get(uuid=uuid)
        return OrderList.objects.filter(user=user, status=2).order_by('-id')

    def list(self, request, *args, **kwargs):

        field_to_sort = request.query_params.get('field')
        order_in = request.query_params.get('order_in')

        if order_in == 'asc':
            order_by_str = field_to_sort
        elif order_in == 'dec':
            order_by_str = '-' + field_to_sort
        else:
            order_by_str = ''

        if field_to_sort is not None and order_by_str is not None:
            queryset = self.get_queryset().order_by(order_by_str)
            serializer = OrderListSerializer(queryset, many=True)
            page = self.paginate_queryset(serializer.data)
            data = dict(self.get_paginated_response(page).data)
        else:
            data = super(CustomerPurchaseHistoryAdminView, self).list(request, *args, **kwargs).data
        return Response({
            'message': resp_msg.RECORD_FETCHED_SUCCESSFULLY,
            'data': data
        }, status=status.HTTP_200_OK)


class AdminZOHOInvoiceHistoryView(generics.ListAPIView):
    permission_classes = [IsAuthenticated]
    authentication_classes = [TokenAuthentication]
    serializer_class = ZOHOInvoiceHistorySerializers
    queryset = OrderList.objects.all().order_by('-id')
    pagination_class = SetPagination

    def get_serializer_context(self):
        return {'request': self.request}

    def get_queryset(self):
        user_uuid = self.kwargs['uuid']
        user = MyUser.objects.get(uuid=user_uuid)
        zoho_user = ZOHOUser.objects.filter(user=user).first()
        return ZOHOInvoices.objects.filter(user=zoho_user).order_by('-id')

    def list(self, request, *args, **kwargs):
        response = super(AdminZOHOInvoiceHistoryView, self).list(request, *args, **kwargs)
        return Response({
            'message': resp_msg.RECORD_FETCHED_SUCCESSFULLY,
            'data': response.data
        }, status=status.HTTP_200_OK)


class CustomerSpentHistoryAdminView(generics.ListAPIView):
    permission_classes = [IsAuthenticated]
    authentication_classes = [TokenAuthentication]
    serializer_class = SpentHistorySerializer
    queryset = CustomerSpentHistory.objects.all().order_by('-id')
    pagination_class = SetPagination

    def get_queryset(self):
        params = self.request.query_params
        uuid = params['uuid']
        user = MyUser.objects.get(uuid=uuid)
        return CustomerSpentHistory.objects.filter(user=user).order_by('-id')

    def list(self, request, *args, **kwargs):

        field_to_sort = request.query_params.get('field')
        order_in = request.query_params.get('order_in')

        if order_in == 'asc':
            order_by_str = field_to_sort
        elif order_in == 'dec':
            order_by_str = '-' + field_to_sort
        else:
            order_by_str = ''

        if field_to_sort is not None and order_by_str is not None:
            queryset = self.get_queryset().order_by(order_by_str)
            serializer = SpentHistorySerializer(queryset, many=True)
            page = self.paginate_queryset(serializer.data)
            data = dict(self.get_paginated_response(page).data)
        else:

            data = super(CustomerSpentHistoryAdminView, self).list(request, *args, **kwargs).data
        return Response({
            'message': resp_msg.RECORD_FETCHED_SUCCESSFULLY,
            'data': data
        }, status=status.HTTP_200_OK)


class IndividualProfileView(generics.CreateAPIView):
    permission_classes = [IsAuthenticated]
    authentication_classes = [TokenAuthentication]
    serializer_class = UpdateIndividualRegisterSerializer
    queryset = MyUser.objects.all()

    @swagger_auto_schema(request_body=individual_register_register_schema, tags=['customer'])
    def post(self, request):
        params = request.data
        serializer = self.get_serializer(request.user, data=params, context={'request': request}, partial=True)
        serializer.is_valid(raise_exception=True)
        serializer.save()
        return Response({
            'message': 'Profile updated successfully.',
        }, status=status.HTTP_200_OK)


class BusinessProfileView(generics.CreateAPIView):
    permission_classes = [IsAuthenticated]
    authentication_classes = [TokenAuthentication]
    serializer_class = UpdateBusinessRegisterSerializer
    queryset = MyUser.objects.all()

    @swagger_auto_schema(request_body=business_register_register_schema, tags=['customer'])
    def post(self, request):
        params = request.data
        user = request.user
        #---
        old_details = {
            "id":user.id,
            "first_name":user.first_name,
            "last_name":user.last_name,
            "email":user.email,
            "phone_no":user.phone_no,
            "address":user.address_user.address,
            "address":user.address_user.address_2,
            "tax_number":user.business_user.tax_number,
            "company_number":user.business_user.company_number
        }
        #---
        if user.user_type == 3:
            params['business_profile'].pop('bussness_name',None)
        serializer = self.get_serializer(
            request.user,
            data=params,
            context={'request': request},
            partial=True)
        serializer.is_valid(raise_exception=True)
        serializer.save()
        instance = MyUser.objects.get(uuid=request.user.uuid)
        #---
        new_details = {
            "id":instance.id,
            "first_name":instance.first_name,
            "last_name":instance.last_name,
            "email":instance.email,
            "phone_no":instance.phone_no,
            "address":instance.address_user.address,
            "address":instance.address_user.address_2,
            "tax_number":instance.business_user.tax_number,
            "company_number":instance.business_user.company_number
        }
        #---
        #--- admin log----
        x_forwarded_for = request.META.get('HTTP_X_FORWARDED_FOR')

        ip_address=x_forwarded_for.split(',')[0] if x_forwarded_for else request.META.get('REMOTE_ADDR'),
        admin_log = AccessLogsModel.objects.create(
            user=request.user,
            timestamp=datetime.now(),
            ip_address=x_forwarded_for.split(',')[0] if x_forwarded_for else request.META.get('REMOTE_ADDR'),
            method='Update',
            event='Bussness Profile updated',
            module=EmailLogSettings.objects.filter(module='Bussness Customer Profile Updated').last(),
            title='Bussness Profile updated',
            description=f"Customer profile updated",
            old_details=old_details,
            new_details=new_details,
            customer=user,
            to_customer_only=False,
        )
        #--- end admin log----
        return Response({
            'data': {
                'is_evc_customer': instance.is_evc_customer,
                'is_evc_reseller_customer': instance.is_evc_reseller_customer
            },
            'message': 'Profile updated successfully.',
        }, status=status.HTTP_200_OK)


class CustomerResellerCreditView(generics.ListAPIView, generics.UpdateAPIView):
    permission_classes = [IsAuthenticated, ]
    authentication_classes = [TokenAuthentication, ]

    serializer_class = CustomerResellerCreditSerializer

    def get_queryset(self):
        params = self.request.query_params
        user = MyUser.objects.get(uuid=params['uuid'])
        return ResellerDistributeCredit.objects.filter(user=user)

    def list(self, request, *args, **kwargs):
        results = super(CustomerResellerCreditView, self).list(request, *args, **kwargs)
        return Response({
            'data': results.data,
            'message': resp_msg.RECORD_FETCHED_SUCCESSFULLY
        }, status=status.HTTP_200_OK)

    def put(self, request):
        params = request.data
        user = MyUser.objects.get(uuid=params['uuid'])
        instance, _ = ResellerDistributeCredit.objects.get_or_create(
            user=user
        )
        customer_detail = user.first_name + ' ' + user.last_name + '(' + user.email + ')'
        request_user = request.user.first_name + ' ' + request.user.last_name + '(' + request.user.email + ')'

        if int(params['file_key_credit']) < 0:
            is_file_nagative = instance.file_key_credit + int(params['file_key_credit'])
            if is_file_nagative < 0:
                instance.file_key_credit = 0
            else:
                instance.file_key_credit = instance.file_key_credit + int(params['file_key_credit'])
                desc_file = "Subtracted:{0}".format(str(int(params['file_key_credit'])))
        else:
            instance.file_key_credit = instance.file_key_credit + int(params['file_key_credit'])
            desc_file = "Added:{0}".format(str(int(params['file_key_credit'])))

        if int(params['function_key_credit']) < 0:
            is_function_nagative = instance.function_credit + int(params['function_key_credit'])
            if is_function_nagative < 0:
                instance.function_credit = 0
            else:
                instance.function_credit = instance.function_credit + int(params['function_key_credit'])
                desc_function = "Subtracted:{0}".format(str(int(params['function_key_credit'])))
        else:
            instance.function_credit = instance.function_credit + int(params['function_key_credit'])
            desc_function = "Added:{0}".format(str(int(params['function_key_credit'])))

        instance.save()

        x_forwarded_for = request.META.get('HTTP_X_FORWARDED_FOR')

        admin_log = AccessLogsModel.objects.create(
            user=request.user,
            timestamp=datetime.now(),
            ip_address=x_forwarded_for.split(',')[0] if x_forwarded_for else request.META.get('REMOTE_ADDR'),
            method='Update',
            event='Update',
            module=EmailLogSettings.objects.filter(module='Reseller credit').last(),
            title='Reseller Credits updated manually.',
            description='Reseller Credits manually updated: File credit:{0}, Function credit: {1} for {2} by {3}.'.format(
                desc_file, desc_function, customer_detail, request_user),
            customer=user,
        )

        if 'file_request' in params:
            admin_log.file_request = params['file_request']
        if 'credit_update_type' in params:
            admin_log.credit_update_type = params['credit_update_type']
        if 'credit_update_description' in params:
            admin_log.credit_update_description = params['credit_update_description']
        admin_log.save()

        # For customer side log.
        customer_log = AccessLogsModel.objects.create(
            user=request.user,
            timestamp=datetime.now(),
            ip_address=x_forwarded_for.split(',')[0] if x_forwarded_for else request.META.get('REMOTE_ADDR'),
            method='Update',
            event='Update',
            module=EmailLogSettings.objects.filter(module='Customer credit').last(),
            title='Reseller Credits updated manually.',
            description='Reseller Credits manually updated: File credit:{0}, Function credit: {1} in your account by {2}.'.format(
                desc_file, desc_function, request_user),
            customer=user,
            to_customer_only=True,
        )
        if 'file_request' in params:
            customer_log.file_request = params['file_request']
        if 'credit_update_type' in params:
            customer_log.credit_update_type = params['credit_update_type']
        if 'credit_update_description' in params:
            customer_log.credit_update_description = params['credit_update_description']
        customer_log.save()

        serializer = ResellerDealerCreditSerializer(instance)

        return Response({
            'data': serializer.data,
            'message': 'Reseller Credit key updated successfully.',
        }, status=status.HTTP_200_OK)


class CustomerCreditView(generics.ListAPIView, generics.UpdateAPIView):
    permission_classes = [IsAuthenticated, ]
    authentication_classes = [TokenAuthentication, ]

    queryset = MyUser.objects.filter(
        Q(user_type=3) |
        Q(user_type=4) |
        Q(user_type=6)
    ).order_by('-id')
    serializer_class = CustomerListSerializers
    pagination_class = SetPagination
    search_fields = ['first_name', 'last_name', 'email', 'customer_credit__file_key_credit',
                     'customer_credit__function_credit', 'business_user__bussness_name',
                     'customer_credit__evc_credit']
    filter_backends = (filters.DjangoFilterBackend, SearchFilter,)

    def list(self, request, *args, **kwargs):
        field_to_sort = request.query_params.get('field')
        order_in = request.query_params.get('order_in')

        if order_in == 'asc':
            order_by_str = field_to_sort
        elif order_in == 'dec':
            order_by_str = '-' + field_to_sort
        else:
            order_by_str = ''

        if field_to_sort is not None and order_by_str is not None:
            queryset = self.get_queryset().order_by(order_by_str)
            serializer = CustomerListSerializers(queryset, many=True)
            page = self.paginate_queryset(serializer.data)
            data = dict(self.get_paginated_response(page).data)
        else:
            data = super(CustomerCreditView, self).list(request, *args, **kwargs).data
        return Response({
            'data': data,
            'message': resp_msg.RECORD_FETCHED_SUCCESSFULLY
        }, status=status.HTTP_200_OK)

    @swagger_auto_schema(request_body=update_credit_point_schema, tags=['customer'])
    def put(self, request):

        params = request.data
        user = MyUser.objects.get(uuid=params['uuid'])
        instance, _ = CustomerCredit.objects.get_or_create(
            user=user
        )
        old_details={
            'file_key_credit':instance.file_key_credit,
            'function_key_credit':instance.function_credit,
            'evc_key_credit':instance.evc_credit
        }
        customer_detail = user.first_name + ' ' + user.last_name + '(' + user.email + ')'
        request_user = request.user.first_name + ' ' + request.user.last_name + '(' + request.user.email + ')'

        if int(params['file_key_credit']) < 0:
            is_file_nagative = instance.file_key_credit + int(params['file_key_credit'])
            if is_file_nagative < 0:
                instance.file_key_credit = 0
            else:
                instance.file_key_credit = instance.file_key_credit + int(params['file_key_credit'])
                desc_file = "Subtracted:{0}".format(str(int(params['file_key_credit'])))
        else:
            instance.file_key_credit = instance.file_key_credit + int(params['file_key_credit'])
            desc_file = "Added:{0}".format(str(int(params['file_key_credit'])))

        if int(params['function_key_credit']) < 0:
            is_function_nagative = instance.function_credit + int(params['function_key_credit'])
            if is_function_nagative < 0:
                instance.function_credit = 0
            else:
                instance.function_credit = instance.function_credit + int(params['function_key_credit'])
                desc_function = "Subtracted:{0}".format(str(int(params['function_key_credit'])))
        else:
            instance.function_credit = instance.function_credit + int(params['function_key_credit'])
            desc_function = "Added:{0}".format(str(int(params['function_key_credit'])))

        if int(params['evc_key_credit']) < 0:
            instance.evc_credit = params['evc_key_credit']
            is_evc_nagative = instance.evc_credit + int(params['evc_key_credit'])
            if is_evc_nagative < 0:
                instance.evc_credit = 0
            else:
                instance.evc_credit = instance.evc_credit + int(params['evc_key_credit'])
                evc_function = "Subtracted:{0}".format(str(int(params['evc_key_credit'])))
        else:
            instance.evc_credit = instance.evc_credit + int(params['evc_key_credit'])
            evc_function = "Added:{0}".format(str(int(params['evc_key_credit'])))

        triger_socket({
            'uuid': str(params['uuid']),
            'type': 'customer_key_update',
            'file_key_credit': int(params['file_key_credit']),
            'function_credit': int(params['function_key_credit']),
            'evc_key_credit': int(params['evc_key_credit']),
        })
        instance.save()
        new_details={
            'file_key_credit':instance.file_key_credit,
            'function_key_credit':instance.function_credit,
            'evc_key_credit':instance.evc_credit
        }
        x_forwarded_for = request.META.get('HTTP_X_FORWARDED_FOR')

        admin_log = AccessLogsModel.objects.create(
            user=request.user,
            timestamp=datetime.now(),
            ip_address=x_forwarded_for.split(',')[0] if x_forwarded_for else request.META.get('REMOTE_ADDR'),
            method='Update',
            event='Credits updated manually',
            module=EmailLogSettings.objects.filter(module='Customer credit').last(),
            title='Credits updated manually.',
            # description='Credits manually updated: File credit:{0}, Function credit: {1} and EVC credit {2} for {3} by {4}.'.format(
            #     desc_file, desc_function, evc_function,
            #     customer_detail, request_user),
            old_details=old_details,
            new_details=new_details,
            customer=user,
            to_customer_only=False,
        )

        if 'file_request' in params:
            admin_log.file_request = params['file_request']
        if 'credit_update_type' in params:
            admin_log.credit_update_type = params['credit_update_type']
        if 'credit_update_description' in params:
            admin_log.credit_update_description = params['credit_update_description']
        admin_log.save()

        # For customer side log.
        customer_log = AccessLogsModel.objects.create(
            user=request.user,
            timestamp=datetime.now(),
            ip_address=x_forwarded_for.split(',')[0] if x_forwarded_for else request.META.get('REMOTE_ADDR'),
            method='Update',
            event='Credits updated manually',
            module=EmailLogSettings.objects.filter(module='Customer credit').last(),
            title='Credits updated manually.',
            # description='Credits manually updated: File credit:{0}, Function credit: {1} and EVC credit {2} in your account by {3}.'.format(
            #     desc_file, desc_function, evc_function, request_user),
            old_details=old_details,
            new_details=new_details,
            customer=user,
            to_customer_only=True,
        )
        if 'file_request' in params:
            customer_log.file_request = params['file_request']
        if 'credit_update_type' in params:
            customer_log.credit_update_type = params['credit_update_type']
        if 'credit_update_description' in params:
            customer_log.credit_update_description = params['credit_update_description']
        customer_log.save()

        serializer = CustomerCreditSerializer(instance)

        return Response({
            'data': serializer.data,
            'message': 'Credit key updated successfully.',
        }, status=status.HTTP_200_OK)


class EVCPurchaseHistoryView(APIView):
    permission_classes = [IsAuthenticated, ]
    authentication_classes = [TokenAuthentication, ]

    def get(self, request):
        obj = EVCCredentials.objects.all().first()
        customer_id = 33333
        lastndays = 999
        data = evc_utils.get_recent_purchase(
            obj.apiid, obj.username,
            obj.password, lastndays,
            customer_id)
        return Response({
            'data': data,
            'message': resp_msg.RECORD_FETCHED_SUCCESSFULLY
        }, status=status.HTTP_200_OK)


# class AuthTokenView(APIView):

#     def get(self,request):
#         response = FileOperation().generate_auth_token()
#         return Response({
#             'data':response
#         },status=status.HTTP_400_BAD_REQUEST)

# class DecodeFileView(generics.CreateAPIView,generics.ListAPIView):
#     pagination_class = SetPagination
#     parser_classes = (FormParser, MultiPartParser)
#     serializer_class = DecodeFileSerializer
#     permission_classes = [IsAuthenticated,]
#     authentication_classes = [TokenAuthentication, ]
#     queryset = DecodeFiles.objects.all().order_by('-id')

#     def post(self,request):
#         params = request.data
#         is_sucess,response  = False,None
#         evc_instance = EVCCredentials.objects.all().last()
#         if params['type'] == 1 or params['type'] == '1':
#             is_sucess,response = FileOperation().decode_kessV2_file(evc_instance.alientechauttoken,request.FILES['readfile'])
#         elif params['type'] == 2 or params['type'] == '2':
#             is_sucess,response = FileOperation().decode_kess3_file(evc_instance.alientechauttoken,request.FILES['readfile'])
#         elif params['type'] == 3 or params['type'] == '3':
#             is_sucess,response = FileOperation().decode_ktag_file(evc_instance.alientechauttoken,request.FILES['readfile'])
#         else:
#             return Response({
#                 'details':"Invalid Type"
#             },status=status.HTTP_400_BAD_REQUEST)
#         if is_sucess:
#             instance = DecodeFiles.objects.create(
#                 user = request.user,
#                 type = params['type'],
#                 file = request.FILES['readfile'],
#                 decode_response  = response,
#                 guid = response['guid']
#             )
#             instance.update_ids()
#             instance.save()
#             return Response({
#                 'message':'File upload successfully for decode file.',
#                 'data':response
#             })
#         return Response({
#             'message':'Something went wrong while file decode.',
#             'detail':response
#         },status=status.HTTP_400_BAD_REQUEST)


#     def list(self, request, *args, **kwargs):
#         response = super(DecodeFileView, self).list(request, *args, **kwargs)
#         return Response({
#             'message': resp_msg.RECORD_FETCHED_SUCCESSFULLY,
#             'data': response.data
#         }, status=status.HTTP_200_OK)


# class DecodeAnyFileFileView(APIView):
#     permission_classes = [IsAuthenticated,]
#     authentication_classes = [TokenAuthentication, ]

#     @swagger_auto_schema(request_body=encode_download_any_file_schema)
#     def post(self,request):
#         params = request.data
#         evc_instance = EVCCredentials.objects.all().last()

#         is_sucess,response = FileOperation().download_file(
#             evc_instance.alientechauttoken,
#             params['url']
#         )
#         if is_sucess:
#             return Response({
#                 'message':'Decode file details fatched successfully',
#                 'data':response,
#             })
#         return Response({
#             'message':'Something went wrong while file decode.',
#             'detail':response,
#         },status=status.HTTP_400_BAD_REQUEST)


# class DecodeFileDownloadView(APIView):
#     def get(slef,request,guid):
#         evc_instance = EVCCredentials.objects.all().last()
#         decode_instance = DecodeFiles.objects.get(guid=guid)
#         is_sucess,response = FileOperation().download_decode_file(
#             evc_instance.alientechauttoken,
#             json.loads(decode_instance.async_response)['slotGUID'],
#             decode_instance.get_type_display()
#         )
#         if is_sucess:
#             return Response({
#                 'message':'Decode file details fatched successfully',
#                 'data':response,
#                 'filename': json.loads(decode_instance.async_response)['result']['name']  if'result' in json.loads(decode_instance.async_response) and 'name' in json.loads(decode_instance.async_response)['result'] else 'N/A'
#             })
#         return Response({
#             'message':'Something went wrong while file decode.',
#             'detail':response,
#             'testing':json.loads(decode_instance.async_response)
#         },status=status.HTTP_400_BAD_REQUEST)


# class EncodeModifiedFileView(generics.CreateAPIView,generics.ListAPIView):
#     pagination_class = SetPagination
#     parser_classes = (FormParser, MultiPartParser)
#     serializer_class = EncdeFilesFileSerializer
#     permission_classes = [IsAuthenticated,]
#     authentication_classes = [TokenAuthentication, ]
#     queryset = EncdeFiles.objects.all().order_by('-id')

#     def post(self,request):
#         params = request.data
#         is_sucess,response  = False,None
#         evc_instance = EVCCredentials.objects.all().last()

#         decode_instance = DecodeFiles.objects.get(guid = params['decode'])
#         print(decode_instance.type)

#         if decode_instance.type == 1 or decode_instance.type == '1':
#             is_sucess,response = FileOperation().kessv2_upload_modified_file(
#                 evc_instance.alientechauttoken,
#                 request.FILES['readfile'],
#                 json.loads(decode_instance.async_response)['slotGUID'],
#             )
#         elif decode_instance.type == 2 or decode_instance.type == '2':
#             is_sucess,response = FileOperation().kessv3_upload_modified_file(
#                 evc_instance.alientechauttoken,
#                 request.FILES['readfile'],
#                 json.loads(decode_instance.async_response)['slotGUID'],
#                 params['type'],
#             )
#         elif decode_instance.type == 3 or decode_instance.type == '3':
#             is_sucess,response = FileOperation().ktag_upload_modified_file(
#                 evc_instance.alientechauttoken,
#                 request.FILES['readfile'],
#                 json.loads(decode_instance.async_response)['slotGUID'],
#                 params['type'],

#             )
#         else:
#             return Response({
#                 'details':"Invalid Type"
#             },status=status.HTTP_400_BAD_REQUEST)
#         if is_sucess:
#             instance = EncdeFiles.objects.create(
#                 user = request.user,
#                 decode = decode_instance,
#                 modified_guid = response['guid'] if 'guid' in response else 'N/A',
#                 modified_file = request.FILES['readfile'],
#                 encode_response  = response,
#                 file_type = params['type'] if 'type' in params else 'N/A'
#             )
#             if 'parent' in params and params['parent'] != '':
#                 parent = EncdeFiles.objects.get(ids = params['parent'])
#                 instance.parent = EncdeFiles.objects.get(ids = params['parent'])
#                 instance.ids = parent.ids
#             else:
#                 instance.update_ids()
#             instance.save()
#             return Response({
#                 'data':EncdeFilesFileSerializer(instance).data,
#                 'message':'File upload successfully for encode file.',
#             })
#         return Response({
#             'message':'Something went wrong while file decode.',
#             'detail':response
#         },status=status.HTTP_400_BAD_REQUEST)


#     def get_queryset(self):
#         return EncdeFiles.objects.filter(parent__isnull=True).order_by('-id')


#     def list(self, request, *args, **kwargs):
#         response = super(EncodeModifiedFileView, self).list(request, *args, **kwargs)
#         return Response({
#             'message': resp_msg.RECORD_FETCHED_SUCCESSFULLY,
#             'data': response.data
#         }, status=status.HTTP_200_OK)

# class EncodeModifiedByGuidFileView(APIView):
#     permission_classes = [IsAuthenticated,]
#     authentication_classes = [TokenAuthentication, ]
#     def get(self,request,guid):
#         instance = EncdeFiles.objects.filter(ids = guid).order_by('id')
#         serializer = EncdeFilesFileSerializer(instance,many=True).data
#         return Response({
#             'data':serializer,
#             'messgae':"Data fatched successfully"
#         })

# class EncodeOriginalFileView(generics.CreateAPIView):
#     pagination_class = SetPagination
#     parser_classes = (FormParser, MultiPartParser)
#     serializer_class = EncdeFilesFileSerializer
#     permission_classes = [IsAuthenticated,]
#     authentication_classes = [TokenAuthentication, ]
#     queryset = EncdeFiles.objects.all().order_by('-id')
#     def post(self,request):
#         params = request.data
#         evc_instance = EVCCredentials.objects.all().last()

#         decode_instance = EncdeFiles.objects.get(decode__guid = params['decode'])
#         if decode_instance.decode.type == 1 or decode_instance.decode.type == '1':
#             is_sucess,response = FileOperation().kessv2_upload_original_file(
#                 evc_instance.alientechauttoken,
#                 request.FILES['readfile'],
#                json.loads(decode_instance.async_response)['slotGUID'],
#             )
#         elif decode_instance.decode.type == 2 or decode_instance.decode.type == '2':
#             print('2')
#         elif decode_instance.decode.type == 3 or decode_instance.decode.type == '3':
#             print('3')
#         else:
#             return Response({
#                 'details':"Invalid Type"
#             },status=status.HTTP_400_BAD_REQUEST)
#         if is_sucess:
#             return Response({
#                 'message':'Original File upload successfully for encode file.',
#                 'data':response
#             })
#         return Response({
#             'message':'Something went wrong while file decode.',
#             'detail':response
#         },status=status.HTTP_400_BAD_REQUEST)

# class EncodeFileView(APIView):
#     permission_classes = [IsAuthenticated,]
#     authentication_classes = [TokenAuthentication, ]

#     @swagger_auto_schema(request_body=encode_file_schema)

#     def post(self,request):
#         evc_instance = EVCCredentials.objects.all().last()
#         params = request.data
#         decode_instance = EncdeFiles.objects.get(ids = params['guid'])
#         if decode_instance.decode.type == 1 or decode_instance.decode.type == '1':
#             is_sucess,response = FileOperation().kessv2_encode_file(
#                 evc_instance.alientechauttoken,
#                 json.loads(decode_instance.async_response)['slotGUID'],
#                 decode_instance.modified_guid,
#                 params['is_correct_cvn']
#             )
#         elif decode_instance.decode.type == 2 or decode_instance.decode.type == '2':
#             print('2')
#         elif decode_instance.decode.type == 3 or decode_instance.decode.type == '3':
#             print('3')
#         else:
#             return Response({
#                 'details':"Invalid Type"
#             },status=status.HTTP_400_BAD_REQUEST)
#         if is_sucess:
#             #TODO Create new entry.

#             # decode_instance.async_response = response
#             # decode_instance.save()

#             instance = EncdeFiles.objects.create(
#                 user = request.user,
#                 decode = decode_instance.decode,
#                 modified_guid = response['guid'] if 'guid' in response else 'N/A',
#                 # modified_file = request.FILES['readfile'],
#                 encode_response  = response,
#                 file_type = params['type'] if 'type' in params else 'Encode',
#                 parent = decode_instance,
#                 ids = decode_instance.ids
#             )
#             return Response({
#                 'message':'Original File upload successfully for encode file.',
#                 'data':response
#             })
#         return Response({
#             'message':'Something went wrong while file decode.',
#             'detail':response
#         },status=status.HTTP_400_BAD_REQUEST)

class DecodeFileStatusView(APIView):
    def get(self, request, guid):
        evc_instance = EVCCredentials.objects.all().last()
        is_sucess, response = FileOperation().async_operation_guid(evc_instance.alientechauttoken, guid)
        if is_sucess:
            return Response({
                'message': 'Decode file details fatched successfully',
                'data': response
            })
        return Response({
            'message': 'Something went wrong while file decode.',
            'detail': response
        }, status=status.HTTP_400_BAD_REQUEST)


class ZOHOInvoiceHistoryView(generics.ListAPIView):
    permission_classes = [IsAuthenticated]
    authentication_classes = [TokenAuthentication]
    serializer_class = ZOHOInvoiceHistorySerializers
    queryset = ZOHOInvoices.objects.all().order_by('-id')
    filter_backends = (filters.DjangoFilterBackend, SearchFilter,)
    search_fields = ['invoice_id', 'invoice_number', 'customer_id', 'customer_name', 'is_invoice_avail']
    pagination_class = SetPagination

    def get_serializer_context(self):
        return {'request': self.request}

    def get_queryset(self):
        print(self.request.user)
        zoho_user = ZOHOUser.objects.filter(user=self.request.user).first()
        return ZOHOInvoices.objects.filter(user=zoho_user).order_by('-id')

    def list(self, request, *args, **kwargs):

        field_to_sort = request.query_params.get('field')
        order_in = request.query_params.get('order_in')
        # print(field_to_sort)
        # print(order_in)

        if order_in == 'asc':
            order_by_str = field_to_sort
        elif order_in == 'dec':
            order_by_str = '-' + field_to_sort
        else:
            order_by_str = ''

        if field_to_sort is not None and order_by_str is not None:
            queryset = self.get_queryset().order_by(order_by_str)
            serializer = ZOHOInvoiceHistorySerializers(queryset, many=True)
            page = self.paginate_queryset(serializer.data)
            data = dict(self.get_paginated_response(page).data)
        else:
            data = super(ZOHOInvoiceHistoryView, self).list(request, *args, **kwargs).data
        return Response({
            'message': resp_msg.RECORD_FETCHED_SUCCESSFULLY,
            'data': data
        }, status=status.HTTP_200_OK)


class ZOHOInvoiceDownloadView(APIView):
    permission_classes = [IsAuthenticated]
    authentication_classes = [TokenAuthentication]

    def get(self, request, *args, **kwargs):
        params = self.kwargs['invoice_id']
        object = ZOHOInvoices.objects.get(invoice_id=params)
        is_invoice_avail = object.is_invoice_avail
        if not is_invoice_avail:
            is_pdf_response, error, response = download_zoho_invoice_pdf(object)
            if is_pdf_response:
                object = ZOHOInvoices.objects.get(invoice_id=params)
                response = object.invoice_s3_url
                return Response({
                    'message': resp_msg.RECORD_FETCHED_SUCCESSFULLY,
                    'url': response,
                    'is_success': True
                }, status=status.HTTP_200_OK)
            else:
                return Response({
                    'message': "Something went wrong while downloading invoice.",
                    'url': '',
                    'is_success': False
                }, status=status.HTTP_200_OK)
        if is_invoice_avail:
            return Response({
                'message': resp_msg.RECORD_FETCHED_SUCCESSFULLY,
                'url': object.invoice_s3_url,
                'is_success': True
            }, status=status.HTTP_200_OK)

        return Response({
            'message': "Something went wrong while downloading invoice.",
            'url': '',
            'is_success': False
        }, status=status.HTTP_200_OK)


class ResellersDealerListView(generics.ListAPIView):
    from apps.customer.serializer import ResellerSubdealerSerializers

    permission_classes = [IsAuthenticated, ]
    authentication_classes = [TokenAuthentication, ]
    queryset = MyUser.objects.filter(
        user_type=7
    ).order_by('id')
    serializer_class = ResellerSubdealerSerializers
    pagination_class = SetPagination
    search_fields = ['first_name', 'last_name', 'email']
    filter_backends = (filters.DjangoFilterBackend, SearchFilter,)

    def get_queryset(self):

        return self.queryset.filter(
            parent__uuid=self.kwargs['uuid']
        ).order_by('-id')

    def list(self, request, *args, **kwargs):
        from apps.customer.serializer import ResellerSubdealerSerializers
        field_to_sort = request.query_params.get('field')
        order_in = request.query_params.get('order_in')

        if order_in == 'asc':
            order_by_str = '-' + field_to_sort
        elif order_in == 'dec':
            order_by_str = field_to_sort
        else:
            order_by_str = ''

        if field_to_sort is not None and order_by_str is not None:
            queryset = self.get_queryset().order_by(order_by_str)
            serializer = ResellerSubdealerSerializers(queryset, many=True)
            page = self.paginate_queryset(serializer.data)
            data = dict(self.get_paginated_response(page).data)
        else:
            data = super(ResellersDealerListView, self).list(request, *args, **kwargs).data

        return Response({
            'data': data,
            'message': resp_msg.RECORD_FETCHED_SUCCESSFULLY
        }, status=status.HTTP_200_OK)


class ResellersDealerCreditUpdateView(generics.UpdateAPIView):
    from apps.customer.serializer import ResellerSubdealerSerializers

    permission_classes = [IsAuthenticated, ]
    authentication_classes = [TokenAuthentication, ]
    serializer_class = ResellerSubdealerSerializers

    def put(self, request):
        desc_file = "Added:{0}".format(0)
        desc_function = "Added:{0}".format(0)
        evc_function = "Added:{0}".format(0)

        params = request.data
        user = MyUser.objects.get(uuid=params['uuid'])
        reseller = MyUser.objects.get(
            uuid=params['uuid']
        ).parent

        file_key_credit = params.get('file_key_credit')
        function_key_credit = params.get('function_key_credit')
        evc_key_credit = params.get('evc_key_credit')

        try:
            reseller_credits = ResellerDistributeCredit.objects.get(user=reseller)
        except Exception as error:
            reseller_credits = ResellerDistributeCredit.objects.create(
                file_key_credit=0,
                function_credit=0,
                evc_credit=0,
                user=reseller)
        reseller_file_credit = reseller_credits.file_key_credit
        reseller_function_credit = reseller_credits.function_credit
        reseller_evc_credit = reseller_credits.evc_credit
        # Reseller's sub dealer.
        sub_dealer_credit = CustomerCredit.objects.get(user=user)

        if file_key_credit:
            is_sufficent_file_credit = reseller_file_credit - file_key_credit
            if is_sufficent_file_credit < 0:
                return Response({
                    'success': False,
                    'message': 'Not enough dealer file key credit.',
                }, status=status.HTTP_200_OK)

        if function_key_credit:
            is_sufficent_function_credit = reseller_function_credit - function_key_credit
            if is_sufficent_function_credit < 0:
                return Response({
                    'success': False,
                    'message': 'Not enough dealer function key credit.',
                }, status=status.HTTP_200_OK)

        if evc_key_credit:
            is_sufficent_evc_credit = reseller_evc_credit - evc_key_credit
            if is_sufficent_evc_credit < 0:
                return Response({
                    'success': False,
                    'message': 'Not enough dealer EVC key credit.',
                }, status=status.HTTP_200_OK)

        if file_key_credit:
            if file_key_credit > 0:
                sub_dealer_credit.file_key_credit += file_key_credit
                reseller_credits.file_key_credit -= file_key_credit
                desc_file = "Added:{0}".format(str(file_key_credit))
            if file_key_credit < 0:
                sub_dealer_credit.file_key_credit += file_key_credit
                reseller_credits.file_key_credit -= file_key_credit
                desc_file = "Subtracted:{0}".format(str(file_key_credit))
            reseller_credits.save()
            sub_dealer_credit.save()

            # ManualCreditHistory.objects.create(
            #     user = request.user,
            #     file_key_credit = file_key_credit,
            #     manual_update_to_user = sub_dealer_credit.user
            # )

        if function_key_credit:
            if function_key_credit > 0:
                sub_dealer_credit.function_credit += function_key_credit
                reseller_credits.function_credit -= function_key_credit
                desc_function = "Added:{0}".format(str(function_key_credit))
            if function_key_credit < 0:
                sub_dealer_credit.function_credit += function_key_credit
                reseller_credits.function_credit -= function_key_credit
                desc_function = "Subtracted:{0}".format(str(function_key_credit))
            reseller_credits.save()
            sub_dealer_credit.save()

            # ManualCreditHistory.objects.create(
            #     user = request.user,
            #     function_credit = function_key_credit,
            #     manual_update_to_user = sub_dealer_credit.user
            # )

        if evc_key_credit:
            if evc_key_credit > 0:
                sub_dealer_credit.evc_credit += evc_key_credit
                reseller_credits.evc_credit -= evc_key_credit
                evc_function = "Added:{0}".format(str(evc_key_credit))
            if evc_key_credit < 0:
                sub_dealer_credit.evc_credit += evc_key_credit
                reseller_credits.evc_credit -= evc_key_credit
                evc_function = "Subtracted:{0}".format(str(evc_key_credit))
            reseller_credits.save()
            sub_dealer_credit.save()

            # ManualCreditHistory.objects.create(
            #     user = request.user,
            #     evc_credit = evc_key_credit,
            #     manual_update_to_user = sub_dealer_credit.user
            # )

        dealer_detail = user.first_name + ' ' + user.last_name + '(' + user.email + ')'
        request_user = request.user.first_name + ' ' + request.user.last_name + '(' + request.user.email + ')'
        x_forwarded_for = request.META.get('HTTP_X_FORWARDED_FOR')

        AccessLogsModel.objects.create(
            user=request.user,
            timestamp=datetime.now(),
            ip_address=x_forwarded_for.split(',')[0] if x_forwarded_for else request.META.get('REMOTE_ADDR'),
            method='Update',
            event='Update',
            module=EmailLogSettings.objects.filter(module='Customer credit').last(),
            title='Sub-dealer Credits updated manually.',
            description='Credits manually updated: File credit:{0}, Function credit: {1} and EVC credit {2} for Sub-dealer:{3} by {4}.'.format(
                desc_file, desc_function, evc_function,
                dealer_detail, request_user),
        )

        serializer = CustomerCreditSerializer(sub_dealer_credit)
        return Response({
            'success': True,
            'data': serializer.data,
            'message': 'Credits updated successfully.',
        }, status=status.HTTP_200_OK)


class CustomerLogsListView(generics.ListAPIView):
    permission_classes = [IsAuthenticated, ]
    authentication_classes = [TokenAuthentication, ]
    queryset = AccessLogsModel.objects.all().exclude(title__isnull=True).order_by('-sys_id')
    serializer_class = CustomerLogsModelSerializers
    pagination_class = SetPagination
    search_fields = ['sys_id', 'user__first_name', 'user__last_name',
                     'user__email', 'module__module', 'description', 'file_request',
                     'credit_update_type', 'credit_update_description', 'title', 'event']
    filter_backends = (filters.DjangoFilterBackend, SearchFilter,)
    filterset_class = LogsFilter

    def get_queryset(self):
        queryset = AccessLogsModel.objects.filter(
            customer=self.request.user,
            to_customer_only=True
        ).order_by('-sys_id')
        search_filter = SearchFilter()
        queryset = search_filter.filter_queryset(self.request, queryset, self)
        return queryset

    def list(self, request, *args, **kwargs):
        from_date = request.query_params.get('from_date')
        to_date = request.query_params.get('to_date')
        field_to_sort = request.query_params.get('field')
        order_in = request.query_params.get('order_in')

        if from_date and to_date:
            from_date = from_date + ' 00:00:00'
            to_date = to_date + ' 23:59:59'
            from_date = datetime.strptime(from_date, '%Y-%m-%d %H:%M:%S')
            to_date = datetime.strptime(to_date, '%Y-%m-%d %H:%M:%S')
            queryset = self.get_queryset().filter(timestamp__gte=from_date, timestamp__lte=to_date)
        else:
            queryset = self.get_queryset()
        if field_to_sort and order_in:
            if order_in == 'asc':
                order_by_str = field_to_sort
                queryset = queryset.order_by(order_by_str)
            elif order_in == 'dec':
                order_by_str = '-' + field_to_sort
                queryset = queryset.order_by(order_by_str)
        page = self.paginate_queryset(queryset)
        if page is not None:
            serializer = self.get_serializer(page, many=True)
            paginated_response = self.get_paginated_response(serializer.data)
            return Response({
                'data': paginated_response.data,
                'message': resp_msg.RECORD_FETCHED_SUCCESSFULLY
            }, status=status.HTTP_200_OK)

        serializer = self.get_serializer(queryset, many=True)
        return Response({
            'data': serializer.data,
            'message': resp_msg.RECORD_FETCHED_SUCCESSFULLY
        }, status=status.HTTP_200_OK)


class CustomerLogsDownloadListView(generics.ListAPIView):
    permission_classes = [IsAuthenticated, ]
    authentication_classes = [TokenAuthentication, ]
    queryset = AccessLogsModel.objects.all().order_by('-sys_id')
    serializer_class = CustomerLogsModelSerializers
    filterset_class = LogsFilter

    def list(self, request, *args, **kwargs):
        params = self.request.query_params
        from_date = params['from_date'] + ' 00:00:00'
        to_date = params['to_date'] + ' 23:59:59'

        from_date = datetime.strptime(from_date, '%Y-%m-%d %H:%M:%S')
        to_date = datetime.strptime(to_date, '%Y-%m-%d %H:%M:%S')
        queryset = AccessLogsModel.objects.filter(created_at__gte=from_date, created_at__lte=to_date,
                                                  customer=self.request.user, to_customer_only=True).exclude(
            title__isnull=True).order_by('-sys_id')
        serializer = self.serializer_class(queryset, many=True)
        return Response({
            'data': serializer.data,
            'message': resp_msg.RECORD_FETCHED_SUCCESSFULLY
        }, status=status.HTTP_200_OK)


class ResellerLogsReteriveView(generics.ListAPIView):
    permission_classes = [IsAuthenticated, ]
    authentication_classes = [TokenAuthentication, ]
    serializer_class = CustomerLogsModelSerializers

    def get(self, request, id):
        instance = AccessLogsModel.objects.get(sys_id=id)
        serializer = CustomerLogsModelSerializers(instance)
        return Response({
            'data': serializer.data,
            'message': resp_msg.RECORD_FETCHED_SUCCESSFULLY
        }, status=status.HTTP_200_OK)


class CustomerFileRequestListView(generics.ListAPIView):
    permission_classes = [IsAuthenticated, ]
    authentication_classes = [TokenAuthentication, ]
    queryset = FileRequest.objects.all()
    serializer_class = CustomerFileRequestListSerializer

    def list(self, request, *args, **kwargs):
        uuid = self.request.query_params.get('uuid')
        user = MyUser.objects.get(uuid=uuid)
        queryset = self.queryset.filter(user=user).values('id', 'request_id').order_by('-pk')
        serializer = self.get_serializer(queryset, many=True)
        return Response({
            'data': serializer.data,
            'message': resp_msg.RECORD_FETCHED_SUCCESSFULLY
        }, status=status.HTTP_200_OK)
