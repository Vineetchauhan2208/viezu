import json
from urllib.parse import urljoin

import requests
from django.conf import settings
from rest_framework import serializers

from apps.account.models import (
    AccessLogsModel, Address, BusinessCustomer, EVCCredentials,
    IndividualCustomer, MyUser, ResellerAndSubDealer, ZOHOInvoices,EmailLogSettings
)
from apps.admin_management.models import (
    Conversation, Notification,
    TicketAttachment, TicketCategory,
    TicketHistory, TicketStatus
)
from apps.file_request.models import FileRequest

from apps.customer.models import (
    Cart, CustomerSpentHistory,
    OrderList, CustomerCredit, ResellerDistributeCredit,
)
# DecodeFiles, EncdeFiles,

from apps.utils.custom_exception import BaseCustomException
from apps.utils.evc_apis import (
    is_evc_customer_exist, is_evc_reseller_customer_exist,
    personal_account_balance
)
from apps.utils.helper import create_notification, triger_socket
from apps.utils.woocommerce_shop import WoocommerceShop
from django.db.models import Q
from django.template.loader import render_to_string
from apps.utils.helper import SendMail, create_notification
from urllib.parse import unquote
from datetime import datetime

class TicketCretedByDetailsSerializer(serializers.ModelSerializer):
    first_name = serializers.SerializerMethodField()
    last_name = serializers.SerializerMethodField()

    def get_first_name(self, obj):
        if obj.user_type == 3 and hasattr(obj, 'business_user'):
            return obj.business_user.bussness_name
        elif obj.user_type in [6, 7] and hasattr(obj, 'reseller_sub_dealer'):
            return obj.reseller_sub_dealer.bussness_name
        return obj.first_name

    def get_last_name(self, obj):
        if obj.user_type in [3, 6, 7]:
            return ''
        return obj.last_name if obj.last_name is not None else ''

    class Meta:
        model = MyUser
        fields = ('first_name', 'last_name', 'email', 'image', 'pk', 'id', 'uuid')


class TicketAttachmentSerializer(serializers.ModelSerializer):
    """ Category serializer for email template."""
    uploaded_by = TicketCretedByDetailsSerializer(read_only=True)
    file_size = serializers.SerializerMethodField()

    class Meta:
        model = TicketAttachment
        fields = ('file', 'id', 'uploaded_by', 'created_at',
                  'attachement_type', 'attachement_name', 'file_size')

    def get_file_size(self, obj):
        # Fetch the file size from the S3 URL using a HEAD request
        if obj.file:
            try:
                if "https%3A" in obj.file.url:
                    url = obj.file.url
                    decoded_url = unquote(url)
                    if "https://" in decoded_url:
                        corrected_url = decoded_url.split("https:/")[-1]
                        corrected_url = "https://" + corrected_url
                    corrected_url = corrected_url
                    response = requests.head(corrected_url)
                    file_size = response.headers.get('Content-Length', None)
                else:    
                    response = requests.head(obj.file.url)
                    file_size = response.headers.get('Content-Length', None)
                if file_size:
                    return int(file_size)
            except Exception as e:
                return None
        return None


class TicketStatusSerializer(serializers.ModelSerializer):
    display_user_status = serializers.CharField(source='get_user_status_display', read_only=True)

    class Meta:
        model = TicketStatus
        fields = ('team_status', 'user_status', 'display_user_status', 'id')


class CopyVehicleRequestDetailSerializer(serializers.ModelSerializer):
    credit_spent = serializers.SerializerMethodField()

    def get_credit_spent(self, obj):
        data = {}
        queryset = CustomerSpentHistory.objects.filter(file_request_id=obj.request_id)
        if len(queryset) > 0:
            queryset = queryset.first()
            data = {
                'credit_type': queryset.credit_type if queryset.credit_type else None,
                'credit': queryset.credit
            }
        return data

    class Meta:
        model = FileRequest
        fields = ("id", "request_id", "vehicle_type", "vehicle_make",
                  "model", "vehicle_registration", "vehicle_year",
                  "vehicle_VIN", "engine_size", "transmission",
                  "fuel_type", "mileage_type", "mileage",
                  "ecu_brand", "customer_first_name", "customer_last_name",
                  "ecu_version", "control_unit", "file_type",
                  "country", "tuning_tool_used", "tuning_required",
                  "additional_info", "tuning_file", "is_error", "credit_spent",)


class FileRequestSerializer(serializers.ModelSerializer):
    credit_spent = serializers.SerializerMethodField()

    def get_credit_spent(self, obj):
        if type(obj) == dict:
            request_id = obj['request_id']
        else:
            request_id = obj.request_id

        data = {}
        queryset = CustomerSpentHistory.objects.filter(file_request_id=request_id)
        if len(queryset) > 0:
            queryset = queryset.first()
            data = {
                'credit_type': queryset.credit_type if queryset.credit_type else None,
                'credit': queryset.credit
            }

        return data

    class Meta:
        model = FileRequest
        fields = ["credit_spent"]


class TicketHistorySerializer(serializers.Serializer):
    """ Create new roles serializer. """
    file_request = FileRequestSerializer(read_only=True)
    updated_at = serializers.DateTimeField(read_only=True)
    created_at = serializers.DateTimeField(read_only=True)
    id = serializers.IntegerField(read_only=True)
    tags = TicketCretedByDetailsSerializer(read_only=True, many=True)
    ids = serializers.CharField(read_only=True)
    files = serializers.FileField(required=False)
    subject = serializers.CharField(required=True)
    category = serializers.CharField(required=True)
    created_by = TicketCretedByDetailsSerializer(read_only=True)
    assigned_to = TicketCretedByDetailsSerializer(read_only=True)
    description = serializers.CharField(required=True)
    ticket_status = TicketStatusSerializer(read_only=True)
    attachment_ticket = TicketAttachmentSerializer(read_only=True, many=True)
    admin_ticket = CopyVehicleRequestDetailSerializer(read_only=True, many=True)
    vehicle_details = serializers.JSONField(required=False)
    request_id = serializers.CharField(required=False)
    other_fields = serializers.CharField(max_length=255, required=False)
    conversation_count = serializers.IntegerField(read_only=True)

    def create(self, validated_data):
        request = self.context.get('request')
        params = request.data
        if 'files' in validated_data:
            validated_data.pop('files')

        if 'file_request' in validated_data:
            validated_data.pop('file_request')

        if 'category' in validated_data:
            validated_data.pop('category')

        vehicle_details = validated_data.get('vehicle_details')
        if vehicle_details is not None:
            vehicle_details = vehicle_details
        else:
            vehicle_details = {}

        ai_admin = MyUser.objects.get(email='technical@viezu.com') if MyUser.objects.filter(
            email='technical@viezu.com').exists() else None
        try:
            fr = FileRequest.objects.get(
                request_id=params['file_request']) if 'file_request' in params and FileRequest.objects.filter(
                request_id=params['file_request']).exists() else None
            ticket = TicketHistory.objects.create(
                created_by=fr.user if fr is not None else request.user,
                assigned_to=ai_admin,
                category=TicketCategory.objects.get(id=params['category']),
                file_request=fr if fr is not None else None,
                request_id=fr.request_id if fr is not None else None,
                ticket_status=TicketStatus.objects.get(team_status="New"),
                **validated_data
            )
            ticket.update_ids()
            try:
                ticket.ticket_status = TicketStatus.objects.get(
                    team_status='Pending'
                )
                ticket.save()
            except:
                pass

            ticket.vehicle_details = vehicle_details
            ticket.save()

            if 'files' in request.FILES:
                for data in request.FILES.getlist('files'):
                    TicketAttachment.objects.create(
                        uploaded_by=request.user,
                        ticket=ticket,
                        file=data
                    )
            from datetime import datetime
            now = datetime.now()
            date = now.strftime("%d-%m-%Y")

            Notification.objects.create(
                recipient=ticket.assigned_to,
                ticket=ticket,
                title="Ticket has been created.",
                message="Ticket created by user on {0}.".format(date)
            )

            Conversation.objects.create(
                ticket=ticket,
                message_type="text",
                text=ticket.description,
                sender=request.user,
                recipient=ai_admin,
            )

            triger_socket({
                'uuid': str(request.user.uuid),
                'type': 'ticket_create_notification_customer',
                'ids': str(ticket.ids),
                'created_at': str(ticket.created_at),
                'message': str("Ticket {0} has been successfully created.".format(ticket.ids))
            })
            data = MyUser.objects.filter(
                Q(roles__name="Technical Team User") |
                Q(roles__name="Admin Management"))
            if len(data) > 0:
                for each in data:
                    triger_socket({
                        'uuid': str(each.uuid),
                        'type': 'admin_ticket_notification_technical_team',
                        'ids': str(ticket.ids),
                        'created_at': str(ticket.created_at),
                        'message': str("Ticket {0} has been successfully created by the customer.".format(ticket.ids))
                    })

            context = {
                'ticket': ticket,
                'status': ticket.ticket_status.team_status if ticket.ticket_status else 'New',
                'frontend_url': 'www.viezu-files.com',
            }
            get_template = render_to_string('email_template/ticket/ticket_created.html', context)
            SendMail.mail("Ticket has been created:{0}".format(ticket.ids), request.user.email, get_template)

            get_template = render_to_string('email_template/ticket/ticket_created_admin.html', context)
            SendMail.mail("Ticket has been created:{0}".format(ticket.ids), "technical@viezu.com", get_template)
            #---
            x_forwarded_for = request.META.get('HTTP_X_FORWARDED_FOR')
            admin_log = AccessLogsModel.objects.create(
                user=request.user,
                timestamp=datetime.now(),
                ip_address=x_forwarded_for.split(',')[0] if x_forwarded_for else request.META.get('REMOTE_ADDR'),
                method='Create',
                event='Create',
                module=EmailLogSettings.objects.filter(module='ticket').last(),
                title=f'Ticket Created Manaully - {ticket.ids}',
                description=f'Ticket Created by - {request.user}',
                customer=request.user,
            )
            print(f"Admin logs created : {admin_log}")

            # For customer side log.
            customer_log = AccessLogsModel.objects.create(
                user=request.user,
                timestamp=datetime.now(),
                ip_address=x_forwarded_for.split(',')[0] if x_forwarded_for else request.META.get('REMOTE_ADDR'),
                method='Create',
                event='Create',
                module=EmailLogSettings.objects.filter(module='ticket').last(),
                title=f'Ticket Created Manaully - {ticket.ids}',
                description=f'Ticket Created by - {request.user}',
                customer=request.user,
                to_customer_only=True,
            )
            print(f"customer log created : {customer_log}")
            #---
            return ticket
        except Exception as e:
            raise BaseCustomException(detail=e.args[0], code=400)


class StatusCountSerializer(serializers.ModelSerializer):
    id = serializers.SerializerMethodField()
    ticket_status = serializers.SerializerMethodField()
    count = serializers.SerializerMethodField()

    def get_id(self, obj):
        staus = self.context.get('tickets')
        return obj.pk

    def get_ticket_status(self, obj):
        staus = self.context.get('tickets')
        return obj.get_user_status_display()

    def get_count(self, obj):
        tickets = self.context.get('tickets')
        if obj.user_status != 3:
            return tickets.filter(ticket_status__user_status=obj.user_status).count()

    class Meta:
        model = TicketStatus
        fields = ('id', 'ticket_status', 'count')


class ConversationListSerializers(serializers.ModelSerializer):
    sender_name = serializers.SerializerMethodField()
    recipient_name = serializers.SerializerMethodField()
    sender_image = serializers.SerializerMethodField()
    recipient_image = serializers.SerializerMethodField()
    message = serializers.SerializerMethodField()

    def get_sender_name(self, obj):
        if obj.sender:
            return "{} {}".format(obj.sender.first_name, obj.sender.last_name)
        return None

    def get_recipient_name(self, obj):
        if obj.recipient:
            return "{} {}".format(obj.recipient.first_name, obj.recipient.last_name)
        return None

    def get_sender_image(self, obj):
        if obj.sender and obj.sender.image:
            return obj.sender.image.url
        return None

    def get_recipient_image(self, obj):
        if obj.recipient and obj.recipient.image:
            return obj.recipient.image.url
        return None

    def get_message(self, obj):
        return obj.text

    class Meta:
        model = Conversation
        fields = ('id', 'sender', 'recipient', 'message_type', 'file', 'message', 'sender_name', 'sender_image',
                  'recipient_image', 'recipient_name', 'created_at')


class UploadTicketAttachmentSerializer(serializers.ModelSerializer):
    files = serializers.FileField(required=True)

    class Meta:
        model = TicketAttachment
        fields = ('files',)


class CartSerializer(serializers.ModelSerializer):
    product_details = serializers.SerializerMethodField()
    product_id = serializers.SerializerMethodField()

    def get_product_id(self, obj):
        return obj.product

    def get_product_details(self, obj):
        obj_one = WoocommerceShop()
        wcapi = obj_one.connect_woocommerce()
        data = obj_one.get_product_by_id(wcapi, obj.product)
        return data

    class Meta:
        model = Cart
        fields = ('quantity', 'price', 'product_id',
                  'product_details', 'vat', 'tunning_credit',
                  'type', 'is_dealer_credit', 'dealer_credit_type')


class DashboardTicketHistorySerializer(serializers.ModelSerializer):
    created_by = TicketCretedByDetailsSerializer()

    class Meta:
        model = TicketHistory
        fields = ("ids", "created_at", "ticket_status", "created_by")


class ZOHOInvoiceSpentSerializers(serializers.ModelSerializer):
    class Meta:
        model = ZOHOInvoices
        fields = ["created_at", "invoice_number"]


class OrderListSerializer(serializers.ModelSerializer):
    items = serializers.SerializerMethodField()
    invoice = serializers.SerializerMethodField()

    def get_items(self, obj):
        items = []

        woo_obj = WoocommerceShop()
        wcapi = woo_obj.connect_woocommerce()

        for each in obj.checkout_data['line_items']:
            product_id = each['product_id']
            data = woo_obj.get_product_by_id(wcapi, product_id)
            product_image_url = data['images']
            if len(product_image_url) > 0:
                product_image_url = product_image_url[0]
            else:
                product_image_url = "https://filemaker-stage.s3.amazonaws.com/assets/proimg.png"

            items.append({
                'product_name': each['name'],
                'quantity': each['quantity'],
                'price': each['price'],
                'sub_total': each['subtotal'],
                "product_image_url": product_image_url
            })

        return items

    def get_invoice(self, obj):

        queryset = ZOHOInvoices.objects.filter(order_list=obj)
        serializer = ZOHOInvoiceSpentSerializers(queryset, many=True)
        return serializer.data

    class Meta:
        model = OrderList
        fields = ("ids", "created_at", "total_price",
                  "file_credit", "function_credit", "evc_credit",
                  "stripe_id", "items", "invoice", "tax_price",)


class SpentHistorySerializer(serializers.ModelSerializer):
    class Meta:
        model = CustomerSpentHistory
        fields = "__all__"


class NotificationHistorySerializer(serializers.ModelSerializer):
    sender = TicketCretedByDetailsSerializer(read_only=True)
    recipient = TicketCretedByDetailsSerializer(read_only=True)
    recipient = TicketCretedByDetailsSerializer(read_only=True)
    ticket = serializers.SerializerMethodField()

    def get_ticket(self, obj):
        if obj.ticket:
            return {
                'ids': obj.ticket.ids,
                'id': obj.ticket.id
            }
        return None

    class Meta:
        model = Notification
        fields = ('sender', 'recipient', 'title', 'message', 'id', 'is_seen', 'created_at', 'ticket')


class UpdateIndividualRegisterSerializer(serializers.ModelSerializer):
    """ Customer register serializer.

    Custom models serializer for Individual customer on platform.
    """

    def update(self, instance, validated_data):
        request = self.context.get('request')
        user = request.user
        #---
        old_details = {
            "id":user.id,
            "first_name":user.first_name,
            "last_name":user.last_name,
            "email":user.email,
            "phone_no":user.phone_no,
            "address":user.address_user.address,
            "address_2":user.address_user.address_2,
            "product_name":user.individual_user.product_name,
            "tool_serial_number":user.individual_user.tool_serial_number,
        }
        #---
        print(f"Old Details : {old_details}")
        params = request.data
        if 'first_name' in params['individual']:
            instance.first_name = params['individual']['first_name']
        if 'last_name' in params['individual']:
            instance.last_name = params['individual']['last_name']

        if 'image' in request.FILES:
            instance.image = request.FILES['image']

        Address.objects.filter(
            user=instance,
        ).update(**params['address'])
        IndividualCustomer.objects.filter(
            user=instance,
        ).update(**params['individual_profile'])
        instance.save()
        new_details = {
            "id":instance.id,
            "first_name":instance.first_name,
            "last_name":instance.last_name,
            "email":instance.email,
            "phone_no":instance.phone_no,
            "address":instance.address_user.address,
            "address_2":instance.address_user.address_2,
            "product_name":instance.individual_user.product_name,
            "tool_serial_number":instance.individual_user.tool_serial_number,
        }
        print(f"new details : {new_details}")

        #--- admin log----
        x_forwarded_for = request.META.get('HTTP_X_FORWARDED_FOR')

        ip_address=x_forwarded_for.split(',')[0] if x_forwarded_for else request.META.get('REMOTE_ADDR'),
        admin_log = AccessLogsModel.objects.create(
            user=request.user,
            timestamp=datetime.now(),
            ip_address=x_forwarded_for.split(',')[0] if x_forwarded_for else request.META.get('REMOTE_ADDR'),
            method='Update',
            event='Individual Customer Profile updated',
            module=EmailLogSettings.objects.filter(module='Bussness Customer Profile Updated').last(),
            title='Individual Customer Profile updated',
            description=f"Customer profile updated",
            old_details=old_details,
            new_details=new_details,
            customer=user,
            to_customer_only=False,
        )
        #--- end admin log----
        return instance

    class Meta:
        model = MyUser
        fields = ("id", "uuid", "first_name", "last_name")


class UpdateBusinessRegisterSerializer(serializers.ModelSerializer):
    """ Customer register serializer.

    Custom models serializer for Business customer on platform.
    """

    def update(self, instance, validated_data):
        request = self.context.get('request')
        params = request.data
        if 'first_name' in params['business']:
            instance.first_name = params['business']['first_name']
        if 'last_name' in params['business']:
            instance.last_name = params['business']['last_name']

        if 'phone_no' in params['business']:
            instance.phone_no = params['business']['phone_no']

        if 'image' in request.FILES:
            instance.image = request.FILES['image']

        Address.objects.filter(
            user=instance,
        ).update(**params['address'])

        if hasattr(instance, 'address_user'):
            if instance.address_user.country != params['address']['country'] or \
                    instance.address_user.state != params['address']['state'] or \
                    instance.address_user.zip != params['address']['zip'] or \
                    instance.address_user.city != params['address']['city'] or \
                    instance.address_user.address_2 != params['address']['address_2'] or \
                    instance.address_user.address != params['address']['address']:
                create_notification(
                    instance,
                    "Address Update",
                    "Business/Customer primary billing or shipping address is changed for added to {} {} – please verify the change for account security".format(
                        instance.first_name,
                        instance.last_name
                    ),
                    sender=instance
                )

        evc_number = params['business_profile']['win_ols_license_number']
        if evc_number != '':
            is_evc_customer = BusinessCustomer.objects.filter(win_ols_license_number=evc_number).exclude(
                user=request.user)
            if len(is_evc_customer):
                raise BaseCustomException(detail="This winols number already exists.", code=400)
            is_reseller_evc_customer = ResellerAndSubDealer.objects.filter(win_ols_license_number=evc_number).exclude(
                user=request.user)
            if len(is_reseller_evc_customer):
                raise BaseCustomException(detail="EVC number already exists.", code=400)

        BusinessCustomer.objects.filter(
            user=instance,
        ).update(**params['business_profile'])
        evc_cred = EVCCredentials.objects.all().last()
        if evc_cred is not None and 'business_profile' in params and 'win_ols_license_number' \
                in params['business_profile'] and params['business_profile']['win_ols_license_number'] != '':
            is_evc_customer = is_evc_customer_exist(evc_cred.apiid,
                                                    params['business_profile']['win_ols_license_number'],
                                                    evc_cred.username, evc_cred.password)
            instance.is_evc_customer = is_evc_customer
            if is_evc_customer:
                instance.is_evc_reseller_customer_exist = is_evc_reseller_customer_exist(evc_cred.apiid,
                                                                                         params['business_profile'][
                                                                                             'win_ols_license_number'],
                                                                                         evc_cred.username,
                                                                                         evc_cred.password)
            instance.save()
        else:
            instance.is_evc_customer = False
            instance.is_evc_reseller_customer = False
            instance.save()

        if instance.phone_no != params['business']['phone_no']:
            create_notification(
                instance,
                "Phone No Update",
                "Business primary phone number/s is changed for added to {} {} – please verify the change for account security".format(
                    instance.first_name,
                    instance.last_name
                ),
                sender=instance
            )
        instance.save()
        return instance

    class Meta:
        model = MyUser
        fields = ("id", "uuid", "first_name", "last_name")


class CustomerCreditSerializer(serializers.ModelSerializer):
    evc_credit = serializers.SerializerMethodField()

    def get_evc_credit(self, obj):
        instance = EVCCredentials.objects.all().last()
        if instance is not None and hasattr(obj.user,
                                            'business_user') and obj.user.business_user.win_ols_license_number:
            is_sucess, credit = personal_account_balance(instance.apiid, obj.user.business_user.win_ols_license_number,
                                                         instance.username, instance.password)
            if is_sucess:
                cust_evc, _ = CustomerCredit.objects.get_or_create(
                    user=obj.user
                )
                cust_evc.evc_credit = credit
                cust_evc.save()
            return credit
        return 0

    class Meta:
        model = CustomerCredit
        fields = "__all__"

    def update(self, instance, validated_data):
        request = self.context.get('request')
        params = request.data
        CustomerCredit.objects.filter(user=instance).update(
            file_key_credit=params['file_key_credit'],
            function_credit=params['function_credit'],
            evc_credit=params['evc_credit'],
        )
        return instance


class CustomerResellerCreditSerializer(serializers.ModelSerializer):
    class Meta:
        model = ResellerDistributeCredit
        fields = "__all__"


# class DecodeFileSerializer(serializers.ModelSerializer):
#     readfile  = serializers.FileField(required = True,write_only=True)
#     type  = serializers.IntegerField(required = False)

#     file  = serializers.FileField(required = False)
#     user = serializers.CharField(required=False,read_only=True)
#     active = serializers.CharField(required=False,read_only=True)
#     deleted = serializers.CharField(required=False,read_only=True)
#     ids = serializers.CharField(required=False,read_only=True)
#     decode_response = serializers.JSONField(required=False,read_only=True)
#     async_response = serializers.JSONField(required=False,read_only=True)
#     is_failed = serializers.BooleanField(required=False,read_only=True)
#     guid = serializers.CharField(required=False,read_only=True)
#     # type  = serializers.IntegerField(required = True,write_only=True)
#     display_type_status = serializers.CharField(source='get_type_display', read_only=True)

#     async_response = serializers.SerializerMethodField()
#     def get_async_response(self,obj):
#         try:
#             return json.loads(obj.async_response)
#         except:
#             return {}

#     class Meta:
#         model = DecodeFiles
#         fields = ("__all__")


# class EncdeFilesFileSerializer(serializers.ModelSerializer):
#     readfile  = serializers.FileField(required = True,write_only=True)
#     decode  = serializers.CharField(required = True,write_only=True)
#     type  = serializers.CharField(required = True,write_only=True)

#     decode = DecodeFileSerializer(read_only=True)
#     modified_file  = serializers.FileField(required = False)
#     original_file  = serializers.FileField(required = False)
#     user = serializers.CharField(required=False,read_only=True)
#     active = serializers.CharField(required=False,read_only=True)
#     deleted = serializers.CharField(required=False,read_only=True)
#     ids = serializers.CharField(required=False,read_only=True)
#     decode_response = serializers.JSONField(required=False,read_only=True)
#     is_failed = serializers.BooleanField(required=False,read_only=True)
#     modified_guid = serializers.CharField(required=False,read_only=True)
#     original_guid = serializers.CharField(required=False,read_only=True)

#     async_response = serializers.SerializerMethodField()
#     def get_async_response(self,obj):
#         try:
#             return json.loads(obj.async_response)
#         except:
#             return {}

#     class Meta:
#         model = EncdeFiles
#         fields = "__all__"

class ZOHOInvoiceHistorySerializers(serializers.ModelSerializer):
    class Meta:
        depth = 1
        model = ZOHOInvoices
        fields = "__all__"


class CustomerCreditSerializer(serializers.ModelSerializer):
    # file_key_credit = serializers.SerializerMethodField()
    # function_credit = serializers.SerializerMethodField()
    # evc_credit = serializers.SerializerMethodField()

    class Meta:
        model = CustomerCredit
        fields = "__all__"


class ResellerDealerCreditSerializer(serializers.ModelSerializer):
    class Meta:
        model = ResellerDistributeCredit
        fields = "__all__"


class ResellerSubdealerSerializers(serializers.ModelSerializer):
    user_type = serializers.CharField(source='get_user_type_display')
    reseller_data = serializers.SerializerMethodField()
    credit = serializers.SerializerMethodField()

    def get_reseller_data(self, obj):
        if obj.parent:
            return {'first_name': obj.parent.first_name,
                    'last_name': obj.parent.last_name,
                    'email': obj.parent.email}
        return {}

    def get_credit(self, obj):
        queryset = CustomerCredit.objects.filter(user=obj)
        if len(queryset) > 0:
            queryset = queryset[0]
            serializer = CustomerCreditSerializer(queryset)
            return serializer.data
        else:
            CustomerCredit.objects.get_or_create(
                file_key_credit=0,
                function_credit=0,
                evc_credit=0,
                user=obj
            )
            queryset = CustomerCredit.objects.filter(user=obj)
            queryset = queryset[0]
            serializer = CustomerCreditSerializer(queryset)
            return serializer.data

    class Meta:
        model = MyUser
        fields = ("id", "uuid", "first_name",
                  "last_name", "email",
                  "is_active", "image", "user_type",
                  "reseller_data", "credit"
                  )


class CustomerLogsModelSerializers(serializers.ModelSerializer):
    user = serializers.SerializerMethodField()
    email = serializers.SerializerMethodField()
    module = serializers.SerializerMethodField()

    def get_module(self, obj):
        if obj.module:
            return obj.module.module
        return None

    def get_email(self, obj):
        if obj.user:
            return obj.user.email
        return None

    def get_user(self, obj):
        if obj.user:
            return "{} {}".format(obj.user.first_name, obj.user.last_name)
        return None

    class Meta:
        model = AccessLogsModel
        fields = "__all__"


class CustomerFileRequestListSerializer(serializers.ModelSerializer):
    class Meta:
        model = FileRequest
        fields = ("id", "request_id",)
