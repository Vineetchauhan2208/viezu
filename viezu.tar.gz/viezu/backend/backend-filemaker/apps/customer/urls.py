from django.urls import include, path
from rest_framework.routers import DefaultRouter

from apps.customer import views

app_name = 'customer'


router = DefaultRouter()
router.register(r'ticket', views.TicketView)

urlpatterns = [
    path('', include(router.urls)),
    path('conversation/<str:ids>', views.ConversationListView.as_view()),
    path('conversation/history/<str:ids>', views.ConversationHistoryListView.as_view()),
    path('conversation/attachment/<str:ids>', views.ConversationAttachmentView.as_view()),
    path('conversation/attachment/delete/<str:id>', views.ConversationAttachmentView.as_view()),
    path('conversation/attachment/download/<str:id>', views.AttachmentDownloadLogs.as_view()),

    path('cart/', views.CartView.as_view()),
    path('purchase-history/', views.PurchaseHistoryView.as_view()),


    path('individual-profile/', views.IndividualProfileView.as_view()),
    path('business-profile/', views.BusinessProfileView.as_view()),
    path('credit', views.CustomerCreditView.as_view()),
    path('reseller-credit', views.CustomerResellerCreditView.as_view()),
    path('ticket/search', views.TicketSearchView.as_view({'get': 'list',})),
    path('ticket/update/<str:ids>/', views.TicketUpdateView.as_view({'put': 'update'})),
    path('customer/evc/purchase_history', views.EVCPurchaseHistoryView.as_view()),
    path('customer/zoho/invoice_history', views.ZOHOInvoiceHistoryView.as_view()),
    path('customer/zoho/invoice_download/<str:invoice_id>', views.ZOHOInvoiceDownloadView.as_view()),
    path('purchase-history/admin', views.CustomerPurchaseHistoryAdminView.as_view()),
    path('zoho/admin/invoice_history/<str:uuid>', views.AdminZOHOInvoiceHistoryView.as_view()),
    path('spent-history', views.CustomerSpentHistoryAdminView.as_view()),
    path('reseller/dealers/<str:uuid>/', views.ResellersDealerListView.as_view()),
    path('reseller/dealers/credit_update', views.ResellersDealerCreditUpdateView.as_view()),

    # Logs
    path('logs', views.CustomerLogsListView.as_view()),
    path('logs/csv/download', views.CustomerLogsDownloadListView.as_view()),

    # File requests
    path('file_request/list', views.CustomerFileRequestListView.as_view()),

    # path('decode/', views.DecodeFileView.as_view()),
    path('decode/file/status/<str:guid>', views.DecodeFileStatusView.as_view()),
    # path('decode/file/download/<str:guid>', views.DecodeFileDownloadView.as_view()),

    # path('encode/any/download', views.DecodeAnyFileFileView.as_view()),


    # path('encode/file/modified/', views.EncodeModifiedFileView.as_view()),
    # path('encode/file/modified/<str:guid>', views.EncodeModifiedByGuidFileView.as_view()),
    # path('encode/file/original/', views.EncodeOriginalFileView.as_view()),
    # path('encode/file/', views.EncodeFileView.as_view()),
]