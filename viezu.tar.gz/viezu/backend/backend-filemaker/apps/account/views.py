from django.contrib.auth import authenticate, login, logout
from apps.utils.evc_apis import is_evc_customer_exist, is_evc_reseller_customer_exist
from apps.utils.mailer import sample_email
from apps.utils.tasks import task_create_zoho_invoice

from rest_framework.views import APIView
from rest_framework.response import Response
from rest_framework.authtoken.models import Token
from rest_framework.authentication import TokenAuthentication
from rest_framework.permissions import IsAuthenticated
from rest_framework import status, generics

from drf_yasg.utils import swagger_auto_schema
from apps.account.models import BusinessCustomer, EVCCredentials, MyUser, ResellerAndSubDealer, AccessLogsModel, ZOHOUser
from apps.utils.permissions import CanAdminDeleteOnly

from django.template.loader import render_to_string
from datetime import datetime
from apps.account.schema import (
    login_user_schema,
    forgot_user_schema, otp_verify_schema,
    reset_password_schema, email_verify_schema,
    change_password_schema, update_email_request_schema,
    update_email_schema, individual_register_register_schema,
    business_register_register_schema

)
from apps.admin_management.models import Notification
from apps.utils.decorator import required_fields
import apps.account.response_messages as resp_msg
from apps.account.serializer import (
    BusinessRegisterSerializer, EmailChangeRequestOTPSerializer,
    EmailChangeSerializer, IndividualRegisterSerializer,
    LogedInUserDetailsSerializer, LoginSerializer, NotificationSerializer,
    PasswordchangeSerializer
)
from apps.utils.encryption import Encryption
from apps.utils.helper import SendMail, create_notification, get_random_password
from apps.utils.pagination import SetPagination
from rest_framework.decorators import api_view
from django.conf import settings
import json
#----
# class GetAactiveUsers(APIView):
#     permission_classes = [IsAuthenticated]
#     authentication_classes = [TokenAuthentication, ]

#     def get(self, request):
#         print("Hello")
#         count=0
#         zoho_users = ZOHOUser.objects.filter(active=True)
#         with open("example.txt", "w") as file:
                
#             for item in zoho_users:
#                 file.write(f"Email : {item} | Contact_id : {item.contact_id}\n")
#                 # print(f"{count} --> Email : {item} | Contact_id : {item.contact_id} | Primary_contact_id : {item.contact_id}")
#                 print(f"{count} - Email : {item} | Contact_id : {item.contact_id}\n")

#                 count+=1
#         print(f"Zoho total user : {count}")
#         return Response({
#             'message': 'success'
#         }, status=status.HTTP_200_OK)
# class GetAactiveUsers(APIView):
#     permission_classes = [IsAuthenticated]
#     authentication_classes = [TokenAuthentication, ]

#     def get(self, request):
#         print("Heloo Mohir verma --------------- ")
#         count=0
#         zoho_users = ZOHOUser.objects.filter(active=True)
#         # with open("example.txt", "w") as file:
                
#         #     for item in zoho_users:
#         #         file.write(f"Email : {item} | Contact_id : {item.contact_id} | Primary_contact_id : {item.contact_id} \n")
#         #         # print(f"{count} --> Email : {item} | Contact_id : {item.contact_id} | Primary_contact_id : {item.contact_id}")
#         #         count+=1
#         # print(f"Zoho total user : {count}")

#         with open("inactiveCustomers.json", "r", encoding="utf-8") as file:
#             json_data = json.load(file)
#             # print(f"json_data == {json_data} | type : {type(json_data)}")

#         # emails = [data['email'] for data in json_data]
#         contacts = [data['contact_id'] for data in json_data]
#         # print(f"Contact id : {contacts}")
#         # print(emails,"type: ",type(emails))

#         # filter inactive customer with contact id:
#         # with open("inactiveusers.txt", "w") as file:
#         #     for user in json_data:
#         #         print(f"user : {user}")
#         #         if user.contact_id
        
#         list_contacts = []
#         # filter inactive customers with emails:-----------
#         # with open("inactiveusers.txt", "w") as file:
#         #     i=1
#         #     for user in zoho_users:
#         #         print(f"users == {user}")
#         #         if str(user) in emails:
#         #             print(f"inactive email == {user}")
#         #             list_emails.append(str(user))

#         #-------------filter according to contact id : ----------------------
#         # with open("inactive_contact_id.txt", "w") as file:
#         #     i=1
#         for user in zoho_users:
#             print(f"users == {user.contact_id} | type : {type(user.contact_id)}")
#             if user.contact_id in contacts:
#                 print(f"inactive email == {user.contact_id}")
#                 list_contacts.append(user.contact_id)
        
#         with open("inactive_customers.txt", "w") as file:
#             for data in json_data:
#                 if data['contact_id'] in list_contacts:
#                     print(f"Email : {data['email']} | contact id : {data['contact_id']}")
#                     file.write(f"Email : {data['email']} | contact id : {data['contact_id']} \n")
#         #--------------------------------------------------------------------
                
#         # print(f"list emails : {list_emails}")
#                     # file.write(f"Email : {user} \n")
#         # list_emails = ['lukasz.erbszt@gmail.com','tuningservice00@gmail.com']

#         # with open("inactivecontactid.txt", "w") as file:
#             # for data in json_data:
#             #     if data['email'] in list_emails:
#             #         # print(f"Email : {data['email']} | contact id : {data['contact_id']}")
#             #         file.write(f"Email : {data['email']} | contact id : {data['contact_id']} \n")

#         return Response({
#             'message': 'success'
#         }, status=status.HTTP_200_OK)
#----
class IndividualRegisterView(APIView):
    serializer_class = IndividualRegisterSerializer
    queryset = MyUser.objects.all()

    @swagger_auto_schema(request_body=individual_register_register_schema, tags=['account'])
    def post(self, request):
        params = request.data
        country_code = params['individual'].get('country_code', '')
        phone_no = params['individual'].get('phone_no', '')
        try:
            if MyUser.objects.filter(email=params['individual']['email'].lower()).exists():
                return Response({
                    "detail": resp_msg.EMAIL_ALREADY_EXISTS
                }, status=status.HTTP_400_BAD_REQUEST)

            if MyUser.objects.filter(phone_no=phone_no, country_code=country_code).exists():
                return Response({
                    "detail": resp_msg.PHONE_ALREADY_EXISTS
                }, status=status.HTTP_400_BAD_REQUEST)

            serializer = IndividualRegisterSerializer(data=params, context={'request': request})
            serializer.is_valid(raise_exception=True)
            serializer.save()
            return Response({"message": resp_msg.USER_CREATED})
        except Exception as e:
            return Response({
                "detail": e.args[0] if e.args else str(e)
            }, status=status.HTTP_400_BAD_REQUEST)


class BusinessRegisterView(APIView):
    serializer_class = BusinessRegisterSerializer
    queryset = MyUser.objects.all()

    @swagger_auto_schema(request_body=business_register_register_schema, tags=['account'])
    def post(self, request):
        params = request.data
        country_code = params['business'].get('country_code', '')
        phone_no = params['business'].get('phone_no', '')
        try:
            if MyUser.objects.filter(email=params['business']['email'].lower()).exists():
                return Response({
                    "detail": resp_msg.EMAIL_ALREADY_EXISTS
                }, status=status.HTTP_400_BAD_REQUEST)

            if MyUser.objects.filter(phone_no=phone_no, country_code=country_code).exists():
                return Response({
                    "detail": resp_msg.PHONE_ALREADY_EXISTS
                }, status=status.HTTP_400_BAD_REQUEST)
            serializer = BusinessRegisterSerializer(data=params, context={'request': request})
            serializer.is_valid(raise_exception=True)
            serializer.save()
            return Response({"message": resp_msg.USER_CREATED})
        except Exception as e:
            return Response({
                "detail": e.args[0] if e.args else str(e)
            }, status=status.HTTP_400_BAD_REQUEST)


class LoginView(APIView):
    """login a user in the system API."""

    @swagger_auto_schema(request_body=login_user_schema, tags=['account'])
    @required_fields(field_list=['email', 'password'])
    def post(self, request):
        resp = {}
        serializer = LoginSerializer(data=request.data)
        if serializer.is_valid():
            is_user = MyUser.objects.filter(email=serializer.data.get('email').lower())
            if len(is_user) > 0 and not is_user[0].is_active:
                return Response({
                    'detail': 'Your account is Inactive, Please contact to the support.'
                }, status=status.HTTP_400_BAD_REQUEST)

            user = authenticate(
                username=serializer.data.get('email').lower(),
                password=Encryption().decrypt(serializer.data.get('password')),
                is_active=True
            )
            if user is not None:
                if user.profile.is_email_verified:
                    login(request, user)
                    serializer = LogedInUserDetailsSerializer(user)
                    return Response({
                        'success': True,
                        'data': serializer.data,
                        'message': 'Login Successfully'
                    }, status=status.HTTP_200_OK)
                return Response({
                    'resend_mail': True,
                    'success': False,
                    'detail': resp_msg.EMAIL_NOT_VERIFIED
                }, status=status.HTTP_400_BAD_REQUEST)
            return Response({
                'success': False,
                'detail': resp_msg.INVALID_EMAIL_PASSWORD
            }, status=status.HTTP_400_BAD_REQUEST)
        return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)


class VerifyEmailView(APIView):
    """Verify updated email of user API."""

    @swagger_auto_schema(request_body=email_verify_schema, tags=['account'])
    @required_fields(field_list=['uuid'])
    def post(self, request):
        params = request.data
        try:
            user = MyUser.objects.get(uuid=params['uuid'])
            if not user.profile.is_email_verified:
                user.profile.is_email_verified = True
                user.profile.save()
                # if user.created_by:
                passwrord = get_random_password()
                user.set_password(passwrord)
                user.save()
                context = {
                    'name': "{} {}".format(user.first_name, user.last_name),
                    'email': user.email,
                    'password': passwrord,
                    'frontend_url': 'www.viezu-files.com',
                }
                get_template = render_to_string('email_template/temp_password.html', context)
                SendMail.mail(resp_msg.SUBJECT_NEW_USER_ONBOARD, user.email, get_template)
                user.save()
                return Response({
                    "message": resp_msg.EMAIL_VERIFIED
                }, status=status.HTTP_200_OK)
            return Response({
                "detail": resp_msg.EMAIL_ALREADY_VERIFIED
            }, status=status.HTTP_400_BAD_REQUEST)
        except Exception as e:
            return Response({
                "detail": e.args[0]
            }, status=status.HTTP_400_BAD_REQUEST)


class ForgotPasswordView(APIView):
    """ Forgot passwword view for a user."""

    @swagger_auto_schema(request_body=forgot_user_schema, tags=['account'])
    @required_fields(field_list=['email'])
    def post(self, request):
        from django.conf import settings
        params = request.data
        try:
            user = MyUser.objects.get(email=params['email'].lower())
            if not user.profile.is_email_verified:
                return Response({
                    'resend_mail': True,
                    'success': False,
                    'message': resp_msg.EMAIL_NOT_VERIFIED,
                }, status=status.HTTP_200_OK)
            context = {
                'name': "{} {}".format(user.first_name, user.last_name),
                'otp': user.generate_otp(),
                'frontend_url': 'www.viezu-files.com',
            }
            get_template = render_to_string(
                'email_template/forgot_password.html', context)
            SendMail.mail(
                "Forgot Password OTP", user.email, get_template)
            return Response({
                'success': True,
                'message': 'An OTP has been sent to your email ID.',
            }, status=status.HTTP_200_OK)
        except MyUser.DoesNotExist:
            return Response({
                'success': False,
                'detail': "Your email id is not associated with AI Remap."
            }, status=status.HTTP_400_BAD_REQUEST)
        except Exception as e:
            return Response({
                'detail': e.args[0]
            }, status=status.HTTP_400_BAD_REQUEST)


class OTPVerifyView(APIView):
    """ Verify OTP at forgot-password view. """

    @swagger_auto_schema(request_body=otp_verify_schema, tags=['account'])
    @required_fields(field_list=['email', 'otp'])
    def post(self, request):
        params = request.data
        try:
            user = MyUser.objects.get(email=params['email'].lower())
            if str(user.otp) == params['otp']:
                user.generate_otp()
                return Response({
                    'message': 'OTP verified successfully.',
                }, status=status.HTTP_200_OK)
            return Response({
                'detail': 'Please enter a valid OTP.',
            }, status=status.HTTP_400_BAD_REQUEST)
        except Exception as e:
            return Response({
                'detail': e.args[0]
            }, status=status.HTTP_400_BAD_REQUEST)


class ResetPassword(APIView):
    """ Reset user's password view."""

    @swagger_auto_schema(request_body=reset_password_schema, tags=['account'])
    @required_fields(field_list=['email', 'password', 'confirm_password'])
    def post(self, request):
        params = request.data
        try:
            user = MyUser.objects.get(email=params['email'].lower())
            if Encryption().decrypt(params['password']) == Encryption().decrypt(params['confirm_password']):
                password = Encryption().decrypt(params['password'])
                user.set_password(password)
                user.save()
                is_hard_reset = params.get('is_hard_reset', False)
                if is_hard_reset:
                    context = {
                        'name': "{} {}".format(user.first_name, user.last_name),
                        'email': user.email,
                        'password': password,
                        'frontend_url': 'www.viezu-files.com',
                    }
                    get_template = render_to_string('email_template/reset_password.html', context)
                    SendMail.mail(resp_msg.SUBJECT_NEW_USER_ONBOARD, user.email, get_template)
                return Response({
                    'message': resp_msg.PASSWORD_CHANGED
                }, status=status.HTTP_200_OK)
            return Response({
                'detail': resp_msg.PASSWORD_NOT_MATCH
            }, status=status.HTTP_400_BAD_REQUEST)
        except Exception as e:
            return Response({
                'detail': e.args[0]
            }, status=status.HTTP_400_BAD_REQUEST)


class LogoutView(APIView):
    """Logout a user from the system API."""
    permission_classes = [IsAuthenticated, ]
    authentication_classes = [TokenAuthentication, ]

    def get(self, request):
        Token.objects.filter(user=request.user).delete()
        logout(request)
        return Response({'message': resp_msg.LOGOUT})


class ResendVerificationEmail(APIView):
    """Resend verification email API."""

    def get(self, request):
        from django.conf import settings

        email = request.query_params.get("email", '')
        user = MyUser.objects.filter(email=email).first()
        if user is None:
            return Response({'success': False, 'message': "Email not found."})
        else:
            context = {
                'name': "{} {}".format(user.first_name, user.last_name),
                'link': "{}/{}/{}".format(
                    settings.FRONTEND_BASE_URL,
                    settings.FRONTEND_EMAIL_VERIFY_URL,
                    str(user.uuid)
                ),
                'frontend_url': 'www.viezu-files.com',
            }
            get_template = render_to_string('email_template/welcome.html', context)
            SendMail.mail(resp_msg.SUBJECT_NEW_USER_ONBOARD, user.email, get_template)
            return Response({'success': True, 'message': "Verification mail sent successfully."})


class ChangePasswordView(APIView):
    """Change Loggedin user password API."""
    permission_classes = [IsAuthenticated, ]
    authentication_classes = [TokenAuthentication, ]

    @required_fields(field_list=['current_password', 'new_password', ])
    @swagger_auto_schema(request_body=change_password_schema, tags=['account'])
    def post(self, request):
        serializer = PasswordchangeSerializer(
            data=request.data,
            context={"request": request}
        )
        if serializer.is_valid():
            request.user.set_password(Encryption().decrypt(request.data['new_password']))
            request.user.save()
            return Response({
                "message": resp_msg.PASSWORD_CHANGED
            }, status=status.HTTP_200_OK)
        return Response({
            "detail": serializer.errlors
        }, status=status.HTTP_400_BAD_REQUEST)


class UpdateEmailRequestView(APIView):
    """Update email request of user API."""
    permission_classes = [IsAuthenticated, ]
    authentication_classes = [TokenAuthentication, ]

    @required_fields(field_list=['email', ])
    @swagger_auto_schema(request_body=update_email_request_schema, tags=['account'])
    def post(self, request):
        from django.conf import settings
        serializer = EmailChangeRequestOTPSerializer(data=request.data, context={"request": request})
        if serializer.is_valid():
            context = {
                'name': "{} {}".format(request.user.first_name, request.user.last_name),
                'otp': request.user.generate_otp(),
                'id': request.user.id,
                'frontend_url': 'www.viezu-files.com',
            }
            get_template = render_to_string(
                'email_template/forgot_password.html', context)
            SendMail.mail(
                "Email Update Request", request.data['email'], get_template)
            return Response({
                "message": resp_msg.EMAIL_CHANGE_REQUEST
            }, status=status.HTTP_200_OK)
        return Response({
            "detail": serializer.errors
        }, status=status.HTTP_400_BAD_REQUEST)


class UpdateEmailView(APIView):
    """Update email of user API."""
    permission_classes = [IsAuthenticated, ]
    authentication_classes = [TokenAuthentication, ]

    @required_fields(field_list=['email'])
    @swagger_auto_schema(request_body=update_email_schema, tags=['account'])
    def post(self, request):
        serializer = EmailChangeSerializer(data=request.data, context={"request": request})
        user = MyUser.objects.get(uuid=request.data['uuid'])
        if serializer.is_valid():
            user.email = request.data['email'].lower()
            # user.generate_otp()
            user.save()
            if user.user_type == 3:
                create_notification(
                    user,
                    "Email Id Update",
                    "Business Customer primary email address is changed for added to {} {} – please verify the change for account security".format(
                        user.first_name, user.last_name),
                    sender=user
                )
            return Response({
                "message": resp_msg.EMAIL_CHANGED
            }, status=status.HTTP_200_OK)
        return Response({
            "detail": serializer.errors
        }, status=status.HTTP_400_BAD_REQUEST)


class NotificationView(generics.ListAPIView, generics.CreateAPIView):
    permission_classes = [IsAuthenticated, ]
    authentication_classes = [TokenAuthentication, ]
    queryset = Notification.objects.all().order_by('-id')
    serializer_class = NotificationSerializer
    pagination_class = SetPagination

    def get_queryset(self):
        return self.request.user.notification_recipient.all().order_by('-id')

    def list(self, request, *args, **kwargs):
        results = super(NotificationView, self).list(request, *args, **kwargs).data
        results['un_seen_message_count'] = self.request.user.notification_recipient.filter(is_seen=False).count()
        return Response({
            'data': results,
            'detail': resp_msg.RECORD_FETCHED_SUCCESSFULLY
        }, status=status.HTTP_200_OK)

    def post(self, request, *args, **kwargs):
        self.request.user.notification_recipient.filter(is_seen=False).update(is_seen=True)
        return Response({
            'message': 'Notification updated successfully.',
        }, status=status.HTTP_200_OK)


class ProfileView(APIView):
    permission_classes = [IsAuthenticated, ]
    authentication_classes = [TokenAuthentication, ]

    def get(self, request):
        serializer = LogedInUserDetailsSerializer(request.user)
        return Response({
            'data': serializer.data,
            'message': 'Login Successfully'
        }, status=status.HTTP_200_OK)

    def post(self, request):
        user = MyUser.objects.get(uuid=request.data['uuid'])
        user.image = request.FILES['image']
        user.save()
        return Response({
            'url': user.image.url if user.image else '',
            'message': 'Profile picture upload successfully'
        }, status=status.HTTP_200_OK)


class TestZohoFlow(APIView):

    def get(self, request):
        params = self.request.query_params.get('stripe_id')
        task_create_zoho_invoice.delay(str(params))

        return Response({
            'message': 'ZOH flow test.'
        }, status=status.HTTP_200_OK)


class CreateEVCResellerCustomer(APIView):
    permission_classes = [IsAuthenticated, ]
    authentication_classes = [TokenAuthentication, ]

    def post(self, request):

        win_ols_license_number = request.data.get('win_ols_license_number')
        uuid = request.data.get('uuid')

        user = MyUser.objects.get(uuid=uuid)

        if win_ols_license_number == '':
            return Response({
                'success': False,
                'is_evc_customer': False,
                'is_evc_reseller_customer': False,
                'message': 'Please enter the winols license number.'
            }, status=status.HTTP_400_BAD_REQUEST)

        if win_ols_license_number != '':
            is_evc_customer = BusinessCustomer.objects.filter(
                win_ols_license_number=win_ols_license_number
            ).exclude(user=user)
            if len(is_evc_customer):
                print("In businessssssss")
                return Response({
                    'success': False,
                    'is_evc_customer': False,
                    'is_evc_reseller_customer': False,
                    'message': 'This winols number already exists.'
                }, status=status.HTTP_400_BAD_REQUEST)

            is_reseller_evc_customer = ResellerAndSubDealer.objects.filter(
                win_ols_license_number=win_ols_license_number
            ).exclude(user=user)
            if len(is_reseller_evc_customer):
                print("In resellerrrr")
                return Response({
                    'success': False,
                    'is_evc_customer': False,
                    'is_evc_reseller_customer': False,
                    'message': 'This winols number already exists.'
                }, status=status.HTTP_400_BAD_REQUEST)

        if user.user_type == 3:
            business_winols = BusinessCustomer.objects.get(user=user)
            business_winols.win_ols_license_number = win_ols_license_number
            business_winols.save()

        if user.user_type in [6, 7]:
            reseller_dealer_winols = ResellerAndSubDealer.objects.get(user=user)
            reseller_dealer_winols.win_ols_license_number = win_ols_license_number
            reseller_dealer_winols.save()

        instance = EVCCredentials.objects.all().last()
        is_evc_customer = is_evc_customer_exist(
            instance.apiid, win_ols_license_number,
            instance.username, instance.password)

        user.is_evc_customer = is_evc_customer
        if is_evc_customer:
            user.is_evc_reseller_customer_exist = is_evc_reseller_customer_exist(
                instance.apiid, win_ols_license_number,
                instance.username, instance.password)
            user.is_evc_reseller_customer = True
            user.save()
            return Response({
                'success': True,
                'is_evc_customer': user.is_evc_customer,
                'is_evc_reseller_customer': user.is_evc_reseller_customer,
                'message': 'Evc reseller created successfully.'
            }, status=status.HTTP_200_OK)
        elif not is_evc_customer:
            user.is_evc_reseller_customer = False
            user.save()
            return Response({
                'success': False,
                'is_evc_customer': user.is_evc_customer,
                'is_evc_reseller_customer': user.is_evc_reseller_customer,
                'message': 'User in not an EVC customer.'
            }, status=status.HTTP_200_OK)
        else:
            return Response({
                'success': False,
                'is_evc_reseller_customer': user.is_evc_customer,
                'is_evc_reseller_customer': user.user.is_evc_reseller_customer,
                'message': 'Something went wrong while creating EVC customer.'
            }, status=status.HTTP_200_OK)


class DeleteCustomer(APIView):
    permission_classes = [IsAuthenticated, CanAdminDeleteOnly]
    authentication_classes = [TokenAuthentication, ]

    def delete(self, request, *args, **kwargs):
        user_uuid = self.kwargs['uuid']
        user = MyUser.objects.get(uuid=str(user_uuid))
        customer = user.email
        #---
        x_forwarded_for = request.META.get('HTTP_X_FORWARDED_FOR')
        admin_log = AccessLogsModel.objects.create(
            user=request.user,
            timestamp=datetime.now(),
            ip_address=x_forwarded_for.split(',')[0] if x_forwarded_for else request.META.get('REMOTE_ADDR'),
            method='Deleted',
            event='Account Deleted',
            title='Account Deleted',
            description=f"User {customer} Account Deleted by {request.user}",
            # customer=str(customer,
        )
        print(f"admin log = {admin_log}")
        #---
        user.delete()
        return Response({
            'success': True,
            'message': 'Customer deleted successfully.'
        }, status=status.HTTP_200_OK)

class DeleteInternalUser(APIView):
    permission_classes = [IsAuthenticated]
    authentication_classes = [TokenAuthentication, ]

    def delete(self, request, *args, **kwargs):
        id = self.kwargs['id']
        if request.user.user_type not in [1, 2, 5]:
            return Response({
                'success': False,
                'message': 'You are not authorized to perform this action.'
            }, status=status.HTTP_400_BAD_REQUEST)
        else:
            user = MyUser.objects.get(id=int(id))
            user.delete()
            return Response({
                'success': True,
                'message': 'User deleted successfully.'
            }, status=status.HTTP_200_OK)


class InternalAccountStopView(APIView):
    permission_classes = [IsAuthenticated]
    authentication_classes = [TokenAuthentication, ]

    def get(self, request, *args, **kwargs):
        id = self.kwargs['id']
        if request.user.user_type not in [1, 2, 5]:
            return Response({
                'success': False,
                'message': 'You are not authorized to perform this action.'
            }, status=status.HTTP_400_BAD_REQUEST)
        else:
            user = MyUser.objects.get(id=int(id))
            if user.on_stop:
                user.on_stop = False
                message = "Account has been removed from on stop."
            else:
                user.on_stop = True
                message = "Account has been marked as on stop."
            user.save()
            return Response({
                'success': True,
                'message': message
            }, status=status.HTTP_200_OK)


class CustomerAccountStopView(APIView):
    permission_classes = [IsAuthenticated]
    authentication_classes = [TokenAuthentication, ]

    def get(self, request, *args, **kwargs):
        uuid = self.kwargs['uuid']
        if request.user.user_type not in [1, 2, 5]:
            return Response({
                'success': False,
                'message': 'You are not authorized to perform this action.'
            }, status=status.HTTP_400_BAD_REQUEST)
        else:
            customer = MyUser.objects.get(uuid=str(uuid))
            if customer.on_stop:
                customer.on_stop = False
                message = "Customer account has been removed from on stop."
            else:
                customer.on_stop = True
                message = "Customer account has been marked as on stop."
            customer.save()
            return Response({
                'success': True,
                'message': message
            }, status=status.HTTP_200_OK)


class SampleEmail(APIView):

    def get(self, request, *args, **kwargs):
        sample = request.query_params.get("sample", '')
        sample_email(sample)

        return Response({
            'success': True,
            'message': "Email sent."
        }, status=status.HTTP_200_OK)


@api_view(['GET'])
def hello_world(request):
    return Response({"message": "Hello, logs!"})
