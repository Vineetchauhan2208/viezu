USER_TYPE_CHOICES = (
    (1, 'SUPER_ADMIN'),
    (2, 'Internal_Team'),
    (3, 'BUSINESS_CUSTOMER'),
    (4, 'INDIVIDUAL_CUSTOMER'),
    (5, 'AIREMAP_ADMIN'),
    (6, 'RESELLER'),
    (7, 'DEALER'),
)
