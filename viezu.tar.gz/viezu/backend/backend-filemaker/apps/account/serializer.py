from apps.customer.models import ResellerDistributeCredit
from rest_framework import serializers
from apps.account.models import (
    AccessLogsModel, Address, BusinessCustomer, EVCCredentials, EmailLogSettings,
    IndividualCustomer, MyUser, ResellerAndSubDealer,
    UserProfile
)
import apps.account.response_messages as resp_msg
from rest_framework.authtoken.models import Token
from apps.admin_management.models import Notification
from apps.admin_management.serializer import RolesAndPermissionsSerializers
from django.conf import settings
from django.template.loader import render_to_string
from apps.customer.serializer import TicketCretedByDetailsSerializer
from datetime import datetime
from apps.utils.custom_exception import BaseCustomException
from apps.utils.encryption import Encryption
from apps.utils.evc_apis import is_evc_customer_exist, is_evc_reseller_customer_exist
from apps.utils.helper import SendMail, validate_google_recaptcha
from apps.utils.tasks import task_create_customer_stripe, task_create_zoho_customer
import logging

logger = logging.getLogger(__name__)

class IndividualRegisterSerializer(serializers.ModelSerializer):
    """ Customer register serializer.

    Custom models serializer for Individual customer on platform.
    """

    def create(self, validated_data):
        request = self.context.get('request')
        params = request.data
        params['individual']['email'] = params['individual'].get('email').lower()

        if validate_google_recaptcha(params['captcha_response']):
            user = MyUser.objects.create(
                user_type=4,
                **params['individual']
            )
            UserProfile.objects.create(
                user=user
            )
            Address.objects.create(
                user=user,
                **params['address']
            )
            IndividualCustomer.objects.create(
                user=user,
                **params['individual_profile']
            )
            context = {
                'name': "{} {}".format(user.first_name, user.last_name),
                'link': "{}/{}/{}".format(
                    settings.FRONTEND_BASE_URL,
                    settings.FRONTEND_EMAIL_VERIFY_URL,
                    str(user.uuid)
                ),
                'frontend_url': 'www.viezu-files.com',
            }
            get_template = render_to_string('email_template/welcome.html', context)
            SendMail.mail(resp_msg.SUBJECT_NEW_USER_ONBOARD, user.email, get_template)
            task_create_zoho_customer.delay(str(user.uuid))
            task_create_customer_stripe.delay(str(user.uuid))

            x_forwarded_for = request.META.get('HTTP_X_FORWARDED_FOR')
            AccessLogsModel.objects.create(
                user=user,
                timestamp=datetime.now(),
                ip_address=x_forwarded_for.split(',')[0] if x_forwarded_for else request.META.get('REMOTE_ADDR'),
                method='created',
                event='Individual user registered',
                module=EmailLogSettings.objects.filter(module='customer').last(),
                title='Individual user registered.',
                description="Individual user registered with email {0}.".format(user.email),
                customer=user,
            )

            return user
        raise BaseCustomException(detail=resp_msg.GOOGLE_CAPTCHA_ERROR, code=400)

    class Meta:
        model = MyUser
        fields = ("id", "uuid", "first_name", "last_name", "email", "phone_no", "country_code")


class BusinessRegisterSerializer(serializers.ModelSerializer):
    """ Customer register serializer.

    Custom models serializer for Business customer on platform.
    """

    def create(self, validated_data):
        request = self.context.get('request')
        params = request.data

        params['business']['email'] = params['business'].get('email').lower()

        if validate_google_recaptcha(params['captcha_response']):
            user = MyUser.objects.create(
                user_type=3,
                **params['business']
            )
            UserProfile.objects.create(
                user=user
            )
            Address.objects.create(
                user=user,
                **params['address']
            )
            BusinessCustomer.objects.create(
                user=user,
                **params['business_profile']
            )
            instance = EVCCredentials.objects.all().last()
            if instance is not None and 'business_profile' in params and 'win_ols_license_number' \
                    in params['business_profile'] and params['business_profile']['win_ols_license_number'] != '':
                is_evc_customer = is_evc_customer_exist(instance.apiid,
                                                        params['business_profile']['win_ols_license_number'],
                                                        instance.username, instance.password)
                user.is_evc_customer = is_evc_customer
                if is_evc_customer:
                    user.is_evc_reseller_customer_exist = is_evc_reseller_customer_exist(instance.apiid,
                                                                                         params['business_profile'][
                                                                                             'win_ols_license_number'],
                                                                                         instance.username,
                                                                                         instance.password)
                user.save()

            context = {
                'name': "{} {}".format(user.first_name, user.last_name),
                'link': "{}/{}/{}".format(
                    settings.FRONTEND_BASE_URL,
                    settings.FRONTEND_EMAIL_VERIFY_URL,
                    str(user.uuid)
                ),
                'frontend_url': settings.FRONTEND_BASE_URL,
            }
            get_template = render_to_string('email_template/welcome.html', context)
            SendMail.mail(resp_msg.SUBJECT_NEW_USER_ONBOARD, user.email, get_template)
            logger.info(f"Calling Create Zoho Customer function:-------------")
            task_create_zoho_customer.delay(str(user.uuid))
            # task_create_zoho_customer(str(user.uuid))
            task_create_customer_stripe.delay(str(user.uuid))

            x_forwarded_for = request.META.get('HTTP_X_FORWARDED_FOR')
            AccessLogsModel.objects.create(
                user=user,
                timestamp=datetime.now(),
                ip_address=x_forwarded_for.split(',')[0] if x_forwarded_for else request.META.get('REMOTE_ADDR'),
                method='created',
                event='Business user registered',
                module=EmailLogSettings.objects.filter(module='customer').last(),
                title='Business user registered.',
                description="Business user registered with email {0}.".format(user.email),
                customer=user,
            )

            return user
        raise BaseCustomException(detail=resp_msg.GOOGLE_CAPTCHA_ERROR, code=400)

    class Meta:
        model = MyUser
        fields = ("id", "uuid", "first_name", "last_name", "email", "phone_no", "country_code")


class LoginSerializer(serializers.Serializer):
    """ Login seralizer to authenticat and login a user."""

    email = serializers.EmailField(max_length=100)
    password = serializers.CharField(max_length=100)

    def validate_email(self, email):
        """ Validate if email already exist or not.

        Args:
            email (str)

        Raises:
            BaseCustomException: Email validation message.

        Returns:
            email (str)
        """
        is_email_exist = MyUser.objects.filter(email=email.lower()).exists()
        if not is_email_exist:
            raise BaseCustomException(detail=resp_msg.EMAIL_DOES_NOT_EXIST, code=400)
        return email


class AddressSerializer(serializers.ModelSerializer):
    class Meta:
        model = Address
        fields = "__all__"


class ResellerDealerCreditSerializer(serializers.ModelSerializer):
    # file_key_credit = serializers.SerializerMethodField()
    # function_credit = serializers.SerializerMethodField()
    # evc_credit = serializers.SerializerMethodField()

    class Meta:
        model = ResellerDistributeCredit
        fields = "__all__"


class LogedInUserDetailsSerializer(serializers.ModelSerializer):
    from apps.customer.serializer import CustomerCreditSerializer

    """ Get details of logged user serializer. """
    token = serializers.SerializerMethodField()
    role = serializers.SerializerMethodField()
    roles = RolesAndPermissionsSerializers(read_only=True)
    address_user = AddressSerializer()
    additional = serializers.SerializerMethodField()
    customer_credit = CustomerCreditSerializer()
    reseller_dealer_credit = ResellerDealerCreditSerializer()

    user_id = serializers.SerializerMethodField()

    def get_user_id(self, obj):
        return obj.id

    def get_role(self, obj):
        return obj.get_user_type_display()

    def get_token(self, obj):
        token, _ = Token.objects.get_or_create(user=obj)
        return token.key

    def get_additional(self, obj):
        additional = {}
        if obj.get_user_type_display() == "INDIVIDUAL_CUSTOMER":
            data = IndividualCustomer.objects.get(user=obj)
            additional["product_name"] = data.product_name
            additional["tool_serial_number"] = data.tool_serial_number
        elif obj.get_user_type_display() == "BUSINESS_CUSTOMER":
            data = BusinessCustomer.objects.get(user=obj)
            additional["bussness_name"] = data.bussness_name
            additional["tax_number"] = data.tax_number
            additional["company_number"] = data.company_number
            additional["win_ols_license_number"] = data.win_ols_license_number
        elif obj.get_user_type_display() == "RESELLER":
            try:
                data = ResellerAndSubDealer.objects.get(user=obj)
            except Exception as error:
                data = {}
            additional["bussness_name"] = data.bussness_name if data.bussness_name else ""
            additional["tax_number"] = data.tax_number if data.tax_number else ""
            additional["company_number"] = data.company_number if data.company_number else ""
            additional["win_ols_license_number"] = data.win_ols_license_number if data.win_ols_license_number else ""
        elif obj.get_user_type_display() == "DEALER":
            try:
                data = ResellerAndSubDealer.objects.get(user=obj)
            except Exception as error:
                data = {}
            additional["bussness_name"] = data.bussness_name if data.bussness_name else ""
            additional["tax_number"] = data.tax_number if data.tax_number else ""
            additional["company_number"] = data.company_number if data.company_number else ""
            additional["win_ols_license_number"] = data.win_ols_license_number if data.win_ols_license_number else ""
        return additional

    class Meta:
        model = MyUser
        fields = (
            "first_name", "last_name", 'user_id',
            "email", "uuid", "token", "user_type", "role",
            "phone_no", "country_code", "description", "roles", "image", "address_user",
            "additional", "customer_credit", "is_evc_customer", "is_evc_reseller_customer",
            "reseller_dealer_credit", "on_stop", "parent",
        )


class PasswordchangeSerializer(serializers.Serializer):
    """ Password chnage serializer."""

    current_password = serializers.CharField(max_length=100)
    new_password = serializers.CharField(max_length=100)

    def validate(self, validated_data):
        """Validate password data

        # password validation cases.
        # new_password equals to confirm_new_password
        # current_password should be valid.
        # Length should be of 8 with uppercase,lowercase and a digit.
        Args:
            validated_data (request json): JSON data for change pwd.

        Raises:
            BaseCustomException: Custom exception message for usecases.

        Returns:
            validated_data (request json): JSON data for change pwd.
        """
        current_password = Encryption().decrypt(validated_data.get('current_password'))
        new_password = Encryption().decrypt(validated_data.get('new_password'))

        request = self.context.get('request')

        if len(new_password) < 8:
            raise BaseCustomException(detail=resp_msg.PASSWORD_VALIDATION, code=400)

        lower = any(letter.islower() for letter in new_password)
        upper = any(letter.isupper() for letter in new_password)
        digit = any(letter.isdigit() for letter in new_password)
        if (not upper) or (not lower) or (not digit):
            raise BaseCustomException(detail=resp_msg.PASSWORD_VALIDATION, code=400)

        if not request.user.check_password(current_password):
            raise BaseCustomException(detail=resp_msg.INCORRECT_PASSWORD, code=400)
        return validated_data


class EmailChangeRequestOTPSerializer(serializers.Serializer):
    """ Password chnage serializer."""

    email = serializers.CharField(max_length=100)

    def validate(self, validated_data):
        request = self.context.get('request')
        is_email_exists = MyUser.objects.filter(email=validated_data['email'].lower()).exists()
        if is_email_exists:
            raise BaseCustomException(detail=resp_msg.USER_ALREADY_EXISTS, code=400)
        if request.user.email == validated_data['email']:
            raise BaseCustomException(detail=resp_msg.NEW_EMAIL_IS_SAME_WITH_OLD, code=400)

        return validated_data


class EmailChangeSerializer(serializers.Serializer):
    """ Email change serializer serializer."""

    email = serializers.CharField(max_length=100)
    # otp = serializers.CharField(required=True)

    def validate(self, validated_data):
        request = self.context.get('request')
        is_email_exists = MyUser.objects.filter(email=validated_data['email'].lower()).exists()
        if is_email_exists:
            raise BaseCustomException(detail=resp_msg.USER_ALREADY_EXISTS, code=400)
        if request.user.email == validated_data['email']:
            raise BaseCustomException(detail=resp_msg.NEW_EMAIL_IS_SAME_WITH_OLD, code=400)

        # if str(request.user.otp) != validated_data['otp']:
        #     raise BaseCustomException(detail=resp_msg.INVALID_OTP, code=400)
        return validated_data


class NotificationSerializer(serializers.ModelSerializer):
    sender = TicketCretedByDetailsSerializer(read_only=True)
    recipient = TicketCretedByDetailsSerializer(read_only=True)
    recipient = TicketCretedByDetailsSerializer(read_only=True)
    ticket = serializers.SerializerMethodField()

    def get_ticket(self, obj):
        if obj.ticket:
            return {
                'ids': obj.ticket.ids,
                'id': obj.ticket.id
            }
        return None

    class Meta:
        model = Notification
        fields = ('sender', 'recipient', 'title', 'message', 'id', 'is_seen', 'created_at', 'ticket')


class UserDetailSerializer(serializers.ModelSerializer):
    user_type = serializers.CharField(source='get_user_type_display', read_only=True)
    company_name = serializers.SerializerMethodField()

    def get_company_name(self, obj):
        company_name = None

        # Check if the user is a business user (user_type 3)
        if obj.user_type == 3 and hasattr(obj, 'business_user'):
            company_name = obj.business_user.bussness_name  # Use correct attribute name

        # Check if the user is a reseller sub-dealer (user_type 6 or 7)
        elif obj.user_type in [6, 7] and hasattr(obj, 'reseller_sub_dealer'):
            company_name = obj.reseller_sub_dealer.bussness_name  # Use correct attribute name

        return company_name

    class Meta:
        model = MyUser
        fields = ('first_name', 'last_name', 'image', 'email', 'uuid', 'created_at', 'user_type', 'company_name')
