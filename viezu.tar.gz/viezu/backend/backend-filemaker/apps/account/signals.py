from django.db.models.signals import post_save
from django.dispatch import receiver
from django.contrib.auth import get_user_model
User = get_user_model()


@receiver(post_save, sender=User)
def update_credit(sender, created, instance, **kwargs):
    from apps.customer.models import CustomerCredit
    if created:
        if instance.user_type == 3 or instance.user_type == 4 or instance.user_type == 6 or instance.user_type == 7:
            CustomerCredit.objects.create(
                file_key_credit = 0,
                function_credit = 0,
                evc_credit = 0,
                user = instance
            )
    return instance