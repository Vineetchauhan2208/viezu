"""file_maker_system URL Configuration

The `urlpatterns` list routes URLs to views. For more information please see:
    https://docs.djangoproject.com/en/4.1/topics/http/urls/
Examples:
Function views
    1. Add an import:  from my_app import views
    2. Add a URL to urlpatterns:  path('', views.home, name='home')
Class-based views
    1. Add an import:  from other_app.views import Home
    2. Add a URL to urlpatterns:  path('', Home.as_view(), name='home')
Including another URLconf
    1. Import the include() function: from django.urls import include, path
    2. Add a URL to urlpatterns:  path('blog/', include('blog.urls'))
"""
from django.contrib import admin
from django.urls import path,include,re_path

from django.template import RequestContext
from drf_yasg import openapi
from drf_yasg.views import get_schema_view

from rest_framework import permissions
from rest_framework.documentation import include_docs_urls

schema_view = get_schema_view(
    openapi.Info(
        title="File-Maker-system App",
        default_version='v1',
        description="Swagger API Documentation",
        contact=openapi.Contact(email="")

    ),
    public=True,
    permission_classes=(permissions.AllowAny,),
)

urlpatterns = [
    path('file-maker-admin/', admin.site.urls),
    path('api/v1/customer/', include('apps.customer.urls', namespace='customer')),
    path('api/v1/admin/', include('apps.admin_management.urls', namespace='admin_api')),
    path('api/v1/account/', include('apps.account.urls', namespace='account')),
    path('api/v1/file/service/', include('apps.file_request.urls', namespace='file_request')),
    path('api/v1/shop/', include('apps.shop.urls', namespace='shop')),
    path('api/v1/dashboard/', include('apps.dashboard.urls', namespace='dashboard')),
    path('api/v1/zoho/', include('apps.zoho.urls', namespace='zoho')),
    path('api/v1/file-operation/', include('apps.alientech.urls', namespace='alientech')),

    # swagger URLs
    path('api-doc/', include_docs_urls(title='File Maker Documentation')),
    path('', schema_view.with_ui('swagger', cache_timeout=0),name='schema-swagger-ui'),
    path('api-auth/', include(('rest_framework.urls','rest_framework'), namespace='rest_framework')),
    re_path(r'^swagger(?P<format>\.json|\.yaml)$',schema_view.without_ui(cache_timeout=0), name='schema-json'),
    path('djrichtextfield/', include('djrichtextfield.urls')),

]
