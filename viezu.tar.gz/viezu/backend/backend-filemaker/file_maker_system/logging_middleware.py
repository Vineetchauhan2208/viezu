from apps.account.models import AccessLogsModel

from django.conf import settings
from django.utils import timezone
from django.contrib.auth.models import AnonymousUser
import json

from rest_framework.authtoken.models import Token
from apps.account.models import EmailLogSettings
from apps.utils.tasks import send_logs_on_email

def get_user(token):
    try:
        tokens = token.split()
        instance = Token.objects.get(key = tokens[1])
        return instance.user
    except Exception as e:
        return None
from django.http import JsonResponse

logs_dict = [
    {
        'name' :'customer',
        'path':[
            '/api/v1/admin/customer/import/business/',
            '/api/v1/admin/customer/import/individual/',
            '/api/v1/account/business-register/',
            '/api/v1/account/individual-register/',
            '/api/v1/account/update-email',
            # '/api/v1/customer/credit',
        ]
    },
    # {
    #     'name' :'permissions',
    #     'path':['/api/v1/admin/role-and-permissions/']
    # },
    {
        'name' :'ticket',
        'path':[
            '/api/v1/admin/update-ticket-history/',
            '/api/v1/admin/assign-ticket-history/'
        ]
    },
    {
        'name' :'user',
        'path':[
            '/api/v1/admin/roles/',
        ]
    },
    
]



class AccessLogsMiddleware(object):

    def __init__(self, get_response=None):
        self.get_response = get_response
        # One-time configuration and initialization.

    def __call__(self, request):
        if not request.session.session_key:
            request.session.create()

        access_logs_data = dict()
        # print(request.path)
        if 'HTTP_AUTHORIZATION' in request.META and request.META['HTTP_AUTHORIZATION'] != '':
            access_logs_data['user'] = get_user(request.META['HTTP_AUTHORIZATION'])

        access_logs_data["path"] = request.path

        x_forwarded_for = request.META.get('HTTP_X_FORWARDED_FOR')
        access_logs_data["ip_address"] = x_forwarded_for.split(',')[0] if x_forwarded_for else request.META.get('REMOTE_ADDR')
        access_logs_data["method"] = request.method
        access_logs_data["referrer"] = request.META.get('HTTP_REFERER',None)
        access_logs_data["session_key"] = request.session.session_key
        data = dict()
        data["get"] = dict(request.GET.copy())
        try:
            data['post'] = json.loads(request.body)
        except:
            data['post'] = dict(request.POST.copy()) 

        keys_to_remove = ["password", "csrfmiddlewaretoken"]
        try:
            for key in keys_to_remove:
                data["post"].pop(key, None)
        except Exception as error:
            print(error)
            pass

        access_logs_data["data"] = data
        access_logs_data['event'] = request.method
        access_logs_data["timestamp"] = timezone.now()
        try:
            flag = False
            for log in logs_dict:
                # print(log)
                for path in log['path']:
                    if path in request.path and (request.method == 'POST' or request.method == 'PUT' or request.method == 'DELETE'):
                        access_logs_data['module'] = EmailLogSettings.objects.get(
                            path = log['name']
                        )
                        flag = True
                        break
            if flag:
                if access_logs_data["path"] != '/api/v1/account/business-register/' or access_logs_data["path"] != '/api/v1/account/individual-register/':
                    instance = AccessLogsModel.objects.create(**access_logs_data)
                    send_logs_on_email.delay(instance.sys_id)
        except Exception as error:
            print(error)
        response = self.get_response(request)
        return response
