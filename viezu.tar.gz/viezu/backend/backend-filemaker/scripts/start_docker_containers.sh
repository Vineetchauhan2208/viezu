#!/bin/bash
cd /opt/workspace
docker-compose down
docker-compose up -d
