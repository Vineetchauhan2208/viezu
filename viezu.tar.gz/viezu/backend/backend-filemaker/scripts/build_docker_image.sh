#!/bin/bash
cd /opt/workspace/backend
docker build -t backend .
