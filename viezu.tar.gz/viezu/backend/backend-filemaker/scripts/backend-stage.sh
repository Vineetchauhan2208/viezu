#!/bin/bash

# Variables
GIT_REPOSITORY="https://goel-satyam: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@github.com/oodlestechnologies/File-Maker-System-BE.git"
GIT_BRANCH='staging'
PROJECT_NAME='Filemaker-Stage-Backend'
WORKSPACE='/opt/workspace'
BACKEND_CODE_DIR="$WORKSPACE/backend/backend_code"
DOCKERFILE_DIR="$WORKSPACE/backend"
DOCKER_COMPOSE_DIR="$WORKSPACE"

# Functions

cleanup() {
    echo "Cleaning up workspace..."
    sudo rm -rf /home/workspace/*
}
trap cleanup EXIT

# Main script

# Initialize
echo "Initializing workspace..."
if [ ! -d "$BACKEND_CODE_DIR" ]; then
    echo "Cloning repository into $BACKEND_CODE_DIR..."
    git clone -b $GIT_BRANCH $GIT_REPOSITORY $BACKEND_CODE_DIR
else
    echo "Directory exists. Pulling the latest code..."
    cd $BACKEND_CODE_DIR
    git pull origin $GIT_BRANCH
fi

# Build Docker image
echo "Building Docker image..."
cd $DOCKERFILE_DIR
sudo docker build -t backend .

# Docker-compose up and down
echo "Restarting Docker containers..."
cd $DOCKER_COMPOSE_DIR
sudo docker-compose down
sudo docker-compose up -d
sudo docker-compose ps

# Cleanup unused Docker resources
sudo docker system prune -f

# Post steps
if [ $? -eq 0 ]; then
    echo "$PROJECT_NAME deployment successful!"
else
    echo "$PROJECT_NAME deployment failed!"
fi
