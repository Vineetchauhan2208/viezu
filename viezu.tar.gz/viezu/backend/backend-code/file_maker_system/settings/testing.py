from .base import *
from decouple import config

DEBUG = True
DATABASES = {
    'default': {
        'ENGINE': 'django.db.backends.postgresql_psycopg2',
        'NAME': config('TESTING_DB_NAME'), 
        'USER': config('TESTING_USER'), 
        'PASSWORD': config('TESTING_PASSWORD'),
        'HOST': config('TESTING_HOST'), 
        'PORT': config('TESTING_PORT'),
    }
}
# ELASTIC_APM = {
#   'SERVICE_NAME': config('ELK_SERVICE_NAME'),
#   'SECRET_TOKEN': config('ELK_SECRET_TOKEN'),
#   'SERVER_URL': config('ELK_SERVER_URL'),
#   'ENVIRONMENT': config('ELK_ENVIRONMENT'),
# }
FRONTEND_BASE_URL = 'https://testing.viezu-client-files.com'
FRONTEND_EMAIL_VERIFY_URL = 'verify-email'

MONGO_HOST = config('TESTING_MONGO_HOST')
MONGO_DATABASE = config('TESTING_MONGO_DATABASE')
MONGO_PORT = config('TESTING_MONGO_PORT')

DEFAULT_FILE_STORAGE = 'storages.backends.s3boto3.S3Boto3Storage'
AWS_ACCESS_KEY_ID = config('AWS_ACCESS_KEY_ID')
AWS_SECRET_ACCESS_KEY = config('AWS_SECRET_ACCESS_KEY')
AWS_STORAGE_BUCKET_NAME = config('TESTING_AWS_STORAGE_BUCKET_NAME')
AWS_S3_OBJECT_PARAMETERS = {'CacheControl': 'max-age=86400', }
AWS_QUERYSTRING_AUTH = False
AWS_DEFAULT_ACL = None
AWS_S3_REGION_NAME = config('AWS_S3_REGION_NAME')
DATE_INPUT_FORMATS = ('%d-%m-%Y','%Y-%m-%d')

BROKER_URL = config('TESTING_CELERY_BROKER_URL')
CELERY_RESULT_BACKEND = config('TESTING_CELERY_RESULT_BACKEND')
CELERY_WORKER_CONCURRENCY = config('TESTING_CELERY_WORKER_CONCURRENCY')
CELERY_ACCEPT_CONTENT = ['application/json']
CELERY_TASK_SERIALIZER = 'json'
CELERY_RESULT_SERIALIZER = 'json'
CELERY_TIMEZONE = 'UTC'
CELERY_ENVIOREMENT_SETTING = config('TESTING_SETTING')