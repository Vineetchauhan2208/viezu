from decouple import config
import requests
import json

from apps.account.models import EVCCredentials
BASE_URL = "https://encodingapi.alientech.to" 

import logging
logger = logging.getLogger('django')


class FileOperation:

    def __init__(self):
        self.__clientApplicationGUID = config('ALIENTECH_CLIENT_APPLICATION_GUID')
        self.__secretKey = config('ALIENTECH_SECRET_KEY')
        super().__init__()

    def generate_auth_token(self,):
        logger.info("code inside generate auth token function---------")
        evc_instance = None
        if EVCCredentials.objects.all().exists():
            logger.info("Inside first if condition----")

            evc_instance = EVCCredentials.objects.all().last()
            logger.info(f"evc_instance == {evc_instance}")
        if evc_instance is None:
            logger.info("Inside else condition")
            evc_instance = EVCCredentials.objects.create(
                alientechauttoken = 'test'
            )
            logger.info(f"evc_instance = {evc_instance}")
        
        logger.info(f"Final evc_instance : {evc_instance}")

        url = BASE_URL + "/api/access-tokens/request" 
        payload = json.dumps({
            "clientApplicationGUID": "31b4f3d2-382a-4f7e-a22b-1eefb38f2162",
            "secretKey": "5Ui\"#,`P|Y!mzuMR>#o?*s" #old code
            # "secretKey": "5Ui#,`P|Y!mzuMR>#o?*s" # latest code
        })
        headers = {
            'Content-Type': 'application/json'
        }

        response = requests.request("POST", url,headers=headers, data=payload)
        logger.info(f"Token response : {response}\nToken response token : {response.status_code}")

        if response.status_code == 200:
            evc_instance.alientechauttoken = response.json()['accessToken']
            evc_instance.save()
            print("Token created",response.json()['accessToken'])     
            return True, response.json()['accessToken']
        
        # logger.info(f"generate auth token return  : {response.json()} with false")
        return False,response.json()

    # Decode files by tools
    def decode_kess3_file(self, token, file, customer_code='C0999'):
        logger.info(f"Code inside kess3 ------------------ ")
        url = BASE_URL + "/api/kess3/decode-read-file/"+customer_code
        payload={}
        headers = {'X-Alientech-ReCodAPI-LLC': token}
        files=[
            ('readFile',(file.name,file.read(),'application/octet-stream'))
        ]
        # ---
        logger.info(f"kess3 file url : {url}")
        logger.info(f"payload : {payload}")
        logger.info(f"headers : {headers}")
        logger.info(f"kess3 file name  : {file.name}")
        
        response = requests.request("POST", url, headers=headers, data=payload, files=files)

        # ---
        # try:
        #     response = requests.request("POST", url, headers=headers, data=payload, files=files)
            
        #     logger.info(f"kess3 response == {response}")
        #     logger.info(f"kess3 response status code == {response.status_code}")
        #     logger.info(f"kess3 response Text == {response.text}")
        # except Exception as e:
        #     logger.info(f"Kess 3 API Error : {e}")
        # finally:
        #     logger.info(f"Closed file slot here ----- ")
        #     response_guid = response.get('guid',None)
        #     result = self.close_file_slot(response_guid)
        
        #---
        logger.info(f"kess3 response == {response}")
        logger.info(f"kess3 response status code == {response.status_code}")
        # logger.info(f"kess3 response Text == {response.text}")
        if response.status_code == 401:
            is_sucess,auth_response = self.generate_auth_token()
            if is_sucess:
                self.decode_kess3_file(auth_response,file,customer_code)
        elif response.status_code == 200:
            return True, response.json()
        elif response.status_code == 429:
            response = {"error":response.text}
            return False, response
        return False,response.json()
    
    # ---
    # Decode files by MAGIC tools
    def decode_Magic_file(self, file):
        logger.info(f"Code inside Magic flex ------------------ ")
        print("inside magic api -------------- ")
        # url = BASE_URL + "/api/kess3/decode-read-file/"+customer_code
        url = "https://api.magicmotorsport.com/master/api/v1/slave_manager/decrypt"
        token = "-i8YvlLI9LR7Kj74G0kHFa2C83v5k9P9"

        headers = {
            "X-Api-Key": token,
            "accept":"json",
            }

        files = {
            "input_file":(file.name,file.read(),'application/octet-stream')
        }
        logger.info(f"files == {file.name}")
        payload = {
            "sn":"6363D9B46B8EFAFF"
        }
        logger.info(f"Magic API URL : {url}\nMagic API Token : {token}\nMagic API : {headers}\n Magic API Payloads : {payload}")
        response = requests.post(url, headers=headers,data=payload,files=files)
        
        # logger.info(f"response = {response}")
        logger.info(f"Response status code = {response.status_code}")
        # logger.info(f"Response text = {response.text}")

        if response.status_code == 401:
            logger.info("status code got magic --- 401")
            logger.info(f"Response json : {response.json()}")
        elif response.status_code == 200:
            logger.info("We Got 200 Response of magic api")
            return True, response.json()
        else:
            print("inside else : ------------ ")
            response = {"error":response.text}
            return False, response
        return False,response.json()
    #---
    def decode_kessV2_file(self,token, file, customer_code='C0999'):
        logger.info("Code inside decode kessv2 api---")

        is_sucess, response = False, None #latest code
        auth_response = "" # latest code
        
        url = BASE_URL + "/api/kessv2/decode-read-file/"+customer_code
        headers = {'X-Alientech-ReCodAPI-LLC': token}
        payload={}
        files=[
            ('readFile',(file.name,file.read(),'application/octet-stream'))
        ]
        logger.info(f"kess v2 url : {url}\nkess v2 headers : {headers}\npayloaf : {payload}")

        response = requests.request("POST", url, headers=headers, data=payload, files=files)
        
        logger.info(f"kess v2 APi response == {response}")
        logger.info(f"kess v2 Api status code response : {response.status_code} type : {response.status_code}")
        logger.info(f"kessv2 Response json data : -------------------------------------------------")

        if response.status_code == 401:
            logger.info("===========Inside 401 status code==========")
            logger.info("Generate auth token-----")
            # is_sucess,auth_response = self.generate_auth_token() # old code
            
            # -- latest code with try except:---
            try:
                is_sucess,auth_response = self.generate_auth_token()
            except Exception as e:
                print(f"Error occur vaue is : {e}")
            # ---------------

            logger.info(f"Token is_sucess : {is_sucess} | Token auth_response : {auth_response}")
            if is_sucess:
                logger.info(f"--------------- Again call decode kessv2 file function --------------------")
                self.decode_kessV2_file(auth_response,file,customer_code)
        elif response.status_code == 200:
            return True, response.json()
        elif response.status_code == 429:
            response = {"error":response.text}
            logger.info(f"response = {response}")
            return False, response
        logger.info(f"response text : {response.text} + status code : {response.status_code}")
        return False,"{}/{}".format(response.text,response.status_code)

    def decode_ktag_file(self, token, file, customer_code='C0999'):
        url = BASE_URL + "/api/ktag/decode-read-file/"+customer_code

        files=[
            ('readFile',(file.name,file.read(),'application/octet-stream'))
        ]
        payload = {}
        headers = {'X-Alientech-ReCodAPI-LLC': token}
        response = requests.request("POST", url, headers=headers, data=payload, files=files)
        if response.status_code == 401:
            is_sucess,auth_response = self.generate_auth_token()
            if is_sucess:
                self.decode_ktag_file(auth_response,file,customer_code)
        elif response.status_code == 200:
            return True, response.json()
        elif response.status_code == 429:
            response = {"error":response.text}
            return False, response
        return False,"{}/{}".format(response.text,response.status_code)

    # Decode files by tools end.

    # Encode files by tools
    def encode_kess3_obd_file(self, token,kess3FileSlotGUID,
                            modifiedFileGUID,originalFileGUID='',
                            willCorrectCVN=False,userCustomerCode='C0999',):

        url = BASE_URL+"/api/kess3/encode-obd-file"

        payload=json.dumps({
            "userCustomerCode":userCustomerCode,
            "kess3FileSlotGUID":kess3FileSlotGUID,
            "modifiedFileGUID":modifiedFileGUID,
            "originalFileGUID":originalFileGUID,
            "willCorrectCVN":willCorrectCVN
        })
        headers = {
            'X-Alientech-ReCodAPI-LLC': token,
            'Content-Type': 'application/json'
        }

        response = requests.request("POST", url, headers=headers, data=payload)
        if response.status_code == 401:
            is_sucess,auth_response = self.generate_auth_token()
            if is_sucess:
                self.encode_kess3_obd_file(
                    auth_response,kess3FileSlotGUID,
                    modifiedFileGUID,originalFileGUID,
                    willCorrectCVN,userCustomerCode
                )
        elif response.status_code == 200:
            return True, response.json()
        try:
            return False,response.json()
        except:
            return False,"{}/{}".format(response.text,response.status_code)

    def encode_kess3_boot_bench_file(self, token,
                            kess3FileSlotGUID,microFileGUID='',
                            flashFileGUID='',eepromFileGUID='',
                            mapFileFileGUID='',userCustomerCode='C0999'):
        
        url = BASE_URL+"/api/kess3/encode-boot-bench-file"
                        
        payload = json.dumps({
            "userCustomerCode": userCustomerCode,
            "kess3FileSlotGUID": kess3FileSlotGUID,
            "microFileGUID": microFileGUID,
            "flashFileGUID": flashFileGUID,
            "eepromFileGUID": eepromFileGUID,
            "mapFileFileGUID": mapFileFileGUID
        })
        headers = {
            'X-Alientech-ReCodAPI-LLC': token,
            'Content-Type': 'application/json'
        }
        response = requests.request("POST", url, headers=headers, data=payload)

        if response.status_code == 401:
            is_sucess,auth_response = self.generate_auth_token()
            if is_sucess:
                self.encode_kess3_boot_bench_file(
                    auth_response,kess3FileSlotGUID,
                    microFileGUID,flashFileGUID,
                    eepromFileGUID,mapFileFileGUID,
                    userCustomerCode
                )
        elif response.status_code == 200:
            return True, response.json()
        try:
            return False,response.json()
        except:
            return False,"{}/{}".format(response.text,response.status_code)

    def kessv2_encode_file(self, token,kessv2FileSlotGUID, modifiedFileGUID, willCorrectCVN,originalFileGUID='',userCustomerCode='C0999'):
        url = BASE_URL+"/api/kessv2/encode-file"
        print("###########",token)
        headers = {
            'X-Alientech-ReCodAPI-LLC': token,
            'Content-Type': 'application/json'
        }
        payload = json.dumps({
            "kessv2FileSlotGUID": kessv2FileSlotGUID,
            "modifiedFileGUID": modifiedFileGUID,
            "willCorrectCVN": willCorrectCVN,
            "userCustomerCode": userCustomerCode
        })
        response = requests.request("POST", url, headers=headers, data=payload)
        if response.status_code == 401:
            is_sucess,auth_response = self.generate_auth_token()
            if is_sucess:
                self.kessv2_encode_file(
                    auth_response,kessv2FileSlotGUID,
                    modifiedFileGUID,willCorrectCVN,
                    originalFileGUID,userCustomerCode,
                )
        elif response.status_code == 200:
            return True, response.json()
        try:
            return False,response.json()
        except:
            return False,"{}/{}".format(response.text,response.status_code)

    def ktag_encode_file(
            self, token,kTag2FileSlotGUID, micro_file_guid, flash_guid,eeprom_guid,map_file_guid,userCustomerCode='C0999'
            ):
        url = BASE_URL+"/api/ktag/encode-file"
        print("###########",token)
        headers = {
            'X-Alientech-ReCodAPI-LLC': token,
            'Content-Type': 'application/json'
        }
        payload = json.dumps({
            "ktagFileSlotGUID": kTag2FileSlotGUID,
            "MicroFileGUID": micro_file_guid,
            "FlashFileGUID": flash_guid,
            "EEPROMFileGUID": eeprom_guid,
            'MapFileFileGUID':map_file_guid,
            'userCustomerCode':userCustomerCode
        })
        response = requests.request("POST", url, headers=headers, data=payload)
        if response.status_code == 401:
            is_sucess,auth_response = self.generate_auth_token()
            if is_sucess:
                self.ktag_encode_file(
                    auth_response,kTag2FileSlotGUID,
                    micro_file_guid,flash_guid,
                    eeprom_guid,map_file_guid,userCustomerCode,
                )

        elif response.status_code == 200:
            return True, response.json()
        try:
            return False,response.json()
        except:
            return False,"{}/{}".format(response.text,response.status_code)

    # Encode files by tools

    def async_operation_guid(self, token, asyncOperationGuid):
        # url = BASE_URL + "/api/async-operations/"+asyncOperationGuid # old
        if asyncOperationGuid is not None:
            url = f"{BASE_URL}/api/async-operations/{asyncOperationGuid}" #latest
            headers = {'X-Alientech-ReCodAPI-LLC': token}
            response = requests.request("GET", url, headers=headers)
            if response.status_code == 401:
                is_sucess,auth_response = self.generate_auth_token()
                if is_sucess:
                    self.async_operation_guid(
                        auth_response,asyncOperationGuid
                    )
            elif response.status_code == 200:
                return True, response.json()
            return False,"{}/{}".format(response.text,response.status_code)
        else:
            logger.info(f"asyncOperationGuid is NONE :: {asyncOperationGuid}")
            return False, "GUID is invalid"
    
    def download_decode_file(self, token, slotguid,type='kessv2'):
        url = BASE_URL+"/api/"+type+"/file-slots/"+slotguid+"/files/?fileType=Decoded"
        headers = {'X-Alientech-ReCodAPI-LLC': token}
        response = requests.request("GET", url, headers=headers)
        if response.status_code == 401:
            is_sucess,auth_response = self.generate_auth_token()
            if is_sucess:
                self.download_decode_file(
                    auth_response,slotguid,type
                )
        elif response.status_code == 200:
            file_base_64 = response.json()['data']
            return True, file_base_64
        return False,response.status_code
    
    def download_file(self,token,url):
        payload={}
        headers = {
            'X-Alientech-ReCodAPI-LLC': token
        }
        file_response = None
        file_response = requests.request("GET", url, headers=headers, data=payload)

        # logger.info("==== IN logger file response.======".format(file_response))
        # logger.info("==== IN logger file status.======".format(file_response.status_code))

        is_api_called_successfully = False
        api_response = None
        if file_response.status_code == 401:
            logger.info("==== IN logger file response.======")
            # logger.info(file_response.text)
            is_sucess,auth_response = self.generate_auth_token()
            if is_sucess:
                #  self.download_file(
                #     auth_response,url
                # )
                headers['X-Alientech-ReCodAPI-LLC'] = auth_response
                new_file_response = requests.request("GET", url, headers=headers, data=payload)
                if new_file_response.status_code == 200:
                    return True,new_file_response.json()

        elif file_response.status_code == 200:
            is_api_called_successfully = True
            api_response = file_response.json()
        else:
            is_api_called_successfully = False
            api_response = file_response.status_code
        return is_api_called_successfully,api_response

    def kessv2_upload_modified_file(self, token, file, kessv2FileSlotGUID,customerCode='C0999'):
        url = "{}/api/kessv2/upload-modified-file/{}/{}".format(
            BASE_URL,
            customerCode,
            kessv2FileSlotGUID
        )
        headers = {'X-Alientech-ReCodAPI-LLC': token}
        files=[
            ('file',(file.name,file.read(),'application/octet-stream'))
        ]
        response = requests.request("PUT", url, headers=headers, data={}, files=files)
        # logger.info("==============")
        # logger.info(response.status_code)
        # logger.info(response.text)
        # logger.info("==============")

        if response.status_code == 401:
            is_sucess,auth_response = self.generate_auth_token()
            if is_sucess:
                self.kessv2_upload_modified_file(
                    auth_response,file,
                    kessv2FileSlotGUID,customerCode
                )
        elif response.status_code == 200:
            return True, response.json()
        if 'SLOT_IS_CLOSED' in response.text:
            is_sucess, resp = self.re_open_closed_file(token,kessv2FileSlotGUID,file,'kessv2')
            if not is_sucess:
                return resp
        try:
            return False,response.json()
        except:
            return False,"{}/{}".format(response.text,response.status_code)


    def kessv3_upload_modified_file(self, token, file,
                             kessv3FileSlotGUID,type,
                             customerCode='C0999'):
        url = "{}/api/kess3/upload-modified-file/{}/{}/{}".format(
            BASE_URL,
            customerCode,
            kessv3FileSlotGUID,
            type
        )
        headers = {'X-Alientech-ReCodAPI-LLC': token}
        files=[
            ('file',(file.name,file.read(),'application/octet-stream'))
        ]
        response = requests.request("PUT", url, headers=headers, data={}, files=files)
        logger.info("kessv3_upload_modified_file response %s", response)
        if response.status_code == 401:
            is_sucess,auth_response = self.generate_auth_token()
            if is_sucess:
                self.kessv3_upload_modified_file(
                    auth_response,file,
                    kessv3FileSlotGUID,type,customerCode
                )
        elif response.status_code == 200:
            return True, response.json()
        if 'SLOT_IS_CLOSED' in response.text:
            self.re_open_closed_file(token,kessv3FileSlotGUID,file,'kess3',type)
        try:
            return False,response.json()
        except:
            return False,"{}/{}".format(response.text,response.status_code)

    def ktag_upload_modified_file(self, token, file, ktagFileSlotGUID,type,customerCode='C0999'):
        url = "{}/api/ktag/upload-modified-component-file/{}/{}/{}".format(
            BASE_URL,
            customerCode,
            ktagFileSlotGUID,
            type
        )
        headers = {'X-Alientech-ReCodAPI-LLC': token}
        files=[
            ('file',(file.name,file.read(),'application/octet-stream'))
        ]
        response = requests.request("PUT", url, headers=headers, data={}, files=files)
        if response.status_code == 401:
            is_sucess,auth_response = self.generate_auth_token()
            if is_sucess:
                self.ktag_upload_modified_file(
                    auth_response,file,
                    ktagFileSlotGUID,type,customerCode
                )
        elif response.status_code == 200:
            return True, response.json()
        if 'SLOT_IS_CLOSED' in response.text:
            self.re_open_closed_file(token,ktagFileSlotGUID,file,'ktag',type)
        try:
            return False,response.json()
        except:
            return False,"{}/{}".format(response.text,response.status_code)


    def re_open_closed_file(self,token,guid,file,type='kessv2',file_type=''):
        logger.info("re_open_closed_file")
        #TODO dynamioc kessv2 type
        url = "{}/api/{}/file-slots/{}/reopen".format(
            BASE_URL,
            type,
            guid
        )
        headers = {'X-Alientech-ReCodAPI-LLC': token}
        response = requests.request("POST", url, headers=headers, data={})
        logger.info("re_open_closed_file type -------- %s", type)
        logger.info("re_open_closed_file response -------- %s", response)
        if response.status_code == 200:
            if type == 'kessv2':
                return self.kessv2_upload_modified_file(token,file,guid)    
            elif type == 'kess3':
                return self.kessv3_upload_modified_file(token,file,guid,type)    
            elif type == 'ktag':
                return self.ktag_upload_modified_file(token,file,guid,file_type)    
        try:
            return False,response.json()
        except:
            return False,"{}/{}".format(response.text,response.status_code)


    def re_open_closed_file1(self,token,guid,type='kessv2'):
        url = "{}/api/{}/file-slots/{}/reopen".format(
            BASE_URL,
            type,
            guid
        )
        headers = {'X-Alientech-ReCodAPI-LLC': token}
        response = requests.request("POST", url, headers=headers, data={})
        logger.info("re_open_closed_file response -------- %s", response)
        if response.status_code == 200:
            logger.info("re_open_closed_file response 200 --------")

    def close_file_slot(self,token,guid,file_type):
        url = "{}/api/{}/file-slots/{}/close".format(
            BASE_URL,
            file_type,
            guid
        )
        logger.info(f"close file slot url : {url}")

        headers = {'X-Alientech-ReCodAPI-LLC': token}
        logger.info(f"headers == {headers}")

        response = requests.request("POST", url, headers=headers, data={})
        logger.info(f"Response status code : {response.status_code}")
        logger.info(f"Close File Slot API Response : {response.text}")

        if response.status_code == 401:
            is_sucess,auth_response = self.generate_auth_token()
            if is_sucess:
                self.close_file_slot(
                    auth_response,guid,
                    file_type
                )
        elif response.status_code == 200:
            return True, response.text    
        try:
            return False,response.json()
        except:
            return False,"{}/{}".format(response.text,response.status_code)

    def kessv2_upload_original_file(self, token, file, kessv2FileSlotGUID,customerCode='C0999'):
        url = BASE_URL+"/api/kessv2/upload-original-file/"+customerCode+"+/"+kessv2FileSlotGUID
        headers = {'X-Alientech-ReCodAPI-LLC': token}
        files=[
            ('file',(file.name,file.read(),'application/octet-stream'))
        ]
        response = requests.request("PUT", url, headers=headers, data={}, files=files)
        print(response.text)
        if response.status_code == 401:
            is_sucess,auth_response = self.generate_auth_token()
            if is_sucess:
                self.kessv2_upload_original_file(
                    auth_response,file,
                    kessv2FileSlotGUID,customerCode
                )
        elif response.status_code == 200:
            return True, response.json()
        try:
            return False,response.json()
        except:
            return False,"{}/{}".format(response.text,response.status_code)
        

    def convert_base_64_to_file(base_64_str, file_name):
        import base64

        file_content = 'b2xhIG11bmRv'
        try:
            file_content=base64.b64decode(file_content)
            with open("file_name","w+") as f:
                    f.write(file_content.decode("utf-8"))
        except Exception as e:
            print(str(e))
        
        return True
    
        
# print("=====")
# obj = FileOperation()
# print(obj.generate_auth_token())

# print("=====")
# obj = FileOperation()
# data = obj.download_file('7EE2JjYKp-I','https://encodingapi.alientech.to/api/kessv2/file-slots/09b756f2-87c9-4d04-a29b-77f8553cd48e/files/c440015a-116e-4622-9a6f-6d5becec25d2')
# print(data)
