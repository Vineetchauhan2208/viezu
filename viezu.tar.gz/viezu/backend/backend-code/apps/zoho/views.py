from django.db.models import Q
from rest_framework.response import Response
from rest_framework.views import APIView
from apps.zoho.models import ZOHOToken, ZOHOCategoryTree
from apps.utils.zoho_utils import (
    generate_zoho_access_refresh_token, validate_update_tokens,
)
from apps.utils.zoho_articles_utils import get_root_categories, categorize_data, get_category_tree, load_zoho_articles
from rest_framework import status
from apps.zoho.serializer import (ZOHOTokenSerializer, )
from apps.utils.encryption import Encryption
from rest_framework.authentication import TokenAuthentication
from rest_framework.permissions import IsAuthenticated
from apps.utils.models import ZOHOKnowledgeBaseArticles
from rest_framework import generics
from apps.zoho.serializer import KnowledgeBaseListSerializer, KnowledgeBaseDetailSerializer
from rest_framework.filters import SearchFilter
from django_filters import rest_framework as filters
import apps.admin_management.response_message as resp_msg
from apps.utils.pagination import SetPagination

from apps.utils.tasks import load_zoho_articles_celery

# Create your views here.
class ZOHOAddCredentialsView(APIView):
    """ To add zoho credentials in database.

    token_for:1 == KNOWLEDGEBASE
    token_for:2 == INVOICE

    code,client_id and client_secret must be generated from https://api-console.zoho.eu/
    
    above credentials must be gererated with specific zoho scope.
    Example:
    Desk.articles.READ: To get zoho articles and categories
    ZohoBooks.settings.READ,ZohoBooks.contacts.CREATE,
    ZohoBooks.invoices.READ,ZohoBooks.customerpayments.Create: for invoice flow

    """

    permission_classes = [IsAuthenticated, ]
    authentication_classes = [TokenAuthentication, ]

    serializer_class = ZOHOTokenSerializer

    def post(self, request):

        serializer = ZOHOTokenSerializer(data=request.data)
        if serializer.is_valid():
            token_for = 1 if serializer.data.get('token_for') == "KNOWLEDGEBASE" else 2
            queryset = ZOHOToken.objects.filter(token_for=token_for)
            if token_for == 1:
                if len(queryset) == 0:
                    obj = ZOHOToken.objects.create(
                        code=Encryption().decrypt(serializer.data.get('code')),
                        client_id=Encryption().decrypt(serializer.data.get('client_id')),
                        client_secret=Encryption().decrypt(serializer.data.get('client_secret')),
                        token_for=token_for,
                        organization_id=serializer.data.get('organization_id'),
                        is_valid_tokens=False,
                    )
                    zoho_response = generate_zoho_access_refresh_token()
                    response = validate_update_tokens(zoho_response, obj)
                    return response
                else:
                    obj = queryset.first()
                    obj.code = Encryption().decrypt(serializer.data.get('code'))
                    obj.client_id = Encryption().decrypt(serializer.data.get('client_id'))
                    obj.client_secret = Encryption().decrypt(serializer.data.get('client_secret'))
                    obj.save()
                    zoho_response = generate_zoho_access_refresh_token()
                    response = validate_update_tokens(zoho_response, obj)
                    return response
            if token_for == 2:
                if len(queryset) == 0:
                    obj = ZOHOToken.objects.create(
                        code=Encryption().decrypt(serializer.data.get('code')),
                        client_id=Encryption().decrypt(serializer.data.get('client_id')),
                        client_secret=Encryption().decrypt(serializer.data.get('client_secret')),
                        token_for=token_for,
                        organization_id=serializer.data.get('organization_id'),
                        is_valid_tokens=False,
                    )
                    zoho_response = generate_zoho_access_refresh_token(token_for=token_for)
                    response = validate_update_tokens(zoho_response, obj, token_for=token_for)
                    return response
                else:
                    obj = queryset.first()
                    obj.code = Encryption().decrypt(serializer.data.get('code'))
                    obj.client_id = Encryption().decrypt(serializer.data.get('client_id'))
                    obj.client_secret = Encryption().decrypt(serializer.data.get('client_secret'))
                    obj.save()
                    zoho_response = generate_zoho_access_refresh_token(token_for=token_for)
                    response = validate_update_tokens(zoho_response, obj, token_for=token_for)
                    return response
        else:
            return Response({'errors': serializer.errors},
                            status=status.HTTP_400_BAD_REQUEST)


class GetZOHOCategoriesView(APIView):
    """ Get ZOHO's Knowledgebase categories from database. """

    permission_classes = [IsAuthenticated, ]
    authentication_classes = [TokenAuthentication, ]

    def get(self, request):
        zoho_category = ZOHOCategoryTree.objects.all().first()
        if zoho_category:
            if request.user.user_type == 3:
                data = zoho_category.tree
            elif request.user.user_type == 4:
                data = zoho_category.individual_tree
            elif request.user.user_type == 6:
                data = zoho_category.reseller_tree
            elif request.user.user_type == 7:
                data = zoho_category.dealer_tree if zoho_category.dealer_tree else zoho_category.reseller_tree
            else:
                data = zoho_category.admin_tree
        else:
            data = {}

        return Response({'data': data}, status=status.HTTP_200_OK)

# class AllArticles(APIView):
#     permission_classes = [IsAuthenticated, ]
#     authentication_classes = [TokenAuthentication, ]

#     def get(self, request):
#         from django.core.serializers import serialize
#         from django.http import JsonResponse

#         print("inside function --------- ")
#         data = ZOHOKnowledgeBaseArticles.objects.all().values()

#         # Write data to a text file
#         with open("output.txt", "w", encoding="utf-8") as file:
#             for record in data:
#                 file.write(str(record) + "\n")
#         #---------
#         # data = ZOHOKnowledgeBaseArticles.objects.values_list('tags')
#         # print(f"Data : {data}")

#         # data = serialize('json', ZOHOKnowledgeBaseArticles.objects.values_list('tags'))

#         # print(f"Data : {data}")
#         # data_set = JsonResponse(data, safe=False)
#         # print(f"Data : {data_set}")

#         return Response({
#             "data": "Articles are being updated."
#         }, status=status.HTTP_200_OK)

class UpdateArticlesView(APIView):
    """ Delete all articles from database and re-update it. """

    permission_classes = [IsAuthenticated, ]
    authentication_classes = [TokenAuthentication, ]

    def get(self, request):
        # ZOHOKnowledgeBaseArticles.objects.all().delete()
        zoho_category = ZOHOCategoryTree.objects.all().first()
        if not zoho_category:
            return Response({"error": "No ZOHO categories found."}, status=status.HTTP_404_NOT_FOUND)

        user_type_category_map = {
            3: zoho_category.tree,
            4: zoho_category.individual_tree,
            6: zoho_category.reseller_tree,
            7: zoho_category.dealer_tree,
            5: zoho_category.admin_tree
        }

        def get_all_categories_with_user_types():
            categories_with_user_types = []
            for user_type, categories in user_type_category_map.items():
                category_ids = [category['id'] for category in categories]
                for category_id in category_ids:
                    categories_with_user_types.append((category_id, user_type))
            return categories_with_user_types

        categories_with_user_types = get_all_categories_with_user_types()

        zoho_tokens = ZOHOToken.objects.filter(token_for=1)[0]
        access_token = zoho_tokens.access_token

        for category_id, user_type in categories_with_user_types:
            load_zoho_articles_celery.delay(category_id, access_token, user_type) # latest code
            # load_zoho_articles_celery(category_id, access_token, user_type)

        return Response({
            # "data": "Articles are being updated."
            "data": "Sync in progress... Your data is being updated in the background."
        }, status=status.HTTP_200_OK)


class UpdateZOHOCategoriesView(APIView):
    """ Delete all articles from database and re-update it. """

    permission_classes = [IsAuthenticated, ]
    authentication_classes = [TokenAuthentication, ]

    def get(self, request):
        ZOHOCategoryTree.objects.all().delete()
        data = get_root_categories()

        business_tree, reseller_tree, individual_tree, dealer_tree, admin_tree = categorize_data(data)
        zoho_tokens = ZOHOToken.objects.filter(token_for=1)[0]
        access_token = zoho_tokens.access_token

        business_tree_details = [get_category_tree(category["id"], access_token) for category in business_tree]
        reseller_tree_details = [get_category_tree(category["id"], access_token) for category in reseller_tree]
        individual_tree_details = [get_category_tree(category["id"], access_token) for category in individual_tree]
        dealer_tree_details = [get_category_tree(category["id"], access_token) for category in dealer_tree]
        admin_tree_details = [get_category_tree(category["id"], access_token) for category in admin_tree]

        ZOHOCategoryTree.objects.create(
            tree=business_tree_details,
            reseller_tree=reseller_tree_details,
            individual_tree=individual_tree_details,
            dealer_tree=dealer_tree_details,
            admin_tree=admin_tree_details
        )
        return Response({"data": "ZOHO categories updated."}, status=status.HTTP_200_OK)


class KnowledgeBaseArticlesListView(generics.ListAPIView):
    permission_classes = [IsAuthenticated, ]
    authentication_classes = [TokenAuthentication, ]

    queryset = ZOHOKnowledgeBaseArticles.objects.all().order_by('-id')
    serializer_class = KnowledgeBaseListSerializer
    pagination_class = SetPagination
    search_fields = ['title', 'tags', 'summary']
    filter_backends = (filters.DjangoFilterBackend, SearchFilter,)

    def get_queryset(self):
        print("inside ------- ")
        user_type = self.request.user.user_type
        #----
        if user_type == 7:
            return ZOHOKnowledgeBaseArticles.objects.filter(tags__icontains='subdealer_user').order_by('-id')
        elif user_type == 6:
            return ZOHOKnowledgeBaseArticles.objects.filter(tags__icontains='reseller_user').order_by('-id')
        elif user_type == 5:
            return ZOHOKnowledgeBaseArticles.objects.filter(user_type=5).order_by('-id')
        else:
            return ZOHOKnowledgeBaseArticles.objects.filter(tags__icontains='business_user').order_by('-id')
        #----
        # if user_type == 7:
        #     user_type = 6
        # if user_type in [1, 2]:
        #     return ZOHOKnowledgeBaseArticles.objects.filter(user_type=5).order_by('-id')
        # else:
        #     return ZOHOKnowledgeBaseArticles.objects.filter(user_type=user_type).order_by('-id')

    def list(self, request, *args, **kwargs):
        results = super(KnowledgeBaseArticlesListView, self).list(request, *args, **kwargs)
        return Response({
            'data': results.data,
            'updated_at': results.data['results'][0]['updated_at'] if results.data['results'] else None,
            'message': resp_msg.RECORD_FETCHED_SUCCESSFULLY
        }, status=status.HTTP_200_OK)


class KnowledgeBaseArticlesByCategoryListView(generics.ListAPIView):
    permission_classes = [IsAuthenticated, ]
    authentication_classes = [TokenAuthentication, ]

    queryset = ZOHOKnowledgeBaseArticles.objects.all().order_by('-id')
    serializer_class = KnowledgeBaseListSerializer
    pagination_class = SetPagination
    search_fields = ['title']
    filter_backends = (filters.DjangoFilterBackend, SearchFilter,)

    def get_queryset(self):
        user_type = self.request.user.user_type
        if user_type == 7:
            user_type=6
        if user_type in [1, 2]:
            user_type_to_filter = 5
        else:
            user_type_to_filter = user_type
        category_id = self.kwargs.get('category_id', None)
        if category_id is not None:
            return ZOHOKnowledgeBaseArticles.objects.filter(
                Q(user_type=user_type_to_filter) & (Q(category_id=category_id) | Q(root_category_id=category_id))
            ).order_by('-id')
        return ZOHOKnowledgeBaseArticles.objects.filter(user_type=user_type_to_filter).order_by('-id')

    def list(self, request, *args, **kwargs):
        results = super(KnowledgeBaseArticlesByCategoryListView, self).list(request, *args, **kwargs)
        return Response({
            'data': results.data,
            'message': resp_msg.RECORD_FETCHED_SUCCESSFULLY
        }, status=status.HTTP_200_OK)


class KnowledgeBaseArticlesDetailView(generics.RetrieveAPIView):
    permission_classes = [IsAuthenticated, ]
    authentication_classes = [TokenAuthentication, ]

    queryset = ZOHOKnowledgeBaseArticles.objects.all().order_by('-id')
    serializer_class = KnowledgeBaseDetailSerializer
    lookup_field = "slug"

    def get_queryset(self):
        user_type = self.request.user.user_type
        if user_type in [1, 2]:
            return ZOHOKnowledgeBaseArticles.objects.filter(user_type=5).order_by('-id')
        else:
            return ZOHOKnowledgeBaseArticles.objects.filter(user_type=user_type).order_by('-id')

    def list(self, request, *args, **kwargs):
        results = super(KnowledgeBaseArticlesDetailView, self).list(request, *args, **kwargs)
        return Response({
            'data': results.data,
            'message': resp_msg.RECORD_FETCHED_SUCCESSFULLY
        }, status=status.HTTP_200_OK)
