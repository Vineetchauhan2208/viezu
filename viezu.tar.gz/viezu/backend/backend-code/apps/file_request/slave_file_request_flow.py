N = 7
from apps.utils.mailer import file_request_status_change
import boto3
import pandas as pd
from django.db.models import Q
from apps.utils.helper import triger_socket
import time, json, os, binascii, ast

from apps.alientech.models import DecodeFiles, EncodeFiles
from apps.account.models import (
    EVCCredentials, MyUser
)
from apps.admin_management.models import (
    Directory, TicketCategory, TicketHistory, TicketStatus
)
from apps.file_request.models import (
    DataEcuVersion, FileRequest,
    FileRequestHistory, RequestDownloadFiles,
    FileRequestAveragePerformance
)
from bson.json_util import dumps
from pymongo import MongoClient
from gridfs import GridFS
from django.conf import settings

from apps.file_request.utils import read_user_file_request, upload_file_to_mongo
from apps.utils.ecode_decode import FileOperation
from apps.utils.file_utils import convert_to_n_size_block
import apps.file_request.slave_file_stages_flow as salve_stage
from datetime import datetime
import logging

logger = logging.getLogger('django')

session = boto3.Session(
    aws_access_key_id=settings.AWS_ACCESS_KEY_ID,
    aws_secret_access_key=settings.AWS_SECRET_ACCESS_KEY,
    region_name=settings.AWS_S3_REGION_NAME
)
s3_client = session.client('s3')


def slave_kesv2_file_flow(file_request_id):
    is_file_match_success = True
    __contant_decoded_file = "DECODED FILE"
    matching_found_in_path = ""
    random_generated_path = ""

    file_request_obj = FileRequest.objects.get(request_id=file_request_id)
    data = read_user_file_request(file_request_id)

    user_uploaded_file = read_decode_file(file_request_obj)
    tool_used = file_request_obj.tuning_tool_used

    is_success, response = decode_file_by_tool(tool_used, file_request_obj, user_uploaded_file)
    logger.info("Decode success:{}, decode response:{}".format(is_success, response))

    uploaded_file_name = file_request_obj.tuning_file.url.split("/")[-1]
    create_decode_encode_folder(file_request_obj)
    path = "media/" + str(file_request_obj.request_id)
    dir_name_to_create = str(file_request_obj.request_id)

    if is_success:
        logger.info("Step 3: Create decode file object.")
        tool_used_int = get_tool_type_int(tool_used)
        instance = DecodeFiles.objects.create(
            user=file_request_obj.user,
            tool_type=tool_used_int,
            file=user_uploaded_file,
            decode_response=response,
            guid=response['guid'],
            process_type=2
        )
        instance.update_ids()
        instance.save()
        logger.info(instance.ids)
    else:
        description = "Cannot decode file, got unsuccessfull response.{}".format(response['error'])
        sent_for_manual_handling(file_request_obj, description)
        is_file_match_success = False
        return is_file_match_success

    instance = DecodeFiles.objects.get(ids=instance.ids)
    is_decode_success = validate_decode_status(instance, file_request_obj)

    if not is_decode_success:
        is_file_match_success = False
        return is_file_match_success
    else:
        async_resp = get_async_decode_status(instance)

        if 'error' in async_resp and async_resp['error'] is not None:
            description = async_resp['error']['errorName']
            sent_for_manual_handling(file_request_obj, description)
            close_file_slot(instance, file_request_obj)
            is_file_match_success = False
            file_request_obj.status = 'Manual Handle'
            file_request_obj.save()
            return is_file_match_success, matching_found_in_path, random_generated_path

        logger.info("Step 5: Successfull async response.")

        logger.info("Decode file and saving at local: {}.".format(tool_used))
        decode_file_url = async_resp['result']['decodedFileURL']
        filename = "decoded_" + uploaded_file_name
        is_file_save_local = save_decode_file(path, decode_file_url, file_request_obj)
        logger.info("kessv2 is_file_save_local".format(is_file_save_local))
        if is_file_save_local:
            logger.info("in save file at local")
            local_file_name = path + '/' + filename
            logger.info(local_file_name)
            is_success, url = upload_file_s3(local_file_name, dir_name_to_create,
                                             filename, file_request_obj)
            create_download_file_object(file_request_obj, url, __contant_decoded_file)

        with open(local_file_name, 'rb') as f:
            decoded_file_hexa_dump = binascii.hexlify(f.read()).decode()

        # convert decoded file to hexa_dump_list
        decoded_file_hexa_dump_list = convert_to_n_size_block(decoded_file_hexa_dump, 8)
        decode_id = str(instance.ids)
        directories_to_search = search_based_on_form_data(file_request_obj, data, decode_id)
        matching_original_data = []
        if len(directories_to_search) > 0:
            files_for_algorithm = get_s3_original_files(directories_to_search)
            try:
                matching_original_data = get_matching_ratio_df(
                    files_for_algorithm, file_request_obj,
                    decoded_file_hexa_dump_list)
            except Exception as error:
                print("get matching ratio error", error)
                logger.error("get matching ratio error:{}".format(error))
        else:
            description = salve_stage.SLAVE_FILE_STAGE_MANUAL
            sent_for_manual_handling(file_request_obj, description)
            close_file_slot(instance, file_request_obj)
            is_file_match_success = False
            return is_file_match_success, matching_found_in_path, random_generated_path

        version_files_list = []
        if len(matching_original_data) == 0:
            description = salve_stage.SLAVE_FILE_STAGE_MANUAL_1
            sent_for_manual_handling(file_request_obj, description)
            close_file_slot(instance, file_request_obj)
            is_file_match_success = False
            return is_file_match_success, matching_found_in_path, random_generated_path
        else:
            for original_data in matching_original_data:
                version_files_list = get_version_files_from_dir(
                    original_data['matching_directory'],
                    file_request_obj)
                if len(version_files_list) > 0:
                    break

            logger.info("version list found.")

        # Match version files list.
        version_data = []
        if len(version_files_list) > 0:
            version_data = match_version_files(original_data, version_files_list,
                                               file_request_obj)
        if len(version_data) == 0:
            description = salve_stage.SLAVE_FILE_STAGE_MANUAL_2
            sent_for_manual_handling(file_request_obj, description)
            close_file_slot(instance, file_request_obj)
            is_file_match_success = False
            return is_file_match_success, matching_found_in_path, random_generated_path
        else:
            version_file_hexa_list = version_data['version_file_hexa_list']
            original_file_hexa_list = original_data['matching_original_file_hexa_list']
            # decoded file hexadump.
            similar_original_file_hexadump_list = decoded_file_hexa_dump_list

            updated_similar_hexa_bytes = add_diff_to_similar_original_index_bytes(
                version_file_hexa_list, original_file_hexa_list,
                similar_original_file_hexadump_list, file_request_obj)

            dir_name_to_create = create_directory_name(version_data)

            random_generated_path = dir_name_to_create
            matching_found_in_path = version_data['version_matching_directory']

            if file_request_obj.file_type == "Client/Slave":
                file_name_to_create = "modified_(VPERF)_" + dir_name_to_create.split("/")[-1]
                title = "Modified VPERF File"

            local_file_name = create_file_at_local(file_name_to_create, updated_similar_hexa_bytes,
                                                   file_request_obj)
            is_sucess, url = upload_file_s3(local_file_name, dir_name_to_create,
                                            file_name_to_create, file_request_obj)

            if is_sucess:
                RequestDownloadFiles.objects.create(
                    fil_request_id=file_request_obj,
                    title=title,
                    url=url
                )

            evc_instance = EVCCredentials.objects.all().last()
            title = "Upload modified file"
            decode_instance = DecodeFiles.objects.get(ids=instance.ids)
            modified_file = read_modified_file(file_name_to_create, file_request_obj)
            tool_used = get_tool_type_int(tool_used)

            logger.info("Step 19: Upload modified original file.:{}.".format(tool_used))
            is_sucess, response = FileOperation().kessv2_upload_modified_file(
                evc_instance.alientechauttoken,
                modified_file,
                decode_instance.slot_guid,
            )

            if is_success:
                is_upload_modified_success = True
                save_flow(
                    file_request_obj=file_request_obj,
                    title="Modify file upload.",
                    description="Modified File successfully uploaded to alientech.",
                    is_success=True,
                )
                modified_instance = EncodeFiles.objects.create(
                    user=file_request_obj.user,
                    decode=decode_instance,
                    guid=response['guid'] if 'guid' in response else 'N/A',
                    encode_response=response,
                    file_type="Modified"
                )
                modified_instance.update_ids()
                # after uploda mdified encode the file.
                is_sucess, response = FileOperation().kessv2_encode_file(
                    evc_instance.alientechauttoken,
                    decode_instance.slot_guid,
                    modified_instance.guid,
                    False
                )
                is_sent_for_encode = True if is_sucess else False
            else:
                logger.error(async_resp["error"])
                description = "Upload modified failed with error:{}".format(async_resp['error'])
                sent_for_manual_handling(file_request_obj, description)
                close_file_slot(instance, file_request_obj)
                is_file_match_success = False
                return is_file_match_success, matching_found_in_path, random_generated_path

            if is_sucess and is_upload_modified_success and is_sent_for_encode:
                logger.info("Step 19: File sent for encode successfully.")
                save_flow(
                    file_request_obj=file_request_obj,
                    title="File sent for encode successfully.",
                    description="File sent for encode successfully.",
                    is_success=True,
                )
                logger.info("upper.")
                encode_ins = EncodeFiles.objects.create(
                    user=modified_instance.user,
                    parent=modified_instance,
                    decode=decode_instance,
                    ids=modified_instance.ids,
                    guid=response['guid'] if 'guid' in response else 'N/A',
                    encode_response=response,
                    file_type='Encode'
                )
                logger.info(encode_ins.ids)

                async_resp = get_async_encode_status(encode_ins)

                save_flow(
                    file_request_obj=file_request_obj,
                    title="Kess v2 Encode result successfull.",
                    description="File sent for encode successfully.",
                    is_success=True,
                )
                encoded_file_url = async_resp['result']['encodedFileURL']
                if "encodingapi.alientech.to" in encoded_file_url:
                    try:
                        additional_function = file_request_obj.additional_function
                        if additional_function is not None:
                            additional_function = additional_function.split(",")
                            additional_function = list(
                                map(lambda function_name: function_name.upper().strip(), additional_function))
                        else:
                            additional_function = []
                        tuning_required = file_request_obj.tuning_required
                        search_terms = ''
                        if tuning_required == "VBLUE/ECO":
                            search_terms = "ECONOMY"
                        elif tuning_required == "VBLEND/STAGE 0.5":
                            search_terms = "BLEND"
                        elif tuning_required == "VPERF/STAGE 1":
                            search_terms = "PERFORMANCE"
                        elif tuning_required == "VRACE/STAGE 2":
                            search_terms = "vrace"
                        elif tuning_required == "NO TUNE":
                            search_terms = ''
                        uploaded_file_name = uploaded_file_name.upper()
                        filename = uploaded_file_name + ' ' + search_terms
                        if additional_function:
                            filename += ' ' + ' '.join(additional_function)
                        title = uploaded_file_name + ' ' + search_terms
                    except Exception as error:
                        path = "media/" + str(file_request_obj.request_id)
                        filename = "encoded_" + file_request_obj.tuning_file.url.split("/")[-1]
                    is_file_save_local = save_encode_file(path, encoded_file_url, file_request_obj)
                    logger.info("In kess2 save file.")
                    if is_file_save_local:
                        local_file_name = path + '/' + filename
                        dir_name_to_create = file_request_obj.request_id
                        is_success, url = upload_file_s3(local_file_name, dir_name_to_create,
                                                         filename, file_request_obj)
                        logger.info("Save file in model for {}.".format(title))
                        request_instance = RequestDownloadFiles.objects.create(
                            fil_request_id=file_request_obj,
                            title=title,
                            url=url,
                            sent_to_user=True
                        )
                        is_file_match_success = True
                        close_file_slot(instance, file_request_obj)
                        file_request_obj.status = "CLOSED"
                        file_request_obj.save()
                        logger.info("file_request_obj status %s", file_request_obj.status)
                        Directory.objects.create(
                            directory_path="Main/" + random_generated_path.split("/")[-1],
                            ecu_producer=file_request_obj.ecu_brand,
                            ecu_build=file_request_obj.ecu_version,
                            created_by_filemaker=True,
                            vehicle_type=file_request_obj.vehicle_type,
                            vehicle_producer=file_request_obj.vehicle_make,
                            vehicle_model=file_request_obj.model,
                            vehicle_model_year=file_request_obj.vehicle_year,
                            file_request=file_request_obj
                        )
                        upload_file_to_mongo(local_file_name, dir_name_to_create)
                        title = "File is presented to the user."
                        description = "File is present to the user to download with name {0}:".format(
                            random_generated_path + '/' + filename)
                        save_flow(file_request_obj, title, description, True)
                        return is_file_match_success, matching_found_in_path, random_generated_path
                else:
                    print("in manual handle.")
                    description = response
                    sent_for_manual_handling(file_request_obj, description)
                    close_file_slot(instance, file_request_obj)
                    is_file_match_success = False
                    return is_file_match_success, matching_found_in_path, random_generated_path
            else:
                print("in maual handle.")
                description = response
                sent_for_manual_handling(file_request_obj, description)
                close_file_slot(instance, file_request_obj)
                is_file_match_success = False
                return is_file_match_success, matching_found_in_path, random_generated_path

    return is_file_match_success, matching_found_in_path, random_generated_path


def slave_kess3_file_flow(file_request_id):
    is_file_match_success = True
    __contant_decoded_file = "DECODED FILE"
    __contant_encoded_file = "ENCODED FILE"
    __constant_map_file = "map_"
    __constant_flash_file = "flash_"
    __constant_micro_file = "micro_"
    matching_found_in_path = ""
    random_generated_path = ""

    file_request_obj = FileRequest.objects.get(request_id=file_request_id)
    data = read_user_file_request(file_request_id)

    user_uploaded_file = read_decode_file(file_request_obj)
    tool_used = file_request_obj.tuning_tool_used

    is_success, response = decode_file_by_tool(tool_used, file_request_obj, user_uploaded_file)
    logger.info("Decode success:{}, decode response:{}".format(is_success, response))

    uploaded_file_name = file_request_obj.tuning_file.url.split("/")[-1]
    create_decode_encode_folder(file_request_obj)
    path = "media/" + str(file_request_obj.request_id)
    dir_name_to_create = str(file_request_obj.request_id)
    if is_success:
        logger.info("Step 3: Create decode file object.")
        tool_used_int = get_tool_type_int(tool_used)
        instance = DecodeFiles.objects.create(
            user=file_request_obj.user,
            tool_type=tool_used_int,
            file=user_uploaded_file,
            decode_response=response,
            guid=response['guid'],
            process_type=2
        )
        instance.update_ids()
        instance.save()
        logger.info(instance.ids)
    else:
        description = "Cannot decode file, got unsuccessfull response.{}".format(response['error'])
        sent_for_manual_handling(file_request_obj, description)
        is_file_match_success = False
        return is_file_match_success, matching_found_in_path, random_generated_path

    instance = DecodeFiles.objects.get(ids=instance.ids)
    is_decode_success = validate_decode_status(instance, file_request_obj)

    if not is_decode_success:
        is_file_match_success = False
        return is_file_match_success
    else:
        async_resp = get_async_decode_status(instance)

        if 'error' in async_resp and async_resp['error'] is not None:
            description = async_resp['error']['errorName']
            sent_for_manual_handling(file_request_obj, description)
            close_file_slot(instance, file_request_obj)
            is_file_match_success = False
            file_request_obj.status = 'Manual Handle'
            file_request_obj.save()
            return is_file_match_success, matching_found_in_path, random_generated_path

        logger.info("Step 5: Successfull async response.")

        logger.info("Decode file and saving at local: {}.".format(tool_used))
        kess_mode = async_resp['result']['kess3Mode']

        # Saving kess3 obd files at local.
        if kess_mode == "OBD":
            logger.info("IN OBD")
            decode_file_url = async_resp['result']['obdDecodedFileURL']
            filename = "decoded_" + uploaded_file_name

            is_file_save_local = save_decode_file(path, decode_file_url, file_request_obj)
            if is_file_save_local:
                logger.info("save OBD file at local")
                obd_local_file_name = path + '/' + filename
                is_success, url = upload_file_s3(obd_local_file_name, dir_name_to_create,
                                                 filename, file_request_obj)
                request_instance = create_download_file_object(file_request_obj, url, __contant_decoded_file)
                is_obd_file = True if request_instance else False

            with open(obd_local_file_name, 'rb') as f:
                decoded_file_hexa_dump = binascii.hexlify(f.read()).decode()

            # convert decoded file to hexa_dump_list
            decoded_file_hexa_dump_list = convert_to_n_size_block(decoded_file_hexa_dump, 8)
            decode_id = str(instance.ids)
            directories_to_search = search_based_on_form_data(file_request_obj, data, decode_id)
            matching_original_data = []
            if len(directories_to_search) > 0:
                files_for_algorithm = get_s3_original_files(directories_to_search)
                try:
                    matching_original_data = get_matching_ratio_df(
                        files_for_algorithm, file_request_obj,
                        decoded_file_hexa_dump_list)
                except Exception as error:
                    logger.error("get matching ratio error:{}".format(error))
            else:
                description = salve_stage.SLAVE_FILE_STAGE_MANUAL
                sent_for_manual_handling(file_request_obj, description)
                close_file_slot(instance, file_request_obj)
                is_file_match_success = False
                return is_file_match_success, matching_found_in_path, random_generated_path
            version_files_list = []
            if len(matching_original_data) == 0:
                description = salve_stage.SLAVE_FILE_STAGE_MANUAL_1
                sent_for_manual_handling(file_request_obj, description)
                close_file_slot(instance, file_request_obj)
                is_file_match_success = False
                return is_file_match_success, matching_found_in_path, random_generated_path
            else:
                for original_data in matching_original_data:
                    version_files_list = get_version_files_from_dir(
                        original_data['matching_directory'],
                        file_request_obj)
                    if len(version_files_list) > 0:
                        break

            # Match version files list.
            version_data = []
            if len(version_files_list) > 0:
                version_data = match_version_files(original_data, version_files_list,
                                                   file_request_obj)
            if len(version_data) == 0:
                description = salve_stage.SLAVE_FILE_STAGE_MANUAL_2
                sent_for_manual_handling(file_request_obj, description)
                close_file_slot(instance, file_request_obj)
                is_file_match_success = False
                return is_file_match_success, matching_found_in_path, random_generated_path
            else:
                version_file_hexa_list = version_data['version_file_hexa_list']
                original_file_hexa_list = original_data['matching_original_file_hexa_list']
                # decoded file hexadump.
                similar_original_file_hexadump_list = decoded_file_hexa_dump_list

                updated_similar_hexa_bytes = add_diff_to_similar_original_index_bytes(
                    version_file_hexa_list, original_file_hexa_list,
                    similar_original_file_hexadump_list, file_request_obj)

                dir_name_to_create = create_directory_name(version_data)

                random_generated_path = dir_name_to_create
                matching_found_in_path = version_data['version_matching_directory']

                if file_request_obj.file_type == "Client/Slave":
                    file_name_to_create = "modified_(VPERF)_" + dir_name_to_create.split("/")[-1]
                    title = "Modified VPERF File"

                local_file_name = create_file_at_local(file_name_to_create, updated_similar_hexa_bytes,
                                                       file_request_obj)
                is_sucess, url = upload_file_s3(local_file_name, dir_name_to_create,
                                                file_name_to_create, file_request_obj)

                if is_sucess:
                    RequestDownloadFiles.objects.create(
                        fil_request_id=file_request_obj,
                        title=title,
                        url=url
                    )

                evc_instance = EVCCredentials.objects.all().last()

                title = "Upload modified file"
                decode_instance = DecodeFiles.objects.get(ids=instance.ids)
                modified_file = read_modified_file(file_name_to_create, file_request_obj)
                tool_used = get_tool_type_int(tool_used)

                logger.info("Step 19: Upload modified original file.:{}.".format(tool_used))
                is_sucess, response = FileOperation().kessv3_upload_modified_file(
                    evc_instance.alientechauttoken,
                    modified_file,
                    decode_instance.slot_guid,
                    "OBDModified"
                )

                if is_success:
                    is_upload_modified_success = True
                    save_flow(
                        file_request_obj=file_request_obj,
                        title="Modify file upload.",
                        description="Modified File successfully uploaded to alientech.",
                        is_success=True,
                    )
                    modified_instance = EncodeFiles.objects.create(
                        user=file_request_obj.user,
                        decode=decode_instance,
                        guid=response['guid'] if 'guid' in response else 'N/A',
                        encode_response=response,
                        file_type="Modified"
                    )
                    modified_instance.update_ids()
                    # after uploda mdified encode the file.
                    is_sucess, response = FileOperation().encode_kess3_obd_file(
                        evc_instance.alientechauttoken,
                        decode_instance.slot_guid,
                        modified_instance.guid,
                        originalFileGUID='',
                        willCorrectCVN=False
                    )
                    is_sent_for_encode = True if is_sucess else False
                else:
                    logger.error(async_resp["error"])
                    description = "Upload modified failed with error:{}".format(async_resp['error'])
                    sent_for_manual_handling(file_request_obj, description)
                    close_file_slot(instance, file_request_obj)
                    is_file_match_success = False
                    return is_file_match_success, matching_found_in_path, random_generated_path

                if is_sucess and is_upload_modified_success and is_sent_for_encode:
                    logger.info("Step 19: File sent for encode successfully.")
                    save_flow(
                        file_request_obj=file_request_obj,
                        title="File sent for encode successfully.",
                        description="File sent for encode successfully.",
                        is_success=True,
                    )
                    encode_ins = EncodeFiles.objects.create(
                        user=modified_instance.user,
                        parent=modified_instance,
                        decode=decode_instance,
                        ids=modified_instance.ids,
                        guid=response['guid'] if 'guid' in response else 'N/A',
                        encode_response=response,
                        file_type='Encode'
                    )
                    logger.info(encode_ins.ids)
                    async_resp = get_async_encode_status(encode_ins)

                    save_flow(
                        file_request_obj=file_request_obj,
                        title="Kess3 Encode result successfull.",
                        description="File sent for encode successfully.",
                        is_success=True,
                    )
                    encoded_file_url = async_resp['result']['encodedFileURL']
                    if "encodingapi.alientech.to" in encoded_file_url:
                        try:
                            additional_function = file_request_obj.additional_function
                            if additional_function is not None:
                                additional_function = additional_function.split(",")
                                additional_function = list(
                                    map(lambda function_name: function_name.upper().strip(), additional_function))
                            else:
                                additional_function = []
                            tuning_required = file_request_obj.tuning_required
                            search_terms = ''
                            if tuning_required == "VBLUE/ECO":
                                search_terms = "ECONOMY"
                            elif tuning_required == "VBLEND/STAGE 0.5":
                                search_terms = "BLEND"
                            elif tuning_required == "VPERF/STAGE 1":
                                search_terms = "PERFORMANCE"
                            elif tuning_required == "VRACE/STAGE 2":
                                search_terms = "vrace"
                            elif tuning_required == "NO TUNE":
                                search_terms = ''
                            uploaded_file_name = uploaded_file_name.upper()
                            filename = uploaded_file_name + ' ' + search_terms
                            if additional_function:
                                filename += ' ' + ' '.join(additional_function)
                            title = uploaded_file_name + ' ' + search_terms
                        except Exception as error:
                            path = "media/" + str(file_request_obj.request_id)
                            filename = "encoded_" + file_request_obj.tuning_file.url.split("/")[-1]
                        is_file_save_local = save_encode_file(path, encoded_file_url, file_request_obj)
                        logger.info("In kess3 save file.")
                        if is_file_save_local:
                            local_file_name = path + '/' + filename
                            dir_name_to_create = file_request_obj.request_id
                            is_success, url = upload_file_s3(local_file_name, dir_name_to_create,
                                                             filename, file_request_obj)
                            logger.info("Save file in model for {}.".format(title))
                            RequestDownloadFiles.objects.create(
                                fil_request_id=file_request_obj,
                                title=title,
                                url=url,
                                sent_to_user=True
                            )
                            is_file_match_success = True
                            close_file_slot(instance, file_request_obj)
                            file_request_obj.status = "CLOSED"
                            file_request_obj.save()
                            logger.info("file_request_obj status %s", file_request_obj.status)
                            Directory.objects.create(
                                directory_path="Main/" + random_generated_path.split("/")[-1],
                                ecu_producer=file_request_obj.ecu_brand,
                                ecu_build=file_request_obj.ecu_version,
                                created_by_filemaker=True,
                                vehicle_type=file_request_obj.vehicle_type,
                                vehicle_producer=file_request_obj.vehicle_make,
                                vehicle_model=file_request_obj.model,
                                vehicle_model_year=file_request_obj.vehicle_year,
                                file_request=file_request_obj
                            )
                            upload_file_to_mongo(local_file_name, dir_name_to_create)
                            title = "File is presented to the user."
                            description = "File is present to the user to download with name {0}:".format(
                                random_generated_path + '/' + filename)
                            save_flow(file_request_obj, title, description, True)
                            return is_file_match_success, matching_found_in_path, random_generated_path
                    else:
                        print("in manual handle.")
                        description = response
                        sent_for_manual_handling(file_request_obj, description)
                        close_file_slot(instance, file_request_obj)
                        is_file_match_success = False
                        return is_file_match_success, matching_found_in_path, random_generated_path
                else:
                    print("in manual handle.")
                    description = response
                    sent_for_manual_handling(file_request_obj, description)
                    close_file_slot(instance, file_request_obj)
                    is_file_match_success = False
                    return is_file_match_success, matching_found_in_path, random_generated_path

        # Saving kess3 bootbench files at local.
        elif kess_mode == "BootBench":
            logger.info("IN Bootbench")
            components = async_resp['result']['bootBenchComponents']

            is_map_file_kess3 = any(d['type'] == 'MapFile' for d in components)
            is_micro_file_kess3 = any(d['type'] == 'Micro' for d in components)
            is_flash_file_kess3 = any(d['type'] == 'Flash' for d in components)

            logger.info("kess3 mapfile:{}".format(is_map_file_kess3))
            logger.info("kess3 is_micro_file:{}".format(is_micro_file_kess3))
            logger.info("kess3 is_flash_file:{}".format(is_flash_file_kess3))

            if is_map_file_kess3:
                logger.info("Download Map file for kess3.")
                map_dict = list(filter(lambda x: x['type'] == 'MapFile', components))
                filename = __constant_map_file + "decoded_" + uploaded_file_name

                is_file_save_local = save_decode_file(path, map_dict['decodedFileURL'],
                                                      file_request_obj, 'mapfile_')
                if is_file_save_local:
                    map_local_file_name_kess3 = path + '/' + filename
                    is_success, url = upload_file_s3(map_local_file_name_kess3, dir_name_to_create,
                                                     filename, file_request_obj)
                    create_download_file_object(
                        file_request_obj, url,
                        __constant_map_file)

            if not is_map_file_kess3 and is_micro_file_kess3:
                logger.info("Download Micro file for kess3.")
                micro_dict = list(filter(lambda x: x['type'] == 'Micro', components))[0]

                filename = __constant_micro_file + "decoded_" + uploaded_file_name

                is_file_save_local = save_decode_file(path, micro_dict['decodedFileURL'],
                                                      file_request_obj, 'micro_')
                if is_file_save_local:
                    micro_local_file_name_kess3 = path + '/' + filename
                    logger.info(micro_local_file_name_kess3)
                    is_success, url = upload_file_s3(micro_local_file_name_kess3, dir_name_to_create,
                                                     filename, file_request_obj)
                    create_download_file_object(
                        file_request_obj, url,
                        "Micro")

            if not is_map_file_kess3 and is_flash_file_kess3:
                logger.info("Download Flash file for kess3.")
                flash_dict = list(filter(lambda x: x['type'] == 'Flash', components))[0]
                filename = __constant_flash_file + "decoded_" + uploaded_file_name
                is_file_save_local = save_decode_file(path, flash_dict['decodedFileURL'],
                                                      file_request_obj, 'flash_')
                if is_file_save_local:
                    flash_local_file_name_kess3 = path + '/' + filename
                    logger.info(flash_local_file_name_kess3)
                    is_success, url = upload_file_s3(flash_local_file_name_kess3, dir_name_to_create,
                                                     filename, file_request_obj)
                    create_download_file_object(
                        file_request_obj, url,
                        "Flash")

            is_matching_found_with_map_kess3 = False
            is_matching_found_with_flash_kess3 = False
            is_matching_found_with_micro_kess3 = False

            if is_map_file_kess3:
                with open(map_local_file_name_kess3, 'rb') as f:
                    decoded_file_hexa_dump = binascii.hexlify(f.read()).decode()

                logger.info("Find matching with map decoded file.")
                save_flow(
                    file_request_obj=file_request_obj,
                    title="Find matching.",
                    description="Find matching with Map decoded file.",
                    is_success=True
                )
                decoded_file_hexa_dump_list = convert_to_n_size_block(decoded_file_hexa_dump, 8)
                decode_id = str(instance.ids)
                directories_to_search = search_based_on_form_data(file_request_obj, data, decode_id)
                if directories_to_search != 0:
                    files_for_algorithm = get_s3_original_files(directories_to_search)
                    try:
                        matching_original_data = get_matching_ratio_df(
                            files_for_algorithm, file_request_obj,
                            decoded_file_hexa_dump_list)

                        if len(matching_original_data) != 0:
                            is_matching_found_with_map_kess3 = True
                            save_flow(
                                file_request_obj=file_request_obj,
                                title="Found matching.",
                                description="Found matching with map decoded file.",
                                is_success=True
                            )
                        else:
                            is_matching_found_with_map_kess3 = False

                    except Exception as error:
                        is_matching_found_with_map_kess3 = False
                        print("get matching ratio error", error)
                        logger.error("get matching ratio error:{}".format(error))

            if not is_map_file_kess3 and is_flash_file_kess3:
                with open(flash_local_file_name_kess3, 'rb') as f:
                    decoded_file_hexa_dump = binascii.hexlify(f.read()).decode()

                logger.info("Find matching with Flash decoded file.")
                save_flow(
                    file_request_obj=file_request_obj,
                    title="Find matching.",
                    description="Find matching with flash decoded file.",
                    is_success=True
                )
                decoded_file_hexa_dump_list = convert_to_n_size_block(decoded_file_hexa_dump, 8)
                decode_id = str(instance.ids)
                directories_to_search = search_based_on_form_data(file_request_obj, data, decode_id)
                if directories_to_search != 0:
                    files_for_algorithm = get_s3_original_files(directories_to_search)
                    try:
                        matching_original_data = get_matching_ratio_df(
                            files_for_algorithm, file_request_obj,
                            decoded_file_hexa_dump_list)

                        if len(matching_original_data) != 0:
                            is_matching_found_with_flash_kess3 = True
                            save_flow(
                                file_request_obj=file_request_obj,
                                title="Found matching.",
                                description="Found matching with flash decoded file.",
                                is_success=True
                            )
                        else:
                            is_matching_found_with_flash_kess3 = False

                    except Exception as error:
                        is_matching_found_with_flash_kess3 = False
                        print("get matching ratio error", error)
                        logger.error("get matching ratio error:{}".format(error))

            if (not is_map_file_kess3
                    and is_micro_file_kess3
                    and not is_matching_found_with_flash_kess3):
                with open(micro_local_file_name_kess3, 'rb') as f:
                    decoded_file_hexa_dump = binascii.hexlify(f.read()).decode()

                logger.info("Find matching with Micro decoded file.")
                save_flow(
                    file_request_obj=file_request_obj,
                    title="Find matching.",
                    description="Find matching with Micro decoded file.",
                    is_success=True
                )
                decoded_file_hexa_dump_list = convert_to_n_size_block(decoded_file_hexa_dump, 8)
                decode_id = str(instance.ids)
                directories_to_search = search_based_on_form_data(file_request_obj, data, decode_id)
                if directories_to_search != 0:
                    files_for_algorithm = get_s3_original_files(directories_to_search)
                    try:
                        matching_original_data = get_matching_ratio_df(
                            files_for_algorithm, file_request_obj,
                            decoded_file_hexa_dump_list)

                        if len(matching_original_data) != 0:
                            is_matching_found_with_micro_kess3 = True
                            save_flow(
                                file_request_obj=file_request_obj,
                                title="Found matching.",
                                description="Found matching with Micro decoded file.",
                                is_success=True
                            )
                        else:
                            is_matching_found_with_micro_kess3 = False

                    except Exception as error:
                        is_matching_found_with_micro_kess3 = False
                        print("get matching ratio error", error)
                        logger.error("get matching ratio error:{}".format(error))

            if is_map_file_kess3 and not is_matching_found_with_map_kess3:
                logger.info("Matching not found with map file sent for manual handle kess3.")
                description = salve_stage.SLAVE_FILE_STAGE_MANUAL_1
                sent_for_manual_handling(file_request_obj, description)
                close_file_slot(instance, file_request_obj)
                is_file_match_success = False
                # return is_file_match_success
                return is_file_match_success, matching_found_in_path, random_generated_path

            if (not is_matching_found_with_flash_kess3 and
                    not is_matching_found_with_micro_kess3 and
                    not is_matching_found_with_map_kess3):
                logger.info("Matching not found with any file sent for manual handle kess3.")
                description = salve_stage.SLAVE_FILE_STAGE_MANUAL_1
                sent_for_manual_handling(file_request_obj, description)
                close_file_slot(instance, file_request_obj)
                is_file_match_success = False
                # return is_file_match_success
                return is_file_match_success, matching_found_in_path, random_generated_path

            # ================================ Map Found ==================================
            if is_matching_found_with_map_kess3:
                logger.info("salve fun")
                logger.info("In matching found with Map kess3.")

                version_files_list = get_version_files_from_dir(
                    matching_original_data['matching_directory'],
                    file_request_obj
                )
                logger.info("version list found.")

                # Match version files list.
                if len(version_files_list) > 0:
                    version_data = match_version_files(matching_original_data, version_files_list,
                                                       file_request_obj)
                else:
                    version_data = []
                if len(version_data) == 0:
                    logger.info("Map no data")
                    description = salve_stage.SLAVE_FILE_STAGE_MANUAL_2
                    sent_for_manual_handling(file_request_obj, description)
                    close_file_slot(instance, file_request_obj)
                    is_file_match_success = False
                    return is_file_match_success
                else:
                    logger.info("Map Matching data")
                    version_file_hexa_list = version_data['version_file_hexa_list']
                    original_file_hexa_list = matching_original_data['matching_original_file_hexa_list']
                    # decoded file hexadump.
                    similar_original_file_hexadump_list = decoded_file_hexa_dump_list

                    updated_similar_hexa_bytes = add_diff_to_similar_original_index_bytes(
                        version_file_hexa_list, original_file_hexa_list,
                        similar_original_file_hexadump_list, file_request_obj)

                    dir_name_to_create = create_directory_name(version_data)

                    random_generated_path = dir_name_to_create
                    matching_found_in_path = version_data['version_matching_directory']

                    if file_request_obj.file_type == "Client/Slave":
                        file_name_to_create = "modified_(VPERF)_" + dir_name_to_create.split("/")[-1]
                        title = "Modified VPERF File"

                    local_file_name = create_file_at_local(file_name_to_create, updated_similar_hexa_bytes,
                                                           file_request_obj)
                    is_sucess, url = upload_file_s3(local_file_name, dir_name_to_create,
                                                    file_name_to_create, file_request_obj)

                    if is_sucess:
                        RequestDownloadFiles.objects.create(
                            fil_request_id=file_request_obj,
                            title=title,
                            url=url
                        )

                    evc_instance = EVCCredentials.objects.all().last()

                    title = "Upload modified file"
                    decode_instance = DecodeFiles.objects.get(ids=instance.ids)
                    modified_file = read_modified_file(file_name_to_create, file_request_obj)
                    tool_used = get_tool_type_int(tool_used)

                    logger.info("Step 19: Upload modified original file.:{}.".format(tool_used))
                    is_sucess, response = FileOperation().kessv3_upload_modified_file(
                        evc_instance.alientechauttoken,
                        modified_file,
                        decode_instance.slot_guid,
                        "BootBenchModifiedMapFile"
                    )
                    logger.info("upload modified response.")
                    logger.info(response)

                    if is_success:
                        is_upload_modified_success = True
                        save_flow(
                            file_request_obj=file_request_obj,
                            title="Modify file upload.",
                            description="Mapfile Modified File successfully uploaded to alientech.",
                            is_success=True,
                        )
                        map_modified_instance = EncodeFiles.objects.create(
                            user=file_request_obj.user,
                            decode=decode_instance,
                            guid=response['guid'] if 'guid' in response else 'N/A',
                            encode_response=response,
                            file_type="BootBenchModifiedMapFile"
                        )
                        map_modified_instance.update_ids()
                        # after uploda mdified encode the file.
                        is_sucess, response = FileOperation().encode_kess3_boot_bench_file(
                            evc_instance.alientechauttoken,
                            kess3FileSlotGUID=decode_instance.slot_guid,
                            microFileGUID='',
                            flashFileGUID='',
                            eepromFileGUID='',
                            mapFileFileGUID=map_modified_instance.guid,
                        )
                        is_sent_for_encode = True if is_sucess else False

                        logger.info("encode response")
                        logger.info(response)
                    else:
                        logger.error(async_resp["error"])
                        description = "Upload modified failed with error:{}".format(async_resp['error'])
                        sent_for_manual_handling(file_request_obj, description)
                        close_file_slot(instance, file_request_obj)
                        is_file_match_success = False
                        return is_file_match_success

                    if is_sucess and is_upload_modified_success and is_sent_for_encode:
                        logger.info("Step 19: File sent for encode successfully.")
                        save_flow(
                            file_request_obj=file_request_obj,
                            title="File sent for encode successfully.",
                            description="File sent for encode successfully.",
                            is_success=True,
                        )
                        encode_ins = EncodeFiles.objects.create(
                            user=map_modified_instance.user,
                            parent=map_modified_instance,
                            decode=decode_instance,
                            ids=map_modified_instance.ids,
                            guid=response['guid'] if 'guid' in response else 'N/A',
                            encode_response=response,
                            file_type='Encode'
                        )
                        logger.info(encode_ins.ids)
                        async_resp = get_async_encode_status(encode_ins)

                        save_flow(
                            file_request_obj=file_request_obj,
                            title="Kess3 Encode result successfull.",
                            description="Successfully encoded..",
                            is_success=True,
                        )
                        encoded_file_url = async_resp['result']['encodedFileURL']
                        if "encodingapi.alientech.to" in encoded_file_url:
                            try:
                                additional_function = file_request_obj.additional_function
                                if additional_function is not None:
                                    additional_function = additional_function.split(",")
                                    additional_function = list(
                                        map(lambda function_name: function_name.upper().strip(), additional_function))
                                else:
                                    additional_function = []
                                tuning_required = file_request_obj.tuning_required
                                search_terms = ''
                                if tuning_required == "VBLUE/ECO":
                                    search_terms = "ECONOMY"
                                elif tuning_required == "VBLEND/STAGE 0.5":
                                    search_terms = "BLEND"
                                elif tuning_required == "VPERF/STAGE 1":
                                    search_terms = "PERFORMANCE"
                                elif tuning_required == "VRACE/STAGE 2":
                                    search_terms = "vrace"
                                elif tuning_required == "NO TUNE":
                                    search_terms = ''
                                uploaded_file_name = uploaded_file_name.upper()
                                filename = uploaded_file_name + ' ' + search_terms
                                if additional_function:
                                    filename += ' ' + ' '.join(additional_function)
                                title = uploaded_file_name + ' ' + search_terms
                            except Exception as error:
                                path = "media/" + str(file_request_obj.request_id)
                                filename = "encoded_" + file_request_obj.tuning_file.url.split("/")[-1]
                            is_file_save_local = save_encode_file(path, encoded_file_url, file_request_obj)
                            logger.info("In kess3 map save file.")
                            if is_file_save_local:
                                local_file_name = path + '/' + filename
                                dir_name_to_create = file_request_obj.request_id
                                is_success, url = upload_file_s3(local_file_name, dir_name_to_create,
                                                                 filename, file_request_obj)
                                logger.info("Save file in model for {}.".format(title))
                                RequestDownloadFiles.objects.create(
                                    fil_request_id=file_request_obj,
                                    title=title,
                                    url=url,
                                    sent_to_user=True
                                )
                                is_file_match_success = True
                                close_file_slot(instance, file_request_obj)
                                file_request_obj.status = "CLOSED"
                                file_request_obj.save()
                                logger.info("file_request_obj status %s", file_request_obj.status)
                                Directory.objects.create(
                                    directory_path="Main/" + random_generated_path.split("/")[-1],
                                    ecu_producer=file_request_obj.ecu_brand,
                                    ecu_build=file_request_obj.ecu_version,
                                    created_by_filemaker=True,
                                    vehicle_type=file_request_obj.vehicle_type,
                                    vehicle_producer=file_request_obj.vehicle_make,
                                    vehicle_model=file_request_obj.model,
                                    vehicle_model_year=file_request_obj.vehicle_year,
                                    file_request=file_request_obj
                                )
                                upload_file_to_mongo(local_file_name, dir_name_to_create)
                                title = "File is presented to the user."
                                description = "File is present to the user to download with name {0}:".format(
                                    random_generated_path + '/' + filename)
                                save_flow(file_request_obj, title, description, True)
                                return is_file_match_success, matching_found_in_path, random_generated_path
                        else:
                            print("in maual handle.")
                            description = response
                            sent_for_manual_handling(file_request_obj, description)
                            close_file_slot(instance, file_request_obj)
                            is_file_match_success = False
                            return is_file_match_success, matching_found_in_path, random_generated_path
                    else:
                        print("in maual handle.")
                        description = response
                        sent_for_manual_handling(file_request_obj, description)
                        close_file_slot(instance, file_request_obj)
                        is_file_match_success = False
                        return is_file_match_success, matching_found_in_path, random_generated_path
            # ================================ Map Found End ==================================

            # ================================ Flash Found ==================================
            if not is_map_file_kess3 and is_matching_found_with_flash_kess3:
                logger.info("salve fun")
                logger.info("In matching found with Flase kess3.")

                version_files_list = get_version_files_from_dir(
                    matching_original_data['matching_directory'],
                    file_request_obj
                )
                logger.info("version list found.")

                # Match version files list.
                if len(version_files_list) > 0:
                    version_data = match_version_files(matching_original_data, version_files_list,
                                                       file_request_obj)
                else:
                    version_data = []
                if len(version_data) == 0:
                    logger.info("Flash no data")
                    description = salve_stage.SLAVE_FILE_STAGE_MANUAL_2
                    sent_for_manual_handling(file_request_obj, description)
                    close_file_slot(instance, file_request_obj)
                    is_file_match_success = False
                    return is_file_match_success
                else:
                    logger.info("Flash Matching data")
                    version_file_hexa_list = version_data['version_file_hexa_list']
                    original_file_hexa_list = matching_original_data['matching_original_file_hexa_list']
                    # decoded file hexadump.
                    similar_original_file_hexadump_list = decoded_file_hexa_dump_list

                    updated_similar_hexa_bytes = add_diff_to_similar_original_index_bytes(
                        version_file_hexa_list, original_file_hexa_list,
                        similar_original_file_hexadump_list, file_request_obj)

                    dir_name_to_create = create_directory_name(version_data)

                    random_generated_path = dir_name_to_create
                    matching_found_in_path = version_data['version_matching_directory']

                    if file_request_obj.file_type == "Client/Slave":
                        file_name_to_create = "modified_(VPERF)_" + dir_name_to_create.split("/")[-1]
                        title = "Modified VPERF File"

                    local_file_name = create_file_at_local(file_name_to_create, updated_similar_hexa_bytes,
                                                           file_request_obj)
                    is_sucess, url = upload_file_s3(local_file_name, dir_name_to_create,
                                                    file_name_to_create, file_request_obj)

                    if is_sucess:
                        RequestDownloadFiles.objects.create(
                            fil_request_id=file_request_obj,
                            title=title,
                            url=url
                        )

                    evc_instance = EVCCredentials.objects.all().last()
                    title = "Upload modified file"
                    decode_instance = DecodeFiles.objects.get(ids=instance.ids)
                    modified_file = read_modified_file(file_name_to_create, file_request_obj)
                    tool_used = get_tool_type_int(tool_used)

                    logger.info("Step 19: Upload modified original file.:{}.".format(tool_used))
                    is_sucess, response = FileOperation().kessv3_upload_modified_file(
                        evc_instance.alientechauttoken,
                        modified_file,
                        decode_instance.slot_guid,
                        "BootBenchModifiedFlash"
                    )
                    logger.info("upload modified response.")
                    logger.info(response)

                    if is_success:
                        is_upload_modified_success = True
                        save_flow(
                            file_request_obj=file_request_obj,
                            title="Modify file upload.",
                            description="Flash Modified File successfully uploaded to alientech.",
                            is_success=True,
                        )
                        flash_modified_instance = EncodeFiles.objects.create(
                            user=file_request_obj.user,
                            decode=decode_instance,
                            guid=response['guid'] if 'guid' in response else 'N/A',
                            encode_response=response,
                            file_type="BootBenchModifiedFlash"
                        )
                        flash_modified_instance.update_ids()
                        # after uploda mdified encode the file.
                        is_sucess, response = FileOperation().encode_kess3_boot_bench_file(
                            evc_instance.alientechauttoken,
                            kess3FileSlotGUID=decode_instance.slot_guid,
                            microFileGUID='',
                            flashFileGUID=flash_modified_instance.guid,
                            eepromFileGUID='',
                            mapFileFileGUID='',
                        )
                        is_sent_for_encode = True if is_sucess else False

                        logger.info("encode response")
                        logger.info(response)
                    else:
                        logger.error(async_resp["error"])
                        description = "Upload modified failed with error:{}".format(async_resp['error'])
                        sent_for_manual_handling(file_request_obj, description)
                        close_file_slot(instance, file_request_obj)
                        is_file_match_success = False
                        return is_file_match_success

                    if is_sucess and is_upload_modified_success and is_sent_for_encode:
                        logger.info("Step 19: File sent for encode successfully.")
                        save_flow(
                            file_request_obj=file_request_obj,
                            title="File sent for encode successfully.",
                            description="File sent for encode successfully.",
                            is_success=True,
                        )
                        encode_ins = EncodeFiles.objects.create(
                            user=flash_modified_instance.user,
                            parent=flash_modified_instance,
                            decode=decode_instance,
                            ids=flash_modified_instance.ids,
                            guid=response['guid'] if 'guid' in response else 'N/A',
                            encode_response=response,
                            file_type='Encode'
                        )
                        logger.info(encode_ins.ids)
                        async_resp = get_async_encode_status(encode_ins)

                        save_flow(
                            file_request_obj=file_request_obj,
                            title="Kess3 Encode result successfull.",
                            description="Successfully encoded..",
                            is_success=True,
                        )
                        encoded_file_url = async_resp['result']['encodedFileURL']
                        if "encodingapi.alientech.to" in encoded_file_url:
                            try:
                                additional_function = file_request_obj.additional_function
                                if additional_function is not None:
                                    additional_function = additional_function.split(",")
                                    additional_function = list(
                                        map(lambda function_name: function_name.upper().strip(), additional_function))
                                else:
                                    additional_function = []
                                tuning_required = file_request_obj.tuning_required
                                search_terms = ''
                                if tuning_required == "VBLUE/ECO":
                                    search_terms = "ECONOMY"
                                elif tuning_required == "VBLEND/STAGE 0.5":
                                    search_terms = "BLEND"
                                elif tuning_required == "VPERF/STAGE 1":
                                    search_terms = "PERFORMANCE"
                                elif tuning_required == "VRACE/STAGE 2":
                                    search_terms = "vrace"
                                elif tuning_required == "NO TUNE":
                                    search_terms = ''
                                uploaded_file_name = uploaded_file_name.upper()
                                filename = uploaded_file_name + ' ' + search_terms
                                if additional_function:
                                    filename += ' ' + ' '.join(additional_function)
                                title = uploaded_file_name + ' ' + search_terms
                            except Exception as error:
                                path = "media/" + str(file_request_obj.request_id)
                                filename = "encoded_" + file_request_obj.tuning_file.url.split("/")[-1]
                            is_file_save_local = save_encode_file(path, encoded_file_url, file_request_obj)
                            logger.info("In kess3 flash save file.")
                            if is_file_save_local:
                                local_file_name = path + '/' + filename
                                dir_name_to_create = file_request_obj.request_id
                                is_success, url = upload_file_s3(local_file_name, dir_name_to_create,
                                                                 filename, file_request_obj)
                                logger.info("Save file in model for {}.".format(title))
                                RequestDownloadFiles.objects.create(
                                    fil_request_id=file_request_obj,
                                    title=title,
                                    url=url,
                                    sent_to_user=True
                                )
                                is_file_match_success = True
                                close_file_slot(instance, file_request_obj)
                                file_request_obj.status = "CLOSED"
                                file_request_obj.save()
                                logger.info("file_request_obj status %s", file_request_obj.status)
                                Directory.objects.create(
                                    directory_path="Main/" + random_generated_path.split("/")[-1],
                                    ecu_producer=file_request_obj.ecu_brand,
                                    ecu_build=file_request_obj.ecu_version,
                                    created_by_filemaker=True,
                                    vehicle_type=file_request_obj.vehicle_type,
                                    vehicle_producer=file_request_obj.vehicle_make,
                                    vehicle_model=file_request_obj.model,
                                    vehicle_model_year=file_request_obj.vehicle_year,
                                    file_request=file_request_obj
                                )
                                upload_file_to_mongo(local_file_name, dir_name_to_create)
                                title = "File is presented to the user."
                                description = "File is present to the user to download with name {0}:".format(
                                    random_generated_path + '/' + filename)
                                save_flow(file_request_obj, title, description, True)
                                return is_file_match_success, matching_found_in_path, random_generated_path
                        else:
                            print("in maual handle.")
                            description = response
                            sent_for_manual_handling(file_request_obj, description)
                            close_file_slot(instance, file_request_obj)
                            is_file_match_success = False
                            return is_file_match_success, matching_found_in_path, random_generated_path
                    else:
                        print("in maual handle.")
                        description = response
                        sent_for_manual_handling(file_request_obj, description)
                        close_file_slot(instance, file_request_obj)
                        is_file_match_success = False
                        return is_file_match_success, matching_found_in_path, random_generated_path
            # ================================ Flash Found End ==================================

            # ================================ Micro Found ==================================
            if (not is_map_file_kess3 and
                    not is_matching_found_with_flash_kess3 and
                    is_matching_found_with_micro_kess3):
                logger.info("In matching found with micro Kess3.")

                version_files_list = get_version_files_from_dir(
                    matching_original_data['matching_directory'],
                    file_request_obj
                )
                logger.info("version list found.")

                # Match version files list.
                if len(version_files_list) > 0:
                    version_data = match_version_files(matching_original_data, version_files_list,
                                                       file_request_obj)
                else:
                    version_data = []

                if len(version_data) == 0:
                    logger.info("Micro no data")
                    description = salve_stage.SLAVE_FILE_STAGE_MANUAL_2
                    sent_for_manual_handling(file_request_obj, description)
                    close_file_slot(instance, file_request_obj)
                    is_file_match_success = False
                    return is_file_match_success
                else:
                    logger.info("Micro Matching data")
                    version_file_hexa_list = version_data['version_file_hexa_list']
                    original_file_hexa_list = matching_original_data['matching_original_file_hexa_list']
                    # decoded file hexadump.
                    similar_original_file_hexadump_list = decoded_file_hexa_dump_list

                    updated_similar_hexa_bytes = add_diff_to_similar_original_index_bytes(
                        version_file_hexa_list, original_file_hexa_list,
                        similar_original_file_hexadump_list, file_request_obj)

                    dir_name_to_create = create_directory_name(version_data)

                    random_generated_path = dir_name_to_create
                    matching_found_in_path = version_data['version_matching_directory']

                    if file_request_obj.file_type == "Client/Slave":
                        file_name_to_create = "modified_(VPERF)_" + dir_name_to_create.split("/")[-1]
                        title = "Modified VPERF File"

                    local_file_name = create_file_at_local(file_name_to_create, updated_similar_hexa_bytes,
                                                           file_request_obj)
                    is_sucess, url = upload_file_s3(local_file_name, dir_name_to_create,
                                                    file_name_to_create, file_request_obj)

                    if is_sucess:
                        RequestDownloadFiles.objects.create(
                            fil_request_id=file_request_obj,
                            title=title,
                            url=url
                        )

                    evc_instance = EVCCredentials.objects.all().last()
                    # no need to add above two lines.

                    title = "Upload modified file"
                    decode_instance = DecodeFiles.objects.get(ids=instance.ids)
                    modified_file = read_modified_file(file_name_to_create, file_request_obj)
                    tool_used = get_tool_type_int(tool_used)

                    logger.info("Step 19: Upload modified original file.:{}.".format(tool_used))
                    is_sucess, response = FileOperation().kessv3_upload_modified_file(
                        evc_instance.alientechauttoken,
                        modified_file,
                        decode_instance.slot_guid,
                        "BootBenchModifiedMicro"
                    )
                    logger.info("upload modified response.")
                    logger.info(response)

                    if is_success:
                        is_upload_modified_success = True
                        save_flow(
                            file_request_obj=file_request_obj,
                            title="Modify file upload.",
                            description="Micro Modified File successfully uploaded to alientech.",
                            is_success=True,
                        )
                        micro_modified_instance = EncodeFiles.objects.create(
                            user=file_request_obj.user,
                            decode=decode_instance,
                            guid=response['guid'] if 'guid' in response else 'N/A',
                            encode_response=response,
                            file_type="BootBenchModifiedMicro"
                        )
                        micro_modified_instance.update_ids()
                        # after uploda mdified encode the file.
                        is_sucess, response = FileOperation().encode_kess3_boot_bench_file(
                            evc_instance.alientechauttoken,
                            kess3FileSlotGUID=decode_instance.slot_guid,
                            microFileGUID=micro_modified_instance.guid,
                            flashFileGUID='',
                            eepromFileGUID='',
                            mapFileFileGUID='',
                        )
                        is_sent_for_encode = True if is_sucess else False

                        logger.info("encode response")
                        logger.info(response)
                    else:
                        logger.error(async_resp["error"])
                        description = "Upload modified failed with error:{}".format(async_resp['error'])
                        sent_for_manual_handling(file_request_obj, description)
                        close_file_slot(instance, file_request_obj)
                        is_file_match_success = False
                        return is_file_match_success

                    if is_sucess and is_upload_modified_success and is_sent_for_encode:
                        logger.info("Step 19: File sent for encode successfully.")
                        save_flow(
                            file_request_obj=file_request_obj,
                            title="File sent for encode successfully.",
                            description="File sent for encode successfully.",
                            is_success=True,
                        )
                        encode_ins = EncodeFiles.objects.create(
                            user=micro_modified_instance.user,
                            parent=micro_modified_instance,
                            decode=decode_instance,
                            ids=micro_modified_instance.ids,
                            guid=response['guid'] if 'guid' in response else 'N/A',
                            encode_response=response,
                            file_type='Encode'
                        )
                        logger.info(encode_ins.ids)
                        async_resp = get_async_encode_status(encode_ins)

                        save_flow(
                            file_request_obj=file_request_obj,
                            title="Kess3 Encode result successfull.",
                            description="Successfully encoded..",
                            is_success=True,
                        )
                        encoded_file_url = async_resp['result']['encodedFileURL']
                        if "encodingapi.alientech.to" in encoded_file_url:
                            try:
                                additional_function = file_request_obj.additional_function
                                if additional_function is not None:
                                    additional_function = additional_function.split(",")
                                    additional_function = list(
                                        map(lambda function_name: function_name.upper().strip(), additional_function))
                                else:
                                    additional_function = []
                                tuning_required = file_request_obj.tuning_required
                                search_terms = ''
                                if tuning_required == "VBLUE/ECO":
                                    search_terms = "ECONOMY"
                                elif tuning_required == "VBLEND/STAGE 0.5":
                                    search_terms = "BLEND"
                                elif tuning_required == "VPERF/STAGE 1":
                                    search_terms = "PERFORMANCE"
                                elif tuning_required == "VRACE/STAGE 2":
                                    search_terms = "vrace"
                                elif tuning_required == "NO TUNE":
                                    search_terms = ''
                                uploaded_file_name = uploaded_file_name.upper()
                                filename = uploaded_file_name + ' ' + search_terms
                                if additional_function:
                                    filename += ' ' + ' '.join(additional_function)
                                title = uploaded_file_name + ' ' + search_terms
                            except Exception as error:
                                path = "media/" + str(file_request_obj.request_id)
                                filename = "encoded_" + file_request_obj.tuning_file.url.split("/")[-1]
                            is_file_save_local = save_encode_file(path, encoded_file_url, file_request_obj)
                            logger.info("In kess3 micro save file.")
                            if is_file_save_local:
                                local_file_name = path + '/' + filename
                                dir_name_to_create = file_request_obj.request_id
                                is_success, url = upload_file_s3(local_file_name, dir_name_to_create,
                                                                 filename, file_request_obj)
                                logger.info("Save file in model for {}.".format(title))
                                request_instance = RequestDownloadFiles.objects.create(
                                    fil_request_id=file_request_obj,
                                    title=title,
                                    url=url,
                                    sent_to_user=True
                                )
                                is_file_match_success = True
                                close_file_slot(instance, file_request_obj)
                                file_request_obj.status = "CLOSED"
                                file_request_obj.save()
                                logger.info("file_request_obj status %s", file_request_obj.status)
                                Directory.objects.create(
                                    directory_path="Main/" + random_generated_path.split("/")[-1],
                                    ecu_producer=file_request_obj.ecu_brand,
                                    ecu_build=file_request_obj.ecu_version,
                                    created_by_filemaker=True,
                                    vehicle_type=file_request_obj.vehicle_type,
                                    vehicle_producer=file_request_obj.vehicle_make,
                                    vehicle_model=file_request_obj.model,
                                    vehicle_model_year=file_request_obj.vehicle_year,
                                    file_request=file_request_obj
                                )
                                upload_file_to_mongo(local_file_name, dir_name_to_create)
                                title = "File is presented to the user."
                                description = "File is present to the user to download with name {0}:".format(
                                    random_generated_path + '/' + filename)
                                save_flow(file_request_obj, title, description, True)
                                return is_file_match_success, matching_found_in_path, random_generated_path
                        else:
                            print("in maual handle.")
                            description = response
                            sent_for_manual_handling(file_request_obj, description)
                            close_file_slot(instance, file_request_obj)
                            is_file_match_success = False
                            return is_file_match_success, matching_found_in_path, random_generated_path
                    else:
                        print("in maual handle.")
                        description = response
                        sent_for_manual_handling(file_request_obj, description)
                        close_file_slot(instance, file_request_obj)
                        is_file_match_success = False
                        return is_file_match_success, matching_found_in_path, random_generated_path
            # ================================ Micro Found ==================================
    return is_file_match_success, matching_found_in_path, random_generated_path


def slave_ktag_file_flow(file_request_id):
    is_file_match_success = True
    __contant_decoded_file = "DECODED FILE"
    __contant_encoded_file = "ENCODED FILE"
    __constant_map_file = "map_"
    __constant_flash_file = "flash_"
    __constant_micro_file = "micro_"
    matching_found_in_path = ""
    random_generated_path = ""

    file_request_obj = FileRequest.objects.get(request_id=file_request_id)
    data = read_user_file_request(file_request_id)

    user_uploaded_file = read_decode_file(file_request_obj)
    tool_used = file_request_obj.tuning_tool_used

    is_success, response = decode_file_by_tool(tool_used, file_request_obj, user_uploaded_file)
    logger.info("Decode success:{}, decode response:{}".format(is_success, response))

    uploaded_file_name = file_request_obj.tuning_file.url.split("/")[-1]
    create_decode_encode_folder(file_request_obj)
    path = "media/" + str(file_request_obj.request_id)
    dir_name_to_create = str(file_request_obj.request_id)
    if is_success:
        logger.info("Step 3: Create decode file object.")
        tool_used_int = get_tool_type_int(tool_used)
        instance = DecodeFiles.objects.create(
            user=file_request_obj.user,
            tool_type=tool_used_int,
            file=user_uploaded_file,
            decode_response=response,
            guid=response['guid'],
            process_type=2
        )
        instance.update_ids()
        instance.save()
        logger.info(instance.ids)
    else:
        description = "Cannot decode file, got unsuccessfull response.{}".format(response['error'])
        sent_for_manual_handling(file_request_obj, description)
        is_file_match_success = False
        return is_file_match_success, matching_found_in_path, random_generated_path

    instance = DecodeFiles.objects.get(ids=instance.ids)
    is_decode_success = validate_decode_status(instance, file_request_obj)

    if not is_decode_success:
        is_file_match_success = False
        return is_file_match_success, matching_found_in_path, random_generated_path
    else:
        async_resp = get_async_decode_status(instance)
        if 'error' in async_resp and async_resp['error'] is not None:
            description = async_resp['error']['errorName']
            sent_for_manual_handling(file_request_obj, description)
            close_file_slot(instance, file_request_obj)
            is_file_match_success = False
            file_request_obj.status = 'Manual Handle'
            file_request_obj.save()
            return is_file_match_success, matching_found_in_path, random_generated_path

        logger.info("Step 5: Successfull async response.")

        logger.info("Decode file and saving at local: {}.".format(tool_used))
        components = async_resp['result']['components']

        is_map_file_ktag = any(d['type'] == 'MapFile' for d in components)
        is_micro_file_ktag = any(d['type'] == 'Micro' for d in components)
        is_flash_file_ktag = any(d['type'] == 'Flash' for d in components)

        logger.info("ktag mapfile:{}".format(is_map_file_ktag))
        logger.info("ktag is_micro_file:{}".format(is_micro_file_ktag))
        logger.info("ktag is_flash_file:{}".format(is_flash_file_ktag))

        if is_map_file_ktag:
            logger.info("Download Map file for ktag.")
            map_dict = list(filter(lambda x: x['type'] == 'MapFile', components))
            filename = __constant_map_file + "decoded_" + uploaded_file_name

            is_file_save_local = save_decode_file(path, map_dict['decodedFileURL'],
                                                  file_request_obj, 'mapfile_')
            if is_file_save_local:
                map_local_file_name_ktag = path + '/' + filename
                is_success, url = upload_file_s3(map_local_file_name_ktag, dir_name_to_create,
                                                 filename, file_request_obj)
                create_download_file_object(
                    file_request_obj, url,
                    __constant_map_file)

        if not is_map_file_ktag and is_micro_file_ktag:
            logger.info("Download Micro file for ktag.")
            micro_dict = list(filter(lambda x: x['type'] == 'Micro', components))[0]

            filename = __constant_micro_file + "decoded_" + uploaded_file_name

            is_file_save_local = save_decode_file(path, micro_dict['decodedFileURL'],
                                                  file_request_obj, 'micro_')
            if is_file_save_local:
                micro_local_file_name_ktag = path + '/' + filename
                logger.info(micro_local_file_name_ktag)
                is_success, url = upload_file_s3(micro_local_file_name_ktag, dir_name_to_create,
                                                 filename, file_request_obj)
                create_download_file_object(
                    file_request_obj, url,
                    "Micro")

        if not is_map_file_ktag and is_flash_file_ktag:
            logger.info("Download Flash file for ktag.")
            flash_dict = list(filter(lambda x: x['type'] == 'Flash', components))[0]
            filename = __constant_flash_file + "decoded_" + uploaded_file_name
            is_file_save_local = save_decode_file(path, flash_dict['decodedFileURL'],
                                                  file_request_obj, 'flash_')
            if is_file_save_local:
                flash_local_file_name_ktag = path + '/' + filename
                logger.info(flash_local_file_name_ktag)
                is_success, url = upload_file_s3(flash_local_file_name_ktag, dir_name_to_create,
                                                 filename, file_request_obj)
                create_download_file_object(file_request_obj, url, "Flash")

        is_matching_found_with_map_ktag = False
        is_matching_found_with_flash_ktag = False
        is_matching_found_with_micro_ktag = False

        if is_map_file_ktag:
            with open(map_local_file_name_ktag, 'rb') as f:
                decoded_file_hexa_dump = binascii.hexlify(f.read()).decode()

            logger.info("Find matching with map decoded file.")
            save_flow(
                file_request_obj=file_request_obj,
                title="Find matching.",
                description="Find matching with Map decoded file.",
                is_success=True
            )
            decoded_file_hexa_dump_list = convert_to_n_size_block(decoded_file_hexa_dump, 8)
            decode_id = str(instance.ids)
            directories_to_search = search_based_on_form_data(file_request_obj, data, decode_id)
            if directories_to_search != 0:
                files_for_algorithm = get_s3_original_files(directories_to_search)
                try:
                    matching_original_data = get_matching_ratio_df(
                        files_for_algorithm, file_request_obj,
                        decoded_file_hexa_dump_list)

                    if len(matching_original_data) != 0:
                        is_matching_found_with_map_ktag = True
                        save_flow(
                            file_request_obj=file_request_obj,
                            title="Found matching.",
                            description="Found matching with map decoded file.",
                            is_success=True
                        )
                    else:
                        is_matching_found_with_map_ktag = False

                except Exception as error:
                    is_matching_found_with_map_ktag = False
                    print("get matching ratio error", error)
                    logger.error("get matching ratio error:{}".format(error))

        if not is_map_file_ktag and is_flash_file_ktag:
            with open(flash_local_file_name_ktag, 'rb') as f:
                decoded_file_hexa_dump = binascii.hexlify(f.read()).decode()

            logger.info("Find matching with Flash decoded file.")
            save_flow(
                file_request_obj=file_request_obj,
                title="Find matching.",
                description="Find matching with flash decoded file.",
                is_success=True
            )
            decoded_file_hexa_dump_list = convert_to_n_size_block(decoded_file_hexa_dump, 8)
            decode_id = str(instance.ids)
            directories_to_search = search_based_on_form_data(file_request_obj, data, decode_id)
            if directories_to_search != 0:
                files_for_algorithm = get_s3_original_files(directories_to_search)
                try:
                    matching_original_data = get_matching_ratio_df(
                        files_for_algorithm, file_request_obj,
                        decoded_file_hexa_dump_list)

                    if len(matching_original_data) != 0:
                        is_matching_found_with_flash_ktag = True
                        save_flow(
                            file_request_obj=file_request_obj,
                            title="Found matching.",
                            description="Found matching with flash decoded file.",
                            is_success=True
                        )
                    else:
                        is_matching_found_with_flash_ktag = False

                except Exception as error:
                    is_matching_found_with_flash_ktag = False
                    print("get matching ratio error", error)
                    logger.error("get matching ratio error:{}".format(error))

        if (not is_map_file_ktag
                and is_micro_file_ktag
                and not is_matching_found_with_flash_ktag):
            with open(micro_local_file_name_ktag, 'rb') as f:
                decoded_file_hexa_dump = binascii.hexlify(f.read()).decode()

            logger.info("Find matching with Micro decoded file.")
            save_flow(
                file_request_obj=file_request_obj,
                title="Find matching.",
                description="Find matching with Micro decoded file.",
                is_success=True
            )
            decoded_file_hexa_dump_list = convert_to_n_size_block(decoded_file_hexa_dump, 8)
            decode_id = str(instance.ids)
            directories_to_search = search_based_on_form_data(file_request_obj, data, decode_id)
            if directories_to_search != 0:
                files_for_algorithm = get_s3_original_files(directories_to_search)
                try:
                    matching_original_data = get_matching_ratio_df(
                        files_for_algorithm, file_request_obj,
                        decoded_file_hexa_dump_list)

                    if len(matching_original_data) != 0:
                        is_matching_found_with_micro_ktag = True
                        save_flow(
                            file_request_obj=file_request_obj,
                            title="Found matching.",
                            description="Found matching with Micro decoded file.",
                            is_success=True
                        )
                    else:
                        is_matching_found_with_micro_ktag = False

                except Exception as error:
                    is_matching_found_with_micro_ktag = False
                    print("get matching ratio error", error)
                    logger.error("get matching ratio error:{}".format(error))

        if is_map_file_ktag and not is_matching_found_with_map_ktag:
            logger.info("Matching not found with map file sent for manual handle kess3.")
            description = salve_stage.SLAVE_FILE_STAGE_MANUAL_1
            sent_for_manual_handling(file_request_obj, description)
            close_file_slot(instance, file_request_obj)
            is_file_match_success = False
            return is_file_match_success, matching_found_in_path, random_generated_path

        if (not is_matching_found_with_flash_ktag and
                not is_matching_found_with_micro_ktag and
                not is_matching_found_with_map_ktag):
            logger.info("Matching not found with any file sent for manual handle kess3.")
            description = salve_stage.SLAVE_FILE_STAGE_MANUAL_1
            sent_for_manual_handling(file_request_obj, description)
            close_file_slot(instance, file_request_obj)
            is_file_match_success = False
            return is_file_match_success, matching_found_in_path, random_generated_path

        # ================================ Map Found ==================================
        if is_matching_found_with_map_ktag:
            logger.info("salve fun")
            logger.info("In matching found with Map kess3.")
            version_files_list = get_version_files_from_dir(
                matching_original_data['matching_directory'],
                file_request_obj
            )
            logger.info("version list found.")
            # Match version files list.
            if len(version_files_list) > 0:
                version_data = match_version_files(matching_original_data, version_files_list,
                                                   file_request_obj)
            else:
                version_data = []
            if len(version_data) == 0:
                logger.info("map no data")
                description = salve_stage.SLAVE_FILE_STAGE_MANUAL_2
                sent_for_manual_handling(file_request_obj, description)
                close_file_slot(instance, file_request_obj)
                is_file_match_success = False
                return is_file_match_success
            else:
                logger.info("map Matching data")
                version_file_hexa_list = version_data['version_file_hexa_list']
                original_file_hexa_list = matching_original_data['matching_original_file_hexa_list']
                # decoded file hexadump.
                similar_original_file_hexadump_list = decoded_file_hexa_dump_list

                updated_similar_hexa_bytes = add_diff_to_similar_original_index_bytes(
                    version_file_hexa_list, original_file_hexa_list,
                    similar_original_file_hexadump_list, file_request_obj)

                dir_name_to_create = create_directory_name(version_data)

                random_generated_path = dir_name_to_create
                matching_found_in_path = version_data['version_matching_directory']

                if file_request_obj.file_type == "Client/Slave":
                    file_name_to_create = "modified_(VPERF)_" + dir_name_to_create.split("/")[-1]
                    title = "Modified VPERF File"

                local_file_name = create_file_at_local(file_name_to_create, updated_similar_hexa_bytes,
                                                       file_request_obj)
                is_sucess, url = upload_file_s3(local_file_name, dir_name_to_create,
                                                file_name_to_create, file_request_obj)

                if is_sucess:
                    RequestDownloadFiles.objects.create(
                        fil_request_id=file_request_obj,
                        title=title,
                        url=url,
                        sent_to_user=True
                    )

                evc_instance = EVCCredentials.objects.all().last()
                # no need to add above two lines.

                title = "Upload modified file"
                decode_instance = DecodeFiles.objects.get(ids=instance.ids)
                modified_file = read_modified_file(file_name_to_create, file_request_obj)
                tool_used = get_tool_type_int(tool_used)

                logger.info("Step 19: Upload modified original file.:{}.".format(tool_used))
                is_sucess, response = FileOperation().kessv3_upload_modified_file(
                    evc_instance.alientechauttoken,
                    modified_file,
                    decode_instance.slot_guid,
                    "MapFile"
                )
                logger.info("upload modified response.")
                logger.info(response)

                if is_success:
                    is_upload_modified_success = True
                    save_flow(
                        file_request_obj=file_request_obj,
                        title="Modify file upload.",
                        description="MapFile Modified File successfully uploaded to alientech.",
                        is_success=True,
                    )
                    map_modified_instance = EncodeFiles.objects.create(
                        user=file_request_obj.user,
                        decode=decode_instance,
                        guid=response['guid'] if 'guid' in response else 'N/A',
                        encode_response=response,
                        file_type="MapFile"
                    )
                    map_modified_instance.update_ids()
                    # after uploda mdified encode the file.
                    is_sucess, response = FileOperation().ktag_encode_file(
                        evc_instance.alientechauttoken,
                        kTag2FileSlotGUID=decode_instance.slot_guid,
                        micro_file_guid='',
                        flash_guid='',
                        eeprom_guid='',
                        map_file_guid=map_modified_instance.guid,
                    )
                    is_sent_for_encode = True if is_sucess else False

                    logger.info("encode response")
                    logger.info(response)
                else:
                    logger.error(async_resp["error"])
                    description = "Upload modified failed with error:{}".format(async_resp['error'])
                    sent_for_manual_handling(file_request_obj, description)
                    close_file_slot(instance, file_request_obj)
                    is_file_match_success = False
                    return is_file_match_success, matching_found_in_path, random_generated_path

                if is_sucess and is_upload_modified_success and is_sent_for_encode:
                    logger.info("Step 19: File sent for encode successfully.")
                    save_flow(
                        file_request_obj=file_request_obj,
                        title="File sent for encode successfully.",
                        description="File sent for encode successfully.",
                        is_success=True,
                    )
                    encode_ins = EncodeFiles.objects.create(
                        user=map_modified_instance.user,
                        parent=map_modified_instance,
                        decode=decode_instance,
                        ids=map_modified_instance.ids,
                        guid=response['guid'] if 'guid' in response else 'N/A',
                        encode_response=response,
                        file_type='Encode'
                    )
                    logger.info(encode_ins.ids)
                    async_resp = get_async_encode_status(encode_ins)

                    save_flow(
                        file_request_obj=file_request_obj,
                        title="ktag Encode result successfull.",
                        description="Successfully encoded..",
                        is_success=True,
                    )
                    encoded_file_url = async_resp['result']
                    if "encodingapi.alientech.to" in encoded_file_url:
                        try:
                            additional_function = file_request_obj.additional_function
                            if additional_function is not None:
                                additional_function = additional_function.split(",")
                                additional_function = list(
                                    map(lambda function_name: function_name.upper().strip(), additional_function))
                            else:
                                additional_function = []
                            tuning_required = file_request_obj.tuning_required
                            search_terms = ''
                            if tuning_required == "VBLUE/ECO":
                                search_terms = "ECONOMY"
                            elif tuning_required == "VBLEND/STAGE 0.5":
                                search_terms = "BLEND"
                            elif tuning_required == "VPERF/STAGE 1":
                                search_terms = "PERFORMANCE"
                            elif tuning_required == "VRACE/STAGE 2":
                                search_terms = "vrace"
                            elif tuning_required == "NO TUNE":
                                search_terms = ''
                            uploaded_file_name = uploaded_file_name.upper()
                            filename = uploaded_file_name + ' ' + search_terms
                            if additional_function:
                                filename += ' ' + ' '.join(additional_function)
                            title = uploaded_file_name + ' ' + search_terms
                        except Exception as error:
                            path = "media/" + str(file_request_obj.request_id)
                            filename = "encoded_" + file_request_obj.tuning_file.url.split("/")[-1]
                        is_file_save_local = save_encode_file(path, encoded_file_url, file_request_obj)
                        logger.info("In ktag map save file.")
                        if is_file_save_local:
                            local_file_name = path + '/' + filename
                            dir_name_to_create = file_request_obj.request_id
                            is_success, url = upload_file_s3(local_file_name, dir_name_to_create,
                                                             filename, file_request_obj)
                            logger.info("Save file in model for {}.".format(title))
                            request_instance = RequestDownloadFiles.objects.create(
                                fil_request_id=file_request_obj,
                                title=title,
                                url=url,
                                sent_to_user=True
                            )
                            is_file_match_success = True
                            close_file_slot(instance, file_request_obj)
                            file_request_obj.status = "CLOSED"
                            file_request_obj.save()
                            logger.info("file_request_obj status %s", file_request_obj.status)
                            Directory.objects.create(
                                directory_path="Main/" + random_generated_path.split("/")[-1],
                                ecu_producer=file_request_obj.ecu_brand,
                                ecu_build=file_request_obj.ecu_version,
                                created_by_filemaker=True,
                                vehicle_type=file_request_obj.vehicle_type,
                                vehicle_producer=file_request_obj.vehicle_make,
                                vehicle_model=file_request_obj.model,
                                vehicle_model_year=file_request_obj.vehicle_year,
                                file_request=file_request_obj
                            )
                            upload_file_to_mongo(local_file_name, dir_name_to_create)
                            title = "File is presented to the user."
                            description = "File is present to the user to download with name {0}:".format(
                                random_generated_path + '/' + filename)
                            save_flow(file_request_obj, title, description, True)
                            return is_file_match_success, matching_found_in_path, random_generated_path
                    else:
                        print("in maual handle.")
                        description = response
                        sent_for_manual_handling(file_request_obj, description)
                        close_file_slot(instance, file_request_obj)
                        is_file_match_success = False
                        return is_file_match_success, matching_found_in_path, random_generated_path
                else:
                    print("in maual handle.")
                    description = response
                    sent_for_manual_handling(file_request_obj, description)
                    close_file_slot(instance, file_request_obj)
                    is_file_match_success = False
                    return is_file_match_success, matching_found_in_path, random_generated_path
        # ================================ Map Found END ==================================

        # ================================ Flash Found ==================================
        if not is_map_file_ktag and is_matching_found_with_flash_ktag:
            logger.info("salve fun")
            logger.info("In matching found with Flash kess3.")

            version_files_list = get_version_files_from_dir(
                matching_original_data['matching_directory'],
                file_request_obj
            )
            logger.info("version list found.")

            # Match version files list.
            if len(version_files_list) > 0:
                version_data = match_version_files(matching_original_data, version_files_list,
                                                   file_request_obj)
            else:
                version_data = []
            if len(version_data) == 0:
                logger.info("Flash no data")
                description = salve_stage.SLAVE_FILE_STAGE_MANUAL_2
                sent_for_manual_handling(file_request_obj, description)
                close_file_slot(instance, file_request_obj)
                is_file_match_success = False
                return is_file_match_success, matching_found_in_path, random_generated_path
            else:
                logger.info("Flash Matching data")
                version_file_hexa_list = version_data['version_file_hexa_list']
                original_file_hexa_list = matching_original_data['matching_original_file_hexa_list']
                # decoded file hexadump.
                similar_original_file_hexadump_list = decoded_file_hexa_dump_list

                updated_similar_hexa_bytes = add_diff_to_similar_original_index_bytes(
                    version_file_hexa_list, original_file_hexa_list,
                    similar_original_file_hexadump_list, file_request_obj)

                dir_name_to_create = create_directory_name(version_data)

                random_generated_path = dir_name_to_create
                matching_found_in_path = version_data['version_matching_directory']

                if file_request_obj.file_type == "Client/Slave":
                    file_name_to_create = "modified_(VPERF)_" + dir_name_to_create.split("/")[-1]
                    title = "Modified VPERF File"

                local_file_name = create_file_at_local(file_name_to_create, updated_similar_hexa_bytes,
                                                       file_request_obj)
                is_sucess, url = upload_file_s3(local_file_name, dir_name_to_create,
                                                file_name_to_create, file_request_obj)

                if is_sucess:
                    RequestDownloadFiles.objects.create(
                        fil_request_id=file_request_obj,
                        title=title,
                        url=url
                    )

                evc_instance = EVCCredentials.objects.all().last()
                # no need to add above two lines.

                title = "Upload modified file"
                decode_instance = DecodeFiles.objects.get(ids=instance.ids)
                modified_file = read_modified_file(file_name_to_create, file_request_obj)
                tool_used = get_tool_type_int(tool_used)

                logger.info("Step 19: Upload modified original file.:{}.".format(tool_used))
                is_sucess, response = FileOperation().kessv3_upload_modified_file(
                    evc_instance.alientechauttoken,
                    modified_file,
                    decode_instance.slot_guid,
                    "Flash"
                )
                logger.info("upload modified response.")
                logger.info(response)

                if is_success:
                    is_upload_modified_success = True
                    save_flow(
                        file_request_obj=file_request_obj,
                        title="Modify file upload.",
                        description="Micro Modified File successfully uploaded to alientech.",
                        is_success=True,
                    )
                    flash_modified_instance = EncodeFiles.objects.create(
                        user=file_request_obj.user,
                        decode=decode_instance,
                        guid=response['guid'] if 'guid' in response else 'N/A',
                        encode_response=response,
                        file_type="Micro"
                    )
                    flash_modified_instance.update_ids()
                    # after uploda mdified encode the file.
                    is_sucess, response = FileOperation().ktag_encode_file(
                        evc_instance.alientechauttoken,
                        kTag2FileSlotGUID=decode_instance.slot_guid,
                        micro_file_guid='',
                        flash_guid=flash_modified_instance.guid,
                        eeprom_guid='',
                        map_file_guid='',
                    )
                    is_sent_for_encode = True if is_sucess else False

                    logger.info("encode response")
                    logger.info(response)
                else:
                    logger.error(async_resp["error"])
                    description = "Upload modified failed with error:{}".format(async_resp['error'])
                    sent_for_manual_handling(file_request_obj, description)
                    close_file_slot(instance, file_request_obj)
                    is_file_match_success = False
                    return is_file_match_success, matching_found_in_path, random_generated_path

                if is_sucess and is_upload_modified_success and is_sent_for_encode:
                    logger.info("Step 19: File sent for encode successfully.")
                    save_flow(
                        file_request_obj=file_request_obj,
                        title="File sent for encode successfully.",
                        description="File sent for encode successfully.",
                        is_success=True,
                    )
                    encode_ins = EncodeFiles.objects.create(
                        user=flash_modified_instance.user,
                        parent=flash_modified_instance,
                        decode=decode_instance,
                        ids=flash_modified_instance.ids,
                        guid=response['guid'] if 'guid' in response else 'N/A',
                        encode_response=response,
                        file_type='Encode'
                    )
                    logger.info(encode_ins.ids)
                    async_resp = get_async_encode_status(encode_ins)

                    save_flow(
                        file_request_obj=file_request_obj,
                        title="ktag Encode result successfull.",
                        description="Successfully encoded..",
                        is_success=True,
                    )
                    encoded_file_url = async_resp['result']['encodedFileURL']
                    if "encodingapi.alientech.to" in encoded_file_url:
                        try:
                            additional_function = file_request_obj.additional_function
                            if additional_function is not None:
                                additional_function = additional_function.split(",")
                                additional_function = list(
                                    map(lambda function_name: function_name.upper().strip(), additional_function))
                            else:
                                additional_function = []
                            tuning_required = file_request_obj.tuning_required
                            search_terms = ''
                            if tuning_required == "VBLUE/ECO":
                                search_terms = "ECONOMY"
                            elif tuning_required == "VBLEND/STAGE 0.5":
                                search_terms = "BLEND"
                            elif tuning_required == "VPERF/STAGE 1":
                                search_terms = "PERFORMANCE"
                            elif tuning_required == "VRACE/STAGE 2":
                                search_terms = "vrace"
                            elif tuning_required == "NO TUNE":
                                search_terms = ''
                            uploaded_file_name = uploaded_file_name.upper()
                            filename = uploaded_file_name + ' ' + search_terms
                            if additional_function:
                                filename += ' ' + ' '.join(additional_function)
                            title = uploaded_file_name + ' ' + search_terms
                        except Exception as error:
                            path = "media/" + str(file_request_obj.request_id)
                            filename = "encoded_" + file_request_obj.tuning_file.url.split("/")[-1]
                        is_file_save_local = save_encode_file(path, encoded_file_url, file_request_obj)
                        logger.info("In ktag flash save file.")
                        if is_file_save_local:
                            local_file_name = path + '/' + filename
                            dir_name_to_create = file_request_obj.request_id
                            is_success, url = upload_file_s3(local_file_name, dir_name_to_create,
                                                             filename, file_request_obj)
                            logger.info("Save file in model for {}.".format(title))
                            RequestDownloadFiles.objects.create(
                                fil_request_id=file_request_obj,
                                title=title,
                                url=url,
                                sent_to_user=True
                            )
                            is_file_match_success = True
                            close_file_slot(instance, file_request_obj)
                            file_request_obj.status = "CLOSED"
                            file_request_obj.save()
                            logger.info("file_request_obj status %s", file_request_obj.status)
                            Directory.objects.create(
                                directory_path="Main/" + random_generated_path.split("/")[-1],
                                ecu_producer=file_request_obj.ecu_brand,
                                ecu_build=file_request_obj.ecu_version,
                                created_by_filemaker=True,
                                vehicle_type=file_request_obj.vehicle_type,
                                vehicle_producer=file_request_obj.vehicle_make,
                                vehicle_model=file_request_obj.model,
                                vehicle_model_year=file_request_obj.vehicle_year,
                                file_request=file_request_obj
                            )
                            upload_file_to_mongo(local_file_name, dir_name_to_create)
                            title = "File is presented to the user."
                            description = "File is present to the user to download with name {0}:".format(
                                random_generated_path + '/' + filename)
                            save_flow(file_request_obj, title, description, True)
                            return is_file_match_success, matching_found_in_path, random_generated_path
                    else:
                        print("in maual handle.")
                        description = response
                        sent_for_manual_handling(file_request_obj, description)
                        close_file_slot(instance, file_request_obj)
                        is_file_match_success = False
                        return is_file_match_success, matching_found_in_path, random_generated_path
                else:
                    print("in maual handle.")
                    description = response
                    sent_for_manual_handling(file_request_obj, description)
                    close_file_slot(instance, file_request_obj)
                    is_file_match_success = False
                    return is_file_match_success, matching_found_in_path, random_generated_path
        # ================================ Flash Found ==================================

        # ================================ Micro Found ==================================
        if (not is_map_file_ktag and
                not is_matching_found_with_flash_ktag and
                is_matching_found_with_micro_ktag):
            logger.info("In matching found with Micro Kess3.")

            version_files_list = get_version_files_from_dir(
                matching_original_data['matching_directory'],
                file_request_obj
            )
            logger.info("version list found.")

            # Match version files list.
            if len(version_files_list) > 0:
                version_data = match_version_files(matching_original_data, version_files_list,
                                                   file_request_obj)
            else:
                version_data = []

            if len(version_data) == 0:
                logger.info("Micro no data")
                description = salve_stage.SLAVE_FILE_STAGE_MANUAL_2
                sent_for_manual_handling(file_request_obj, description)
                close_file_slot(instance, file_request_obj)
                is_file_match_success = False
                return is_file_match_success, matching_found_in_path, random_generated_path
            else:
                logger.info("Micro Matching data")
                version_file_hexa_list = version_data['version_file_hexa_list']
                original_file_hexa_list = matching_original_data['matching_original_file_hexa_list']
                # decoded file hexadump.
                similar_original_file_hexadump_list = decoded_file_hexa_dump_list

                updated_similar_hexa_bytes = add_diff_to_similar_original_index_bytes(
                    version_file_hexa_list, original_file_hexa_list,
                    similar_original_file_hexadump_list, file_request_obj)

                dir_name_to_create = create_directory_name(version_data)

                random_generated_path = dir_name_to_create
                matching_found_in_path = version_data['version_matching_directory']

                if file_request_obj.file_type == "Client/Slave":
                    file_name_to_create = "modified_(VPERF)_" + dir_name_to_create.split("/")[-1]
                    title = "Modified VPERF File"

                local_file_name = create_file_at_local(file_name_to_create, updated_similar_hexa_bytes,
                                                       file_request_obj)
                is_sucess, url = upload_file_s3(local_file_name, dir_name_to_create,
                                                file_name_to_create, file_request_obj)

                if is_sucess:
                    RequestDownloadFiles.objects.create(
                        fil_request_id=file_request_obj,
                        title=title,
                        url=url
                    )

                evc_instance = EVCCredentials.objects.all().last()
                # no need to add above two lines.

                title = "Upload modified file"
                decode_instance = DecodeFiles.objects.get(ids=instance.ids)
                modified_file = read_modified_file(file_name_to_create, file_request_obj)
                tool_used = get_tool_type_int(tool_used)

                logger.info("Step 19: Upload modified original file.:{}.".format(tool_used))
                is_sucess, response = FileOperation().kessv3_upload_modified_file(
                    evc_instance.alientechauttoken,
                    modified_file,
                    decode_instance.slot_guid,
                    "Micro"
                )
                logger.info("upload modified response.")
                logger.info(response)

                if is_success:
                    is_upload_modified_success = True
                    save_flow(
                        file_request_obj=file_request_obj,
                        title="Modify file upload.",
                        description="Micro Modified File successfully uploaded to alientech.",
                        is_success=True,
                    )
                    micro_modified_instance = EncodeFiles.objects.create(
                        user=file_request_obj.user,
                        decode=decode_instance,
                        guid=response['guid'] if 'guid' in response else 'N/A',
                        encode_response=response,
                        file_type="Micro"
                    )
                    micro_modified_instance.update_ids()
                    # after uploda mdified encode the file.
                    is_sucess, response = FileOperation().ktag_encode_file(
                        evc_instance.alientechauttoken,
                        kTag2FileSlotGUID=decode_instance.slot_guid,
                        micro_file_guid=micro_modified_instance.guid,
                        flash_guid='',
                        eeprom_guid='',
                        map_file_guid='',
                    )
                    is_sent_for_encode = True if is_sucess else False

                    logger.info("encode response")
                    logger.info(response)
                else:
                    logger.error(async_resp["error"])
                    description = "Upload modified failed with error:{}".format(async_resp['error'])
                    sent_for_manual_handling(file_request_obj, description)
                    close_file_slot(instance, file_request_obj)
                    is_file_match_success = False
                    return is_file_match_success, matching_found_in_path, random_generated_path

                if is_sucess and is_upload_modified_success and is_sent_for_encode:
                    logger.info("Step 19: File sent for encode successfully.")
                    save_flow(
                        file_request_obj=file_request_obj,
                        title="File sent for encode successfully.",
                        description="File sent for encode successfully.",
                        is_success=True,
                    )
                    encode_ins = EncodeFiles.objects.create(
                        user=micro_modified_instance.user,
                        parent=micro_modified_instance,
                        decode=decode_instance,
                        ids=micro_modified_instance.ids,
                        guid=response['guid'] if 'guid' in response else 'N/A',
                        encode_response=response,
                        file_type='Encode'
                    )
                    logger.info(encode_ins.ids)
                    async_resp = get_async_encode_status(encode_ins)

                    save_flow(
                        file_request_obj=file_request_obj,
                        title="ktag Encode result successfull.",
                        description="Successfully encoded..",
                        is_success=True,
                    )
                    encoded_file_url = async_resp['result']['encodedFileURL']
                    if "encodingapi.alientech.to" in encoded_file_url:
                        try:
                            additional_function = file_request_obj.additional_function
                            if additional_function is not None:
                                additional_function = additional_function.split(",")
                                additional_function = list(
                                    map(lambda function_name: function_name.upper().strip(), additional_function))
                            else:
                                additional_function = []
                            tuning_required = file_request_obj.tuning_required
                            search_terms = ''
                            if tuning_required == "VBLUE/ECO":
                                search_terms = "ECONOMY"
                            elif tuning_required == "VBLEND/STAGE 0.5":
                                search_terms = "BLEND"
                            elif tuning_required == "VPERF/STAGE 1":
                                search_terms = "PERFORMANCE"
                            elif tuning_required == "VRACE/STAGE 2":
                                search_terms = "vrace"
                            elif tuning_required == "NO TUNE":
                                search_terms = ''
                            uploaded_file_name = uploaded_file_name.upper()
                            filename = uploaded_file_name + ' ' + search_terms
                            if additional_function:
                                filename += ' ' + ' '.join(additional_function)
                            title = uploaded_file_name + ' ' + search_terms
                        except Exception as error:
                            path = "media/" + str(file_request_obj.request_id)
                            filename = "encoded_" + file_request_obj.tuning_file.url.split("/")[-1]
                        is_file_save_local = save_encode_file(path, encoded_file_url, file_request_obj)
                        logger.info("In ktag micro save file.")
                        if is_file_save_local:
                            local_file_name = path + '/' + filename
                            dir_name_to_create = file_request_obj.request_id
                            is_success, url = upload_file_s3(local_file_name, dir_name_to_create,
                                                             filename, file_request_obj)
                            logger.info("Save file in model for {}.".format(title))
                            request_instance = RequestDownloadFiles.objects.create(
                                fil_request_id=file_request_obj,
                                title=title,
                                url=url,
                                sent_to_user=True
                            )
                            is_file_match_success = True
                            close_file_slot(instance, file_request_obj)
                            file_request_obj.status = "CLOSED"
                            file_request_obj.save()
                            logger.info("file_request_obj status %s", file_request_obj.status)
                            Directory.objects.create(
                                directory_path="Main/" + random_generated_path.split("/")[-1],
                                ecu_producer=file_request_obj.ecu_brand,
                                ecu_build=file_request_obj.ecu_version,
                                created_by_filemaker=True,
                                vehicle_type=file_request_obj.vehicle_type,
                                vehicle_producer=file_request_obj.vehicle_make,
                                vehicle_model=file_request_obj.model,
                                vehicle_model_year=file_request_obj.vehicle_year,
                                file_request=file_request_obj
                            )
                            upload_file_to_mongo(local_file_name, dir_name_to_create)
                            title = "File is presented to the user."
                            description = "File is present to the user to download with name {0}:".format(
                                random_generated_path + '/' + filename)
                            save_flow(file_request_obj, title, description, True)
                            return is_file_match_success, matching_found_in_path, random_generated_path
                    else:
                        print("in manual handle.")
                        description = response
                        sent_for_manual_handling(file_request_obj, description)
                        close_file_slot(instance, file_request_obj)
                        is_file_match_success = False
                        return is_file_match_success, matching_found_in_path, random_generated_path
                else:
                    print("in manual handle.")
                    description = response
                    sent_for_manual_handling(file_request_obj, description)
                    close_file_slot(instance, file_request_obj)
                    is_file_match_success = False
                    return is_file_match_success, matching_found_in_path, random_generated_path
            # ================================ Micro Found ==================================

        # ================================ Micro Found ==================================

    return is_file_match_success, matching_found_in_path, random_generated_path


def decode_file_by_tool(tool_used, file_request_obj, user_uploaded_file):
    title = "File sent for decoding."
    description = "File sent for decoding using: {} tool".format(tool_used)

    start_time = datetime.now()

    is_sucess, response = False, None
    evc_instance = EVCCredentials.objects.all().last()
    if tool_used == "KESS v2":
        logger.info("Step 2: Send file for decoding:{}.".format(tool_used))
        save_flow(file_request_obj, title, description, is_success=True)
        is_sucess, response = FileOperation().decode_kessV2_file(evc_instance.alientechauttoken, user_uploaded_file)
    elif tool_used == "KESS3":
        logger.info("Step 2: Send file for decoding:{}.".format(tool_used))
        save_flow(file_request_obj, title, description, is_success=True)
        is_sucess, response = FileOperation().decode_kess3_file(evc_instance.alientechauttoken, user_uploaded_file)
        logger.info(is_sucess)
        logger.info(response)
    elif tool_used == "KTAG":
        logger.info("Step 2: Send file for decoding:{}.".format(tool_used))
        save_flow(file_request_obj, title, description, is_success=True)
        is_sucess, response = FileOperation().decode_ktag_file(evc_instance.alientechauttoken, user_uploaded_file)

    end_time = datetime.now()
    second_diff = end_time - start_time

    if is_sucess:
        FileRequestAveragePerformance.objects.create(
            file_request_obj=file_request_obj,
            file_type=file_request_obj.file_type,
            decoding_success=True,
            decoding_success_time=second_diff.seconds
        )
    else:
        FileRequestAveragePerformance.objects.create(
            file_request_obj=file_request_obj,
            file_type=file_request_obj.file_type,
            decoding_failure=True,
            decoding_failure_time=second_diff.seconds
        )
    return is_sucess, response


def sent_for_manual_handling(file_obj, description):
    """Check cases to sent for manual handling.

    Args:
        file_obj (file request object): _description_
        description (str): description to be set for filerequesthistory.
    """
    # print("Step X: Sent for manual handling.")
    logger.info(f"Step X: Sent for manual handling(slave-flow) | File Request : {file_obj.file_request_id}")
    sent_for_handle = True

    is_manual_handle = TicketCategory.objects.filter(name="Manual Handle").exists()
    if not is_manual_handle:
        TicketCategory.objects.create(name="Manual Handle")

    if not TicketHistory.objects.filter(request_id=file_obj.file_request_id).exists():
        ticket = TicketHistory.objects.create(
            created_by=file_obj.user,
            assigned_to=MyUser.objects.get(email='technical@viezu.com'
                                        ) if MyUser.objects.filter(email='technical@viezu.com'
                                                                    ).exists() else None,
            category=TicketCategory.objects.get(name='Manual Handle'
                                                ) if TicketCategory.objects.filter(name='Manual Handle'
                                                                                ).exists() else None,
            file_request=file_obj,
            request_id=file_obj.request_id,
            subject="File Request to be manually handle.",
            ticket_status=TicketStatus.objects.get(team_status="New")
        )
        ticket.update_ids()
        logger.info(f"ticket created : {ticket}")

    file_obj.status = "Manual Handle"
    file_obj.save()

    title = "Sent to manual handling."
    is_success = True

    file_request_status_change(file_obj.user, file_obj)

    save_flow(file_obj, title,
              description, is_success)

    admin_user = MyUser.objects.get(email='technical@viezu.com')
    triger_socket({
        'uuid': str(admin_user.uuid),
        'type': 'admin_file_assigned',
        'ids': str(file_obj.request_id),
        'message': "File is assigned for manual handle:{}.".format(file_obj.request_id)
    })

    return sent_for_handle


def save_flow(file_request_obj, title,
              description, is_success,
              additional_information=''):
    FileRequestHistory.objects.create(
        file_request_id=file_request_obj,
        title=title,
        description=description,
        is_success=is_success,
        additional_information=additional_information
    )

    return True


def download_s3_file(file_obj, purpose):
    file_name = file_obj.tuning_file.url.split("/")[-1]
    content = file_obj.tuning_file.read()

    title = "Download file from cloud."
    description = "Download file from cloud for:{}".format(purpose)
    save_flow(file_obj, title, description, True)
    return file_name, content


def create_file_at_local(file_name, file_content, file_req_obj=None):
    if file_req_obj:
        local_file_name = 'media/{}/{}'.format(str(file_req_obj.request_id), file_name)
    else:
        local_file_name = 'media/{}'.format(file_name)

    file = open(local_file_name, 'wb')
    file.write(file_content)
    file.close()
    return local_file_name


def read_decode_file(file_obj):
    file = file_obj.tuning_file
    return file


def read_modified_file(modified_file_name, file_req_obj):
    modified_file_path = 'media/{}/{}'.format(str(file_req_obj.request_id), modified_file_name)
    file = open(modified_file_path, 'rb')

    return file


def validate_decode_status(instance, file_req_obj):
    is_decode_success = False
    data = instance.decode_response
    if data['hasFailed'] == False:
        is_decode_success = True
    else:
        is_decode_success = False
        description = data["error"]
        sent_for_manual_handling(file_req_obj, description)

    return is_decode_success


def get_async_decode_status(instance):
    logger.info("Step 4: Get async response.")
    while True:
        logger.info("getting decode async response.")
        decode_id = instance.ids
        decode = DecodeFiles.objects.get(ids=decode_id)
        if decode.is_completed and decode.status == 2:
            async_resp = json.loads(decode.async_response)
            break
        elif decode.is_completed and decode.status == 3:
            async_resp = json.loads(decode.async_response)
            break

        time.sleep(20)

    return async_resp


def get_async_encode_status(encode_instance):
    logger.info("Step last: Get async response.")
    async_resp = {}
    while True:
        logger.info("getting encode async response.")
        encode_id = encode_instance.id
        encode = EncodeFiles.objects.get(id=encode_id)
        if encode.is_completed and encode.status == 2:
            async_resp = json.loads(encode.async_response)
            logger.info("Get async Encode Status Success")
            return async_resp
        elif encode.is_completed and encode.status == 3:
            async_resp = json.loads(encode.async_response)
            logger.info("Get async Encode Status Failed")
            return async_resp
        time.sleep(5)
    return async_resp


def get_tool_type_int(tool_used):
    if tool_used == "KESS v2":
        tool_used_int = 1
    elif tool_used == "KESS3":
        tool_used_int = 2
    else:
        tool_used_int = 3

    return tool_used_int


def create_decode_encode_folder(file_request_obj):
    logger.info("Step 6: Create folder on local in media folder with req_id.")
    is_folder_created = False
    try:
        decode_id = str(file_request_obj.request_id)
        path = "media/" + decode_id
        logger.info(path)
        if not os.path.exists(path):
            # logger.info('1111111111111111111111111111111111111111111')
            os.mkdir(path)
            is_folder_created = True
        else:
            print("folder already exists.")
            logger.warning("folder with name {} already exists.".format(file_request_obj.request_id))
            is_folder_created = True
    except Exception as error:
        # logger.error('Amit Maurya')
        logger.error(str(error))

    return is_folder_created


def save_decode_file(path, url, file_request_obj, file_type_name=None):
    logger.info("Step 7: save decode file at local.")
    evc_instance = EVCCredentials.objects.all().last()
    try:
        is_download, response = FileOperation().download_file(
            evc_instance.alientechauttoken,
            url
        )
        logger.info("download is success.{}".format(is_download))
        if is_download:
            logger.info("in success save decode file")
            import base64
            file_content = base64.b64decode(response['data'])
            if not file_type_name:
                file_name = 'decoded_' + file_request_obj.tuning_file.url.split("/")[-1]
            else:
                file_name = file_type_name + 'decoded_' + file_request_obj.tuning_file.url.split("/")[-1]
            filename = path + '/' + file_name
            logger.info(file_name)
            with open(filename, 'wb') as f:
                f.write(file_content)
            is_file_save_local = True
        else:
            title = "Decode file download issue."
            description = "Something went wrong while downloading decode file"
            save_flow(file_request_obj, title, description, False)
            is_file_save_local = False
    except Exception as error:
        logger.info("Error:{}".format(error))
        title = "Decode file download issue."
        description = "Something went wrong while downloading decode file"
        save_flow(file_request_obj, title, description, False)
        is_file_save_local = False
    return is_file_save_local


def save_encode_file(path, url, file_request_obj):
    logger.info("Step last encoed: save encode file at local.")

    is_file_save_local = False
    evc_instance = EVCCredentials.objects.all().last()
    is_sucess, response = FileOperation().download_file(
        evc_instance.alientechauttoken,
        url
    )

    if is_sucess and response:
        import base64
        uploaded_file_name = file_request_obj.tuning_file.url.split("/")[-1]
        file_content = base64.b64decode(response['data'])
        additional_function = file_request_obj.additional_function
        if additional_function is not None:
            additional_function = additional_function.split(",")
            additional_function = list(map(lambda function_name: function_name.upper().strip(), additional_function))
        else:
            additional_function = []
        tuning_required = file_request_obj.tuning_required
        search_terms = ''
        if tuning_required == "VBLUE/ECO":
            search_terms = "ECONOMY"
        elif tuning_required == "VBLEND/STAGE 0.5":
            search_terms = "BLEND"
        elif tuning_required == "VPERF/STAGE 1":
            search_terms = "PERFORMANCE"
        elif tuning_required == "VRACE/STAGE 2":
            search_terms = "vrace"
        elif tuning_required == "NO TUNE":
            search_terms = ''
        uploaded_file_name = uploaded_file_name.upper()
        file_name_to_create = uploaded_file_name + ' ' + search_terms
        if additional_function:
            file_name_to_create += ' ' + ' '.join(additional_function)
        filename = path + '/' + file_name_to_create
        with open(filename, 'wb') as f:
            f.write(file_content)
        is_file_save_local = True
    else:
        title = "encode file download issue."
        description = "Something went wrong while downloading encoded file."
        save_flow(file_request_obj, title, description, False)
        is_file_save_local = False

    return is_file_save_local


def save_any_file(path, url, file_request_obj, file_type):
    logger.info("Step save {} file at local.".format(file_type))

    is_file_save_local = False
    evc_instance = EVCCredentials.objects.all().last()
    is_sucess, response = FileOperation().download_file(
        evc_instance.alientechauttoken,
        url
    )

    if is_sucess and response:
        import base64
        file_content = base64.b64decode(response['data'])
        file_name = file_type + file_request_obj.tuning_file.url.split("/")[-1]
        filename = path + '/' + file_name
        with open(filename, 'wb') as f:
            f.write(file_content)
        is_file_save_local = True
    else:
        title = "encode file download issue."
        description = "Something went wrong while downloading encoded file."
        save_flow(file_request_obj, title, description, False)
        is_file_save_local = False

    return is_file_save_local


def upload_file_s3(local_file_name, dir_name_to_create,
                   file_name_to_create, file_request_obj):
    logger.info("Step 18: Uplaod file to s3.")
    try:
        is_sucess, url = upload_file_to_s3(local_file_name, "{}/{}".format(dir_name_to_create, file_name_to_create))
    except Exception as error:
        logger.info("error:{}".format(error))
    return is_sucess, url


def upload_file_to_s3(local_path, bucket_path):
    myfile = local_path
    client = boto3.client(
        's3',
        region_name='us-east-1',
        aws_access_key_id=settings.AWS_ACCESS_KEY_ID,
        aws_secret_access_key=settings.AWS_SECRET_ACCESS_KEY
    )
    try:
        client.upload_file(
            myfile,
            settings.AWS_STORAGE_BUCKET_NAME,
            bucket_path,
            ExtraArgs={'ACL': 'public-read'}
        )
        url = "https://{}.s3.us-east-1.amazonaws.com/{}".format(
            settings.AWS_STORAGE_BUCKET_NAME, bucket_path)
        # os.remove(myfile)
        return True, url
    except Exception as e:
        print("S3", e)
        return False, None


def create_download_file_object(file_request_obj, url, title):
    logger.info("Save file in model for {}.".format(title))
    request_instance = RequestDownloadFiles.objects.create(
        fil_request_id=file_request_obj,
        title=title,
        url=url
    )
    return request_instance


def search_based_on_form_data(file_request_obj, data, decode_id):
    # print("Step 9: Search ECU brand and ECU version from the files on cloud.")
    logger.info("Step 9: Search ECU brand and ECU version from the files on cloud.")
    directories_to_search = []
    vehicle_type = file_request_obj.vehicle_type
    if vehicle_type == "Car":
        vehicle_type = "Passenger car"
    elif vehicle_type == "Truck":
        vehicle_type = "Truck"
    elif vehicle_type == "Tractor":
        vehicle_type = "Tractor"
    elif vehicle_type == "Boat":
        vehicle_type = "Boat"
    elif vehicle_type == "Bike":
        vehicle_type = "Motorbike"

    queryset = Directory.objects.filter(
        Q(ecu_producer__contains=data['ecu_brand']) |
        Q(ecu_build__contains=data['ecu_version']),
        vehicle_type__contains=vehicle_type
    ).values('directory_path')
    if len(queryset) != 0:
        directories_to_search = [dir['directory_path'] for dir in queryset]
    if len(directories_to_search) != 0:
        title = "Search similar original files and database."
        description = salve_stage.SLAVE_FILE_STAGE_4.format("yes")
        FileRequestHistory.objects.create(
            file_request_id=file_request_obj,
            title=title,
            description=description,
            is_success=True,
            additional_information=decode_id)

    return directories_to_search


def get_s3_original_files(prefix_list):
    logger.info("Step 10: Search for all related original files in the database")

    # MongoDB connection
    client = MongoClient(settings.MONGO_HOST, 27017)
    db = client['filemaker_directory']
    fs = GridFS(db)
    coll = db['directory']

    # Remove 'Main/' prefix
    prefix_without_main = [prefix.replace('Main/', '') for prefix in prefix_list]

    # MongoDB query to find files with specified prefixes
    data = coll.find(
        {'directory_name': {'$in': prefix_without_main}},
        {'file_name': 1, 'directory_name': 1, '_id': 0}
    )
    json_data = ast.literal_eval(dumps(data))

    # Create DataFrame and filter original files
    df = pd.DataFrame(json_data)
    df = df[df['file_name'].str.contains("original", case=False)]

    # List of original file names
    original_files_list = df['file_name'].tolist()

    # MongoDB query to get file data
    data = fs.find({'filename': {'$in': original_files_list}})

    # Read file data and create DataFrame
    json_data = [
        {
            'directory': file.metadata["directory_name"],
            'hex_dump': binascii.hexlify(file.read()).decode(),
            'original': file.filename
        } for file in data
    ]
    df = pd.DataFrame(json_data)
    logger.info("++++++++ Total file ++++++++")
    logger.info(df.count())
    logger.info("++++++++ Total file ++++++++")
    # df = parallelize_dataframe(df, apply_convert_to_n_size_block)
    df["file_hexa_content_list"] = df['hex_dump'].apply(lambda x: convert_to_n_size_block(x, 8))
    files_for_algorithm = df.to_dict('records')
    return files_for_algorithm


def get_matching_ratio_df(files_for_algorithm, file_request_obj,
                          decoded_file_hexa_dump_list):
    logger.info("Step 12: calculate percentage match of original files.")

    start_time = datetime.now()

    df = pd.DataFrame(files_for_algorithm)
    try:
        df["percentage"] = df.apply(lambda row:
                                    get_matching_ratio2(
                                        row["file_hexa_content_list"],
                                        decoded_file_hexa_dump_list), axis=1)
    except Exception as error:
        print(error)

    ecu_brand = file_request_obj.ecu_brand
    ecu_version = file_request_obj.ecu_version

    ecu_matching_percentage = DataEcuVersion.objects.filter(
        brand__brand_name=ecu_brand,
        ecu_version_name=ecu_version)

    df = df.sort_values(by=['percentage'], ascending=False)
    df = df[df['percentage'] >= ecu_matching_percentage[0].percentage]

    df.rename(columns={
        'original': 'matching_file_name',
        'directory': 'matching_directory',
        'percentage': 'matching_percentage',
        'file_hexa_content_list': 'matching_original_file_hexa_list'
    }, inplace=True)
    # print(list(df.columns))
    data = df.to_dict('records')

    end_time = datetime.now()
    second_diff = end_time - start_time

    if len(data) > 0:
        FileRequestAveragePerformance.objects.create(
            file_request_obj=file_request_obj,
            file_type=file_request_obj.file_type,
            original_found=True,
            original_found_time=second_diff.seconds
        )
    else:
        FileRequestAveragePerformance.objects.create(
            file_request_obj=file_request_obj,
            file_type=file_request_obj.file_type,
            original_not_found=True,
            original_not_found_time=second_diff.seconds
        )

    return data


def get_matching_ratio2(hexdata1, hexdata2):
    logger.info("Step 11: Get matching percentage from the original files.")
    total_common_items = len(set(hexdata1) & set(hexdata2))
    total_distinct_items = float(len(set(hexdata1) | set(hexdata2)))
    percentage_diff = (total_common_items / total_distinct_items) * 100
    return percentage_diff


def get_version_files_from_dir(version_directory, file_request_obj):
    logger.info("Step 13: Get version files form the directory of original.")

    client = MongoClient(settings.MONGO_HOST, 27017)
    db = client['filemaker_directory']
    coll = db['directory']
    fs = GridFS(db)

    # mongo query
    data = coll.find(
        {'directory_name': version_directory},
        {'_id': 0, 'file_name': 1, 'directory_name': 2}
    )
    json_data = ast.literal_eval(dumps(data))

    # create dataframe.
    df = pd.DataFrame(json_data)

    tuning_required = file_request_obj.tuning_required
    additional_function = file_request_obj.additional_function

    additional_function = get_upper_additional_function(additional_function)
    search_terms = get_search_terms(tuning_required)

    tuning_term = search_terms.upper()

    if len(additional_function) > 0 and tuning_term != '':
        print(1)
        combinations, combinations_to_list = get_combinations(tuning_term, additional_function)
        files_to_search = additional_search(tuning_term, combinations)
        version_file_data = get_version_file_match_or_not(files_to_search, json_data)

    elif len(additional_function) == 0 and tuning_term != '':
        print(2)
        updated_tuning_term = tuning_term + ')'
        files_to_search = [updated_tuning_term]
        version_file_data = get_version_file_match_or_not(files_to_search, json_data)

    elif len(additional_function) > 0 and tuning_term == '':
        print(3)
        combinations, combinations_to_list = get_combinations(tuning_term, additional_function)
        files_to_search = additional_search(tuning_term, combinations)
        version_file_data = get_version_file_match_or_not(files_to_search, json_data)

    version_file_data = [] if version_file_data is None else version_file_data
    if version_file_data != []:
        version_file_data = [version_file_data]
    version_files_list = [file['file_name'] for file in version_file_data]

    # mongo query
    data = fs.find({'filename': {'$in': version_files_list}})

    json_data = [
        {'version_directory': file.metadata["directory_name"],
         'version_original_file_hexadump': binascii.hexlify(file.read()).decode(),
         'version_original': file.filename
         } for file in data]

    df = pd.DataFrame(json_data)

    if df.empty:
        logger.info("In empty dataframe.")
        version_files_list = []
        title = "Search for version files."
        additional_str = ",".join(additional_function)
        description = "No file found with {} {} in directory:{}".format(search_terms,
                                                                        additional_str, version_directory)

        save_flow(file_request_obj, title=title,
                  description=description, is_success=True)
        return version_files_list
    else:
        title = "Search for version files."
        additional_str = ",".join(additional_function)
        description = "File found with {} {} in directory:{}".format(search_terms,
                                                                     additional_str, version_directory)
        save_flow(file_request_obj, title=title,
                  description=description, is_success=True)
        df["version_file_hexa_content_list"] = df.apply(
            lambda row: convert_to_n_size_block(row['version_original_file_hexadump'], 8), axis=1)

        version_files_list = df.to_dict('records')

        title = "Search for version files."
        description = salve_stage.SLAVE_FILE_STAGE_6
        save_flow(file_request_obj, title=title,
                  description=description, is_success=True)

    return version_files_list


def check_string_exists(version_files, data):
    version_files_list = []
    for file in version_files:
        f = file
        f = f.split(")")
        if len(f) > 0:
            f = f[0].split(" ")

        count = 0
        for i in data:
            print(i)
            if i in file:
                count += 1

        if len(f) == count:
            version_files_list.append(file)

    return version_files_list


def file_naming(file_request_obj):
    tuning_required = file_request_obj.tuning_required
    additional_function = file_request_obj.additional_function

    if tuning_required == "VBLUE/ECO":
        search_terms = "(VBLUE "
    elif tuning_required == "VBLEND/STAGE 0.5":
        search_terms = "(VBLEND "
    elif tuning_required == "VPERF/STAGE 1":
        search_terms = "(VPERF "
    elif tuning_required == "VRACE/STAGE 2":
        search_terms = "(VRACE "
    elif tuning_required == "NO TUNE":
        search_terms = "("

    if additional_function is not None:
        if len(additional_function) > 0:
            additional_function = file_request_obj.additional_function.split(",")
            additional_function = list(map(lambda x: x.lower().strip(), additional_function))
    else:
        additional_function = []

    if additional_function:
        file_name = search_terms + ' ' + ' '.join(additional_function) + ')_'
    else:
        file_name = search_terms + ')_'
    return file_name


def match_version_files(data, version_files_list, file_request_obj):
    logger.info("Step 14: Match version files (percentage match) form the directory of original.")

    start_time = datetime.now()

    version_data = {}
    similar_original_file_hexadump_list = data['matching_original_file_hexa_list']
    df = pd.DataFrame(version_files_list)

    try:
        df["percentage"] = df.apply(lambda row:
                                    get_matching_ratio2(
                                        row["version_file_hexa_content_list"],
                                        similar_original_file_hexadump_list), axis=1)
    except Exception as error:
        print(error)

    df = df[df.percentage == df.percentage.max()]
    # print(df)
    end_time = datetime.now()
    second_diff = end_time - start_time
    # Get max original data from df
    if df.iloc[0]['percentage'] == 0:
        title = salve_stage.SLAVE_FILE_STAGE_7
        description = "No version file found or found with percentage zero."
        save_flow(file_request_obj, title=title, description=description, is_success=True)
        FileRequestAveragePerformance.objects.create(
            file_request_obj=file_request_obj,
            file_type=file_request_obj.file_type,
            refrence_not_found=True,
            refrence_not_found_time=second_diff.seconds
        )
    else:
        version_data['version_matching_directory'] = df.iloc[0]['version_directory']
        version_data['version_matching_file_name'] = df.iloc[0]['version_original']
        version_data['version_matching_percentage'] = df.iloc[0]['percentage']
        version_data['version_file_hexa_list'] = df.iloc[0]['version_file_hexa_content_list']
        title = salve_stage.SLAVE_FILE_STAGE_7
        description = "File name:{}, directory:{}, matching percentage:{}".format(
            version_data['version_matching_file_name'],
            version_data['version_matching_directory'],
            version_data['version_matching_percentage']
        )
        FileRequestAveragePerformance.objects.create(
            file_request_obj=file_request_obj,
            file_type=file_request_obj.file_type,
            refrence_found=True,
            refrence_found_time=second_diff.seconds
        )
        save_flow(file_request_obj, title=title,
                  description=description, is_success=True)

    return version_data


def add_diff_to_similar_original_index_bytes(
        version_hexa, new_version_hexa,
        similar_hexa, file_request_obj):
    logger.info("Step 15: Copy the content onto another file and create.")

    version_hexa_str = "".join(version_hexa)
    version_bytes = binascii.unhexlify(version_hexa_str)

    new_file_version_str = "".join(new_version_hexa)
    new_file_version_bytes = binascii.unhexlify(new_file_version_str)

    similar_file_version_str = "".join(similar_hexa)
    similar_file_version_bytes = binascii.unhexlify(similar_file_version_str)

    new_file_version_bytes_array = list(new_file_version_bytes)
    similar_file_version_bytes_array = list(similar_file_version_bytes)

    min_len = min(map(len, (version_bytes, new_file_version_bytes)))
    count = 0
    for i in range(min_len):  # use smaller length
        if (version_bytes[i] != new_file_version_bytes[i]):
            # print("index:{0} file1:{1} file2:{2}".format(
            #     i,version_bytes[i], new_file_version_bytes[i]))
            # new_file_version_bytes_array[i] = version_bytes[i]

            similar_file_version_bytes_array[i] = version_bytes[i]
            count += 1
    result = bytes(similar_file_version_bytes_array)

    title = "copying content onto another file."
    description = "copying content."
    save_flow(file_request_obj, title=title,
              description=description, is_success=True)

    return result


def create_directory_name(version_data):
    logger.info("Step 16: create the directory name.")
    split_dir = version_data['version_matching_directory'].split("/")
    import string
    import random
    N = 7
    res = ''.join(random.choices(string.ascii_uppercase +
                                 string.digits, k=N))
    final_dir_name = split_dir[0] + "/" + split_dir[-1] + "_" + res
    return final_dir_name


def close_file_slot(instance, file_obj):
    is_closed = False
    if instance:
        logger.info("Step 19: Close file slot.")
        evc_instance = EVCCredentials.objects.all().last()
        tool_used = file_obj.tuning_tool_used
        decode_response = instance.decode_response
        slot_guid = decode_response['slotGUID']
        if tool_used == "KESS v2":
            file_type = "kessv2"
        elif tool_used == "KESS3":
            file_type = "kess3"
        else:
            file_type = "ktag"

        FileOperation().close_file_slot(evc_instance.alientechauttoken, slot_guid, file_type)
        is_closed = True
    return is_closed


def get_combinations(tuning_term: str, additional_function: list):
    from itertools import permutations

    tuning_list = [tuning_term]
    combinations_to_list = tuning_list + additional_function
    combinations = permutations(combinations_to_list, 2)
    return combinations, combinations_to_list


def multi_pass_files(combinations: object, combinations_to_list: list):
    files_to_search = []
    for comb in combinations:
        str = " ".join(list(comb))
        data = {}
        to_remove = str.split(" ")
        not_in_list = list(filter(lambda i: i not in to_remove, combinations_to_list))
        data['comb'] = str
        data['not_in_comb'] = not_in_list[0]
        files_to_search.append(data)

    return files_to_search


def additional_search(tuning_term: str, combinations: object):
    files_to_search = []

    for comb in combinations:
        if tuning_term != '' and tuning_term in comb:
            str = " ".join(list(comb))
            files_to_search.append(str)
        if tuning_term == '' and '' not in comb:
            str = " ".join(list(comb))
            files_to_search.append(str)
        if tuning_term == '' and '' in comb:
            str = " ".join(list(comb)).strip()
            files_to_search.append(str)

    return files_to_search


def get_version_file_match_or_not(files_to_search, json_data):
    found_directory = None
    for file_name in files_to_search:

        for directory in json_data:
            if file_name in directory['file_name']:
                found_directory = directory
                break

    return found_directory


def get_upper_additional_function(additional_function):
    """ Get uppercase additional function.  """

    if additional_function is not None:
        additional_function = additional_function.split(",")
        additional_function = list(map(lambda function_name: function_name.upper().strip(), additional_function))
    else:
        additional_function = []

    return additional_function


def get_search_terms(tuning_required):
    """ Get search terms in str format.

    Args:
        tuning_required (str): _description_

    Returns:
        str: Search terms
    """

    if tuning_required == "VBLUE/ECO":
        search_terms = "vblue"
    elif tuning_required == "VBLEND/STAGE 0.5":
        search_terms = "vblend"
    elif tuning_required == "VPERF/STAGE 1":
        search_terms = "vperf"
    elif tuning_required == "VRACE/STAGE 2":
        search_terms = "vrace"
    elif tuning_required == "NO TUNE":
        search_terms = ''

    return search_terms


def get_files_from_dir(version_directory):
    client = MongoClient(settings.MONGO_HOST, 27017)
    db = client['filemaker_directory']
    coll = db['directory']
    fs = GridFS(db)

    # mongo query
    data = coll.find(
        {'directory_name': version_directory},
        {'_id': 0, 'file_name': 1, 'directory_name': 2}
    )
    json_data = ast.literal_eval(dumps(data))

    return json_data


def get_files_by_query_from_dir(query):
    client = MongoClient(settings.MONGO_HOST, 27017)
    db = client['filemaker_directory']
    coll = db['directory']
    fs = GridFS(db)

    # mongo query
    data = coll.find(
        query,
        {'_id': 0, 'file_name': 1, 'directory_name': 2}
    )
    json_data = ast.literal_eval(dumps(data))

    return json_data


def single_directory_multipass(matching_original_data, file_request_obj):
    logger.info("In single directory multipass.")

    matching_files = {}

    tuning_required = file_request_obj.tuning_required
    additional_function = file_request_obj.additional_function

    additional_function = get_upper_additional_function(additional_function)
    search_terms = get_search_terms(tuning_required)
    search_terms = search_terms.upper()

    combinations, combinations_to_list = get_combinations(search_terms, additional_function)
    for original_data in matching_original_data:
        json_data = get_files_from_dir(original_data['matching_directory'])
        for comb in combinations:
            to_search = " ".join(list(comb))
            not_in_list = list(filter(lambda i: i not in comb, combinations_to_list))[0]

            is_not_in_list_in_dir = [dir for dir in json_data if not_in_list in dir['file_name']]
            is_to_search_in_dir = [dir for dir in json_data if to_search in dir['file_name']]

            if len(is_not_in_list_in_dir) > 0 and len(is_to_search_in_dir) > 0:
                title = "Searching and found different files in single directory."
                description = "Search for {} and {} file in {} directory.".format(
                    not_in_list, to_search,
                    original_data['matching_directory'])
                save_flow(file_request_obj, title, description, True)

                matching_files = {
                    'matching_ref_1': is_not_in_list_in_dir,
                    'matching_ref_2': is_to_search_in_dir
                }
                return matching_files

    return matching_files


def decode_resubmit_slave_file(file_request_id):
    logger.info("In decode resubmit slave function.")
    __contant_decoded_file = "DECODED FILE"
    file_request_obj = FileRequest.objects.get(request_id=file_request_id)
    user_uploaded_file = read_decode_file(file_request_obj)
    tool_used = file_request_obj.tuning_tool_used

    is_sucess, response = False, None
    evc_instance = EVCCredentials.objects.all().last()
    print(0)
    if tool_used == "KESS v2":
        logger.info("Decoding kessv2 File:{}.".format(tool_used))
        is_sucess, response = FileOperation().decode_kessV2_file(evc_instance.alientechauttoken, user_uploaded_file)
        print(is_sucess, response)
        save_flow(
            file_request_obj=file_request_obj,
            title="Kess v2 Decode.",
            description="File sent for decode successfully.",
            is_success=True,
        )
    elif tool_used == "KESS3":
        logger.info("Decoding kess3 File:{}.".format(tool_used))
        is_sucess, response = FileOperation().decode_kess3_file(evc_instance.alientechauttoken, user_uploaded_file)
        save_flow(
            file_request_obj=file_request_obj,
            title="Kess 3 Decode.",
            description="File sent for decode successfully.",
            is_success=True,
        )
    elif tool_used == "KTAG":
        logger.info("Decoding ktag File:{}.".format(tool_used))
        is_sucess, response = FileOperation().decode_ktag_file(evc_instance.alientechauttoken, user_uploaded_file)
        save_flow(
            file_request_obj=file_request_obj,
            title="Ktag Decode.",
            description="File sent for decode successfully.",
            is_success=True,
        )

    uploaded_file_name = file_request_obj.tuning_file.url.split("/")[-1]
    create_decode_encode_folder(file_request_obj)
    path = "media/" + str(file_request_obj.request_id)
    dir_name_to_create = str(file_request_obj.request_id)
    if is_sucess:
        logger.info("Step 3: Create decode file object.")
        tool_used_int = get_tool_type_int(tool_used)
        instance = DecodeFiles.objects.create(
            user=file_request_obj.user,
            tool_type=tool_used_int,
            file=user_uploaded_file,
            decode_response=response,
            guid=response['guid'],
            process_type=2
        )
        instance.update_ids()
        instance.save()
        logger.info(instance.ids)
    else:
        print(4.1)
        description = "Cannot decode file, got unsuccessfull response.{}".format(response['error'])
        sent_for_manual_handling(file_request_obj, description)

    instance = DecodeFiles.objects.get(ids=instance.ids)
    is_decode_success = validate_decode_status(instance, file_request_obj)

    if not is_decode_success:
        description = "Cannot decode file, got unsuccessfull response."
        sent_for_manual_handling(file_request_obj, description)
        close_file_slot(instance, file_request_obj)
    else:
        async_resp = get_async_decode_status(instance)
        if 'error' in async_resp and async_resp['error'] is not None:
            description = async_resp['error']['errorName']
            sent_for_manual_handling(file_request_obj, description)
            close_file_slot(instance, file_request_obj)
        else:
            logger.info("Step 5: Successfull async response.")
            logger.info("Decode file and saving at local: {}.".format(tool_used))
            decode_file_url = async_resp['result']['obdDecodedFileURL']
            filename = "decoded_" + uploaded_file_name
            is_file_save_local = save_decode_file(path, decode_file_url, file_request_obj)
            logger.info("kessv3 is_file_save_local".format(is_file_save_local))
            if is_file_save_local:
                logger.info("in save file at local")
                local_file_name = path + '/' + filename
                logger.info(local_file_name)
                is_success, url = upload_file_s3(local_file_name, dir_name_to_create,
                                                 filename, file_request_obj)
                create_download_file_object(file_request_obj, url, __contant_decoded_file)
                logger.info("File Decoded and saved successfully.")
                save_flow(
                    file_request_obj=file_request_obj,
                    title="File decoded successfully.",
                    description="Decoded file available to download.",
                    is_success=True,
                )
                sent_for_manual_handling(file_request_obj, "File Sent to manual handling.")
                close_file_slot(instance, file_request_obj)
            else:
                logger.info("File can't be Decoded successfully.")
                sent_for_manual_handling(file_request_obj, "File Sent to manual handling.")
                close_file_slot(instance, file_request_obj)


def convert_s3_file_to_hex(bucket_name, s3_key, chunk_size=1024):
    s3 = boto3.client(
        's3',
        region_name='us-east-1',
        aws_access_key_id=settings.AWS_ACCESS_KEY_ID,
        aws_secret_access_key=settings.AWS_SECRET_ACCESS_KEY
    )
    hex_data = []
    obj = s3.get_object(Bucket=bucket_name, Key=s3_key)
    stream = obj['Body']

    while True:
        chunk = stream.read(chunk_size)
        if not chunk:
            break
        hex_data.append(binascii.hexlify(chunk).decode())

    return ''.join(hex_data)


def resubmit_file(json_data):
    file_request_id = json_data.get('file_request_id')
    decode_id = json_data.get('additional_information')
    file_request_obj = FileRequest.objects.get(request_id='FR' + str(file_request_id))
    logger.info("Step 1: Read user's file submitted in the file request form. %s", file_request_id)
    data = {}
    data['ecu_brand'] = file_request_obj.ecu_brand
    data['ecu_version'] = file_request_obj.ecu_version
    bucket_name = 'filemaker-stage'
    uploaded_file_name = file_request_obj.tuning_file.url.split("/")[-1]
    s3_key = 'FR' + str(file_request_id) + '/' + 'decoded_' + uploaded_file_name
    matching_found_in_path = ""
    random_generated_path = ""
    instance = DecodeFiles.objects.get(ids=decode_id)
    evc_instance = EVCCredentials.objects.all().last()
    FileOperation().re_open_closed_file1(
        evc_instance.alientechauttoken,
        instance.slot_guid,
        "kess3"
    )
    decoded_file_hexa_dump = convert_s3_file_to_hex(bucket_name, s3_key)
    decoded_file_hexa_dump_list = convert_to_n_size_block(decoded_file_hexa_dump, 8)
    directories_to_search = []
    vehicle_type = file_request_obj.vehicle_type
    if vehicle_type == "Car":
        vehicle_type = "Passenger car"
    elif vehicle_type == "Truck":
        vehicle_type = "Truck"
    elif vehicle_type == "Tractor":
        vehicle_type = "Tractor"
    elif vehicle_type == "Boat":
        vehicle_type = "Boat"
    elif vehicle_type == "Bike":
        vehicle_type = "Motorbike"
    queryset = Directory.objects.filter(
        Q(ecu_producer__contains=data['ecu_brand']) |
        Q(ecu_build__contains=data['ecu_version']),
        vehicle_type__contains=vehicle_type
    ).values('directory_path')
    if len(queryset) != 0:
        directories_to_search = [dir['directory_path'] for dir in queryset]
    if directories_to_search != 0:
        files_for_algorithm = get_s3_original_files(directories_to_search)
        try:
            matching_original_data = get_matching_ratio_df(
                files_for_algorithm, file_request_obj,
                decoded_file_hexa_dump_list)
        except Exception as error:
            logger.error("get matching ratio error:{}".format(error))
    else:
        sent_for_manual_handling(file_request_obj, "File Sent to manual handling.")
        close_file_slot(instance, file_request_obj)
        is_file_match_success = False
        return is_file_match_success, matching_found_in_path, random_generated_path

    if len(matching_original_data) == 0:
        description = salve_stage.SLAVE_FILE_STAGE_MANUAL_1
        sent_for_manual_handling(file_request_obj, description)
        close_file_slot(instance, file_request_obj)
        is_file_match_success = False
        return is_file_match_success, matching_found_in_path, random_generated_path
    else:
        for original_data in matching_original_data:
            version_files_list = get_version_files_from_dir(
                original_data['matching_directory'],
                file_request_obj)
            if len(version_files_list) > 0:
                break

    # Match version files list.
    if len(version_files_list) > 0:
        version_data = match_version_files(original_data, version_files_list,
                                           file_request_obj)
    else:
        version_data = []

    if len(version_data) == 0:
        description = salve_stage.SLAVE_FILE_STAGE_MANUAL_2
        sent_for_manual_handling(file_request_obj, description)
        close_file_slot(instance, file_request_obj)
        is_file_match_success = False
        return is_file_match_success, matching_found_in_path, random_generated_path
    else:
        version_file_hexa_list = version_data['version_file_hexa_list']
        original_file_hexa_list = original_data['matching_original_file_hexa_list']
        # decoded file hexadump.
        similar_original_file_hexadump_list = decoded_file_hexa_dump_list

        updated_similar_hexa_bytes = add_diff_to_similar_original_index_bytes(
            version_file_hexa_list, original_file_hexa_list,
            similar_original_file_hexadump_list, file_request_obj)

        path = "media/" + str(file_request_obj.request_id)
        if not os.path.exists(path):
            os.makedirs(path)
        dir_name_to_create = create_directory_name(version_data)
        logger.info("dir_name_to_create %s", dir_name_to_create)
        random_generated_path = dir_name_to_create
        matching_found_in_path = version_data['version_matching_directory']

        if file_request_obj.file_type == "Client/Slave":
            file_name_to_create = "modified_(VPERF)_" + dir_name_to_create.split("/")[-1]
            title = "Modified VPERF File"

        local_file_name = create_file_at_local(file_name_to_create, updated_similar_hexa_bytes,
                                               file_request_obj)
        is_sucess, url = upload_file_s3(local_file_name, dir_name_to_create,
                                        file_name_to_create, file_request_obj)

        if is_sucess:
            RequestDownloadFiles.objects.create(
                fil_request_id=file_request_obj,
                title=title,
                url=url
            )

        evc_instance = EVCCredentials.objects.all().last()
        decode_instance = DecodeFiles.objects.get(ids=instance.ids)
        modified_file = read_modified_file(file_name_to_create, file_request_obj)
        logger.info("Step 19: Upload modified original file.")
        is_sucess, response = FileOperation().kessv3_upload_modified_file(
            evc_instance.alientechauttoken,
            modified_file,
            decode_instance.slot_guid,
            "OBDModified"
        )
        save_flow(
            file_request_obj=file_request_obj,
            title="Modify file upload.",
            description="Modified File successfully uploaded to alientech.",
            is_success=True,
        )
        modified_instance = EncodeFiles.objects.create(
            user=file_request_obj.user,
            decode=decode_instance,
            guid=response['guid'] if 'guid' in response else 'N/A',
            encode_response=response,
            file_type="Modified"
        )

        modified_instance.update_ids()
        # after uploda mdified encode the file.
        logger.info("modified_instance %s", modified_instance.guid)
        is_sucess, response = FileOperation().encode_kess3_obd_file(
            evc_instance.alientechauttoken,
            decode_instance.slot_guid,
            modified_instance.guid,
            originalFileGUID='',
            willCorrectCVN=False
        )

        is_sent_for_encode = True if is_sucess else False
        logger.info("is_sucess %s", is_sucess)
        logger.info("encode_kess3_obd_file response %s", response)
        if is_sucess and is_sent_for_encode:
            logger.info("Step 19: File sent for encode successfully.")
            save_flow(
                file_request_obj=file_request_obj,
                title="File sent for encode successfully.",
                description="File sent for encode successfully.",
                is_success=True,
            )
            encode_ins = EncodeFiles.objects.create(
                user=modified_instance.user,
                parent=modified_instance,
                decode=decode_instance,
                ids=modified_instance.ids,
                guid=response['guid'] if 'guid' in response else 'N/A',
                encode_response=response,
                file_type='Encode'
            )
            logger.info(encode_ins.ids)
            async_resp = get_async_encode_status(encode_ins)

            save_flow(
                file_request_obj=file_request_obj,
                title="Kess3 Encode result successfull.",
                description="File sent for encode successfully.",
                is_success=True,
            )
            encoded_file_url = async_resp['result']['encodedFileURL']
            if "encodingapi.alientech.to" in encoded_file_url:
                try:
                    additional_function = file_request_obj.additional_function
                    if additional_function is not None:
                        additional_function = additional_function.split(",")
                        additional_function = list(
                            map(lambda function_name: function_name.upper().strip(), additional_function))
                    else:
                        additional_function = []
                    tuning_required = file_request_obj.tuning_required
                    search_terms = ''
                    if tuning_required == "VBLUE/ECO":
                        search_terms = "ECONOMY"
                    elif tuning_required == "VBLEND/STAGE 0.5":
                        search_terms = "BLEND"
                    elif tuning_required == "VPERF/STAGE 1":
                        search_terms = "PERFORMANCE"
                    elif tuning_required == "VRACE/STAGE 2":
                        search_terms = "vrace"
                    elif tuning_required == "NO TUNE":
                        search_terms = ''
                    uploaded_file_name = uploaded_file_name.upper()
                    filename = uploaded_file_name + ' ' + search_terms
                    if additional_function:
                        filename += ' ' + ' '.join(additional_function)
                    title = uploaded_file_name + ' ' + search_terms
                except Exception:
                    path = "media/" + str(file_request_obj.request_id)
                    filename = "encoded_" + file_request_obj.tuning_file.url.split("/")[-1]
                is_file_save_local = save_encode_file(path, encoded_file_url, file_request_obj)
                logger.info("In kess3 save file.")
                if is_file_save_local:
                    local_file_name = path + '/' + filename
                    dir_name_to_create = file_request_obj.request_id
                    is_success, url = upload_file_s3(local_file_name, dir_name_to_create,
                                                     filename, file_request_obj)
                    logger.info("Save file in model for {}.".format(title))
                    RequestDownloadFiles.objects.create(
                        fil_request_id=file_request_obj,
                        title=title,
                        url=url,
                        sent_to_user=True
                    )
                    is_file_match_success = True
                    close_file_slot(instance, file_request_obj)
                    file_request_obj.status = "CLOSED"
                    file_request_obj.save()
                    logger.info("file_request_obj status %s", file_request_obj.status)
                    Directory.objects.create(
                        directory_path="Main/" + random_generated_path.split("/")[-1],
                        ecu_producer=file_request_obj.ecu_brand,
                        ecu_build=file_request_obj.ecu_version,
                        created_by_filemaker=True,
                        vehicle_type=file_request_obj.vehicle_type,
                        vehicle_producer=file_request_obj.vehicle_make,
                        vehicle_model=file_request_obj.model,
                        vehicle_model_year=file_request_obj.vehicle_year,
                        file_request=file_request_obj
                    )
                    upload_file_to_mongo(local_file_name, dir_name_to_create)
                    title = "File is presented to the user."
                    description = "File is present to the user to download with name {0}:".format(
                        random_generated_path + '/' + filename)
                    save_flow(file_request_obj, title, description, True)
                    return is_file_match_success, matching_found_in_path, random_generated_path
            else:
                logger.info("in manual handle.")
                description = response
                sent_for_manual_handling(file_request_obj, description)
                close_file_slot(instance, file_request_obj)
                is_file_match_success = False
                return is_file_match_success, matching_found_in_path, random_generated_path
        else:
            logger.info("in manual handle.")
            description = response
            sent_for_manual_handling(file_request_obj, description)
            # close_file_slot(instance, file_request_obj)
            is_file_match_success = False
            return is_file_match_success, matching_found_in_path, random_generated_path
