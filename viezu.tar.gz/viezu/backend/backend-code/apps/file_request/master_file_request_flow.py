import ast
import os
from apps.utils.mailer import file_request_status_change
import boto3
import binascii
import pandas as pd
from gridfs import GridFS
from django.db.models import Q
from pymongo import MongoClient
from django.conf import settings
from bson.json_util import dumps
import apps.file_request.master_file_stages_flow as file_stage 

from apps.file_request.models import (
    DataEcuVersion, FileRequest, FileRequestHistory,
    FileRequestTime, FileRequestAveragePerformance, RefrenceMadeFile
)

from apps.admin_management.models import (
    Directory, TicketCategory,TicketHistory, TicketStatus
)

from apps.account.models import (MyUser,)
from apps.utils.helper import triger_socket
from apps.file_request.models import RequestDownloadFiles
from apps.utils.file_utils import convert_to_n_size_block, generate_blocks
from apps.file_request.utils import read_user_file_request
import logging
logger = logging.getLogger('django')
from datetime import datetime

session = boto3.Session(
    aws_access_key_id = settings.AWS_ACCESS_KEY_ID,
    aws_secret_access_key = settings.AWS_SECRET_ACCESS_KEY,
    region_name = settings.AWS_S3_REGION_NAME
)
s3_client = session.client('s3')

def upload_file_to_s3(local_path,bucket_path):
    myfile = local_path
    client = boto3.client(
        's3',
        region_name='us-east-1',
        aws_access_key_id=settings.AWS_ACCESS_KEY_ID,
        aws_secret_access_key=settings.AWS_SECRET_ACCESS_KEY
    )
    try:
        response = client.upload_file(
            myfile,
            settings.AWS_STORAGE_BUCKET_NAME,
            bucket_path,
            ExtraArgs={'ACL': 'public-read'}
        )
        url = "https://{}.s3.us-east-1.amazonaws.com/{}".format(
            settings.AWS_STORAGE_BUCKET_NAME, bucket_path)
        return True, url
    except Exception as e:
        print("S3", e)
        return False, None

def master_file_flow(file_request_id):
    """ Flow for master file submitted through file request form.

    Step 1: Read user's file submitted in the file request form.
    Step 2: Search ECU brand and ECU version from the directory model database.
    Step 3: Search for all realted original files in the database.
    Step 4: Get matching percentage from the original files.
    Step 5: calculate percentage match of original files.
    Step 6: Get version files form the directory of original.
    Step 7: Match version files (percentage match) form the directory of original.
    Step 8: Copy the content onto another file and create.
    Step 9: create the directory name.
    Step 10: create file at local in media folder to upload on s3.
    Step 11: Upload file on s3 cloud.

    Step X: Sent for manual handling.
    Args:
        file_request_id (file_request_id): str

    Returns:
        _type_: _description_
    """
    matching_found_in_path = ""
    random_generated_path = ""
    matching_files = []
    matching_original_data = []
    multipass_files_list = []

    is_file_match_success = True
    file_request_obj = FileRequest.objects.get(request_id = file_request_id)
    data = read_user_file_request(file_request_id)

    directories_to_search = search_based_on_form_data(file_request_obj, data)

    if len(directories_to_search) != 0:
        print("in original search")
        files_for_algorithm = get_s3_original_files(directories_to_search, file_request_obj)
        # print("=========files for algorithm===========")
        # print(files_for_algorithm)
        # print("=========files for algorithm===========")
        if len(files_for_algorithm) == 0:
            description = "No original files found."
            sent_for_manual_handling(file_request_obj, description)
            is_file_match_success = False
            return is_file_match_success, matching_found_in_path, random_generated_path
        else:
            try:
                matching_original_data = get_matching_ratio_df(files_for_algorithm, file_request_obj)
            except Exception as error:
                logger.info("get matching ratio error:".format(error))
    else:
        # sent_for_manual_handling(file_request_obj)
        is_file_match_success = False
        return is_file_match_success, matching_found_in_path, random_generated_path

    if len(matching_original_data) == 0:
        description = file_stage.MASTER_FILE_STAGE_MANUAL_1
        sent_for_manual_handling(file_request_obj, description)
        is_file_match_success = False
        return is_file_match_success, matching_found_in_path, random_generated_path
    else:
        for original_data in matching_original_data:
            version_files_list = get_version_files_from_dir(
                                original_data['matching_directory'],
                                file_request_obj)
            if len(version_files_list) > 0:
                break

    # Match version files list.

    # print("===========Version files list =========")
    # print(version_files_list)
    # print("===========Version files list =========")

    if len(version_files_list) > 0:
        version_data = match_version_files(original_data, version_files_list,
                                        file_request_obj)
    else:
        version_data = []
        # Multipass (single directory multiple files).
        matching_files = single_directory_multipass(matching_original_data, file_request_obj)

    if len(version_data) == 0 and len(matching_files) == 0:
        # Multipass (Multiple directory multiple files).
        multipass_files_list = multiple_directory_multipass(
                            matching_original_data, file_request_obj
                        )


    if (len(version_data) == 0 and 
        len(matching_files) == 0 and 
        len(multipass_files_list) == 0):
        logger.info("Manual handle.")
        description = file_stage.MASTER_FILE_STAGE_MANUAL_2
        sent_for_manual_handling(file_request_obj, description)
        is_file_match_success = False
        return is_file_match_success, matching_found_in_path, random_generated_path
    elif (len(version_data) > 0 and 
         len(matching_files) == 0 and 
         len(multipass_files_list) == 0):
        logger.info("Found in first pass.")
        version_file_hexa_list = version_data['version_file_hexa_list']
        original_file_hexa_list = original_data['matching_original_file_hexa_list']
        similar_original_file_hexadump_list = ast.literal_eval(file_request_obj.file_hexa_content_list)

        updated_similar_hexa_bytes = add_diff_to_similar_original_index_bytes(
                                    version_file_hexa_list,original_file_hexa_list,
                                    similar_original_file_hexadump_list, file_request_obj)

        dir_name_to_create = create_directory_name(version_data, file_request_obj)
        random_generated_path = dir_name_to_create
        matching_found_in_path = version_data['version_matching_directory']
        file_name = file_naming(file_request_obj)
        user_uploaded_file_name = file_request_obj.tuning_file.url.split("/")[-1]
        file_name_to_create = file_name

        local_file_name = create_version_file_at_local(file_name_to_create, updated_similar_hexa_bytes,
                                            dir_name_to_create)
        is_sucess, url = upload_file_s3(local_file_name, dir_name_to_create,
                                            file_name_to_create, file_request_obj)
        last_file_name = local_file_name

        if is_sucess:
            RequestDownloadFiles.objects.create(
                fil_request_id = file_request_obj,
                title = last_file_name,
                url = url
            )

        # Code for file name to give to user only.
        file_for_user = create_file_name_for_user(file_request_obj, last_file_name)
        file_for_user  = file_for_user.rstrip(' ')
        file_for_user = file_for_user.split('  ')[0]
        
        last_file_name = create_version_file_at_local(file_for_user, updated_similar_hexa_bytes,
                                            dir_name_to_create)
        is_sucess, url = upload_file_s3(last_file_name, dir_name_to_create,
                                            last_file_name, file_request_obj)

        RequestDownloadFiles.objects.create(
            fil_request_id = file_request_obj,
            title = file_for_user,
            url = url,
            sent_to_user = True
        )

    elif (len(version_data) == 0 and 
        len(matching_files) > 0 and 
        len(multipass_files_list) == 0):
        logger.info("Single directory single pass.")
        dir_name_to_create = create_directory_name(version_data, file_request_obj)
        random_generated_path = dir_name_to_create
        user_uploaded_file_name = file_request_obj.tuning_file.url.split("/")[-1]
        user_uploaded_file_name = clean_user_uploaded_file_name(user_uploaded_file_name)

        # original_file = 
        last_file_name = None
        for key,file in matching_files.items():
            matching_file = file[0]['file_name']

            file_json =  get_file_with_hex(matching_file)
            original_file_json = get_original_file_hex(file[0]['directory_name'])
            file_hex  = convert_to_n_size_block(file_json[0]['hex_dump'],8)
            original_file_hex  = convert_to_n_size_block(original_file_json[0]['hex_dump'],8)

            version_file_hexa_list = file_hex
            original_file_hexa_list = original_file_hex
            if last_file_name is None:
                refrence_file_name = create_refrence_file_name(matching_file, user_uploaded_file_name, True)
                similar_original_file_hexadump_list = ast.literal_eval(file_request_obj.file_hexa_content_list)
            else:
                user_uploaded_file_name = last_file_name
                refrence_file_name = create_refrence_file_name(matching_file, user_uploaded_file_name, False)
                with open(last_file_name, 'rb') as f:
                    similar_original_file_hex = binascii.hexlify(f.read()).decode()
                similar_original_file_hexadump_list = convert_to_n_size_block(similar_original_file_hex,8)

            # Save Flow.
            title = "copy difference onto User Submitted file."
            description = "Copy the difference between {0} and {1} \
                        onto user submitted file {2}.".format(
                            matching_file, original_file_json[0]['file_name'],
                            user_uploaded_file_name
                        )
            
            save_flow(file_request_obj, title, description, is_success = True)

            updated_similar_hexa_bytes = add_diff_to_similar_original_index_bytes(
                                        version_file_hexa_list,original_file_hexa_list,
                                        similar_original_file_hexadump_list, file_request_obj)
            last_file_name = create_version_file_at_local(refrence_file_name, updated_similar_hexa_bytes,
                                                dir_name_to_create)

            matching_found_in_path = file[0]['directory_name']

            is_sucess, url = upload_file_s3(last_file_name, dir_name_to_create,
                                                matching_file, file_request_obj)
        
            if is_sucess:
                RequestDownloadFiles.objects.create(
                    fil_request_id = file_request_obj,
                    title = create_file_names(file_request_obj),
                    url = url
                )

        # Code for file name to give to user only.
        file_for_user = create_file_name_for_user(file_request_obj, refrence_file_name)
        last_file_name = create_version_file_at_local(file_for_user, updated_similar_hexa_bytes,
                                            dir_name_to_create)
        is_sucess, url = upload_file_s3(last_file_name, dir_name_to_create,
                                            last_file_name, file_request_obj)
        RequestDownloadFiles.objects.create(
            fil_request_id = file_request_obj,
            title = file_for_user,
            url = url,
            sent_to_user = True
        )

    elif (len(version_data) == 0 and 
        len(matching_files) == 0 and 
        len(multipass_files_list) > 0):
        logger.info("Multiple directory multiple pass.")

        dir_name_to_create = create_directory_name(version_data, file_request_obj)
        random_generated_path = dir_name_to_create
        user_uploaded_file_name = file_request_obj.tuning_file.url.split("/")[-1]
        user_uploaded_file_name = clean_user_uploaded_file_name(user_uploaded_file_name)

        last_file_name = None
        # print("================= Multipass directoriesssssssssss =============")
        # print(multipass_files_list)
        # print("================= Multipass directoriesssssssssss =============")

        for file in multipass_files_list:
            matching_file = file['file_name']

            file_json =  get_file_with_hex(matching_file)
            original_file_json = get_original_file_hex(file['directory_name'])
            file_hex  = convert_to_n_size_block(file_json[0]['hex_dump'],8)
            original_file_hex  = convert_to_n_size_block(original_file_json[0]['hex_dump'],8)

            version_file_hexa_list = file_hex
            original_file_hexa_list = original_file_hex
            if last_file_name is None:
                refrence_file_name = create_refrence_file_name(matching_file, user_uploaded_file_name, True)
                similar_original_file_hexadump_list = ast.literal_eval(file_request_obj.file_hexa_content_list)
            else:
                user_uploaded_file_name = last_file_name
                refrence_file_name = create_refrence_file_name(matching_file, user_uploaded_file_name, False)
                with open(last_file_name, 'rb') as f:
                    similar_original_file_hex = binascii.hexlify(f.read()).decode()
                similar_original_file_hexadump_list = convert_to_n_size_block(similar_original_file_hex,8)
            
            # Save Flow.
            title = "copy difference onto User Submitted file."
            description = "Copy the difference between {0} and {1} \
                        onto user submitted file {2}.".format(
                            matching_file, original_file_json[0]['file_name'],
                            user_uploaded_file_name
                        )
            # print("==========here ============")
            save_flow(file_request_obj, title, description, is_success = True)

            updated_similar_hexa_bytes = add_diff_to_similar_original_index_bytes(
                                        version_file_hexa_list,original_file_hexa_list,
                                        similar_original_file_hexadump_list, file_request_obj)
            last_file_name = create_version_file_at_local(refrence_file_name, updated_similar_hexa_bytes,
                                                dir_name_to_create)

            matching_found_in_path = file['directory_name']

            is_sucess, url = upload_file_s3(last_file_name, dir_name_to_create,
                                                matching_file, file_request_obj)
            if is_sucess:
                RequestDownloadFiles.objects.create(
                    fil_request_id = file_request_obj,
                    title = create_file_names(file_request_obj),
                    url = url
                )

        # Code for file name to give to user only.
        file_for_user = create_file_name_for_user(file_request_obj, refrence_file_name)

        last_file_name = create_version_file_at_local(file_for_user, updated_similar_hexa_bytes,
                                            dir_name_to_create)
        is_sucess, url = upload_file_s3(last_file_name, dir_name_to_create,
                                            last_file_name, file_request_obj)

        # print("===============Dir name to create ===============")
        # print(url)
        # print("===============Dir name to create ===============")

        RequestDownloadFiles.objects.create(
            fil_request_id = file_request_obj,
            title = file_for_user,
            url = url,
            sent_to_user = True
        )

    # creating new directory after file-maker process.
    Directory.objects.create(
        directory_path = dir_name_to_create,
        ecu_producer = file_request_obj.ecu_brand,
        ecu_build = file_request_obj.ecu_version,
        created_by_filemaker = True,
        vehicle_type          = file_request_obj.vehicle_type,
        vehicle_producer      = file_request_obj.vehicle_make,
        vehicle_model         = file_request_obj.model,
        vehicle_model_year    = file_request_obj.vehicle_year,
        file_request          = file_request_obj
    )

    title = "File is presented to the user."
    description = "File is present to the user to download with name {0}:".format(last_file_name)
    save_flow(file_request_obj, title, description, True)

    # file_json = {
    #     "directory":dir_name_to_create,
    #     "refrence_made":last_file_name,
    #     "request_id":file_request_obj,
    #     "created_at":datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    # }

    # is_file_exists = RefrenceMadeFile.objects.filter(file_name = version_data['version_matching_file_name'])
    # if len(is_file_exists):
    #     refrence_obj = is_file_exists.first()
    #     refrence_data = refrence_obj.refrence_made
    #     refrence_data.append(file_json)
    #     refrence_obj.save()
    # else:
    #     RefrenceMadeFile.objects.create(
    #         file_name = version_data['version_matching_file_name'],
    #         file_directory = version_data['version_matching_directory'],
    #         refrence_made = file_json,
    #     )
    # upload_file_to_mongo(local_file_name, dir_name_to_create)

    return is_file_match_success, matching_found_in_path, random_generated_path


def search_based_on_form_data(file_request_obj, data):
    print("Step 2: Search ECU brand and ECU version from the files on cloud.")

    directories_to_search = []
    vehicle_type = file_request_obj.vehicle_type
    if vehicle_type == "Car":
        vehicle_type = "Passenger car"
    elif vehicle_type == "Truck":
        vehicle_type = "Truck"
    elif vehicle_type == "Tractor":
        vehicle_type = "Tractor"
    elif vehicle_type == "Boat":
        vehicle_type = "Boat"
    elif vehicle_type == "Bike":
        vehicle_type = "Motorbike"
    
    queryset =  Directory.objects.filter(
                    Q(ecu_producer__contains=data['ecu_brand']) | 
                    Q(ecu_build__contains=data['ecu_version']), 
                    vehicle_type__contains=vehicle_type
                ).values('directory_path')  

    if len(queryset) != 0:
        directories_to_search = [dir['directory_path'] for dir in queryset]

    if len(directories_to_search) != 0:
        title = "Search similar original files and database."
        description = file_stage.MASTER_FILE_STAGE_4.format("yes")
        save_flow(file_request_obj, title, description, True)
    else:
        description = file_stage.MASTER_FILE_STAGE_MANUAL
        sent_for_manual_handling(file_request_obj, description)

    return directories_to_search

def get_s3_original_files(prefix_list, file_request_obj):
    logger.info("Step 3: Search for all realted original files in the database")

    submitted_file_size_mb = file_request_obj.file_size
    submitted_file_size_bytes = submitted_file_size_mb * 1024 * 1024
    lower_file_size = submitted_file_size_bytes - 200000

    if len(prefix_list) != 0:
        # Mongo wihout error
        client = MongoClient(settings.MONGO_HOST, 27017)
        db = client['filemaker_directory']
        fs = GridFS(db)
        coll = db['directory']

        # prefix without main
        prefix_without_main = list(map(lambda x: x.replace('Main/',''), prefix_list))
        print(1)
        # mongo query


        # print("========================================")
        # print(prefix_without_main)
        # print("========================================")

        data = coll.find(
                    {'directory_name':{'$in':prefix_without_main}},
                    {'_id':0,'file_name': 1,'directory_name':2 }
                )
        json_data = ast.literal_eval(dumps(data))
        
        print(2)
        # print(json_data)

        # create dataframe.
        df = pd.DataFrame(json_data)

        # Get only files with name original in it.
        df = df[df["file_name"].str.contains("original", case=False)]

        # projection = {
        #     "_id": 1,
        #     "filename": 1,
        #     "length":1,
        # }

        # all original files for processing
        print("))))))))))))")
        original_files_list = df['file_name'].tolist()
        print(len(original_files_list))
        print("))))))))))))")

        collection = db['fs.files']
        query = {
            "filename":{'$in':original_files_list},
            "length": { "$gte": lower_file_size, "$lte": submitted_file_size_bytes},
        }
        cursor = collection.find(query)
        original_files_list = []
        for result in cursor:
            original_files_list.append(result['filename'])

        print("{{{{{{{}}}}}}}")
        print(len(original_files_list))
        print("{{{{{{{}}}}}}}")

        # mongo query
        data = fs.find({'filename':{'$in':original_files_list}})
        print(3)

        json_data = [
                        {'directory':file.metadata["directory_name"],
                        'hex_dump':binascii.hexlify(file.read()).decode(),
                        'original':file.filename
                    } for file in data]
        print(4)
        print(len(json_data))

        df = pd.DataFrame(json_data)
        # try:
        #     df["file_hexa_content_list"] = df.apply(lambda row: convert_to_n_size_block(row['hex_dump'],8), axis=1)
        # except Exception as error:
        #     print("=======error==============")
        #     print(error)
        print(5)
        try:
            block_generator = generate_blocks(df)
        except Exception as error:
            print("=======Error while converting to block.==============")
            print(error)
        df['file_hexa_content_list'] = list(block_generator)
        # print(df.head(5))

        files_for_algorithm = df.to_dict('records')
    else:
        return []
    # input()
    return files_for_algorithm

def get_matching_ratio2(hexdata1, hexdata2):
    logger.info("Step 4: Get matching percentage from the original files.")
    total_common_items = len(set(hexdata1)&set(hexdata2))
    total_distinct_items = float(len(set(hexdata1) | set(hexdata2)))
    percentage_diff = (total_common_items / total_distinct_items) * 100
    return percentage_diff

def sent_for_manual_handling(file_obj, description):
    """Check cases to sent for manual handling.

    Args:
        file_obj (file request object): _description_
        description (str): description to be set for filerequesthistory.
    """
    logger.info(f"Step X: Sent for manual handling(master-flow) | File Request : {file_obj.file_request_id}")
    sent_for_handle = True

    is_manual_handle = TicketCategory.objects.filter(name = "Manual Handle").exists()
    if not is_manual_handle:
        TicketCategory.objects.create(name="Manual Handle")

    if not TicketHistory.objects.filter(request_id=file_obj.file_request_id).exists():
        ticket =  TicketHistory.objects.create(
            created_by = file_obj.user,
            assigned_to = MyUser.objects.get(email='technical@viezu.com'
                        ) if MyUser.objects.filter(email='technical@viezu.com'
                        ).exists() else None,
            category = TicketCategory.objects.get(name='Manual Handle'
                        ) if TicketCategory.objects.filter(name='Manual Handle'
                        ).exists() else None,
            file_request = file_obj,
            request_id = file_obj.request_id,
            subject="File Request to be manually handle.",
            ticket_status = TicketStatus.objects.get(team_status="New")
        )
        ticket.update_ids()
        logger.info(f"ticket created : {ticket}")

    file_obj.status = "Manual handle"
    file_obj.save()

    title = "Sent to manual handling."
    is_success = True

    save_flow(file_obj, title, 
            description, is_success) 

    file_request_status_change(file_obj.user,file_obj)

    admin_user = MyUser.objects.get(email='technical@viezu.com')
    triger_socket({
        'uuid':str(admin_user.uuid),
        'type':'admin_file_assigned',
        'ids':str(file_obj.request_id),
        'created_at':str(file_obj.created_at),
        'message':"File is assigned for manual handle:{}.".format(file_obj.request_id)
    })
    
    return sent_for_handle

def get_matching_ratio_df(files_for_algorithm, file_request_obj):
    start_time = datetime.now()

    logger.info("Step 5: calculate percentage match of original files.")
    df = pd.DataFrame(files_for_algorithm)
    similar_original_file_hexadump_list = ast.literal_eval(file_request_obj.file_hexa_content_list)
    try:
        df["percentage"] = df.apply(lambda row: 
                        get_matching_ratio2(
                            row["file_hexa_content_list"], 
                            similar_original_file_hexadump_list), axis=1)
    except Exception as error:
        logger.error(error)

    ecu_brand = file_request_obj.ecu_brand
    ecu_version = file_request_obj.ecu_version

    ecu_matching_percentage = DataEcuVersion.objects.filter(
                    Q(brand__brand_name = ecu_brand),
                    Q(ecu_version_name=ecu_version))

    df = df.sort_values(by=['percentage'], ascending=False)
    df = df[df['percentage'] >= ecu_matching_percentage[0].percentage]

    print(df[['directory','percentage']])

    df.rename(columns =  {
            'original':'matching_file_name',
            'directory':'matching_directory',
            'percentage':'matching_percentage',
            'file_hexa_content_list':'matching_original_file_hexa_list'
        },inplace = True)
    data = df.to_dict('records')   
    end_time = datetime.now()
    second_diff = end_time - start_time

    if len(data) > 0:
        FileRequestAveragePerformance.objects.create(
            file_request_obj = file_request_obj,
            file_type = file_request_obj.file_type,
            original_found = True,
            original_found_time = second_diff.seconds
        )
    else:
        FileRequestAveragePerformance.objects.create(
            file_request_obj = file_request_obj,
            file_type = file_request_obj.file_type,
            original_not_found = True,
            original_not_found_time = second_diff.seconds
        )

    return data

def get_version_files_from_dir(version_directory, file_request_obj):
    logger.info("Step 6: Get version files form the directory of original.")

    client = MongoClient(settings.MONGO_HOST, 27017)
    db = client['filemaker_directory']
    coll = db['directory']
    fs = GridFS(db)

    # mongo query
    data = coll.find(
                {'directory_name':version_directory},
                {'_id':0,'file_name': 1,'directory_name':2 }
            )
    json_data = ast.literal_eval(dumps(data))

    # create dataframe.
    df = pd.DataFrame(json_data)

    tuning_required = file_request_obj.tuning_required
    additional_function = file_request_obj.additional_function

    additional_function = get_upper_additional_function(additional_function)
    search_terms = get_search_terms(tuning_required)

    tuning_term = search_terms.upper()

    #Search based on tuning term and additional functions
    if len(additional_function) > 0 and tuning_term != '':
        print(1)
        combinations, combinations_to_list = get_combinations(tuning_term, additional_function)
        files_to_search = additional_search(tuning_term, combinations)
        version_file_data = get_version_file_match_or_not(files_to_search, json_data)
    # Search based on tuning term
    elif len(additional_function) == 0 and tuning_term != '':
        print(2)
        updated_tuning_term = tuning_term+')'
        files_to_search = [updated_tuning_term]
        version_file_data = get_version_file_match_or_not(files_to_search, json_data)
    # Search based on NO TUNE
    elif len(additional_function) > 0 and tuning_term == '':
        print(3)
        combinations, combinations_to_list = get_combinations(tuning_term, additional_function)
        files_to_search = additional_search(tuning_term, combinations)
        version_file_data = get_version_file_match_or_not(files_to_search, json_data)

    version_file_data = [] if version_file_data is None else version_file_data
    if version_file_data != []:
        version_file_data = [version_file_data]
    version_files_list = [file['file_name'] for file in version_file_data]

    # mongo query
    data = fs.find({'filename':{'$in':version_files_list}})

    json_data = [
                    {'version_directory':file.metadata["directory_name"],
                    'version_original_file_hexadump':binascii.hexlify(file.read()).decode(),
                    'version_original':file.filename
                } for file in data]

    df = pd.DataFrame(json_data)

    # print("===========df==================")
    # print(df)
    # print("===========df==================")

    if df.empty:
        logger.info("In empty dataframe.")
        version_files_list = []
        title = "Search for version files."
        additional_str = ",".join(additional_function)
        description = "No file found with {} {} in directory in single pass:{}".format(search_terms, 
                                                    additional_str, version_directory)

        save_flow(file_request_obj,title=title, 
                description=description, is_success=True)
        return version_files_list
    else:
        title = "Search for version files."
        additional_str = ",".join(additional_function)
        description = "File found with {} {} in directory:{}".format(search_terms, 
                                                    additional_str, version_directory)

        save_flow(file_request_obj,title=title, 
                description=description, is_success=True)
        df["version_file_hexa_content_list"] = df.apply(lambda row: convert_to_n_size_block(row['version_original_file_hexadump'],8), axis=1)

        version_files_list = df.to_dict('records')

        title = "Search for version files."
        description = file_stage.MASTER_FILE_STAGE_6
        save_flow(file_request_obj,title=title, 
                description=description, is_success=True)
    
    return version_files_list

def check_string_exists(version_files, data):
    version_files_list = []
    for file in version_files:
        f = file
        f = f.split(")")
        if len(f) > 0:
            f = f[0].split(" ")
        
        count = 0
        for i in data:
            if i in file:
                count +=1
                
        if len(f) == count:
            version_files_list.append(file)
    
    # print(version_files)
    return version_files_list

def file_naming(file_request_obj):
    tuning_required = file_request_obj.tuning_required
    additional_function = file_request_obj.additional_function

    if tuning_required == "VBLUE/ECO":
        search_terms = "(VBLUE "
    elif tuning_required == "VBLEND/STAGE 0.5":
        search_terms = "(VBLEND "
    elif tuning_required == "VPERF/STAGE 1":
        search_terms = "(VPERF "
    elif tuning_required == "VRACE/STAGE 2":
        search_terms = "(VRACE "
    elif tuning_required == "NO TUNE":
        search_terms = "("

    if additional_function is not None:
        if len(additional_function) > 0:
            additional_function = file_request_obj.additional_function.split(",")
            additional_function = list(map(lambda x:x.upper().strip(), additional_function))
    else:
        additional_function = []
    
    join_str = " ".join(additional_function)
    file_name = search_terms+join_str+')'

    return file_name

def match_version_files(data, version_files_list, file_request_obj):
    logger.info("Step 7: Match version files (percentage match) form the directory of original.")

    start_time = datetime.now()
    version_data = {}
    similar_original_file_hexadump_list = data['matching_original_file_hexa_list']
    df = pd.DataFrame(version_files_list)

    try:
        df["percentage"] = df.apply(lambda row: 
                        get_matching_ratio2(
                            row["version_file_hexa_content_list"], 
                            similar_original_file_hexadump_list), axis=1)
    except Exception as error:
        logger.error(error)

    # print(df[['directory_name','percentage']])
    
    df = df[df.percentage == df.percentage.max()]
    # Get max original data from df

    end_time = datetime.now()
    second_diff = end_time - start_time

    if df.iloc[0]['percentage'] == 0:
        title = file_stage.MASTER_FILE_STAGE_7
        description = "No version file found or found with percentage zero."
        save_flow(file_request_obj,title=title, description=description, is_success=True)
        FileRequestAveragePerformance.objects.create(
            file_request_obj = file_request_obj,
            file_type = file_request_obj.file_type,
            refrence_not_found = True,
            refrence_not_found_time = second_diff.seconds
        )
    else:
        version_data['version_matching_directory'] = df.iloc[0]['version_directory']
        version_data['version_matching_file_name'] = df.iloc[0]['version_original']
        version_data['version_matching_percentage'] = df.iloc[0]['percentage']
        version_data['version_file_hexa_list'] = df.iloc[0]['version_file_hexa_content_list']
        title = file_stage.MASTER_FILE_STAGE_7
        description = "File name:{}, directory:{}, matching percentage:{}".format(
                                        version_data['version_matching_file_name'],
                                        version_data['version_matching_directory'],
                                        version_data['version_matching_percentage']
                                    )

        FileRequestAveragePerformance.objects.create(
            file_request_obj = file_request_obj,
            file_type = file_request_obj.file_type,
            refrence_found = True,
            refrence_found_time = second_diff.seconds
        )

        save_flow(file_request_obj,title=title, 
                description=description, is_success=True)

    return version_data

def add_diff_to_similar_original_index_bytes(
                            version_hexa, new_version_hexa,
                            similar_hexa, file_request_obj):
    logger.info("Step 8: Copy the content onto another file and create.")
    
    version_hexa_str = "".join(version_hexa)
    version_bytes = binascii.unhexlify(version_hexa_str)

    new_file_version_str = "".join(new_version_hexa)
    new_file_version_bytes = binascii.unhexlify(new_file_version_str)

    similar_file_version_str = "".join(similar_hexa)
    similar_file_version_bytes = binascii.unhexlify(similar_file_version_str)

    new_file_version_bytes_array = list(new_file_version_bytes)
    similar_file_version_bytes_array = list(similar_file_version_bytes)

    min_len = min(map(len, (version_bytes, new_file_version_bytes)))
    count = 0
    for i in range(min_len): # use smaller length
        if (version_bytes[i] != new_file_version_bytes[i]):
            # print("index:{0} file1:{1} file2:{2}".format(
            #     i,version_bytes[i], new_file_version_bytes[i]))
            # new_file_version_bytes_array[i] = version_bytes[i]

            similar_file_version_bytes_array[i] = version_bytes[i]
            count +=1
    result = bytes(similar_file_version_bytes_array)

    title = "copying content onto another file."
    description = "copying content."
    save_flow(file_request_obj,title=title, 
            description=description, is_success=True)

    return result

def save_flow(file_request_obj, title, 
            description, is_success,
            additional_information=''):
    logger.info("save flow")
    FileRequestHistory.objects.create(
            file_request_id = file_request_obj,
            title = title,
            description = description,
            is_success = is_success,
            additional_information=additional_information
    )
    
    return True

def create_directory_name(version_data, file_request_obj):
    logger.info("Step 9: create the directory name.")
    import string
    import random
    N = 7
    res = ''.join(random.choices(string.ascii_uppercase +
                                string.digits, k=N))

    if 'version_matching_directory' in version_data:
        split_dir = version_data['version_matching_directory'].split("/")
        final_dir_name = split_dir[0]+"/"+split_dir[-1]+"_"+res
    else:
        split_dir = file_request_obj.vehicle_registration if file_request_obj.vehicle_registration else ''
        final_dir_name = split_dir+"_"+res

    return final_dir_name

def create_version_file_at_local(file_name, file_content, dir_name_to_create):
    dir_to_create_at_local = dir_name_to_create.split("/")[-1]
    local_media_folder_name = 'media/{}'.format(dir_to_create_at_local)

    isExist = os.path.exists(local_media_folder_name)
    if not isExist:
        print("creating folder")
        os.makedirs(local_media_folder_name)

    logger.info("Step 10: create file at local in media folder to upload on s3.")
    local_file_name = 'media/{}/{}'.format(dir_to_create_at_local, file_name)
    file = open(local_file_name, 'wb')
    file.write(file_content)
    file.close()
    return local_file_name

def upload_file_s3(local_file_name, dir_name_to_create, 
                file_name_to_create, file_request_obj):
    logger.info("Step 11: Upload file on s3 cloud.")
    is_sucess, url = upload_file_to_s3(local_file_name,"{}/{}".format(dir_name_to_create,file_name_to_create))
    
    title = file_stage.MASTER_FILE_STAGE_8
    description = "File and directory created.:{}".format(dir_name_to_create)
    save_flow(file_request_obj,title=title, 
            description=description, is_success=True)
    return is_sucess, url

def get_combinations(tuning_term:str, additional_function:list):
    from itertools import permutations

    tuning_list = [tuning_term]
    combinations_to_list = tuning_list + additional_function
    combinations = permutations(combinations_to_list,2)
    return combinations, combinations_to_list

def multi_pass_files(combinations:object, combinations_to_list:list):
    
    files_to_search = []
    for comb in combinations:
        str = " ".join(list(comb))
        data = {}
        to_remove = str.split(" ")        
        not_in_list = list(filter(lambda i: i not in to_remove, combinations_to_list))
        data['comb'] = str
        data['not_in_comb'] = not_in_list[0]
        files_to_search.append(data)
    
    return files_to_search        
    
def additional_search(tuning_term:str, combinations:object):
    files_to_search = []

    for comb in combinations:
        if tuning_term != '' and tuning_term in comb:
            str = " ".join(list(comb))
            files_to_search.append(str)
        if tuning_term == '' and '' not in comb:
            str = " ".join(list(comb))
            files_to_search.append(str)
        if tuning_term == '' and '' in comb:
            str = " ".join(list(comb)).strip()
            files_to_search.append(str)
    
    return files_to_search 


def get_version_file_match_or_not(files_to_search, json_data):

    # print("===========File to search ================")
    # print(files_to_search)
    # print("===========File to search ================")

    found_directory = None
    for file_name in files_to_search:
        
        for directory in json_data:
            if file_name in directory['file_name']:
                found_directory = directory
                break
    # print("==========Found directory ===============")
    # print(found_directory)
    # print("==========Found directory ===============")
    return found_directory

def get_upper_additional_function(additional_function):
    """ Get uppercase additional function.  """

    if additional_function is not None:
        additional_function = additional_function.split(",")
        additional_function = list(map(lambda function_name:function_name.upper().strip(), additional_function))
    else:
        additional_function = []
    
    return additional_function

def get_search_terms(tuning_required):
    """ Get search terms in str format.

    Args:
        tuning_required (str): _description_

    Returns:
        str: Search terms
    """

    if tuning_required == "VBLUE/ECO":
        search_terms = "vblue"
    elif tuning_required == "VBLEND/STAGE 0.5":
        search_terms = "vblend"
    elif tuning_required == "VPERF/STAGE 1":
        search_terms = "vperf"
    elif tuning_required == "VRACE/STAGE 2":
        search_terms = "vrace"
    elif tuning_required == "NO TUNE":
        search_terms = ''

    return search_terms

def get_files_from_dir(version_directory):

    client = MongoClient(settings.MONGO_HOST, 27017)
    db = client['filemaker_directory']
    coll = db['directory']
    fs = GridFS(db)

    # mongo query
    data = coll.find(
                {'directory_name':version_directory},
                {'_id':0,'file_name': 1,'directory_name':2 }
            )
    json_data = ast.literal_eval(dumps(data))

    return json_data

def get_files_by_query_from_dir(query):

    client = MongoClient(settings.MONGO_HOST, 27017)
    db = client['filemaker_directory']
    coll = db['directory']
    fs = GridFS(db)

    # mongo query
    data = coll.find(
                query,
                {'_id':0,'file_name': 1,'directory_name':2 }
            )
    json_data = ast.literal_eval(dumps(data))

    return json_data

def get_file_with_hex(file_name):
    client = MongoClient(settings.MONGO_HOST, 27017)
    db = client['filemaker_directory']
    fs = GridFS(db)

    data = fs.find({'filename':{'$in':[file_name]}})

    json_data = [
                    {'directory':file.metadata["directory_name"],
                    'hex_dump':binascii.hexlify(file.read()).decode(),
                    'file_name':file.filename
                } for file in data]
    
    return json_data

def get_original_file_hex(directory_name):
    client = MongoClient(settings.MONGO_HOST, 27017)
    db = client['filemaker_directory']
    coll = db['directory']
    fs = GridFS(db)

    # mongo query
    data = coll.find(
                {'directory_name':{'$in':[directory_name]}},
                {'_id':0,'file_name': 1,'directory_name':2 }
            )
    json_data = ast.literal_eval(dumps(data))
    # create dataframe.
    df = pd.DataFrame(json_data)

    # Get only files with name original in it.
    df = df[df["file_name"].str.contains("original", case=False)]
    original_files_list = df['file_name'].tolist()

    # mongo query
    data = fs.find({'filename':{'$in':original_files_list}})

    json_data = [
                    {'directory':file.metadata["directory_name"],
                    'hex_dump':binascii.hexlify(file.read()).decode(),
                    'file_name':file.filename
                } for file in data]
    
    return json_data


def single_directory_multipass(matching_original_data, file_request_obj):
    logger.info("In single directory multipass.")

    matching_files = {}

    tuning_required = file_request_obj.tuning_required
    additional_function = file_request_obj.additional_function

    additional_function = get_upper_additional_function(additional_function)
    search_terms = get_search_terms(tuning_required)
    search_terms = search_terms.upper()

    combinations, combinations_to_list = get_combinations(search_terms, additional_function)
    for original_data in matching_original_data:
        json_data = get_files_from_dir(original_data['matching_directory'])
        for comb in combinations:
            to_search = " ".join(list(comb))
            not_in_list = list(filter(lambda i: i not in comb, combinations_to_list))
            if len(not_in_list) > 0:
                not_in_list = not_in_list[0]
                is_not_in_list_in_dir = [dir for dir in json_data if not_in_list in dir['file_name']]
                is_to_search_in_dir = [dir for dir in json_data if to_search in dir['file_name']]
            else:
                not_in_list = []
                is_not_in_list_in_dir = []
                is_to_search_in_dir = []

            if len(is_not_in_list_in_dir) > 0 and len(is_to_search_in_dir) > 0:

                title = "Searching and found different files in single directory."
                description = "Search for {} and {} file in {} directory.".format(
                                        not_in_list, to_search,
                                        original_data['matching_directory'])
                save_flow(file_request_obj, title, description, True)

                matching_files = {
                    'matching_ref_1':is_not_in_list_in_dir,
                    'matching_ref_2':is_to_search_in_dir
                }
                return matching_files
    
    title = "No file found in Single directory single pass."
    additional_str = ",".join(additional_function)
    description = "No file found with {} and  {} in same directory \
                    and  multiple files.".format(search_terms, additional_str)

    save_flow(file_request_obj, title, description, is_success = True)

    return matching_files

def clean_user_uploaded_file_name(file_name):
    
    if "original" in file_name:
        f = file_name.replace("original","(original)")
    else:
        f= file_name

    upper_file_name = f.upper()
    splitted_file_name = upper_file_name.split(".")

    if "OLS" in splitted_file_name:
        file_name = "".join(splitted_file_name)
        file_name = file_name.replace("OLS",".ols")
    
    if "OLS" not in splitted_file_name:
        file_name = splitted_file_name[-1]

    return file_name

def create_refrence_file_name(file_name, user_file_name, 
                            is_initial_file = True):
    final_file_name = ''

    last_file_name = user_file_name
    if is_initial_file:
        file_name = file_name.split(")")
        file_name = file_name[0].split("(")
        file_name = file_name[-1]
        
        user_file_name = user_file_name.split(")")
        if user_file_name[-1] == '':
            user_file_name = user_file_name[0]
            if "(ORIGINAL" in user_file_name or "(original" in user_file_name:
                user_file_name = user_file_name.replace("(ORIGINAL","")
                user_file_name = user_file_name.replace("(original","")
        else:
            user_file_name = user_file_name[-1] 
   
        final_file_name = "("+file_name+")"+user_file_name

    else:
        user_file_name = user_file_name.split(")")[0].split("(")[-1]
        previous_file_name_list = file_name.split("(")
        previous_file_name_list[0] = "("+user_file_name+" "
        final_file_name = "".join(previous_file_name_list)
        final_file_name = final_file_name.split(")")
        last_file_name = last_file_name.split("/")[-1].split(")")[-1]
        final_file_name = final_file_name[0]+")"+last_file_name

    return final_file_name

def create_functions_list(tuning_required, additional_functions):

    functions = {}
    for fun in additional_functions:
        functions[fun] = False
        
    functions.update({tuning_required:False})
    return functions

    
def multipass_get_combinations(tuning_term, additional_function, 
                    comb_count=3, combinatons_list = []):
    from itertools import permutations

    tuning_list = [tuning_term]
    combinations_to_list = tuning_list + additional_function
    combinations = permutations(combinations_to_list,comb_count)
    for comb in combinations:
        combinatons_list.append(comb)
    comb_count -= 1
    if comb_count == 0:
        return combinatons_list, combinations_to_list
    return multipass_get_combinations(tuning_term, additional_function, 
                            comb_count, combinatons_list)

def multiple_directory_multipass(matching_original_data, file_request_obj):
    logger.info("In multiple directory multipass.")

    tuning_required = file_request_obj.tuning_required
    additional_function = file_request_obj.additional_function

    additional_function = get_upper_additional_function(additional_function)
    search_terms = get_search_terms(tuning_required)
    search_terms = search_terms.upper()
    functions = create_functions_list(search_terms, additional_function)

    combinations_list, combinations_to_list = multipass_get_combinations(search_terms, additional_function)
    str_combinations_list = ["("+" ".join(list(comb))+")" for comb in combinations_list]
    str_combinations_list.reverse()

    # print("======== STR combinations list ================")
    # print(str_combinations_list)
    # print(functions)
    # print("======== STR combinations list ================")

    files_list = []
    for original_data in matching_original_data:
            files_list.extend(get_files_from_dir(original_data['matching_directory']))

    functions_list = list(functions.keys())

    # print("============ Files list ==================")
    # print(files_list)
    # print("============ Files list ==================")

    multipass_files_list = []
    for comb in str_combinations_list:
        for file in files_list:
            replaced_comb = comb.replace("(","")
            replaced_comb = replaced_comb.replace(")","")
            replaced_comb_list = replaced_comb.split(" ")
            if comb in file['file_name'] and False in functions.values():
                multipass_files_list.append(file)

                if len(replaced_comb_list) == 1:
                    to_update = replaced_comb_list[0]
                if to_update in comb:
                    functions[to_update] = True

    if False in functions.values():
        multipass_files_list = []
        title = "No file found in multipass."
        additional_str = ",".join(additional_function)
        description = "No file found with {} {} in any directory \
                     during multi-pass.".format(search_terms, additional_str)

        save_flow(file_request_obj, title, description, is_success = True)
        return multipass_files_list
    else:
        return multipass_files_list

def create_file_names(file_request_obj):
    
    tuning_required = file_request_obj.tuning_required
    additional_function = file_request_obj.additional_function
    vehicle_registration = file_request_obj.vehicle_registration

    if tuning_required == "VBLUE/ECO":
        search_terms = "ECONOMY "
    elif tuning_required == "VBLEND/STAGE 0.5":
        search_terms = "BLEND "
    elif tuning_required == "VPERF/STAGE 1":
        search_terms = "PERFORMANCE "
    elif tuning_required == "NO TUNE":
        search_terms = "("

    if additional_function is not None:
        if len(additional_function) > 0:
            additional_function = file_request_obj.additional_function.split(",")
            additional_function = list(map(lambda x:x.upper().strip(), additional_function))
    else:
        additional_function = []
    
    join_str = " ".join(additional_function)
    file_name = vehicle_registration +' '+search_terms+' '+join_str

    return file_name

def create_file_name_for_user(file_request_obj, file_name):

    tuning_required = file_request_obj.tuning_required
    vehicle_registration = file_request_obj.vehicle_registration

    file_name = file_name.split("(")[-1]
    file_name = file_name.split(")")

    if tuning_required == "VBLUE/ECO":
        search_terms = "ECONOMY "
    elif tuning_required == "VBLEND/STAGE 0.5":
        search_terms = "BLEND "
    elif tuning_required == "VPERF/STAGE 1":
        search_terms = "PERFORMANCE "
    elif tuning_required == "NO TUNE":
        search_terms = "("

    final_file_name = vehicle_registration +' '+search_terms + ' '+file_name[0]
    return final_file_name

# RefrenceMadeFile.objects.create(
#     file_name = version_data['version_matching_file_name'],
#     file_directory = version_data['version_matching_directory'],
#     refrence_made = file_json,
# )
