from botocore.exceptions import ClientError

from apps.utils.helper import triger_socket
import boto3
import os
from apps.utils.models import InternalErrorLog
from django.conf import settings
from apps.admin_management.models import Directory

session = boto3.Session(
    aws_access_key_id=settings.AWS_ACCESS_KEY_ID,
    aws_secret_access_key=settings.AWS_SECRET_ACCESS_KEY,
    region_name=settings.AWS_S3_REGION_NAME
)
s3_client = session.client('s3')


def main_directory_folders(prefix="Main/"):
    data = []
    response = s3_client.list_objects_v2(Bucket=settings.AWS_STORAGE_BUCKET_NAME, Prefix=prefix)
    for content in response.get('Contents', []):
        folder = {'folder': os.path.dirname(content['Key']).split("/")[-1], 'last_modified': content['LastModified']}
        data.append(folder)

    data = list({v['folder']: v for v in data}.values())
    data = sorted(data, key=lambda k: (k['last_modified']), reverse=True)

    return data

def get_sub_files(prefix=''):
    """
    Get sub-files from directories in an S3 bucket, ensuring no duplicate base names.
    Args:
        prefix (str, optional): Path from where files should be listed. Defaults to ''.
    Returns:
        sub_dir (list): List of distinct files in a folder with their last modified dates.
    """
    s3 = session.resource('s3')
    # my_bucket = s3.Bucket(settings.AWS_STORAGE_BUCKET_NAME) # old code
    my_bucket = s3.Bucket('filemaker-stage') # latest code

    sub_dir = []
    file_names = []  # List to hold distinct file names
    exact_files_found = False  # Flag to indicate if direct files are found

    # Ensure the prefix ends without a trailing slash to consider only direct files
    base_prefix = prefix.rstrip('/')
    print(f"base_prefix : {base_prefix}")

    # Check for direct files (not in subfolders)
    for obj in my_bucket.objects.filter(Prefix=base_prefix):
        file_name = obj.key.split("/")[-1].strip()

        if "/" not in obj.key[len(base_prefix):]:  # Ensure it's a direct file, not from a subfolder
            if file_name != "":
                file_names.append(file_name)
                dir_info = {
                    'folder': file_name,
                    'last_modified': obj.last_modified
                }
                sub_dir.append(dir_info)
                exact_files_found = True

    # If direct files are found, return them immediately without processing subfolders
    if exact_files_found:
        return sub_dir

    # If no direct files, check subfolders
    for obj in my_bucket.objects.filter(Prefix=prefix):
        file_name = obj.key.split("/")[-1].strip()

        if file_name != "":
            file_names.append(file_name)
            dir_info = {
                'folder': file_name,
                'last_modified': obj.last_modified
            }
            sub_dir.append(dir_info)

    return sub_dir


def download_file(filename, filepath):
    is_file_download = False
    try:
        session.resource('s3').Bucket(settings.AWS_STORAGE_BUCKET_NAME).download_file(filename, filepath)
        is_file_download = True
    except Exception as error:
        print("Error", error)
        InternalErrorLog.objects.create(
            error=str(error),
            action="Download S3 File.",
            module="Directory"
        )
        is_file_download = False
    return is_file_download


def rename_dir():
    pass


def rename_file(filepath_with_name, new_name):
    """Not working."""

    try:
        response = s3_client.list_objects_v2(Bucket=settings.AWS_STORAGE_BUCKET_NAME, Prefix=filepath_with_name)
        source_key = response["Contents"][0]["Key"]
        copy_source = {'Bucket': settings.AWS_STORAGE_BUCKET_NAME, 'Key': source_key}
        s3_client.copy_object(Bucket=settings.AWS_STORAGE_BUCKET_NAME, CopySource=copy_source, Key=new_name)
        s3_client.delete_object(Bucket=settings.AWS_STORAGE_BUCKET_NAME, Key=source_key)
        return True
    except:
        return False


def delete_directory(path):
    is_directory_deleted = False
    s3 = session.resource('s3')
    my_bucket = s3.Bucket(settings.AWS_STORAGE_BUCKET_NAME)
    try:
        my_bucket.objects.filter(Prefix=path).delete()
        is_directory_deleted = True
    except Exception as error:
        is_directory_deleted = False
        InternalErrorLog.objects.create(
            error=str(error),
            action="Delete S3 File.",
            module="Directory"
        )
        print(error)

    return is_directory_deleted


def delete_file(file_path):
    """ Delete a file from s3 bucket.

    Args:
        file_path (str): filepath to delete from s3

    Returns:
        is_file_deleted(boolean): if a file is deleted or not.
    """
    is_file_deleted = False
    s3 = session.resource('s3')
    my_bucket = s3.Bucket(settings.AWS_STORAGE_BUCKET_NAME)
    try:
        my_bucket.objects.filter(Prefix=file_path).delete()
        is_file_deleted = True
    except Exception as error:
        is_file_deleted = False
        InternalErrorLog.objects.create(
            error=str(error),
            action="Delete S3 File.",
            module="Directory"
        )
        print(error)

    return is_file_deleted


def upload_file_to_s3(file, filepath, filename):
    is_file_uploaded = False
    try:
        s3_client.upload_fileobj(file, Bucket=settings.AWS_STORAGE_BUCKET_NAME, Key=filepath + filename)
        is_file_uploaded = True
    except Exception as error:
        print("Error", error)
        InternalErrorLog.objects.create(
            error=str(error),
            action="upload S3 File.",
            module="Directory",
        )
        is_file_uploaded = False
    return is_file_uploaded


def create_directory_s3(dir_path):
    """Create directory in s3 bucket.

    Args:
        dir_path (str): directory path to create in s3 exa: "Main/Folder1

    Returns:
        is_dir_created(Boolean): If directory creaed or not.
    """
    is_dir_created = False
    s3 = session.resource('s3')
    try:
        s3_client.put_object(Bucket=settings.AWS_STORAGE_BUCKET_NAME, Key=(dir_path + '/'))
        is_dir_created = True
    except Exception as error:
        print("Error", error)
        InternalErrorLog.objects.create(
            error=str(error),
            action="create S3 Folder.",
            module="Directory",
        )
        is_dir_created = False
    return is_dir_created


def IsObjectExists(path):
    """Check if folder exists already.

    Args:
        path (str): string path to check.

    Returns:
        Boolean: if folder exists or not.
    """
    s3 = session.resource('s3')
    my_bucket = s3.Bucket(settings.AWS_STORAGE_BUCKET_NAME)
    for object_summary in my_bucket.objects.filter(Prefix=path):
        return True
    return False


def upload_zip_file(file, path_to_upload):
    is_zip_uploaded = False

    try:
        s3_client.upload_fileobj(file, settings.AWS_STORAGE_BUCKET_NAME, path_to_upload)
        is_zip_uploaded = True
    except Exception as err:
        print("Error", err)
        InternalErrorLog.objects.create(
            error=str(err),
            action="upload zip Folder.",
            module="Directory",
        )
        is_zip_uploaded = False

    return is_zip_uploaded


def read_ini_file1(uuid):
    s3 = session.resource('s3')
    bucket = s3.Bucket('filemaker-stage')
    count = 0
    for obj in bucket.objects.filter(Prefix='Main/'):
        # print(count)
        key = obj.key
        ini_fil_details = {}
        if key.endswith('.ini'):
            body = obj.get()['Body'].read().decode('utf-8')
            for line in body.split('\n'):
                try:
                    name, var = line.partition("=")[::2]
                    ini_fil_details[name.strip()] = var
                except:
                    pass
            split_path = key.split('/')
            instance, _ = Directory.objects.get_or_create(
                directory_path='/'.join(split_path[:-1]),
                ini_file_path=key
            )
            instance.vehicle_type = ini_fil_details.get('VehicleType', None)
            instance.vehicle_producer = ini_fil_details.get('VehicleProducer', None)
            instance.vehicle_series = ini_fil_details.get('VehicleSeries', None)
            instance.vehicle_model = ini_fil_details.get('VehicleModel', None)
            instance.vehicle_model_year = ini_fil_details.get('VehicleModelyear', None)
            instance.ecu_use = ini_fil_details.get('EcuUse', None)
            instance.ecu_producer = ini_fil_details.get('EcuProducer', None)
            instance.ecu_build = ini_fil_details.get('EcuBuild', None)
            instance.ecu_prodnr = ini_fil_details.get('EcuProdNr', None)
            instance.ecu_software_version = ini_fil_details.get('EcuSoftwareVersion', None)
            instance.ecu_stgnr = ini_fil_details.get('EcuStgNr', None)
            instance.engine_name = ini_fil_details.get('EngineName', None)
            instance.engine_type = ini_fil_details.get('EngineType', None)
            instance.engine_displacement = ini_fil_details.get('EngineDisplacement', None)
            instance.save()
            count += 1
            print(count)

    print("Initial database sync done.")

    triger_socket({
        'uuid': str(uuid),
        'type': 'admin_cloud_sync_completed',
        'message': "Syncing has been completed sucessfully in initial database, you will receive a mail once all file uploaded to secondary database."
    })

    from apps.utils.tasks import read_s3_files_to_mongo, remove_duplicate_dir
    read_s3_files_to_mongo.delay()
    remove_duplicate_dir.delay()


from django.db.models import Count, F


def read_ini_file(uuid):
    s3 = session.resource('s3')
    bucket = s3.Bucket('filemaker-stage')
    count = 0
    total_count = sum(1 for obj in bucket.objects.filter(Prefix='Main/') if obj.key.endswith('.ini'))
    print(f"Total files under 'Main/': {total_count}")
    # Process the .ini files and update or create Directory instances
    for obj in bucket.objects.filter(Prefix='Main/'):
        key = obj.key
        ini_fil_details = {}

        if key.endswith('.ini') and len(key.split('/')) == 2:
            try:
                body = obj.get()['Body'].read().decode('utf-8')
            except UnicodeDecodeError as e:
                print(f"UnicodeDecodeError encountered: {e}. Attempting to decode with ISO-8859-1.")
                body = obj.get()['Body'].read().decode('ISO-8859-1')
            for line in body.split('\n'):
                try:
                    name, var = line.partition("=")[::2]
                    ini_fil_details[name.strip()] = var.strip()
                except Exception as e:
                    print(f"Error processing line: {line}, error: {e}")
                    pass

            split_path = key.split('/')
            file_name = split_path[1]
            # if len(split_path) > 2:
            #     # If there are more than two parts, there is a subfolder structure
            #     directory_path = '/'.join(split_path[:-1])  # Everything except the last part (filename)
            # else:
            #     # If there are only two parts, the file is directly under Main
            #     directory_path = split_path[0]
            dir = key.replace('(Original)', '').replace('.ini', '')
            ini_file_path = dir + "/" + file_name
            Directory.objects.update_or_create(
                directory_path=dir,
                ini_file_path=ini_file_path,
                defaults={
                    'vehicle_type': ini_fil_details.get('VehicleType', None),
                    'vehicle_producer': ini_fil_details.get('VehicleProducer', None),
                    'vehicle_series': ini_fil_details.get('VehicleSeries', None),
                    'vehicle_model': ini_fil_details.get('VehicleModel', None),
                    'vehicle_model_year': ini_fil_details.get('VehicleModelyear', None),
                    'ecu_use': ini_fil_details.get('EcuUse', None),
                    'ecu_producer': ini_fil_details.get('EcuProducer', None),
                    'ecu_build': ini_fil_details.get('EcuBuild', None),
                    'ecu_prodnr': ini_fil_details.get('EcuProdNr', None),
                    'ecu_software_version': ini_fil_details.get('EcuSoftwareVersion', None),
                    'ecu_stgnr': ini_fil_details.get('EcuStgNr', None),
                    'engine_name': ini_fil_details.get('EngineName', None),
                    'engine_type': ini_fil_details.get('EngineType', None),
                    'engine_displacement': ini_fil_details.get('EngineDisplacement', None),
                }
            )

            count += 1
            print(f"Processed {count} files.")

    # Remove duplicates based on directory_path
    duplicate_paths = Directory.objects.values('directory_path').annotate(count=Count('id')).filter(count__gt=1)
    for duplicate in duplicate_paths:
        duplicates = Directory.objects.filter(directory_path=duplicate['directory_path'])
        to_keep = duplicates.first()
        to_delete = duplicates.exclude(id=to_keep.id)
        to_delete.delete()

    directories = Directory.objects.all()
    for directory in directories:
        if directory.ecu_producer:
            directory.ecu_producer = directory.ecu_producer.replace('Siemens/Continental', 'Continental').replace('Sid208',
                                                                                                                  'SID208').replace(
                'sid208', 'SID208')
            if directory.ecu_build:
                directory.ecu_build = directory.ecu_build.replace('Sid208', 'SID208').replace('sid208', 'SID208').replace(
                    'PCR2.1', 'Simos PCR 2.1')
            directory.vehicle_type = directory.vehicle_type.replace('Passenger car', 'Car')

            # Trim spaces and remove carriage returns
            directory.ecu_producer = directory.ecu_producer.replace('\r', '').strip()
            if directory.ecu_build:
                directory.ecu_build = directory.ecu_build.replace('\r', '').strip()
            directory.vehicle_type = directory.vehicle_type.replace('\r', '').strip()

            directory.save()

    # Directory.objects.filter(directory_path='Main').delete()

    print("Initial database sync and cleanup done.")

    from apps.utils.tasks import task_sync_main_dir_bigquery
    task_sync_main_dir_bigquery.delay()


def read_s3_for_mongo():
    s3 = session.resource('s3')
    bucket = s3.Bucket(settings.AWS_STORAGE_BUCKET_NAME)
    directory_list = []

    from pymongo import MongoClient

    # Creating a pymongo client
    client = MongoClient('localhost', 27017)

    # Getting the database instance
    db = client['filemaker_directory']

    # Creating a collection
    coll = db['directory']

    for obj in bucket.objects.filter(Prefix='Main/'):
        key = obj.key
        print("key:::::", key)
        if key != "Main/" or ".ini" not in key:
            file_obj = key.split("/")
            directory = {}
            directory["directory_name"] = file_obj[-2]
            directory["file_name"] = file_obj[-1]
            directory["content"] = obj.get()['Body'].read()
            # directory_list.append(directory)
            res = coll.insert_one(directory)
            print("Data inserted ......")
            print("done")

    # Inserting document into a collection
    # res = coll.insert_many(directory_list)
    # print("Data inserted ......")
    # print(res.inserted_ids)

    print("mongo data save done.")
    # # data = coll.find( { '_id': "649c0211c63b8526c7bd4821" } )
    # cur = coll.find({"directory_name":'DESKTOP-78VPINJ_10113'})
    # for c in cur:
    #     print(c['directory_name'])

    # # print(coll.find_one({"file_name": "DESKTOP-78VPINJ_10113"}))


# read_s3_for_mongo()


def delete_directories_from_s3(directories):
    s3 = boto3.resource('s3')
    bucket = s3.Bucket(settings.AWS_STORAGE_BUCKET_NAME)

    for directory in directories:
        # List all objects within the directory
        objects_to_delete = bucket.objects.filter(Prefix=directory)

        # Collect object keys to delete
        keys_to_delete = [{'Key': obj.key} for obj in objects_to_delete]

        if keys_to_delete:
            # Delete objects in batches
            delete_response = bucket.delete_objects(Delete={'Objects': keys_to_delete})
            print(f"Deleted objects in directory '{directory}': {delete_response}")
        else:
            print(f"No objects found in directory '{directory}'")


# # Example usage
# bucket_name = 'your-bucket-name'
# directories_to_delete = ['directory1/', 'directory2/', 'directory3/']
#
# delete_directories_from_s3(bucket_name, directories_to_delete)


def delete_s3_directory(directory_name):
    s3 = session.resource('s3')
    bucket = s3.Bucket(settings.AWS_STORAGE_BUCKET_NAME)
    # Create a list of all objects with the given directory prefix
    objects_to_delete = bucket.objects.filter(Prefix=directory_name)
    # Delete each object
    for obj in objects_to_delete:
        obj.delete()


def check_s3_file_exists(bucket_name, s3_path):
    """Check if a file exists in the S3 bucket."""
    try:
        s3_client.head_object(Bucket=bucket_name, Key=s3_path)
        return True
    except ClientError as e:
        if e.response['Error']['Code'] == '404':
            return False
        # Raise other errors like AccessDenied
        raise e
