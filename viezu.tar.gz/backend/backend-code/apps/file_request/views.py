import json
from django.db.models import Count
from django.contrib.postgres.aggregates import ArrayAgg

import boto3
from decouple import config
from django.core.files.storage import default_storage
from datetime import date
from apps.account.models import AccessLogsModel, EmailLogSettings
from apps.admin_management.models import Directory, TicketHistory
from apps.utils.helper import triger_socket, create_notification
from rest_framework.views import APIView
from rest_framework.response import Response
from rest_framework import status, generics
from rest_framework.permissions import IsAuthenticated
from rest_framework.authentication import TokenAuthentication
from rest_framework.parsers import FormParser, MultiPartParser
from django.db.models import Q, Prefetch
from django.db.models import OuterRef, Subquery
from django_filters import rest_framework as filters
from rest_framework.filters import SearchFilter
import apps.admin_management.response_message as resp_msg
import pdb
from . import slave_file_request_matching_time
from .serializer import (
    RefrenceMadeSerializer, VehicleRequestReSubmitSerializer, VehicleRequestSerializer, VehicleRequestListSerializer,
    FileFormDatSerializer, VehicleRequestSlaveOtherSerializer, VehicleTyperSerializer, VehicleBrandSerializer,
    VehicleModelSerializer, VehicleControlSerializer, VehicleRequestDetailSerializer,
    FileRequestHistorySerializer, FileRequestFileDownloadSerializer,
    EcuBrandSerializer, EcuVersionSerializer, FileRequestMatchingTimeSerializer,FileRequestGroupSerializer
)
from .models import (FileRequest, FileRequestFormData, RefrenceMadeFile, RequestDownloadFiles, VehicleType,
                     VehicleBrand, VehicleModel, VehicleControl,
                     FileRequestHistory, DataEcuBrand, DataEcuVersion, FileFormScheduleTaskLog, FileRequestTime,
                     VehicleManagement, FileRequestGroup, FileRequestActiveFilter)
from apps.utils.pagination import SetPagination
import binascii
from apps.utils.file_utils import convert_to_n_size_block
from apps.customer.models import CustomerSpentHistory
from datetime import datetime
from apps.utils.tasks import process_file_request_history, task_algo_slave_file_matching_time
import pandas as pd
import logging
logger = logging.getLogger('django')
import pdb
import requests
from apps.account.models import EVCCredentials
from apps.alientech.models import DecodeFiles, EncodeFiles
from apps.utils.ecode_decode import FileOperation
from apps.account.models import MyUser

import json
import pandas as pd
from datetime import date
from django.http import HttpResponse
from openpyxl import Workbook
#--
# class MagicFlexView(APIView):
    
#     permission_classes = [IsAuthenticated]
#     authentication_classes = [TokenAuthentication, ]
#     parser_classes = (FormParser, MultiPartParser)

#     def post(self,request):
#         logger.info(f"inside magic api function ------------------ ")
#         tuning_file = request.FILES.get('input_file')
#         print(f"tuning_file = {tuning_file}")
#         logger.info(f"tuning_file == {tuning_file}")

#         params = request.data
#         # url = "https://api.magicmotorsport.com/master/api/v1/slave_manager/decrypt"
#         url = "https://api.magicmotorsport.com/master/api/v1/slave_manager/encrypt"

#         token = "-i8YvlLI9LR7Kj74G0kHFa2C83v5k9P9"
        
#         headers = {
#             "X-Api-Key": token,
#             # 'Content-Type': 'multipart/form-data',
#             "accept":"json"
#             }
#         print(f"headers : {headers}")
#         logger.info(f"headers == {headers}")

#         payload={
#             "memory_type": "int_flash",
#             "sn": params['sn'],
#         }
#         print(f"payload : {payload}")
#         logger.info(f"payload : {payload}")

#         # file_path = "/home/mohit/Documents/WinOLS (Land Rover Range Rover (Original) - 086686).bin"
#         # files = {
#         #     "input_file": open(file_path, "rb"),
#         # }

#         files=[
#             ('readFile',(tuning_file.name,tuning_file.read(),'application/octet-stream'))
#         ]
#         logger.info(f"files : {files}")
#         try:
#             response = requests.post(url, data=payload, headers=headers, files=files)
#             print(f"response == {response}")
#             print(f"Response status code == {response.status_code}")
#             print(f"Response text == {response.text}")
#         except Exception as e:
#             logger.info(f"Exception occur : {e}")
#             return Response({
#                 "status":"Failed",
#                 'message': 'File Decode Failed',
#                 "response_data":response_data
#             })

#         response_data = json.loads(response.text)
#         if response.status_code==200:
        
#             return Response({
#                 "status":"success",
#                 'message': 'File Decoded successfully',
#                 "response_data":response_data
#             }, status=status.HTTP_200_OK)
        
#         elif response.status_code==401:
#             return Response(response_data,status=status.HTTP_401_UNAUTHORIZED)
#         else:
#             return Response(response_data, status=status.HTTP_400_BAD_REQUEST)
#--

#---
class FileRequestCloseSlot(APIView):
    permission_classes = [IsAuthenticated]
    authentication_classes = [TokenAuthentication, ]
    parser_classes = (FormParser, MultiPartParser)

    def generate_auth_token(self,):
        logger.info("code inside generate auth token function---------")
        evc_instance = None
        BASE_URL="https://encodingapi.alientech.to"

        if EVCCredentials.objects.all().exists():
            logger.info("Inside first if condition----")

            evc_instance = EVCCredentials.objects.all().last()
            logger.info(f"evc_instance == {evc_instance}")
        if evc_instance is None:
            logger.info("Inside else condition")
            evc_instance = EVCCredentials.objects.create(
                alientechauttoken = 'test'
            )
            logger.info(f"evc_instance = {evc_instance}")
        
        logger.info(f"Final evc_instance : {evc_instance}")

        url = BASE_URL + "/api/access-tokens/request" 
        payload = json.dumps({
            "clientApplicationGUID": "31b4f3d2-382a-4f7e-a22b-1eefb38f2162",
            "secretKey": "5Ui\"#,`P|Y!mzuMR>#o?*s" #old code
            # "secretKey": "5Ui#,`P|Y!mzuMR>#o?*s" # latest code
        })
        headers = {
            'Content-Type': 'application/json'
        }

        response = requests.request("POST", url,headers=headers, data=payload)
        logger.info(f"Token response : {response}\nToken response token : {response.status_code}")

        if response.status_code == 200:
            evc_instance.alientechauttoken = response.json()['accessToken']
            evc_instance.save()
            print("Token created",response.json()['accessToken'])     
            return True, response.json()['accessToken']
        
        logger.info(f"generate auth token return  : {response.json()} with false")
        return False,response.json()
    
    def post(self, request):
        print("api created ---------- ")
        
        params = request.data
        print(f"params : {params}")
        guid = params.get('guid')
        file_type = params.get('file_type')

        evc_instance = EVCCredentials.objects.all().last()

        BASE_URL="https://encodingapi.alientech.to"
        file_type="kess3"
        token = evc_instance.alientechauttoken
        
        #--
        # url = "{}/api/{}/file-slots/{}/close".format(
        #     BASE_URL,
        #     file_type,
        #     guid
        # )
        headers = {'X-Alientech-ReCodAPI-LLC': token}
        # print(f"url = {url}\nheaders = {headers}")

        # response = requests.request("POST", url, headers=headers, data={})
        
        #---
        for each in DecodeFiles.objects.filter(is_completed=True).filter(tool_type=2):
            print(f"Each ---- {each}")
            guid=each.decode_response.get('slotGUID','')
            url = "{}/api/{}/file-slots/{}/close".format(
                BASE_URL,
                file_type,
                guid
            )
            print(f"url = {url}\nheaders = {headers}")
            response = requests.request("POST", url, headers=headers, data={})
            print("Response close slot : ",response)
            if response.status_code == 200:
                each.is_file_closed=True

        if response.status_code == 401:
            is_sucess,auth_response = self.generate_auth_token()
            if is_sucess:
                self.close_file_slot(
                    auth_response,guid,
                    file_type
                )
        elif response.status_code == 200:
            # return True, response.text
            logger.info(f"Response : {response}")
            logger.info(f"Response text : {response.text}")
            return Response({
                'status': 'success',
                'response': response.text
            }, status=status.HTTP_200_OK)    
        # try:
        #     return False,response.json()
        # except:
        #     return False,"{}/{}".format(response.text,response.status_code)
        #--
        else:
            return Response({
                'status': 'Failed',
                'message':'Something went wrong'
            }, status=status.HTTP_400_BAD_REQUEST)
#---

#---File Request Group view----
# class FileRequestGroupView(APIView):
#     print("inside -------- ")
#     permission_classes = [IsAuthenticated, ]
#     authentication_classes = [TokenAuthentication, ]
#     serializer_class = FileRequestGroupSerializer
#     queryset = FileRequestGroup.objects.all()

#     def get(self, request, *args, **kwargs):
#         queryset = FileRequestGroup.objects.get(id=request.query_params.get('filter_id'))
#         serializer = FileRequestGroupSerializer(queryset)
#         return Response({
#             "success": True,
#             'data': serializer.data,
#             'message': resp_msg.RECORD_FETCHED_SUCCESSFULLY
#         }, status=status.HTTP_200_OK)

#     def post(self, request, *args, **kwargs):
#         title = request.data.get('title')
#         status = request.data.get('status')
#         filter = request.data.get('filter')
#         print(f"Title : {title}")
#         print(f"Filter : {filter}")

#         instance = FileRequestGroup.objects.create(
#             title=request.data.get('title'),
#             status=request.data.get('status'),
#             created_by=request.user,
#             role_id=1,
#             filter=request.data.get('filter')
#         )
#         serializer = FileRequestGroupSerializer(instance)
#         print(f"serializer.data : {serializer.data}")
#         return Response({
#             'success': True,
#             'data': serializer.data,
#             'message': "File Request group created successfully."
#         })

# class FileRequestGroupByroleView(APIView):
#     permission_classes = [IsAuthenticated]
#     authentication_classes = [TokenAuthentication]
#     serializer_class = FileRequestGroupSerializer

#     def get_queryset(self):
#         return FileRequestGroup.objects.all()  # Define the queryset here

#     def get(self, request, *args, **kwargs):
#         print(f"second ----- ")
#         queryset = self.get_queryset()  # Use the get_queryset method
#         print(f"queryset : {queryset}")
#         serializer = self.serializer_class(queryset, many=True)
#         print(f"serializer.data : {serializer.data}")
#         return Response({
#             'data': serializer.data,
#             'message': resp_msg.RECORD_FETCHED_SUCCESSFULLY
#         }, status=status.HTTP_200_OK)

class FileRequestActiveFilterView(APIView):
    permission_classes = [IsAuthenticated, ]
    authentication_classes = [TokenAuthentication, ]

    def post(self, request, *args, **kwargs):
        user = request.user
        status = request.data.get('status')
        active_filter = request.data.get('is_active')
        queryset = FileRequestActiveFilter.objects.filter(user=request.user)
        print(f"user : {queryset}|len : {len(queryset)}")
        if len(queryset)>0:
            fr_filter = FileRequestActiveFilter.objects.filter(user=request.user).update(
                # user=user,
                status=status,
                active_filter=active_filter
            )
            print(f"fr_filter : {fr_filter}")
        else:
            fr_filter = FileRequestActiveFilter.objects.update_or_create(
                user=user,
                status=status,
                active_filter=active_filter
            )
            print(f"fr_filter : {fr_filter}")
        return Response({
            'success': True,
        })
#---
def get_company_name(id):
        # if type(obj) == dict:
        #     user = MyUser.objects.get(id=obj['user'])
        # else:
        #     user = obj.user
        user = MyUser.objects.get(id=id)
        print(f"user == {user}")

        company_name = None
        if user.user_type == 3 and hasattr(user, 'business_user'):
            company_name = user.business_user.bussness_name
        elif user.user_type in [6, 7] and hasattr(user, 'reseller_sub_dealer'):
            company_name = user.reseller_sub_dealer.bussness_name
        
        # return {
        #     'first_name': user.first_name,
        #     'last_name': user.last_name,
        #     'email': user.email,
        #     'company_name': company_name
        # }
        if company_name:
            return company_name
        else:
            return ""

class FileRequestList(APIView):
    permission_classes = [IsAuthenticated]
    authentication_classes = [TokenAuthentication, ]

    def get(self, request):
        final_list_closed = []
        final_manual_list = []
        manual_closed_file = []
        start_date = date(2025, 4, 1)
        end_date = date(2025, 4, 17)
        
        all_file_request = FileRequest.objects.filter(
            created_at__date__gte=start_date,
            created_at__date__lte=end_date
        )
        # closed_file_list = ['FR2458', 'FR2460', 'FR2461', 'FR2462', 'FR2463', 'FR2465', 'FR2464', 'FR2469', 'FR2472', 'FR2478', 'FR2477', 'FR2480', 'FR2484', 'FR2481', 'FR2482', 'FR2485', 'FR2483']
        # closed_file_list = ['FR10404', 'FR11908', 'FR11909', 'FR10862', 'FR11498', 'FR11168', 'FR11170', 'FR10900', 'FR10967', 'FR10371', 'FR10481', 'FR10596', 'FR10556', 'FR10927', 'FR10699', 'FR11214', 'FR11164', 'FR10996', 'FR11505', 'FR12331', 'FR11231', 'FR11466', 'FR11366', 'FR11346', 'FR11977', 'FR11551', 'FR11620', 'FR12520', 'FR11876', 'FR12239', 'FR12173', 'FR12285', 'FR12103', 'FR12143', 'FR12140', 'FR12141', 'FR12142', 'FR12396', 'FR12551', 'FR12480']

        # for file in all_file_request:
        #     if file.status == 'CLOSED':
        #         if file.request_id not in closed_file_list:
        #             print("manual colsed file list : ",file.request_id)
        #             created_filemaker = {}
        #             created_filemaker = {
        #                 'request_id': file.request_id,
        #                 'customer_first_name': file.customer_first_name,
        #                 'customer_last_name': file.customer_last_name,
        #                 'created_at':str(file.created_at),
        #                 'company_name':get_company_name(file.user.id),
        #                 'vehicle_type': file.vehicle_type,
        #                 'vehicle_make': file.vehicle_make,
        #                 'model': file.model,
        #                 'vehicle_registration': file.vehicle_registration,
        #                 'vehicle_year': file.vehicle_year,
        #                 'vehicle_VIN': file.vehicle_VIN,
        #                 'engine_size': file.engine_size,
        #                 'transmission': file.transmission,
        #                 'fuel_type': file.fuel_type,
        #                 'mileage_type': file.mileage_type,
        #                 'mileage': file.mileage,
        #                 'ecu_brand': file.ecu_brand,
        #                 'ecu_version': file.ecu_version,
        #                 'control_unit': file.control_unit,
        #                 'file_type': file.file_type,
        #                 'country': file.country,
        #                 'tuning_tool_used': file.tuning_tool_used,
        #                 'tuning_required': file.tuning_required,
        #                 'additional_info': file.additional_info,
        #                 'file_size':file.file_size,
        #                 'additional_function': file.additional_function,
        #                 'request_type': file.request_type,
        #                 'status': file.status,
        #                 'CREATED_BY_FILEMAKER':'False'
        #             }
        #             file_numbere = file.request_id
        #             num = int(file_numbere[2:])
                    
        #             file_data_set = FileRequestHistory.objects.filter(file_request_id_id=num)
        #             i=0
        #             steps = []
        #             history = {}
        #             for data in file_data_set:
        #                 history[f'title {i}'] = data.title
        #                 history[f'description {i}'] = data.description
        #                 i+=1
        #             # print("HISTORY = ",history)
        #             steps.append(history)
        #             created_filemaker['History_Steps'] = steps

        #             history_steps = created_filemaker.get("History_Steps", [])
        #             if history_steps:
        #                 last_step_index = max([int(key.split()[1]) for key in history_steps[0].keys() if "title" in key])
        #                 last_title = history_steps[0].get(f"title {last_step_index}", "")
        #                 last_description = history_steps[0].get(f"description {last_step_index}", "")

        #                 # Add new fields
        #                 # created_filemaker["last_history_title"] = last_title
        #                 created_filemaker["Manual Handle Reason"] = last_description

        #             manual_closed_file.append(created_filemaker)
            
        #     # with open("manual_closed_files.txt", "w") as file:
        #     #     json.dump(manual_closed_file, file, indent=4)
        #     #     print(f"Successfully printed --------------- ")

        #     df = pd.DataFrame(manual_closed_file)
        #     excel_filename = "manual_closed_files.xlsx"
        #     df.to_excel(excel_filename, index=False)
        
        for file in all_file_request:
            if file.status == 'CLOSED':
                created_by_filemaker = {}
                file_numbere = file.request_id
                num = int(file_numbere[2:]) 
                
                directory_data = Directory.objects.filter(file_request_id=num).values('file_request_id')
                directory_list = list(directory_data)
        
                if directory_list:
                    file_request_id = directory_list[0]["file_request_id"]
                    file_request = FileRequest.objects.get(id=file_request_id)

                    created_by_filemaker['request_id']=file_request.request_id
                    created_by_filemaker['customer_first_name']=file_request.customer_first_name
                    created_by_filemaker['customer_last_name']=file_request.customer_last_name
                    created_by_filemaker['created_at']=str(file_request.created_at)
                    created_by_filemaker['company_name']=get_company_name(file_request.user.id)
                    created_by_filemaker['vehicle_type']=file_request.vehicle_type
                    created_by_filemaker['vehicle_make']=file_request.vehicle_make
                    created_by_filemaker['model']=file_request.model
                    created_by_filemaker['vehicle_registration']=file_request.vehicle_registration
                    created_by_filemaker['vehicle_year']=file_request.vehicle_year
                    created_by_filemaker['vehicle_VIN']=file_request.vehicle_VIN
                    created_by_filemaker['engine_size']=file_request.engine_size
                    created_by_filemaker['transmission']=file_request.transmission

                    created_by_filemaker['fuel_type']=file_request.fuel_type
                    created_by_filemaker['mileage_type']=file_request.mileage_type
                    created_by_filemaker['mileage']=file_request.mileage
                    created_by_filemaker['ecu_brand']=file_request.ecu_brand
                    created_by_filemaker['ecu_version']=file_request.ecu_version
                    created_by_filemaker['control_unit']=file_request.control_unit
                    created_by_filemaker['file_type']=file_request.file_type
                    created_by_filemaker['country']=file_request.country
                    created_by_filemaker['tuning_tool_used']=file_request.tuning_tool_used
                    created_by_filemaker['tuning_required']=file_request.tuning_required
                    created_by_filemaker['additional_info']=file_request.additional_info
                    created_by_filemaker['file_size']=file_request.file_size
                    created_by_filemaker['additional_function']=file_request.additional_function
                    created_by_filemaker['request_type']=file_request.request_type
                    created_by_filemaker['status']=file_request.status
                    created_by_filemaker['CREATED_BY_FILEMAKER']='TRUE'
                    final_list_closed.append(created_by_filemaker)
        # # with open("closed_file.txt", "w") as file:
        # #     json.dump(final_list_closed, file, indent=4)
        # # print(f"Successfully printed --------------- ")

        df = pd.DataFrame(final_list_closed)
        excel_filename = "closed_files.xlsx"
        df.to_excel(excel_filename, index=False)
        #------------------------------------------------------

        for file in all_file_request:
            if file.status == 'Manual Handle':
                created_filemaker = {}
                created_filemaker = {
                    'request_id': file.request_id,
                    'customer_first_name': file.customer_first_name,
                    'customer_last_name': file.customer_last_name,
                    'created_at':str(file.created_at),
                    'company_name':get_company_name(file_request.user.id),
                    'vehicle_type': file.vehicle_type,
                    'vehicle_make': file.vehicle_make,
                    'model': file.model,
                    'vehicle_registration': file.vehicle_registration,
                    'vehicle_year': file.vehicle_year,
                    'vehicle_VIN': file.vehicle_VIN,
                    'engine_size': file.engine_size,
                    'transmission': file.transmission,
                    'fuel_type': file.fuel_type,
                    'mileage_type': file.mileage_type,
                    'mileage': file.mileage,
                    'ecu_brand': file.ecu_brand,
                    'ecu_version': file.ecu_version,
                    'control_unit': file.control_unit,
                    'file_type': file.file_type,
                    'country': file.country,
                    'tuning_tool_used': file.tuning_tool_used,
                    'tuning_required': file.tuning_required,
                    'additional_info': file.additional_info,
                    'file_size':file.file_size,
                    'additional_function': file.additional_function,
                    'request_type': file.request_type,
                    'status': file.status,
                }
                file_numbere = file.request_id
                num = int(file_numbere[2:])
                
                file_data_set = FileRequestHistory.objects.filter(file_request_id_id=num)
                i=0
                steps = []
                history = {}
                for data in file_data_set:
                    history[f'title {i}'] = data.title
                    history[f'description {i}'] = data.description
                    i+=1
                # print("HISTORY = ",history)
                steps.append(history)
                created_filemaker['History_Steps'] = steps

                history_steps = created_filemaker.get("History_Steps", [])
                if history_steps:
                    last_step_index = max([int(key.split()[1]) for key in history_steps[0].keys() if "title" in key])
                    last_title = history_steps[0].get(f"title {last_step_index}", "")
                    last_description = history_steps[0].get(f"description {last_step_index}", "")

                    # Add new fields
                    # created_filemaker["last_history_title"] = last_title
                    created_filemaker["Manual Handle Reason"] = last_description

                final_manual_list.append(created_filemaker)
          
        # # with open("manual_file.txt", "w") as file:
        # #     json.dump(final_manual_list, file, indent=4)
        # #     print(f"Successfully printed --------------- ")

        df = pd.DataFrame(final_manual_list)
        excel_filename = "manual_files.xlsx"
        df.to_excel(excel_filename, index=False)

        return Response({
            'data': "success",
            'message': 'File request created.'
        }, status=status.HTTP_200_OK)
#---
class FileRequestCreateView(APIView):
    """Create a file request for the customer."""

    permission_classes = [IsAuthenticated]
    authentication_classes = [TokenAuthentication, ]
    parser_classes = (FormParser, MultiPartParser)

    def post(self, request):
        original_file_hexadump = None
        original_file_hexadump_list = None
        tuning_file = request.FILES.get('tuning_file')
        logger.info(f"tuning_file = {tuning_file}")
        
        if tuning_file is None:
            return Response({
                'detail': 'Please upload a file to continue.'
            }, status=status.HTTP_400_BAD_REQUEST)

        params = request.data
        logger.info(f"params data = {params}")
        
        if tuning_file is not None:
            file_content = tuning_file.read()
            file_size_mb = tuning_file.size / (1024.0 * 1024.0)
            original_file_hexadump = binascii.hexlify(file_content).decode()
            original_file_hexadump_list = convert_to_n_size_block(original_file_hexadump, 20)
            logger.info("File converted into hexadump successfully---")

        # Check for sufficient balance
        file_key_credit_needed = 0
        function_credit_needed = 0
        old_file_key_credit=0
        old_function_credit=0
        if 'file_key_credit' in params and 'ticket_id' not in params:
            file_key_credit_needed = int(params['file_key_credit'])
            function_credit_needed = int(params['function_credit'])

            if request.user.customer_credit.file_key_credit < file_key_credit_needed:
                return Response({
                    'detail': 'Insufficient file key credits.'
                }, status=status.HTTP_400_BAD_REQUEST)

            if request.user.customer_credit.function_credit < function_credit_needed:
                return Response({
                    'detail': 'Insufficient function credits.'
                }, status=status.HTTP_400_BAD_REQUEST)

            # old credit logs:
            old_file_key_credit = request.user.customer_credit.file_key_credit
            old_function_credit = request.user.customer_credit.function_credit
            old_details = {
                "file_key_credit":old_file_key_credit,
                "function_credit":old_function_credit
            }
            logger.info(f"old_details == {old_details}")
            # Subtract credits if balance is sufficient
            request.user.customer_credit.file_key_credit -= file_key_credit_needed
            request.user.customer_credit.function_credit -= function_credit_needed
            # request.user.customer_credit.save()
        
        serializer = VehicleRequestSerializer(data=request.data,
                                    context={
                                        'request': request,
                                        'original_file_hexadump': original_file_hexadump,
                                        'original_file_hexadump_list': original_file_hexadump_list,
                                        'file_size_mb': file_size_mb
                                        })
        serializer.is_valid(raise_exception=True)
        file_request = serializer.save()
        # just simple check

        if file_request:
            request.user.customer_credit.save()
            logger.info(f"User Credit deducted for file request : {file_request}")
            #-- new credit--
            new_file_key_credit = request.user.customer_credit.file_key_credit
            new_function_credit = request.user.customer_credit.function_credit
            new_details = {
                "file_key_credit":new_file_key_credit,
                "function_credit":new_function_credit
            }
            logger.info(f"new_details : {new_details}")

            x_forwarded_for = request.META.get('HTTP_X_FORWARDED_FOR')
            # customer_detail = request.user.first_name + ' ' + request.user.last_name + '(' + request.user.email + ')'
            admin_log = AccessLogsModel.objects.create(
                user=request.user,
                timestamp=datetime.now(),
                ip_address=x_forwarded_for.split(',')[0] if x_forwarded_for else request.META.get('REMOTE_ADDR'),
                method='Create',
                event='Create',
                module=EmailLogSettings.objects.filter(module='Customer credit').last(),
                title='File Request submited.',
                description=f'File Request submitted - {file_request.request_id}',
                customer=request.user,
                file_request = file_request.request_id
            )
            logger.info(f"Admin logs file submitted : {admin_log}")

            # For customer side log.
            customer_log = AccessLogsModel.objects.create(
                user=request.user,
                timestamp=datetime.now(),
                ip_address=x_forwarded_for.split(',')[0] if x_forwarded_for else request.META.get('REMOTE_ADDR'),
                method='Create',
                event='Create',
                module=EmailLogSettings.objects.filter(module='Customer credit').last(),
                title='File Request submited.',
                description=f'File Request submitted - {file_request.request_id}',
                customer=request.user,
                to_customer_only=True,
                file_request = file_request.request_id
            )
            logger.info(f"customer log file submitted : {customer_log}")
            #---
        else:
            return Response({
                'message': 'Something Went Wrong',
                'Error': "Unable to generate File Request"
            }, status=status.HTTP_400_BAD_REQUEST)
        
        triger_socket({
            'uuid': str(request.user.uuid),
            'type': 'customer_credit_update',
            'file_key_credit': -int(params['file_key_credit']),
            'function_credit': -int(params['function_credit']),
        })
        create_notification(file_request.user, "{} Status Update".format(file_request.request_id),
                            "File Request has been successfully submitted",
                            sender=request.user, ticket=None, file=None)

        if 'file_key_credit' in params and 'ticket_id' not in params:
            if 'file_key_credit' in params and int(params['file_key_credit']) > 0:
                credit_type = 1
                credit = int(params['file_key_credit'])
            elif 'function_credit' in params and int(params['function_credit']) > 0:
                credit_type = 3
                credit = int(params['function_credit'])
            else:
                credit_type = None
                credit = None

            if credit_type is not None and credit is not None and (
                    request.user.user_type in [3, 4, 6, 7]):
                customer_spent_history=CustomerSpentHistory.objects.create(
                    user=request.user,
                    credit=credit,
                    credit_type=credit_type,
                    file_request_id=file_request.request_id
                )
                logger.info(f"customer_spent_history = {customer_spent_history}")

                x_forwarded_for = request.META.get('HTTP_X_FORWARDED_FOR')
                customer_detail = request.user.first_name + ' ' + request.user.last_name + '(' + request.user.email + ')'
                admin_log = AccessLogsModel.objects.create(
                    user=request.user,
                    timestamp=datetime.now(),
                    ip_address=x_forwarded_for.split(',')[0] if x_forwarded_for else request.META.get('REMOTE_ADDR'),
                    method='Update',
                    event='Update',
                    module=EmailLogSettings.objects.filter(module='Customer credit').last(),
                    title='Spent Credits updated.',
                    # description='Spent Credits updated: File credit:{0}, Function credit: {1} and EVC credit {2} for {3} by {4}.'.format(
                    #     file_key_credit_needed, function_credit_needed, 0,
                    #     customer_detail, customer_detail),
                    customer=request.user,
                    old_details=old_details,
                    new_details=new_details,
                )
                logger.info(f"admin_log Credit updates : {admin_log}")
                admin_log.file_request = file_request.request_id
                admin_log.credit_update_type = "Other"
                admin_log.save()

                # For customer side log.
                customer_log = AccessLogsModel.objects.create(
                    user=request.user,
                    timestamp=datetime.now(),
                    ip_address=x_forwarded_for.split(',')[0] if x_forwarded_for else request.META.get('REMOTE_ADDR'),
                    method='Update',
                    event='Update',
                    module=EmailLogSettings.objects.filter(module='Customer credit').last(),
                    title='Spent Credits updated.',
                    # description='Spent Credits updated: File credit:{0}, Function credit: {1} and EVC credit {2} in your account by {3}.'.format(
                    #     file_key_credit_needed, function_credit_needed, 0, customer_detail),
                    customer=request.user,
                    to_customer_only=True,
                    old_details=old_details,
                    new_details=new_details,
                )
                logger.info(f"customer_log credit update : {customer_log}")
                customer_log.file_request = file_request.request_id
                customer_log.credit_update_type = "Other"
                customer_log.save()

        data = {
            'request_id': file_request.request_id
        }
        return Response({
            'data': data,
            'message': 'File request created.'
        }, status=status.HTTP_200_OK)


class FileRequestReSubmitSlaveView(APIView):
    """Create a file request for the customer."""

    permission_classes = [IsAuthenticated]
    authentication_classes = [TokenAuthentication, ]
    parser_classes = (FormParser, MultiPartParser)

    def post(self, request):
        original_file_hexadump = None
        original_file_hexadump_list = None
        tuning_file = request.FILES.get('tuning_file')

        if tuning_file is None:
            return Response({
                'detail': 'Please upload a file to continue.'
            }, status=status.HTTP_400_BAD_REQUEST)

        if tuning_file is not None:
            file_content = tuning_file.read()
            file_size_mb = tuning_file.size / (1024.0 * 1024.0)
            original_file_hexadump = binascii.hexlify(file_content).decode()
            original_file_hexadump_list = convert_to_n_size_block(original_file_hexadump, 20)

        serializer = VehicleRequestSerializer(data=request.data,
                                              context={'request': request,
                                                       'original_file_hexadump': original_file_hexadump,
                                                       'original_file_hexadump_list': original_file_hexadump_list,
                                                       'file_size_mb': file_size_mb})
        serializer.is_valid(raise_exception=True)
        file_request = serializer.save()

        data = {
            'request_id': file_request.request_id
        }
        return Response({
            'data': data,
            'message': 'File request created.'
        }, status=status.HTTP_200_OK)


class FileRequestReSubmitSlaveOtherView(APIView):
    """Create a file request for the customer."""

    permission_classes = [IsAuthenticated]
    authentication_classes = [TokenAuthentication, ]
    parser_classes = (FormParser, MultiPartParser)

    def post(self, request):
        logger.info("INSIDE OTHER FIELD API-------------")
        original_file_hexadump = None
        original_file_hexadump_list = None
        tuning_file = request.FILES.get('tuning_file')
        logger.info(f"tuning_file : {tuning_file}")

        if tuning_file is None:
            return Response({
                'detail': 'Please upload a file to continue.'
            }, status=status.HTTP_400_BAD_REQUEST)

        params = request.data
        logger.info(f"params : {tuning_file}")

        if tuning_file is not None:
            file_content = tuning_file.read()
            file_size_mb = tuning_file.size / (1024.0 * 1024.0)
            original_file_hexadump = binascii.hexlify(file_content).decode()
            original_file_hexadump_list = convert_to_n_size_block(original_file_hexadump, 20)
            logger.info(f"file successfully converted into hexa dump list:")

        # Check for sufficient balance
        file_key_credit_needed = 0
        function_credit_needed = 0
        if 'file_key_credit' in params and 'ticket_id' not in params:
            file_key_credit_needed = int(params['file_key_credit'])
            function_credit_needed = int(params['function_credit'])

            if request.user.customer_credit.file_key_credit < file_key_credit_needed:
                return Response({
                    'detail': 'Insufficient file key credits.'
                }, status=status.HTTP_400_BAD_REQUEST)

            if request.user.customer_credit.function_credit < function_credit_needed:
                return Response({
                    'detail': 'Insufficient function credits.'
                }, status=status.HTTP_400_BAD_REQUEST)

            # Subtract credits if balance is sufficient
            request.user.customer_credit.file_key_credit -= file_key_credit_needed
            request.user.customer_credit.function_credit -= function_credit_needed
            # request.user.customer_credit.save()

        serializer = VehicleRequestSlaveOtherSerializer(data=request.data,
                                                        context={'request': request,
                                                                 'original_file_hexadump': original_file_hexadump,
                                                                 'original_file_hexadump_list': original_file_hexadump_list,
                                                                 'file_size_mb': file_size_mb})
        serializer.is_valid(raise_exception=True)
        file_request = serializer.save()
        logger.info(f"File request : {file_request}")
        if file_request:
            logger.info(f"Credit upated after file request created.")
            request.user.customer_credit.save()
        else:
            return Response({
                'message': 'Something Went Wrong',
                'Error': "Unable to generate File Request"
            }, status=status.HTTP_400_BAD_REQUEST)

        if 'file_key_credit' in params and 'ticket_id' not in params:
            if 'file_key_credit' in params and int(params['file_key_credit']) > 0:
                credit_type = 1
                credit = int(params['file_key_credit'])
            elif 'function_credit' in params and int(params['function_credit']) > 0:
                credit_type = 3
                credit = int(params['function_credit'])
            else:
                credit_type = None
                credit = None

            if credit_type is not None and credit is not None and (
                    request.user.user_type in [3, 4, 6, 7]):
                CustomerSpentHistory.objects.create(
                    user=request.user,
                    credit=credit,
                    credit_type=credit_type,
                    file_request_id=file_request.request_id
                )
                x_forwarded_for = request.META.get('HTTP_X_FORWARDED_FOR')
                customer_detail = request.user.first_name + ' ' + request.user.last_name + '(' + request.user.email + ')'
                admin_log = AccessLogsModel.objects.create(
                    user=request.user,
                    timestamp=datetime.now(),
                    ip_address=x_forwarded_for.split(',')[0] if x_forwarded_for else request.META.get('REMOTE_ADDR'),
                    method='Update',
                    event='Update',
                    module=EmailLogSettings.objects.filter(module='Customer credit').last(),
                    title='Spent Credits updated.',
                    description='Spent Credits updated: File credit:{0}, Function credit: {1} and EVC credit {2} for {3} by {4}.'.format(
                        file_key_credit_needed, function_credit_needed, 0,
                        customer_detail, customer_detail),
                    customer=request.user,
                )
                logger.info(f"admin_log created [creadit]: {admin_log}")
                admin_log.file_request = file_request.request_id
                admin_log.credit_update_type = "Other"
                admin_log.save()

                # For customer side log.
                customer_log = AccessLogsModel.objects.create(
                    user=request.user,
                    timestamp=datetime.now(),
                    ip_address=x_forwarded_for.split(',')[0] if x_forwarded_for else request.META.get('REMOTE_ADDR'),
                    method='Update',
                    event='Update',
                    module=EmailLogSettings.objects.filter(module='Customer credit').last(),
                    title='Spent Credits updated.',
                    description='Spent Credits updated: File credit:{0}, Function credit: {1} and EVC credit {2} in your account by {3}.'.format(
                        file_key_credit_needed, function_credit_needed, 0, customer_detail),
                    customer=request.user,
                    to_customer_only=True,
                )
                logger.info(f"customer_log created [creadit]: {customer_log}")
                customer_log.file_request = file_request.request_id
                customer_log.credit_update_type = "Other"
                customer_log.save()

        data = {
            'request_id': file_request.request_id
        }
        return Response({
            'data': data,
            'message': 'File request created.'
        }, status=status.HTTP_200_OK)


class FileRequestListView(generics.ListAPIView):
    """List file request by user API."""

    permission_classes = [IsAuthenticated, ]
    authentication_classes = [TokenAuthentication, ]
    serializer_class = VehicleRequestListSerializer
    pagination_class = SetPagination

    def get_queryset(self):
        # Selecting only the necessary fields
        queryset = FileRequest.objects.filter(
            request_type='FILE_REQUEST'
        ).select_related(
            'user'
        ).only(
            "id", "request_id", "vehicle_type", "vehicle_make", "model",
            "vehicle_registration", "vehicle_year", "vehicle_VIN", "engine_size",
            "transmission", "fuel_type", "mileage_type", "mileage", "ecu_brand",
            "customer_first_name", "customer_last_name", "ecu_version",
            "control_unit", "file_type", "country", "tuning_tool_used",
            "tuning_required", "additional_info", "tuning_file", "user",
            "status", "created_at"
        ).order_by('-created_at')

        field_to_sort = self.request.query_params.get('field')
        order_in = self.request.query_params.get('order_in')
        order_by_str = ''

        if order_in == 'asc':
            order_by_str = field_to_sort
        elif order_in == 'dec':
            order_by_str = '-' + field_to_sort

        user_type = self.request.user.user_type
        if user_type not in [3, 4, 6, 7]:
            if field_to_sort and order_by_str:
                queryset = queryset.order_by(order_by_str)
            else:
                queryset = queryset.order_by('-pk')
        else:
            queryset = queryset.filter(user=self.request.user).order_by('-pk')
            if field_to_sort and order_by_str:
                queryset = queryset.order_by(order_by_str)

        return queryset

    def list(self, request, *args, **kwargs):
        queryset = self.get_queryset()
        page = self.paginate_queryset(queryset)
        if page is not None:
            serializer = self.serializer_class(page, many=True)
            return self.get_paginated_response(serializer.data)

        serializer = self.serializer_class(queryset, many=True)
        return Response(serializer.data)


class FileRequestDetailView(generics.RetrieveAPIView):
    """Detail file request by user API."""

    permission_classes = [IsAuthenticated, ]
    authentication_classes = [TokenAuthentication, ]
    queryset = FileRequest.objects.all()
    serializer_class = VehicleRequestDetailSerializer
    lookup_field = 'pk'

    def retrieve(self, request, *args, **kwargs):
        instance = self.get_object()
        serializer = self.get_serializer(instance)
        return Response(serializer.data)


class FileRequestHistoryView(generics.ListAPIView):
    permission_classes = [IsAuthenticated, ]
    authentication_classes = [TokenAuthentication, ]
    queryset = FileRequestHistory.objects.all()
    serializer_class = FileRequestHistorySerializer

    def get_queryset(self):
        return super().get_queryset().filter(
            file_request_id__request_id=self.kwargs['file_request_id']
        ).order_by('created_at')


class FileRequestHistoryView1(generics.ListAPIView):
    permission_classes = [IsAuthenticated, ]
    authentication_classes = [TokenAuthentication, ]
    serializer_class = FileRequestHistorySerializer
    queryset = FileRequestHistory.objects.all()

    def get_queryset(self):
        subquery = FileRequestHistory.objects.filter(
            file_request_id=OuterRef('file_request_id')
        ).order_by('-created_at').values('id')[:1]

        return super().get_queryset().filter(
            id__in=Subquery(subquery)
        ).filter(
            file_request_id__request_id=self.kwargs['file_request_id']
        ).order_by('created_at')

    def list(self, request, *args, **kwargs):
        queryset = self.get_queryset()
        serializer = self.get_serializer(queryset, many=True)
        data = serializer.data
        if data:
            record = data[0]
            process_file_request_history.delay(record)
        return Response(data)


class FileRequestMatchingTimeView(generics.ListAPIView):
    permission_classes = [IsAuthenticated]
    authentication_classes = [TokenAuthentication]
    parser_classes = (FormParser, MultiPartParser)
    serializer_class = FileRequestMatchingTimeSerializer  # Add this line

    def post(self, request):
        decoded_file = request.FILES.get('decoded_file')
        submit_file = request.FILES.get('submit_file')
        if decoded_file is None:
            return Response({
                'detail': 'Please upload a file to continue.'
            }, status=status.HTTP_400_BAD_REQUEST)

        params = request.data
        if decoded_file is not None:
            file_request_id = params['file_request_id']
            decoded_file_path = default_storage.save(decoded_file.name, decoded_file)
            submit_file_path = default_storage.save(submit_file.name, submit_file) if submit_file else None
            task_algo_slave_file_matching_time.delay(file_request_id, decoded_file_path, submit_file_path)
        return Response("data")


class VehicleTypeListView(generics.ListAPIView):
    serializer_class = VehicleTyperSerializer
    queryset = VehicleType.objects.all()


class ReteriveVehicleBrandView(generics.ListAPIView):
    queryset = VehicleBrand.objects.all()
    serializer_class = VehicleBrandSerializer

    def get_queryset(self):
        vehicle_type = self.kwargs.get('pk')
        return VehicleBrand.objects.filter(vehicle_type=vehicle_type)


class ReteriveVehicleModelView(generics.ListAPIView):
    queryset = VehicleModel.objects.all()
    serializer_class = VehicleModelSerializer

    def get_queryset(self):
        vehicle_brand = self.kwargs.get('pk')
        return VehicleModel.objects.filter(vehicle_brand=vehicle_brand)


class ReteriveVehicleControlView(generics.ListAPIView):
    queryset = VehicleControl.objects.all()
    serializer_class = VehicleControlSerializer

    def get_queryset(self):
        vehicle_model = self.kwargs.get('pk')
        return VehicleControl.objects.filter(vehicle_model=vehicle_model)


class GetAllECUBrandByModelView(APIView):
    permission_classes = [IsAuthenticated, ]
    authentication_classes = [TokenAuthentication, ]

    def get(self, request, pk):
        # vehicle_model
        model = VehicleModel.objects.get(pk=pk)
        print(model.model_name)

        ecu_brands_list = VehicleControl.objects.filter(vehicle_model=pk).values('ecu_brand').distinct()

        versions_list = VehicleControl.objects.filter(vehicle_model=pk).values('ecu_version').distinct()
        return Response({
            'data': {
                'ecu_brands_list': ecu_brands_list,
                'versions_list': versions_list
            },
            'message': 'Ecu info loaded.'
        }, status=status.HTTP_200_OK)


class FileFormDataListView(APIView):

    def get(self, request):
        queryset = FileRequestFormData.objects.all().first()
        serializer = FileFormDatSerializer(queryset)
        return Response({
            'data': serializer.data,
            'message': 'File Form data fetched successfully.'
        }, status=status.HTTP_200_OK)


class FileKeyUpateView(APIView):
    permission_classes = [IsAuthenticated, ]
    authentication_classes = [TokenAuthentication, ]

    def put(self, request):
        try:
            vehicle_data = request.data['data']
        except Exception as error:
            return Response({
                'message': 'Invalid format.'
            }, status=status.HTTP_400_BAD_REQUEST)

        updated_data = []

        for data in vehicle_data:
            queryset = VehicleModel.objects.get(id=data['id'])

            vehicle_brand_name = queryset.vehicle_brand.brand_name
            vehicle_type = queryset.vehicle_brand.vehicle_type.name

            old_file_credit = queryset.file_key_credit
            if old_file_credit != data["file_key_credit"]:
                update_dict = {'model_name': queryset.model_name,
                               'old_file_credit': old_file_credit,
                               'new_file_credit': data["file_key_credit"]}
                updated_data.append(update_dict)

            queryset.file_key_credit = data["file_key_credit"]
            queryset.save()

        str = ''
        for d in updated_data:
            str += 'Updated File Credit ->Vehcile type: {0}, Vehicle brand:{1}, Model Name:{2}, old credit:{3}, new credit:{4} \n\n'.format(
                vehicle_type, vehicle_brand_name, d['model_name'], d['old_file_credit'], d['new_file_credit'])

        x_forwarded_for = request.META.get('HTTP_X_FORWARDED_FOR')
        AccessLogsModel.objects.create(
            user=self.request.user,
            timestamp=datetime.now(),
            ip_address=x_forwarded_for.split(',')[0] if x_forwarded_for else request.META.get('REMOTE_ADDR'),
            method='Updated',
            event='Updated',
            module=EmailLogSettings.objects.filter(module='Manage Vehicle').last(),
            title='File Credit Updated.',
            description=str,
        )

        return Response({
            'message': 'vehicle data updated successfully.'
        }, status=status.HTTP_200_OK)


class CreditCalculateView(APIView):
    permission_classes = [IsAuthenticated, ]
    authentication_classes = [TokenAuthentication, ]

    def post(self, request):
        vehicle_model_id = request.data.get('vehicle_model_id')
        tune_required = request.data.get('tune_required')
        queryset = VehicleModel.objects.get(id=vehicle_model_id)
        file_key_credit = queryset.file_key_credit
        if tune_required:
            pass
        return Response({
            'message': 'Inprogress.'
        }, status=status.HTTP_200_OK)


class CreateModelView(APIView):
    permission_classes = [IsAuthenticated, ]
    authentication_classes = [TokenAuthentication, ]

    def post(self, request):
        vehicle_brand_id = request.data.get('vehicle_brand_id')
        vehicle_model_name = request.data.get('vehicle_model_name')

        obj = VehicleModel.objects.filter(model_name=vehicle_model_name)
        if len(obj) != 0:
            return Response({
                'message': 'Vehicle model already exists.'
            }, status=status.HTTP_200_OK)
        else:
            model = VehicleModel.objects.create(
                model_name=vehicle_model_name,
                vehicle_brand=VehicleBrand.objects.get(pk=vehicle_brand_id),
                file_key_credit=0
            )
            model.save()
            return Response({
                'message': 'Model created successfully.'
            }, status=status.HTTP_200_OK)


class FileRequestDownloadFilesView(APIView):
    permission_classes = [IsAuthenticated, ]
    authentication_classes = [TokenAuthentication, ]

    def get(self, request, *args, **Kwargs):
        request_id = self.kwargs['request_id']

        user = request.user
        if user.user_type in [3, 4, 6, 7]:
            queryset = RequestDownloadFiles.objects.filter(
                fil_request_id__request_id=request_id,
                sent_to_user=True)
        else:
            queryset = RequestDownloadFiles.objects.filter(
                fil_request_id__request_id=request_id)
        serializer = FileRequestFileDownloadSerializer(queryset, many=True)

        return Response({
            'data': serializer.data,
            'message': 'Files reterived successfully.'
        }, status=status.HTTP_200_OK)


class FileRequestTicketView(APIView):
    permission_classes = [IsAuthenticated, ]
    authentication_classes = [TokenAuthentication, ]

    def get(self, request, *args, **Kwargs):
        request_id = self.kwargs['request_id']
        if TicketHistory.objects.filter(request_id=request_id).exists():
            latest_ticket = TicketHistory.objects.filter(request_id=request_id).order_by('-updated_at').first()
            return Response({
                'message': 'Ticket found.',
                'ticket_id': latest_ticket.id
            }, status=status.HTTP_200_OK)
        else:
            return Response({
                'message': 'No Tickets found.',
                'ticket_id': None
            }, status=status.HTTP_200_OK)


class UpdateVehicleManagement(APIView):
    permission_classes = [IsAuthenticated, ]
    authentication_classes = [TokenAuthentication, ]

    def put(self, request):

        # get the excel file from request:
        if 'file' not in request.FILES:
            return Response({"error": "No file uploaded."}, status=status.HTTP_400_BAD_REQUEST)

        file = request.FILES['file']

        # create Dataframe of file:
        df = pd.read_excel(file)
        print(f"columns : {df.columns}")

        for index, row in df.iterrows():
            brand_name = row['brand name']
            ecu_brand = row['ecu brand']
            ecu_version = row['ecu version']

            if not brand_name and not ecu_brand and not ecu_version:
                continue

            try:
                def handle_nan(value):
                    return '' if pd.isna(value) else str(value).strip()

                cleaned_brand_name = handle_nan(brand_name)
                cleaned_ecu_brand = handle_nan(ecu_brand)
                cleaned_ecu_version = handle_nan(ecu_version)

                if cleaned_brand_name and cleaned_ecu_brand and cleaned_ecu_version:
                    vehicles_data = VehicleManagement.objects.filter(
                        brand_name__iexact=brand_name, ecu_brand__iexact=ecu_brand, ecu_version__iexact=ecu_version
                    )
                    if vehicles_data.exists():
                        for vehicle in vehicles_data:
                            vehicle.dpf = ', '.join(
                                filter(None, [handle_nan(row.get('DPF', '')), handle_nan(row.get('DPF.1', ''))]))
                            vehicle.egr = handle_nan(row.get('EGR ', ''))
                            vehicle.intake_flaps = handle_nan(row.get('Intake flaps', ''))
                            vehicle.adblue = ', '.join(filter(None, [
                                handle_nan(row.get('Adblue', '')),
                                handle_nan(row.get('Adblue.1', '')),
                                handle_nan(row.get('Adblue.2', ''))
                            ]))
                            vehicle.gpf_opf_ppf = ', '.join(filter(None, [
                                handle_nan(row.get('Gpf opf ppf', '')),
                                handle_nan(row.get('Gpf opf ppf.1', ''))
                            ]))
                            vehicle.save()

            except VehicleManagement.DoesNotExist:
                pass

        return Response({"message": "Additional Features updated successfully"},
                        status=status.HTTP_200_OK)


class CounterIncreaseView(APIView):
    permission_classes = [IsAuthenticated, ]
    authentication_classes = [TokenAuthentication, ]

    def get(self, request, *args, **Kwargs):
        pk = self.kwargs['pk']
        queryset = RequestDownloadFiles.objects.get(pk=pk)
        if queryset.downloaded_times is None:
            queryset.downloaded_times = 0
            queryset.save()
            queryset.downloaded_times += 1
            queryset.save()
        else:
            queryset.downloaded_times += 1
            queryset.save()

        return Response({
            'counter': queryset.downloaded_times,
        }, status=status.HTTP_200_OK)


class EcuBrandListView(generics.ListAPIView):
    permission_classes = [IsAuthenticated, ]
    authentication_classes = [TokenAuthentication, ]
    serializer_class = EcuBrandSerializer
    queryset = DataEcuBrand.objects.all()


class EcuVersionListView(generics.ListAPIView):
    permission_classes = [IsAuthenticated, ]
    authentication_classes = [TokenAuthentication, ]
    serializer_class = EcuVersionSerializer
    queryset = DataEcuVersion.objects.all()

    def get_queryset(self):
        brand = self.kwargs.get('pk')
        return DataEcuVersion.objects.filter(brand=brand)

    def list(self, request, *args, **Kwargs):
        queryset = self.get_queryset()
        serializer = self.serializer_class(queryset, many=True)
        return Response(serializer.data)


class EcuVersionCreateView(generics.CreateAPIView):
    permission_classes = [IsAuthenticated, ]
    authentication_classes = [TokenAuthentication, ]
    serializer_class = EcuVersionSerializer

    def create(self, request, *args, **kwargs):
        response = super().create(request, *args, **kwargs)
        return Response({
            'message': 'Ecu version created successfully.',
            'data': response.data
        })


class EcuVersionUpdateView(APIView):
    permission_classes = [IsAuthenticated, ]
    authentication_classes = [TokenAuthentication, ]
    serializer_class = EcuVersionSerializer

    def put(self, request):
        try:
            ecu_data = request.data['data']
        except Exception as error:
            return Response({
                'message': 'Invalid format.'
            }, status=status.HTTP_400_BAD_REQUEST)

        updated_data = []

        for data in ecu_data:
            queryset = DataEcuVersion.objects.get(id=data['id'])
            brand_name = queryset.brand.brand_name
            old_ecu_percentage = queryset.percentage
            if old_ecu_percentage != float(data["percentage"]):
                update_dict = {'ecu_version': queryset.ecu_version_name,
                               'old_percentage': old_ecu_percentage,
                               'new_percentage': float(data["percentage"])}

                updated_data.append(update_dict)

            queryset.percentage = float(data["percentage"])
            queryset.save()

        str = ''
        for d in updated_data:
            str += 'Updated ECU percentage ->Brand name:{0}, ECU version:{1}, old percentage:{2}, new percentage:{3} \n\n'.format(
                brand_name, d['ecu_version'], d['old_percentage'], d['new_percentage'])

        x_forwarded_for = request.META.get('HTTP_X_FORWARDED_FOR')
        AccessLogsModel.objects.create(
            user=self.request.user,
            timestamp=datetime.now(),
            ip_address=x_forwarded_for.split(',')[0] if x_forwarded_for else request.META.get('REMOTE_ADDR'),
            method='Updated',
            event='Updated',
            module=EmailLogSettings.objects.filter(module='Manage Vehicle').last(),
            title='Ecu Percentage Updated.',
            description=str,
        )

        return Response({
            'message': 'ECU data updated successfully.'
        }, status=status.HTTP_200_OK)


class RequestIdSearchView(generics.ListAPIView):
    permission_classes = [IsAuthenticated, ]
    authentication_classes = [TokenAuthentication, ]
    queryset = FileRequest.objects.filter(request_type='FILE_REQUEST').order_by('-created_at')
    serializer_class = VehicleRequestListSerializer
    pagination_class = SetPagination
    search_fields = ["id", "request_id", "vehicle_type", "vehicle_make",
                     "model", "vehicle_registration", "vehicle_year",
                     "vehicle_VIN", "engine_size", "transmission",
                     "fuel_type", "mileage_type", "mileage",
                     "ecu_brand", "customer_first_name", "customer_last_name",
                     "ecu_version", "control_unit", "file_type",
                     "country", "tuning_tool_used", "tuning_required", "status", "additional_info",
                     "additional_function", "created_at", "user__first_name", "user__last_name", "user__email"]
    filter_backends = (filters.DjangoFilterBackend, SearchFilter,)

    def get_queryset(self):
        queryset = super().get_queryset()

        search_query = self.request.query_params.get('search', '').strip().lower()
        if search_query in ['in progress', 'inprogress']:
            queryset = queryset.filter(status__iexact='Manual Handle')

        search_filter = SearchFilter()
        queryset = search_filter.filter_queryset(self.request, queryset, self)

        user_type = self.request.user.user_type
        if user_type in [3, 4, 6, 7]:
            queryset = queryset.filter(user=self.request.user)

        return queryset

    def list(self, request, *args, **kwargs):
        queryset = self.get_queryset()
        page = self.paginate_queryset(queryset)
        filter_queryset = FileRequestActiveFilter.objects.filter(user=request.user)
        print(f"filter_queryset : {filter_queryset}")
        if filter_queryset.exists():
            data =  filter_queryset[0].active_filter
            print(f"data : {data}")
            if data:
                queryset = queryset.filter(status=filter_queryset[0].status)
                # current_status = filter_queryset[0].status
                # serializer = VehicleRequestListSerializer(queryset, many=True)
                # return Response({
                #     'count':len(queryset),
                #     'current_status':current_status,
                #     'data': serializer.data,
                #     'message': "Data fetched successfully."
                # }, status=status.HTTP_200_OK)
                page = self.paginate_queryset(queryset)
                if page is not None:
                    serializer = self.get_serializer(page, many=True)
                    paginated_response = self.get_paginated_response(serializer.data)
                    response_set = dict(paginated_response.data)
                    print(f"Type is : {type(response_set)}")
                    response_set["current_status"] = filter_queryset[0].status
                    return Response({
                        # 'data': paginated_response.data,
                        'count':response_set["count"],
                        'current_status':response_set["current_status"],
                        'data': response_set,
                        'message': "Data fetched successfully!"
                    }, status=status.HTTP_200_OK)

        if page is not None:
            serializer = VehicleRequestListSerializer(page, many=True)
            paginated_response = self.get_paginated_response(serializer.data)
            return Response({
                'data': paginated_response.data,
                'message': "Data fetched successfully."
            }, status=status.HTTP_200_OK)

        serializer = VehicleRequestListSerializer(queryset, many=True)
        return Response({
            'data': serializer.data,
            'message': "Data fetched successfully."
        }, status=status.HTTP_200_OK)


class FileRequestDateSearchView(APIView):
    permission_classes = [IsAuthenticated, ]
    authentication_classes = [TokenAuthentication, ]
    queryset = FileRequest.objects.filter(
        request_type='FILE_REQUEST'
    ).order_by('-created_at')
    serializer_class = VehicleRequestListSerializer
    pagination_class = SetPagination

    def get(self, request, *args, **kwargs):
        """ List all users in the system. """

        params = self.request.query_params
        from_date = params['from_date'] + ' 00:00:00'
        to_date = params['to_date'] + ' 23:59:59'
        from_date = datetime.strptime(from_date, '%Y-%m-%d %H:%M:%S')
        to_date = datetime.strptime(to_date, '%Y-%m-%d %H:%M:%S')

        if request.user.user_type == 5 or request.user.user_type == 2:
            queryset = FileRequest.objects.filter(
                created_at__gte=from_date,
                created_at__lte=to_date)
        else:
            queryset = FileRequest.objects.filter(
                created_at__gte=from_date,
                created_at__lte=to_date,
                user=request.user)
        serializer = self.serializer_class(queryset, many=True)
        return Response({
            'data': serializer.data,
            'message': 'Data fetched successfully.'
        }, status=status.HTTP_200_OK)


class FileRequestErrorView(APIView):
    permission_classes = [IsAuthenticated, ]
    authentication_classes = [TokenAuthentication, ]
    queryset = FileRequestHistory.objects.all()
    serializer_class = FileRequestHistorySerializer
    pagination_class = SetPagination

    def get(self, request, *args, **kwargs):
        """ List all users in the system. """

        params = self.request.query_params
        file_request_id = params['file_request_id']

        file_request = FileRequest.objects.get(request_id=file_request_id)
        queryset = FileRequestHistory.objects.filter(
            file_request_id=file_request,
            is_success=False)
        serializer = FileRequestHistorySerializer(queryset, many=True)
        return Response({
            'data': serializer.data,
            'message': 'Data fetched successfully.'
        }, status=status.HTTP_200_OK)


class FileRequestDirectoryView(APIView):
    # permission_classes = [IsAuthenticated,]
    # authentication_classes = [TokenAuthentication, ]
    queryset = FileRequestHistory.objects.all()
    serializer_class = FileRequestHistorySerializer
    pagination_class = SetPagination

    def get(self, request, request_id):
        """ List all users in the system. """

        is_file_dir_exist = False
        diretory_name = ''
        file = FileRequest.objects.get(request_id=request_id)
        try:
            diretory = Directory.objects.get(file_request=file)
            diretory_name = diretory.directory_path.split("/")[-1]
            is_file_dir_exist = True
        except Exception as error:
            is_file_dir_exist = False

        return Response({
            'data': {
                'is_file_dir_exist': is_file_dir_exist,
                'diretory_name': diretory_name
            },
            'message': 'Data fetched successfully.'
        }, status=status.HTTP_200_OK)


class UpdateCreditView(APIView):

    # permission_classes = [IsAuthenticated,]
    # authentication_classes = [TokenAuthentication, ]

    def get(self, request):

        truck_data = VehicleModel.objects.filter(vehicle_brand__vehicle_type__name='Truck')

        for d in truck_data:
            credit = VehicleModel.objects.get(id=d.id)
            credit.file_key_credit = 2
            credit.save()

        tractor_data = VehicleModel.objects.filter(vehicle_brand__vehicle_type__name='Tractor')

        for d in tractor_data:
            credit = VehicleModel.objects.get(id=d.id)
            credit.file_key_credit = 2
            credit.save()

        return Response({
            'message': 'Truck and tractor credit updated successfully.'
        }, status=status.HTTP_200_OK)


class UpdateECUPercentageView(APIView):

    # permission_classes = [IsAuthenticated,]
    # authentication_classes = [TokenAuthentication, ]

    def get(self, request):
        data = DataEcuVersion.objects.all().update(percentage=100)
        return Response({
            'message': 'All ecu percentage updated.'
        }, status=status.HTTP_200_OK)


class RefrenceMadeListView(APIView):
    permission_classes = [IsAuthenticated, ]
    authentication_classes = [TokenAuthentication, ]
    queryset = RefrenceMadeFile.objects.all()
    serializer_class = RefrenceMadeSerializer

    def get(self, request):
        file_name = request.query_params.get("file_name", '')
        queryset = self.queryset.filter(Q(file_name=file_name))
        serializer = self.serializer_class(queryset, many=True)

        return Response({
            "data": serializer.data,
            'message': 'Data fetched successfully.'
        }, status=status.HTTP_200_OK)
