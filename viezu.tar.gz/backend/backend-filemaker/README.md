# Pangea chat
### Prerequisites
- Python 3.8+ : [Installation](https://docs.python-guide.org/starting/install3/linux/)
- pip3 : [Installtion](https://pip.pypa.io/en/stable/installation/)
- Virtual environment :  [Installation](https://packaging.python.org/en/latest/guides/installing-using-pip-and-virtual-environments/)
- Postgres database : [installation](https://www.postgresql.org/download/linux/ubuntu/)

### Installation
Create a virtualenv of python
```sh
virtualenv -p python3 ven
```
Activate virtualenv
```sh
source venv/bin/activate
```
Install dependencies
```sh
pip install -r requirements.txt
```
### Configuring database
Put .env file in the directory with necessary credentials.

#### First time database setup commands

#### Migrate commands


Running project on machine
```sh
python manage.py makemigrations account --settings=file_maker_system.settings.local
python manage.py migrate account --settings=file_maker_system.settings.local

python manage.py runserver --settings=file_maker_system.settings.local
```

#### Running in browser
[Localhost](http://localhost:8000/)

#### EVC username and password
Username: 13213	
Password: ebKQbQZx5G7oI1Qe	
App Id: j34sbc93hb90


celery -A file_maker_system worker -l info
sudo docker exec -it 993cfa2dbb53 /bin/bash
To run task at local:
change IP:
3.214.165.93 to localhost
at base.py and celery.py, manage.py

ws://127.0.0.1:8000/notification/uuid

### CronJob run at local system

```sh
python manage.py crontab add --settings=file_maker_system.settings.local
python manage.py crontab remove --settings=file_maker_system.settings.local
python manage.py crontab show --settings=file_maker_system.settings.local
```

### Docker 
##### Check docker logs.

```sh
sudo docker ps -a
sudo docker logs "Container id"
```
redis-cli -h 127.0.0.1 -p 6379 slaveof no one

sudo docker logs
Check container logs:
==========================
ssh ubuntu@3.214.165.93

sudo docker logs containerid


Celery flower logs
celery flower --port=5555
http://localhost:5555/broker
celery -A file_maker_system flower --port=5555


Redis:
sudo systemctl restart redis
sudo systemctl status redis

read-replica status
1-redis-cli
2-config get replica-read-only

update read-replica status
1 - cd /etc/redis
2- vim redis.conf
3 -read-replica-only change yes to no update and save


organization id:Knowledgebase: 20065586995
organization id:Invoice: 20092267218

Redis server STAGE:
10.0.2.196

Redis server TESTING:
10.0.0.224

ws://localhost:8000/notification/2d22b375-82fd-446a-bd73-ca5b3134c4af  | akshay.sharma@oodles.io
ws://localhost:8000/notification/7ad1eea6-183a-4799-ad0e-5a40de095bf2  | local airemap
