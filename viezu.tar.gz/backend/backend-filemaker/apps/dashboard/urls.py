from django.urls import include, path
from apps.dashboard import views

app_name = 'dashboard'

technical_dashboard_patterns = [
    path('internal', views.InternalDashboardView.as_view()),
    path('internal/technical/month', views.TechnicalFileTATMonthView.as_view()), # Average File Turnaround Time
    path('internal/technical/used_keys/month', views.InternalUsedKeyMonthView.as_view()),
    path('internal/technical/top_sub_dealers/month', views.TopSubdealerMonthView.as_view()),
    path('internal/technical/all_top_sub_dealers/month', views.AllTopSubdealerMonthView.as_view()),
    path('internal/technical/file_by_model', views.VehicleModelFilesView.as_view()), # Files by Vehicle Make Model
    path('internal/technical/vehicle_tuned/category', views.VehicleTunedByCategoryView.as_view()),  # File Types per Month and year
    path('internal/technical/vehicle_tuned/type', views.VehicleTunedByTypeView.as_view()), # Vehicles Tuned by Type
    path('internal/technical/tool/usage', views.ToolUsageView.as_view()), # Technical Team Dashboard - Tool Usage
    path('internal/ticket/by_status/activity', views.InternalTicketByStatusActivity.as_view()), # Technical Team Dashboard Support Ticket Activity
    path('internal/file_request_by/category_and_credit', views.VehicleTunedByCategoryCreditView.as_view()), # File Maker Dashboard Activity and Performance
    path('internal/file_request_by/category_and_status', views.VehicleTunedByCategoryStatusView.as_view()), # Technical Team Dashboard - File Requests by Type
    path('internal/file_request_by/average/time', views.AverageTimeFileRequestView.as_view()), # File Maker Service Requests Timeline for File Production
    path('internal/file_request/success/number', views.FileSuccessNumberReport.as_view()), # File Maker Productivity Report /Files for Manual Handling
    path('internal/file_request/success/average', views.FileSuccessAverageReport.as_view()), # File Maker Success by Type/Average Time to Send For Manual Handling
    path('internal/file_request/failure/number', views.FileFailNumberReport.as_view()),
    path('internal/file_request/failure/average', views.FileFailAverageReport.as_view()),


    path('internal/technical/month/data', views.TechnicalFileTATMonthDataView.as_view()), # Average File Turnaround Time data
    path('internal/technical/vehicle_tuned/category/data', views.VehicleTunedByCategoryDataView.as_view()),  # File Types per Month and year data
    path('internal/ticket/by_status/activity/data', views.InternalTicketByStatusActivityData.as_view()), # Technical Team Dashboard Support Ticket Activity data

    path('internal/file_request_by/average/time/data', views.AverageTimeFileRequestViewData.as_view()), # File Maker Service Requests Timeline for File Production
    path('internal/file_request_by/category_and_credit/data', views.VehicleTunedByCategoryCreditViewData.as_view()), # File Maker Dashboard Activity and Performance
    # path('internal/file_request_by/category_and_status', views.VehicleTunedByCategoryStatusView.as_view()), # Technical Team Dashboard - File Requests by Type

    path('internal/technical/file_by_model/data', views.VehicleModelFilesDataView.as_view()), # Files by Vehicle Make Model data
    path('internal/technical/vehicle_tuned/type/data', views.VehicleTunedByTypeDataView.as_view()), # Vehicles Tuned by Type data
    path('internal/technical/tool/usage/data', views.ToolUsageDataView.as_view()), # Technical Team Dashboard - Tool Usage data
    path('internal/file_request/success/number/data', views.FileSuccessNumberDataReport.as_view()), # File Maker Productivity Report /Files for Manual Handling data
    path('internal/file_request/success/average/data', views.FileSuccessAverageReportData.as_view()), # File Maker Success by Type/Average Time to Send For Manual Handling
    path('internal/file_request/failure/number/data', views.FileFailNumberReportData.as_view()),
    path('internal/file_request/failure/average/data', views.FileFailAverageReportData.as_view()),

]

business_dashboard_patterns = [
    path('business/dashboard/stats', views.BusinessStatsView.as_view()),
    path('business/dashboard/used_keys/month', views.BusinessUsedKeyMonthView.as_view()),
    path('business/dashboard/ticket/status', views.BusinessTicketStatusView.as_view()),
    path('business/dashboard/file_request/tool', views.BusinessFileSubmittedByToolView.as_view()),
    path('business/dashboard/file_request/month', views.BusinessFileSubmittedView.as_view()),

    # Data Mode
    path('business/dashboard/used_keys/month/data', views.BusinessUsedKeyMonthViewData.as_view()),
    path('business/dashboard/ticket/status/data', views.BusinessTicketStatusDataView.as_view()),
    path('business/dashboard/file_request/tool/data', views.BusinessFileSubmittedByToolDataView.as_view()),
    path('business/dashboard/file_request/month/data', views.BusinessFileSubmittedDataView.as_view()),
]

subdealer_dashboard_patterns = [
    path('sub-dealer/dashboard/stats', views.SubDealerStatsView.as_view()),
    path('sub-dealer/dashboard/used_keys/month', views.SubDealerUsedKeyMonthView.as_view()),
    path('sub-dealer/dashboard/ticket/status', views.SubDealerTicketStatusView.as_view()),
    path('sub-dealer/dashboard/file_request/tool', views.SubDealerFileSubmittedByToolView.as_view()),
    path('sub-dealer/dashboard/file_request/month', views.SubDealerFileSubmittedView.as_view()),

    path('sub-dealer/dashboard/used_keys/month/data', views.SubDealerUsedKeyMonthDataView.as_view()),
    path('sub-dealer/dashboard/ticket/status/data', views.SubDealerTicketStatusDataView.as_view()),
    path('sub-dealer/dashboard/file_request/tool/data', views.SubDealerFileSubmittedByTooDatalView.as_view()),
    path('sub-dealer/dashboard/file_request/month/data', views.SubDealerFileSubmittedDataView.as_view()),
]

individual_dashboard_patterns = [
    path('individual/stats', views.IndividualStatsView.as_view()),
    path('individual/file_request/month', views.IndividualFileSubmittedView.as_view()),
    path('individual/file_requests/status', views.IndividualTicketByStatusView.as_view()),
    # path('individual/ticket_by_status/chart', views.IndividualTicketByStatusView.as_view()),
    # path('individual/file_requests/six/month', views.IndividualVehicleTunedSixMonthView.as_view()),
    # path('individual/vehicle_tuned/month/chart', views.IndividualVehicleTunedMonthView.as_view()),

    path('individual/file_request/month/data', views.IndividualFileSubmittedDataView.as_view()),
    path('individual/file_requests/status/data', views.IndividualTicketByStatusDataView.as_view()),

]

reseller_dashboard_patterns = [
    path('reseller/dashboard/stats', views.ResellerStatsView.as_view()),
    path('reseller/dashboard/file_tuned/month', views.ResellerVehicleTunedByMonthView.as_view()),
    path('reseller/dashboard/used_keys/month', views.ResellerUsedKeyMonthView.as_view()),
    path('reseller/ticket/by_status/activity', views.BusinessTicketByStatusActivity.as_view()),
    path('reseller/top_sub_dealer', views.ResellerTopDealersView.as_view()),
    path('reseller/dealer/spent', views.ResellerDealersSpentView.as_view()),

    path('reseller/dashboard/used_keys/month/data', views.ResellerUsedKeyMonthDataView.as_view()),
    path('reseller/ticket/by_status/activity/data', views.ResellerTicketByStatusActivityData.as_view()),
    path('reseller/dashboard/file_tuned/month/data', views.ResellerVehicleTunedByMonthDataView.as_view()),

]


management_dashboard_patterns = [
    path('internal/management/stats', views.ManagementDashboardStatsView.as_view()),
    path('internal/management/dealer/used_keys', views.DealerCreditUsageView.as_view()),

]

credit_patterns = [
    path('credit_spent', views.CreditSpentListView.as_view()),
    path('credit_purchase', views.CreditPurchaseListView.as_view()),
]

urlpatterns = (
    technical_dashboard_patterns + business_dashboard_patterns + individual_dashboard_patterns +
    reseller_dashboard_patterns + management_dashboard_patterns + credit_patterns + subdealer_dashboard_patterns
)
