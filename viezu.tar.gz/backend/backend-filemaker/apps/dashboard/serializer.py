from apps.file_request.models import FileRequest, FileRequestTime
from rest_framework import serializers
from apps.customer.models import CustomerSpentHistory, ResellerDistributeCredit
from django.db.models import Sum
from apps.account.models import MyUser


class CustomerSpentSerializer(serializers.ModelSerializer):

    name = serializers.SerializerMethodField()
    evc_credit = serializers.SerializerMethodField()
    function_credit = serializers.SerializerMethodField()
    file_credit = serializers.SerializerMethodField()

    class Meta:
        model = MyUser
        fields = ('name','evc_credit','function_credit', 'file_credit',)

# ()
    def get_name(self, obj):
        return obj.first_name +' '+obj.last_name

    def get_evc_credit(self, obj):
        instance =  obj.customer_spent.filter(credit_type = 2).aggregate(Sum('credit'))
        return instance['credit__sum'] if  'credit__sum' in instance and instance['credit__sum'] else 0

    def get_function_credit(self, obj):
        instance =   obj.customer_spent.filter(credit_type = 3).aggregate(Sum('credit'))
        return instance['credit__sum'] if  'credit__sum' in instance and instance['credit__sum'] else 0


    def get_file_credit(self, obj):
        instance =  obj.customer_spent.filter(credit_type = 1).aggregate(Sum('credit'))
        return instance['credit__sum'] if  'credit__sum' in instance and instance['credit__sum'] else 0
    
class CustomerSpentDataSerializer(serializers.ModelSerializer):

    # name = serializers.SerializerMethodField()
    # evc_credit = serializers.SerializerMethodField()
    # function_credit = serializers.SerializerMethodField()
    # file_credit = serializers.SerializerMethodField()

    class Meta:
        model = CustomerSpentHistory
        fields = "__all__"

# ()
    def get_name(self, obj):
        return obj.first_name +' '+obj.last_name

    def get_evc_credit(self, obj):
        instance =  obj.customer_spent.filter(credit_type = 2).aggregate(Sum('credit'))
        return instance['credit__sum'] if  'credit__sum' in instance and instance['credit__sum'] else 0

    def get_function_credit(self, obj):
        instance =   obj.customer_spent.filter(credit_type = 3).aggregate(Sum('credit'))
        return instance['credit__sum'] if  'credit__sum' in instance and instance['credit__sum'] else 0


    def get_file_credit(self, obj):
        instance =  obj.customer_spent.filter(credit_type = 1).aggregate(Sum('credit'))
        return instance['credit__sum'] if  'credit__sum' in instance and instance['credit__sum'] else 0

class ResellerDealerCreditSerializer(serializers.ModelSerializer):

    class Meta:
        model = ResellerDistributeCredit
        fields = "__all__"

class CustomerSpentDealerSerializer(serializers.ModelSerializer):

    class Meta:
        model = CustomerSpentHistory
        fields = "__all__"

class FileRequestTimeSerializer(serializers.ModelSerializer):

    class Meta:
        model = FileRequestTime
        fields = "__all__"

class VehicleRequestListDashboardSerializer(serializers.ModelSerializer):

    user = serializers.SerializerMethodField()
    credit_spent = serializers.SerializerMethodField()

    def get_credit_spent(self, obj):
        if type(obj) == dict:
            request_id = obj['request_id']
        else:
            request_id = obj.request_id

        data = {}
        queryset = CustomerSpentHistory.objects.filter(file_request_id = request_id)
        if len(queryset) > 0:
            queryset = queryset.first()
            data = {
                'credit_type':queryset.credit_type if queryset.credit_type else None,
                'credit':queryset.credit
            }
        
        return data

    def get_user(self, obj):
        print(obj)
        user = obj.user  
        return {
                'first_name':user.first_name,
                'last_name':user.last_name,
                'email':user.email
            }

    class Meta:
        model = FileRequest
        # fields = ('id','request_id','created_at', 'vehicle_type','vehicle_make','user','status',)
        fields = ("id","request_id","vehicle_type","vehicle_make",
                "model","vehicle_registration","vehicle_year",
                "vehicle_VIN","engine_size","transmission",
                "fuel_type","mileage_type","mileage",
                "ecu_brand","customer_first_name", "customer_last_name",
                "ecu_version","control_unit","file_type",
                "country","tuning_tool_used","tuning_required",
                "additional_info","tuning_file","user","status","created_at","credit_spent")