from apps.dashboard.serializer import (
    CustomerSpentDataSerializer, CustomerSpentDealerSerializer, CustomerSpentSerializer, FileRequestTimeSerializer, ResellerDealerCreditSerializer
)
from apps.file_request.serializer import VehicleRequestListSerializer, VehicleRequestSerializer
from apps.utils.pagination import SetPagination
from rest_framework.response import Response
from rest_framework.views import APIView

from rest_framework.authentication import TokenAuthentication
from rest_framework.permissions import IsAuthenticated
from django.db.models import Q,Avg
from apps.account.models import MyUser
from apps.utils.date_utils import get_current_date, get_back_date_by_number_of_days
from apps.account.serializer import UserDetailSerializer
from apps.admin_management.models import TicketHistory, TicketStatus
from apps.customer.serializer import (
    CustomerCreditSerializer, DashboardTicketHistorySerializer, OrderListSerializer, SpentHistorySerializer, TicketHistorySerializer
)
from rest_framework import status, generics, viewsets

from django.utils.timezone import now
from dateutil.relativedelta import relativedelta
import calendar
from apps.customer.models import (
    CustomerCredit, CustomerSpentHistory, 
    ManualCreditHistory, ResellerDistributeCredit
)
from apps.customer.models import OrderList

from apps.file_request.models import (
    FileRequest, FileRequestAveragePerformance, 
    FileRequestTime
)
from rest_framework import status
from datetime import datetime
from django.db.models import Count
from django.db.models.functions import TruncMonth, TruncDay

from django.db.models import Sum

def manage_ticket_user_status(status):
    status_list = []
    if status == "Closed":
        status_list = [20,41, 43]
    elif status == "In Progress":
        status_list = [19, 21]
    elif status == "Pending reply":
        status_list = [22]
    elif status == "In Development":
        status_list = [23, 24, 25, 26, 27, 28, 29, 30, 32]
    elif status == "ECU Booked in":
        status_list = [35]
    elif status == "Awaiting feedback":
        status_list = [33,34]
    elif status == "Escalated":
        status_list = [31]
    elif status == "Awaiting Feedback - Rework":
        status_list = [34]

    return status_list


def get_first_last_date():
    """Get first and last date of the current month.
    
    Args:None
    Return:
      month_first_day: date object
      month_last_day: date_object
    """
    current_date = datetime.now()
    month_first_day = current_date.replace(day=1, hour=0, minute=0, second=0, microsecond=0)
    last_day = calendar.monthrange(current_date.year, current_date.month)[1]
    month_last_day = current_date.replace(day=last_day, hour=0, minute=0, second=0, microsecond=0)
    return month_first_day, month_last_day

def get_first_and_last_date_by_args(month, year):
    from datetime import datetime, timedelta
    first_day = datetime(int(year), int(month), 1)

    # Calculate the last day of the month
    next_month = first_day.replace(day=28) + timedelta(days=4)
    last_day = next_month - timedelta(days=next_month.day)
    return first_day.strftime("%Y-%m-%d"), last_day.strftime("%Y-%m-%d")

def convert_to_date(start_date, end_date):
    import datetime

    format = '%Y-%m-%d'
    # convert from string format to datetime format
    start_date = datetime.datetime.strptime(start_date, format)
    end_date = datetime.datetime.strptime(end_date, format)
    return start_date, end_date

def create_dates_between_range(start_date, end_date):

    import datetime
    format = '%Y-%m-%d'
    start_date = datetime.datetime.strptime(start_date, format).date()
    end_date = datetime.datetime.strptime(end_date, format).date()
    from datetime import timedelta
    delta = timedelta(days=1)
    dates = []

    while start_date <= end_date:
        dates.append(start_date.isoformat())
        start_date += delta

    dates = [datetime.datetime.strptime(date, format) for date in dates]
    return dates

def get_month_first_and_last_date_by_month(year, month_number):
    print(year, month_number)

    import calendar
    _, last_day = calendar.monthrange(year, month_number)
    first_date = f"{year}-{month_number:02d}-01"  # Formatting to YYYY-MM-DD
    last_date = f"{year}-{month_number:02d}-{last_day}"  # Formatting to YYYY-MM-DD

    first_date = datetime.strptime(first_date, "%Y-%m-%d").date()
    last_date = datetime.strptime(last_date, "%Y-%m-%d").date()

    return first_date, last_date

def seconds_to_hms(seconds):
    hours, remainder = divmod(seconds, 3600)
    minutes, seconds = divmod(remainder, 60)
    return "{:02}:{:02}:{:02}".format(int(hours), int(minutes), int(seconds))

class InternalDashboardView(APIView):
    permission_classes = [IsAuthenticated,]
    authentication_classes = [TokenAuthentication, ]

    def file_request_last_six_month(self):
        start_date = now() - relativedelta(months=+5)
        end_date =  now() 
        file_request = FileRequest.objects.filter(created_at__gte=start_date)
        labels = []
        open_data = []
        close_data = []
        in_progress = []
        issue_data = []

        while start_date <= end_date:
            labels.append(start_date.strftime("%b"))
            open_data.append(file_request.filter(status = 'OPEN',created_at__month = start_date.month,created_at__year = start_date.year).count())
            close_data.append(file_request.filter(status = 'CLOSED',created_at__month = start_date.month,created_at__year = start_date.year).count())
            in_progress.append(file_request.filter(status = 'IN_PROGRESS',created_at__month = start_date.month,created_at__year = start_date.year).count())
            issue_data.append(file_request.filter(status = 'ISSUE',created_at__month = start_date.month,created_at__year = start_date.year).count())
            start_date += relativedelta(months=1)


        filedata={
            'labels': labels,
            'datasets': [{
                'label': "Open",
                'data': open_data,
                'backgroundColor': '#3DCAB1',
                # 'barThickness':10
            },
            {
                'label': "Close",
                'data': close_data,
                'backgroundColor': '#FE7375',
                # 'barThickness': 10
            
            },
            {
                'label': "In progress",
                'data': in_progress,
                'backgroundColor': '#FFA500',
                # 'barThickness': 10
                
            },
            {
                'label': "Issue",
                'data': issue_data,
                'backgroundColor': '#7B8196',
                # 'barThickness': 10
                
            }]
        }

        return filedata

    def ticket_data_last_six_month(self):
        start_date = now() - relativedelta(months=+5)
        end_date =  now() 
        queryset = TicketHistory.objects.filter(created_at__gte=start_date)
        labels = []
        open_data = []
        close_data = []
        
        while start_date <= end_date:
            labels.append(start_date.strftime("%b"))
            open_data.append(queryset.filter(created_at__month = start_date.month,created_at__year = start_date.year).exclude(ticket_status__user_status=3).count())
            close_data.append(queryset.filter(created_at__month = start_date.month,created_at__year = start_date.year).filter(ticket_status__user_status=3).count())
            start_date += relativedelta(months=1)

        ticketData={
            'labels':labels,
            'datasets': [{ 
                'label': "Open",
                'data': open_data,
                'backgroundColor': '#3DCAB1',
                'barThickness':10
            },
            {
                'label': "Close",
                'data': close_data,
                'backgroundColor': '#FE7375',
                'barThickness': 10
                
            }]
        }

        return ticketData


    def get(self,request):

        current_date = get_current_date()
        last_week_date = get_back_date_by_number_of_days(current_date)

        #customers data
        list_of_customers = MyUser.objects.filter(Q(user_type=3)|Q(user_type=4))
        total_customers = list_of_customers.count()
        last_week_customers = list_of_customers.filter(
            created_at__gte=last_week_date, 
            created_at__lte=current_date
        ).order_by('-created_at')
        recent_five_customers_queryset = last_week_customers[:5]
        recent_five_customers_serializer = UserDetailSerializer(recent_five_customers_queryset, many=True)

        # Ticket data
        active_ticket_from_last_week = TicketHistory.objects.filter(created_at__gte=last_week_date, 
                                created_at__lte=current_date,ticket_status__user_status=4).order_by('-created_at')
        recent_active_five_ticket_queryset = active_ticket_from_last_week[:5]
        recent_active_five_ticket = DashboardTicketHistorySerializer(recent_active_five_ticket_queryset, many=True)



        #File Data last 6 Mont Status  
        filedata = self.file_request_last_six_month()      

        # Ticket Data last 6 month status wise
        ticketData = self.ticket_data_last_six_month()

        data = {
                'files_graph':filedata,
                'tickets_graph':ticketData,
                'total_customers_count':total_customers,
                'last_week_customers_count':last_week_customers.count(),
                'recent_five_customers':recent_five_customers_serializer.data,
                'active_ticket':active_ticket_from_last_week.count(),
                'recent_active_five_ticket':recent_active_five_ticket.data}
        return Response({
            'data': data,
            'message':"Statics loaded successfully."
        }, status=status.HTTP_200_OK)

class BusinessFileSubmittedView(APIView):

    permission_classes = [IsAuthenticated,]
    authentication_classes = [TokenAuthentication, ]

    def get(self,request):

        file_by_month = []
        data = {}
        range = request.query_params.get("range",6)
        if int(range) != -1:
            if int(range) == 1:
                range = 12

            start_date = now() - relativedelta(months=+int(range)-1)
            end_date =  now() 

            while start_date <= end_date:
                start_date = start_date.replace(day=1, hour=0, minute=0, second=0, microsecond=0)
                last_date = calendar.monthrange(start_date.year, start_date.month)[1]
                month_last_day = start_date.replace(day=last_date, hour=0, minute=0, second=0, microsecond=0)
                data = FileRequest.objects.filter(
                        user = request.user,
                        created_at__gte = start_date,
                        created_at__lte = month_last_day
                    ).count()
                file_by_month.append({'month':start_date.strftime("%b-%Y"),'count':data})
                start_date += relativedelta(months=1)
        else:
            format = '%Y-%m-%d'
            start_date = request.query_params.get("start_date")
            end_date = request.query_params.get("end_date")

            start_date = datetime.strptime(start_date, format)
            end_date = datetime.strptime(end_date, format)

            while start_date <= end_date:
                data = FileRequest.objects.filter(
                        user = request.user,
                        created_at__date = start_date,
                    ).count()
                file_by_month.append({'month':start_date.strftime("%d-%b-%Y"),'count':data})
                start_date += relativedelta(days=1)


        return Response({
            'data': file_by_month,
            'message':"Statics loaded successfully."
        }, status=status.HTTP_200_OK)
    
class BusinessFileSubmittedDataView(APIView):

    permission_classes = [IsAuthenticated,]
    authentication_classes = [TokenAuthentication, ]

    def get(self,request):
        data_by = request.query_params.get("data_by","month")
        month_number = request.query_params.get("month_number")
        year = request.query_params.get("year", datetime.now().year)


        if data_by == "month":
            start_date, month_last_day = get_first_and_last_date_by_args(month_number, year)
            queryset = FileRequest.objects.filter(
                        user = request.user,
                        created_at__gte = start_date,
                        created_at__lte = month_last_day
                    )

        if data_by == "date":
            start_date = request.query_params.get("start_date")
            end_date = request.query_params.get("end_date")
            queryset = FileRequest.objects.filter(
                        user = request.user,
                        created_at__gte = start_date,
                        created_at__lte = end_date
                    )

        serializer = VehicleRequestSerializer(queryset, many = True)

        return Response({
            'data': serializer.data,
            'message':"Statics loaded successfully."
        }, status=status.HTTP_200_OK)


class BusinessFileSubmittedByToolView(APIView):

    permission_classes = [IsAuthenticated,]
    authentication_classes = [TokenAuthentication, ]

    def get(self,request):

        now_year = datetime.now().year
        filter_type = request.query_params.get("filter_type")

        month = int(request.query_params.get("month",1))
        year = int(request.query_params.get("year",now_year))

        if filter_type == "date":
            from_date = request.query_params.get("from_date")
            to_date = request.query_params.get("to_date")
            month_first_day, month_last_day = convert_to_date(from_date, to_date)
        else:
            month_first_day, month_last_day =  get_month_first_and_last_date_by_month(year, month)
            
        # month_first_day,month_last_day = get_first_last_date()
        queryset = FileRequest.objects.filter(
                    user=request.user,
                    created_at__gte = month_first_day,
                    created_at__lte = month_last_day
                    ).values('tuning_tool_used').annotate(
                    count=Count('tuning_tool_used')).order_by('count')


        return Response({
            'data': queryset,
            'message':"File data loaded successfully."
        }, status=status.HTTP_200_OK)
    

class BusinessFileSubmittedByToolDataView(APIView):

    permission_classes = [IsAuthenticated,]
    authentication_classes = [TokenAuthentication, ]

    def get(self,request):

        now_year = datetime.now().year
        filter_type = request.query_params.get("filter_type")

        month = int(request.query_params.get("month",1))
        year = int(request.query_params.get("year",now_year))
        tool_name = request.query_params.get("tool_name")

        if filter_type == "date":
            from_date = request.query_params.get("from_date")
            to_date = request.query_params.get("to_date")
            month_first_day, month_last_day = convert_to_date(from_date, to_date)
        else:
            month_first_day, month_last_day =  get_month_first_and_last_date_by_month(year, month)

        queryset = FileRequest.objects.filter(user=request.user, created_at__gte = month_first_day,
                                        created_at__lte = month_last_day, tuning_tool_used = tool_name)
        serializer = VehicleRequestSerializer(queryset, many = True)

        return Response({
            'data': serializer.data,
            'message':"File data loaded successfully."
        }, status=status.HTTP_200_OK)
    
class BusinessTicketStatusView(APIView):

    permission_classes = [IsAuthenticated,]
    authentication_classes = [TokenAuthentication, ]

    def get(self,request):
        now_year = datetime.now().year
        filter_type = request.query_params.get("filter_type")

        month = int(request.query_params.get("month",1))
        year = int(request.query_params.get("year",now_year))

        if filter_type == "date":
            from_date = request.query_params.get("from_date")
            to_date = request.query_params.get("to_date")
            month_first_day, month_last_day = convert_to_date(from_date, to_date)
        else:
            month_first_day, month_last_day =  get_month_first_and_last_date_by_month(year, month)
        data = TicketHistory.objects.filter(
                created_by = request.user,
                created_at__gte = month_first_day,
                created_at__lte = month_last_day
            ).aggregate(
                new=Count('pk', filter=Q(ticket_status__in=[18]) | Q(ticket_status__isnull=True)),
                closed=Count('pk', filter=Q(ticket_status__in=[20,41, 43])),
                in_progress=Count('pk', filter=Q(ticket_status__in=[19, 21])),
                pending_reply=Count('pk', filter=Q(ticket_status__in=[22])),      
                in_development=Count('pk', filter=Q(ticket_status__in=[23, 24, 25, 26, 27, 28, 29, 30, 32])),   
                ecu_booked_in=Count('pk', filter=Q(ticket_status__in=[35])),   
                awaiting_feedback=Count('pk', filter=Q(ticket_status__in=[33,34])),  
                esclated = Count('pk', filter=Q(ticket_status__in=[31])),   
        )

        return Response({
            'data': data,
            'message':"Statics loaded successfully."
        }, status=status.HTTP_200_OK)
    
class BusinessTicketStatusDataView(APIView):

    permission_classes = [IsAuthenticated,]
    authentication_classes = [TokenAuthentication, ]

    def get(self,request):
        now_year = datetime.now().year
        filter_type = request.query_params.get("filter_type")

        month = int(request.query_params.get("month",1))
        year = int(request.query_params.get("year",now_year))
        ticket_status = request.query_params.get("status")

        if filter_type == "date":
            from_date = request.query_params.get("from_date")
            to_date = request.query_params.get("to_date")
            month_first_day, month_last_day = convert_to_date(from_date, to_date)
        else:
            month_first_day, month_last_day =  get_month_first_and_last_date_by_month(year, month)

        status_list = manage_ticket_user_status(ticket_status)

        if ticket_status != "New":
            print(1)
            queryset = TicketHistory.objects.filter(
                    created_by = request.user,
                    created_at__gte = month_first_day,
                    created_at__lte = month_last_day,
                    ticket_status__in = status_list
                )
        else:
            print(2)
            queryset = TicketHistory.objects.filter(
                    Q(ticket_status__in=[18]) | Q(ticket_status__isnull=True),
                    created_by = request.user,
                    created_at__gte = month_first_day,
                    created_at__lte = month_last_day,
                )
        
        serializer = TicketHistorySerializer(queryset, many=True)

        return Response({
            'data': serializer.data,
            'message':"Statics loaded successfully."
        }, status=status.HTTP_200_OK)

class BusinessStatsView(APIView):

    permission_classes = [IsAuthenticated,]
    authentication_classes = [TokenAuthentication, ]

    def get(self,request):
        data = {}

        # from_date = request.query_params.get("from_date")
        # to_date = request.query_params.get("to_date")

        # if from_date is not None and to_date is not None:
        #     month_first_day, month_last_day = convert_to_date(from_date, to_date)
        # else:
        #     month_first_day,month_last_day = get_first_last_date()
        # month = int(request.query_params.get("month",1))
        # year = datetime.now().year
        # month_first_day, month_last_day =  get_month_first_and_last_date_by_month(year, month)
        month_first_day,month_last_day = get_first_last_date()
        print(month_first_day, month_last_day)
        # Credit spent history
        credit_spent_count = CustomerSpentHistory.objects.filter(
                        created_at__gte = month_first_day,
                        created_at__lte = month_last_day,
                        user=request.user).aggregate(Sum('credit'))
        data['credit_spent_current_month'] = credit_spent_count['credit__sum']

        # credit purchase history
        file_credit_purchased_sum = OrderList.objects.filter(
                                  created_at__gte = month_first_day,
                                  created_at__lte = month_last_day,
                                  status = 2,
                                  user=request.user).aggregate(Sum('file_credit'))
        file_credit_purchased_sum = 0 if file_credit_purchased_sum['file_credit__sum'] is None else file_credit_purchased_sum['file_credit__sum']

        function_credit_purchased_sum = OrderList.objects.filter(
                                  created_at__gte = month_first_day,
                                  created_at__lte = month_last_day,
                                  status = 2,
                                  user=request.user).aggregate(Sum('function_credit'))
        function_credit_purchased_sum = 0 if function_credit_purchased_sum['function_credit__sum'] is None else function_credit_purchased_sum['function_credit__sum']

        evc_credit_purchased_sum = OrderList.objects.filter(
                                  created_at__gte = month_first_day,
                                  created_at__lte = month_last_day,
                                  status = 2,
                                  user=request.user).aggregate(Sum('evc_credit'))
        evc_credit_purchased_sum = 0 if evc_credit_purchased_sum['evc_credit__sum'] is None else evc_credit_purchased_sum['evc_credit__sum']

        data['credit_purchased'] = file_credit_purchased_sum + \
                                   function_credit_purchased_sum + \
                                   evc_credit_purchased_sum

        # Available customer credit
        queryset_available_credit = CustomerCredit.objects.filter(user=request.user)
        data['available_credit_balance'] = CustomerCreditSerializer(queryset_available_credit,many=True).data

        return Response({
            'data': data,
            'message':"Statics loaded successfully."
        }, status=status.HTTP_200_OK)

class BusinessUsedKeyMonthView(APIView):

    permission_classes = [IsAuthenticated,]
    authentication_classes = [TokenAuthentication, ]

    def get(self,request):
        data = {}
        range = request.query_params.get("range",6)
        if int(range) != -1:
            if int(range) == 1:
                range = 11

            start_date = now() - relativedelta(months=+int(range)-1)
            end_date =  now() 

            credit_used_by_month = []
            while start_date <= end_date:
                start_date = start_date.replace(day=1, hour=0, minute=0, second=0, microsecond=0)
                last_date = calendar.monthrange(start_date.year, start_date.month)[1]
                month_last_day = start_date.replace(day=last_date, hour=0, minute=0, second=0, microsecond=0)
                queryset = CustomerSpentHistory.objects.filter(
                                                user = request.user,
                                                created_at__gte = start_date,
                                                created_at__lte = month_last_day
                                            ).aggregate(
                                                file_credit=Sum('credit', filter=Q(credit_type=1)),
                                                evc_credit=Sum('credit', filter=Q(credit_type=2)),
                                                function_credit=Sum('credit', filter=Q(credit_type=3)), 
                                        )
                credit_used_by_month.append({'month':start_date.strftime("%b-%Y"),'credit':queryset})
                start_date += relativedelta(months=1)

            data['credit_used_by_month'] = credit_used_by_month
        elif int(range) == -1:
            print(2)
            start_date = request.query_params.get("start_date")
            end_date = request.query_params.get("end_date")
            credit_data = CustomerSpentHistory.objects.filter(
                            created_at__range=[start_date, end_date],
                            user = request.user).values(
                            'created_at__date'
                        ).annotate(
                file_credit=Sum('credit', filter=Q(credit_type=1)),
                function_credit=Sum('credit', filter=Q(credit_type=3)),
                evc_credit=Sum('credit', filter=Q(credit_type=2)),
            ).order_by('created_at__date')

            data['credit_used_by_month'] = [
                {
                    "month": item['created_at__date'].strftime('%d-%b-%Y'),
                    "credit": {
                        "file_credit": item['file_credit'] or 0,
                        "function_credit": item['function_credit'] or 0,
                        "evc_credit": item['evc_credit'] or 0,
                    }
                }
                for item in credit_data
            ]

        return Response({
            'data': data,
            'message':"Statics loaded successfully."
        }, status=status.HTTP_200_OK)
    
class BusinessUsedKeyMonthViewData(APIView):

    permission_classes = [IsAuthenticated,]
    authentication_classes = [TokenAuthentication, ]

    def get(self,request):
        data_by = request.query_params.get("data_by","month")
        month_number = request.query_params.get("month_number")
        year = request.query_params.get("year", datetime.now().year)

        if data_by == "month":
            start_date, month_last_day = get_first_and_last_date_by_args(month_number, year)
            queryset = CustomerSpentHistory.objects.filter(user = request.user, created_at__range = [start_date, month_last_day])
            serializer = CustomerSpentDataSerializer(queryset, many=True)
            return Response({
                'data': serializer.data,
                'message':"Statics loaded successfully."
            }, status=status.HTTP_200_OK)
        
        elif data_by == "date":
            start_date = request.query_params.get("start_date")
            end_date = request.query_params.get("end_date")
            queryset = CustomerSpentHistory.objects.filter(created_at__range=[start_date, end_date],user = request.user)
            serializer = CustomerSpentDataSerializer(queryset, many=True)
            return Response({
                'data': serializer.data,
                'message':"Statics loaded successfully."
            }, status=status.HTTP_200_OK)

class ResellerStatsView(APIView):

    permission_classes = [IsAuthenticated,]
    authentication_classes = [TokenAuthentication, ]

    def get(self,request):
        data = {}

        from_date = request.query_params.get("from_date")
        to_date = request.query_params.get("to_date")

        if from_date is not None and to_date is not None:
            month_first_day, month_last_day = convert_to_date(from_date, to_date)
        else:
            month_first_day,month_last_day = get_first_last_date()
        # Credit spent history
        credit_spent_count = CustomerSpentHistory.objects.filter(
                        created_at__gte = month_first_day,
                        created_at__lte = month_last_day,
                        user=request.user).aggregate(Sum('credit'))
        data['credit_spent_current_month'] = 0 if credit_spent_count['credit__sum'] is None else credit_spent_count['credit__sum'] 

        # credit purchase history
        file_credit_purchased_sum = OrderList.objects.filter(
                                  created_at__gte = month_first_day,
                                  created_at__lte = month_last_day,
                                  status = 2,
                                  user=request.user).aggregate(Sum('file_credit'))
        file_credit_purchased_sum = 0 if file_credit_purchased_sum['file_credit__sum'] is None else file_credit_purchased_sum['file_credit__sum']

        function_credit_purchased_sum = OrderList.objects.filter(
                                  created_at__gte = month_first_day,
                                  created_at__lte = month_last_day,
                                  status = 2,
                                  user=request.user).aggregate(Sum('function_credit'))
        function_credit_purchased_sum = 0 if function_credit_purchased_sum['function_credit__sum'] is None else function_credit_purchased_sum['function_credit__sum']

        evc_credit_purchased_sum = OrderList.objects.filter(
                                  created_at__gte = month_first_day,
                                  created_at__lte = month_last_day,
                                  status = 2,
                                  user=request.user).aggregate(Sum('evc_credit'))
        evc_credit_purchased_sum = 0 if evc_credit_purchased_sum['evc_credit__sum'] is None else evc_credit_purchased_sum['evc_credit__sum']


        data['credit_purchased'] = file_credit_purchased_sum + \
                                   function_credit_purchased_sum + \
                                   evc_credit_purchased_sum

        unallocated_subdealer_keys_queryset = ResellerDistributeCredit.objects.filter(user = request.user)
        unallocated_serializer = ResellerDealerCreditSerializer(unallocated_subdealer_keys_queryset, many=True)
        data['unallocated_keys_sub_dealer'] = unallocated_serializer.data
        # Available customer credit
        queryset_available_credit = CustomerCredit.objects.filter(user=request.user)
        data['available_credit_balance'] = CustomerCreditSerializer(queryset_available_credit,many=True).data

        data['sub_dealer_count'] = MyUser.objects.filter(parent__uuid = request.user.uuid).count()
        
        return Response({
            'data': data,
            'message':"Statics loaded successfully."
        }, status=status.HTTP_200_OK)

class ResellerVehicleTunedByMonthView(APIView):

    permission_classes = [IsAuthenticated,]
    authentication_classes = [TokenAuthentication, ]

    def get(self,request):
        data = {}
        tuned_by_month = []

        reseller = MyUser.objects.filter(uuid = request.user.uuid)
        subdealers_list = MyUser.objects.filter(parent__uuid = request.user.uuid)
        users_list = subdealers_list | reseller

        filter_by = request.query_params.get("filter_by")
        month_number = int(request.query_params.get("month_number",1))
        range = int(request.query_params.get("range",6))

        if filter_by == 'month' and month_number:
            year = datetime.now().year
            start_date, month_last_day =  get_month_first_and_last_date_by_month(year, month_number)
            month_name = calendar.month_name[month_number]+'-'+ str(year)

            queryset = FileRequest.objects.filter(
                                user__in = users_list,
                                created_at__gte = start_date,
                                created_at__lte = month_last_day,
                        ).count()
            tuned_by_month.append({'month':month_name,'count':queryset})
            
        if filter_by == 'range':
            if int(range) == 1:
                range = 12
            start_date = now() - relativedelta(months=+int(range)-1)
            end_date =  now() 

            while start_date <= end_date:
                start_date = start_date.replace(day=1, hour=0, minute=0, second=0, microsecond=0)
                last_date = calendar.monthrange(start_date.year, start_date.month)[1]
                month_last_day = start_date.replace(day=last_date, hour=0, minute=0, second=0, microsecond=0)
                queryset = FileRequest.objects.filter(
                                    user__in = users_list,
                                    created_at__gte = start_date,
                                    created_at__lte = month_last_day,
                            ).count()
                tuned_by_month.append({'month':start_date.strftime("%b-%Y"),'count':queryset})
                start_date += relativedelta(months=1)

        if filter_by == 'date':
            format = '%Y-%m-%d'
            start_date = request.query_params.get("start_date")
            end_date = request.query_params.get("end_date")

            start_date = datetime.strptime(start_date, format)
            end_date = datetime.strptime(end_date, format)

            while start_date <= end_date:
                queryset = FileRequest.objects.filter(
                                    user__in = users_list,
                                    created_at__date = start_date,
                            ).count()
                tuned_by_month.append({'month':start_date.strftime("%d-%b-%Y"),'count':queryset})
                start_date += relativedelta(days=1)

        data['vehicle_tuned'] = tuned_by_month
        return Response({
            'data': data,
            'message':"Statics loaded successfully."
        }, status=status.HTTP_200_OK)

class ResellerUsedKeyMonthView(APIView):

    permission_classes = [IsAuthenticated,]
    authentication_classes = [TokenAuthentication, ]

    def get(self,request):
        data = {}
        credit_used_by_month = []

        reseller = MyUser.objects.filter(uuid = request.user.uuid)
        subdealers_list = MyUser.objects.filter(parent__uuid = request.user.uuid)
        users_list = subdealers_list | reseller

        filter_by = request.query_params.get("filter_by")
        month_number = int(request.query_params.get("month_number",1))
        range = int(request.query_params.get("range",6))

        if filter_by == 'month' and month_number:
            year = datetime.now().year
            start_date, month_last_day =  get_month_first_and_last_date_by_month(year, month_number)
            month_name = calendar.month_name[month_number]+'-'+ str(year)
            queryset = CustomerSpentHistory.objects.filter(
                                            user__in = users_list,
                                            created_at__gte = start_date,
                                            created_at__lte = month_last_day
                                        ).aggregate(
                                            file_credit=Sum('credit', filter=Q(credit_type=1)),
                                            evc_credit=Sum('credit', filter=Q(credit_type=2)),
                                            function_credit=Sum('credit', filter=Q(credit_type=3)), 
                                    )
            credit_used_by_month.append({'month':month_name,'credit':queryset})

        if filter_by == 'range':
            if int(range) == 1:
                range = 12
            start_date = now() - relativedelta(months=+int(range)-1)
            end_date =  now() 

            while start_date <= end_date:
                start_date = start_date.replace(day=1, hour=0, minute=0, second=0, microsecond=0)
                last_date = calendar.monthrange(start_date.year, start_date.month)[1]
                month_last_day = start_date.replace(day=last_date, hour=0, minute=0, second=0, microsecond=0)
                queryset = CustomerSpentHistory.objects.filter(
                                                user__in = users_list,
                                                created_at__gte = start_date,
                                                created_at__lte = month_last_day
                                            ).aggregate(
                                                file_credit=Sum('credit', filter=Q(credit_type=1)),
                                                evc_credit=Sum('credit', filter=Q(credit_type=2)),
                                                function_credit=Sum('credit', filter=Q(credit_type=3)), 
                                        )
                credit_used_by_month.append({'month':start_date.strftime("%b-%Y"),'credit':queryset})
                start_date += relativedelta(months=1)


        if filter_by == 'date':
            format = '%Y-%m-%d'
            start_date = request.query_params.get("start_date")
            end_date = request.query_params.get("end_date")

            start_date = datetime.strptime(start_date, format)
            end_date = datetime.strptime(end_date, format)

            while start_date <= end_date:
                queryset = CustomerSpentHistory.objects.filter(
                                                user__in = users_list,
                                                created_at__date = start_date,
                                            ).aggregate(
                                                file_credit=Sum('credit', filter=Q(credit_type=1)),
                                                evc_credit=Sum('credit', filter=Q(credit_type=2)),
                                                function_credit=Sum('credit', filter=Q(credit_type=3)), 
                                        )
                credit_used_by_month.append({'month':start_date.strftime("%d-%b-%Y"),'credit':queryset})
                start_date += relativedelta(days=1)

        data['credit_used_by_month'] = credit_used_by_month

        return Response({
            'data': data,
            'message':"Statics loaded successfully."
        }, status=status.HTTP_200_OK)

class BusinessTicketByStatusActivity(APIView):

    permission_classes = [IsAuthenticated,]
    authentication_classes = [TokenAuthentication, ]

    def get(self,request):
        now_year = datetime.now().year
        filter_type = request.query_params.get("filter_type")

        month = int(request.query_params.get("month",1))
        year = int(request.query_params.get("year",now_year))

        if filter_type == "date":
            from_date = request.query_params.get("from_date")
            to_date = request.query_params.get("to_date")
            month_first_day, month_last_day = convert_to_date(from_date, to_date)
        else:
            month_first_day, month_last_day =  get_month_first_and_last_date_by_month(year, month)

        data = TicketHistory.objects.filter(
                created_by = request.user,
                created_at__gte = month_first_day,
                created_at__lte = month_last_day
            ).aggregate(
                new=Count('pk', filter=Q(ticket_status__in=[18]) | Q(ticket_status__isnull=True)),
                closed=Count('pk', filter=Q(ticket_status__in=[20,41, 43])),
                in_progress=Count('pk', filter=Q(ticket_status__in=[19, 21])),
                pending_reply=Count('pk', filter=Q(ticket_status__in=[22])),       
                in_development=Count('pk', filter=Q(ticket_status__in=[23, 24, 25, 26, 27, 28, 29, 30, 32])),   
                ecu_booked_in=Count('pk', filter=Q(ticket_status__in=[35])),   
                awaiting_feedback=Count('pk', filter=Q(ticket_status__in=[33,34])),  
                esclated = Count('pk', filter=Q(ticket_status__in=[31])),    
        )

        return Response({
            'data': data,
            'message':"Statics loaded successfully."
        }, status=status.HTTP_200_OK)

class ResellerTopDealersView(APIView):

    permission_classes = [IsAuthenticated,]
    authentication_classes = [TokenAuthentication, ]

    def get(self,request):

        data = {}
        start_date = request.query_params.get("start_date")
        end_date = request.query_params.get("end_date")
        if start_date and end_date:
            start_date, end_date = convert_to_date(start_date, end_date)
        else:
            start_date,end_date = get_first_last_date()
        sub_dealers_list = MyUser.objects.filter(parent__uuid = request.user.uuid)

        top_sub_dealers = []
        for dealer in sub_dealers_list:
            user_data = {}
            user_data['dealer_name'] = dealer.first_name +' '+ dealer.last_name
            user_data['dealer_profile_image'] = dealer.image.url if dealer.image else None
            user_data['uuid'] = dealer.uuid
            queryset = CustomerSpentHistory.objects.filter(
                                            user = dealer,
                                            created_at__gte = start_date,
                                            created_at__lte = end_date
                                        ).aggregate(Sum('credit'))
            user_data['total_credit_spent'] = queryset['credit__sum']
            top_sub_dealers.append(user_data)

        from operator import itemgetter
        if len(top_sub_dealers) > 0:
            not_none_dealers = []
            for d in top_sub_dealers:
                if d['total_credit_spent'] is not None:
                    not_none_dealers.append(d)
            
            if len(not_none_dealers) > 0:
                top_sub_dealers = sorted(not_none_dealers, key=itemgetter('total_credit_spent'), reverse=True)
            else:
                top_sub_dealers = []
        else:
            top_sub_dealers =[]
        data['top_sub_dealers'] = top_sub_dealers

        return Response({
            'data': data,
            'message':"Statics loaded successfully."
        }, status=status.HTTP_200_OK)
    
class ResellerDealersSpentView(APIView):

    permission_classes = [IsAuthenticated,]
    authentication_classes = [TokenAuthentication, ]

    def get(self,request):

        dealer = MyUser.objects.get(uuid=request.query_params.get("uuid"))
        start_date,end_date = get_first_last_date()
        queryset = CustomerSpentHistory.objects.filter(
                                        user = dealer,
                                        created_at__gte = start_date,
                                        created_at__lte = end_date)
        serializer = CustomerSpentDealerSerializer(queryset, many=True)
        return Response({
            'data': serializer.data,
            'message':"Statics loaded successfully."
        }, status=status.HTTP_200_OK)

class TechnicalFileTATMonthView(APIView):

    permission_classes = [IsAuthenticated,]
    authentication_classes = [TokenAuthentication, ]

    def get(self,request):
        data = {}
        tat_by_month = []

        filter_by = request.query_params.get("filter_by")
        month_number = int(request.query_params.get("month_number",1))
        range = int(request.query_params.get("range",6))
        year = datetime.now().year
        year = int(request.query_params.get("year",year))            

        if filter_by == 'month' and month_number:
            start_date, month_last_day =  get_month_first_and_last_date_by_month(year, month_number)
            month_name = calendar.month_name[month_number]+'-'+ str(year)
            queryset = FileRequestTime.objects.filter(
                                            created_at__gte = start_date,
                                            created_at__lte = month_last_day
                                        ).aggregate(Sum('second_diff'))
            tat = 0 if queryset['second_diff__sum'] is None else queryset['second_diff__sum']
            tat_by_month.append({'month':month_name,'tat':tat})

        if filter_by == 'range':
            if int(range) == 1:
                range = 12
            start_date = now() - relativedelta(months=+int(range)-1)
            end_date =  now() 

            while start_date <= end_date:
                start_date = start_date.replace(day=1, hour=0, minute=0, second=0, microsecond=0)
                last_date = calendar.monthrange(start_date.year, start_date.month)[1]
                month_last_day = start_date.replace(day=last_date, hour=0, minute=0, second=0, microsecond=0)
                queryset = FileRequestTime.objects.filter(
                                                created_at__gte = start_date,
                                                created_at__lte = month_last_day
                                            ).aggregate(Sum('second_diff'))
                tat = 0 if queryset['second_diff__sum'] is None else queryset['second_diff__sum']
                tat_by_month.append({'month':start_date.strftime("%b-%Y"),'tat':tat})
                start_date += relativedelta(months=1)

        if filter_by == 'date':
            format = '%Y-%m-%d'
            start_date = request.query_params.get("start_date")
            end_date = request.query_params.get("end_date")

            start_date = datetime.strptime(start_date, format)
            end_date = datetime.strptime(end_date, format)

            while start_date <= end_date:
                queryset = FileRequestTime.objects.filter(
                                                created_at__date = start_date.date(),
                                            ).aggregate(Sum('second_diff'))
                tat = 0 if queryset['second_diff__sum'] is None else queryset['second_diff__sum']
                tat_by_month.append({'month':start_date.strftime("%d-%b-%Y"),'tat':tat})
                start_date += relativedelta(days=1)

        data['tat_by_month'] = tat_by_month
        return Response({
            'data': data,
            'message':"Statics loaded successfully."
        }, status=status.HTTP_200_OK)

class InternalUsedKeyMonthView(APIView):

    permission_classes = [IsAuthenticated,]
    authentication_classes = [TokenAuthentication, ]

    def get(self,request):
        data = {}
        start_date = now() - relativedelta(months=+5)
        end_date =  now() 

        credit_used_by_month = []
        while start_date <= end_date:
            start_date = start_date.replace(day=1, hour=0, minute=0, second=0, microsecond=0)
            last_date = calendar.monthrange(start_date.year, start_date.month)[1]
            month_last_day = start_date.replace(day=last_date, hour=0, minute=0, second=0, microsecond=0)
            queryset = CustomerSpentHistory.objects.filter(
                                            created_at__gte = start_date,
                                            created_at__lte = month_last_day
                                        ).aggregate(
                                            file_credit=Sum('credit', filter=Q(credit_type=1)),
                                            evc_credit=Sum('credit', filter=Q(credit_type=2)),
                                            function_credit=Sum('credit', filter=Q(credit_type=3)), 
                                    )
            credit_used_by_month.append({'month':start_date.strftime("%b-%Y"),'credit':queryset})
            start_date += relativedelta(months=1)

        data['credit_used_by_month'] = credit_used_by_month
        return Response({
            'data': data,
            'message':"Statics loaded successfully."
        }, status=status.HTTP_200_OK)

class TopSubdealerMonthView(APIView):
    """ Top 10 sub-delaers list. """

    permission_classes = [IsAuthenticated,]
    authentication_classes = [TokenAuthentication, ]

    def get(self,request):
        data = {}
        start_date = request.query_params.get("start_date")
        end_date = request.query_params.get("end_date")
        if start_date and end_date:
            start_date, end_date = convert_to_date(start_date, end_date)
        else:
            start_date,end_date = get_first_last_date()
        sub_dealers_list = MyUser.objects.filter(user_type__in = [3,6,7])
        top_sub_dealers = []
        for dealer in sub_dealers_list:
            user_data = {}
            user_data['dealer_name'] = dealer.first_name +' '+ dealer.last_name
            user_data['dealer_profile_image'] = dealer.image.url if dealer.image else None
            user_data['uuid'] = dealer.uuid
            queryset = CustomerSpentHistory.objects.filter(
                                            user = dealer,
                                            created_at__gte = start_date,
                                            created_at__lte = end_date
                                        ).aggregate(Sum('credit'))
            user_data['total_credit_spent'] = queryset['credit__sum']
            top_sub_dealers.append(user_data)

        from operator import itemgetter
        if len(top_sub_dealers) > 0:
            not_none_dealers = []
            for d in top_sub_dealers:
                if d['total_credit_spent'] is not None:
                    not_none_dealers.append(d)
            
            if len(not_none_dealers) > 0:
                top_sub_dealers = sorted(not_none_dealers, key=itemgetter('total_credit_spent'), reverse=True)
            else:
                top_sub_dealers = []
        else:
            top_sub_dealers =[]
        data['top_sub_dealers'] = top_sub_dealers
        return Response({
            'data': data,
            'message':"Statics loaded successfully."
        }, status=status.HTTP_200_OK)

class AllTopSubdealerMonthView(APIView):
    """ All sub-delaers list. """

    permission_classes = [IsAuthenticated,]
    authentication_classes = [TokenAuthentication, ]

    def get(self,request):
        data = {}
        start_date = request.query_params.get("start_date")
        end_date = request.query_params.get("end_date")
        if start_date and end_date:
            start_date, end_date = convert_to_date(start_date, end_date)
        else:
            start_date,end_date = get_first_last_date()
        sub_dealers_list = MyUser.objects.filter(user_type__in = [3,6,7])
        top_sub_dealers = []
        for dealer in sub_dealers_list:
            user_data = {}
            user_data['dealer_name'] = dealer.first_name +' '+ dealer.last_name
            user_data['dealer_profile_image'] = dealer.image.url if dealer.image else None
            user_data['uuid'] = dealer.uuid
            queryset = CustomerSpentHistory.objects.filter(
                                            user = dealer,
                                            created_at__gte = start_date,
                                            created_at__lte = end_date
                                        ).aggregate(Sum('credit'))
            user_data['total_credit_spent'] = queryset['credit__sum']
            top_sub_dealers.append(user_data)

        from operator import itemgetter
        if len(top_sub_dealers) > 0:
            not_none_dealers = []
            for d in top_sub_dealers:
                if d['total_credit_spent'] is not None:
                    not_none_dealers.append(d)
            
            if len(not_none_dealers) > 0:
                top_sub_dealers = sorted(not_none_dealers, key=itemgetter('total_credit_spent'), reverse=True)
            else:
                top_sub_dealers = []
        else:
            top_sub_dealers =[]
        data['top_sub_dealers'] = top_sub_dealers
        return Response({
            'data': data,
            'message':"Top sub-dealers data fetched successfully."
        }, status=status.HTTP_200_OK)

class VehicleModelFilesView(APIView):

    permission_classes = [IsAuthenticated,]
    authentication_classes = [TokenAuthentication, ]

    def get(self,request):
        filter_by = request.query_params.get("filter_by","month")

        if filter_by == "month":
            month = int(request.query_params.get("month",1))
            year = datetime.now().year
            year = int(request.query_params.get("year",year))  
            start_date, end_date =  get_month_first_and_last_date_by_month(year, month)
            print(f"start_date == {start_date}")
            print(f"end_date == {end_date}")
            queryset = FileRequest.objects.filter(created_at__gte = start_date,
                                                created_at__lte = end_date,
                                                status="CLOSED").values('vehicle_make','model').annotate(
                                                count=Count('pk', distinct=True))#.order_by()[:10]
            print(f"queryset == {queryset}")      
        elif filter_by == "date":
            start_date = request.query_params.get("start_date")
            end_date = request.query_params.get("end_date")
            start_date, end_date = convert_to_date(start_date, end_date)
            print(start_date, end_date)

            queryset = FileRequest.objects.filter(created_at__gte = start_date,
                                                created_at__lte = end_date,
                                                status="CLOSED").values('vehicle_make','model').annotate(
                                                count=Count('pk', distinct=True))#.order_by()[:10]
        return Response({
            'data': queryset,
            'message':"Statics loaded successfully."
        }, status=status.HTTP_200_OK)


class VehicleTunedByCategoryView(APIView):
    permission_classes = [IsAuthenticated]
    authentication_classes = [TokenAuthentication]

    def get(self, request):
        files_by_category = []
        filter_by = request.query_params.get("filter_by", "range")
        tuning_required_list = FileRequest.objects.values_list('tuning_required', flat=True).distinct()

        if filter_by == "range":
            range_months = int(request.query_params.get("range", 6))
            if range_months != -1:
                if range_months == 1:
                    range_months = 12

                start_date = now() - relativedelta(months=range_months - 1)
                end_date = now()

                # Optimize: Truncate by month to avoid the loop
                data = FileRequest.objects.filter(
                    created_at__gte=start_date,
                    created_at__lte=end_date,
                    tuning_required__in=tuning_required_list,
                    status="CLOSED"
                ).annotate(month=TruncMonth('created_at')).values('month', 'tuning_required').annotate(
                    count=Count('tuning_required')
                ).order_by('month', 'count')

                # Group data by month
                grouped_data = {}
                for item in data:
                    month = item['month'].strftime("%b-%Y")
                    if month not in grouped_data:
                        grouped_data[month] = []
                    grouped_data[month].append({'tuning_required': item['tuning_required'], 'count': item['count']})

                for month, status_data in grouped_data.items():
                    files_by_category.append({'month': month, 'status': status_data})

        elif filter_by == "date":
            start_date_str = request.query_params.get("start_date")
            end_date_str = request.query_params.get("end_date")
            format = '%Y-%m-%d'

            start_date = datetime.strptime(start_date_str, format)
            end_date = datetime.strptime(end_date_str, format)

            # Optimize: Truncate by day to avoid the loop
            data = FileRequest.objects.filter(
                created_at__date__gte=start_date,
                created_at__date__lte=end_date,
                tuning_required__in=tuning_required_list,
                status="CLOSED"
            ).annotate(day=TruncDay('created_at')).values('day', 'tuning_required').annotate(
                count=Count('tuning_required')
            ).order_by('day', 'count')

            # Group data by day
            grouped_data = {}
            for item in data:
                day = item['day'].strftime("%d-%b-%Y")
                if day not in grouped_data:
                    grouped_data[day] = []
                grouped_data[day].append({'tuning_required': item['tuning_required'], 'count': item['count']})

            for day, status_data in grouped_data.items():
                files_by_category.append({'month': day, 'status': status_data})

        return Response({
            'data': files_by_category,
            'message': "Statistics loaded successfully."
        }, status=status.HTTP_200_OK)


class VehicleTunedByTypeView(APIView):

    permission_classes = [IsAuthenticated,]
    authentication_classes = [TokenAuthentication, ]

    def get(self,request):
        filter_by = request.query_params.get("filter_by","month")

        if filter_by == "month":

            month = int(request.query_params.get("month",1))
            year = datetime.now().year
            year = int(request.query_params.get("year",year))  
            start_date, end_date =  get_month_first_and_last_date_by_month(year, month)

            queryset = FileRequest.objects.filter(created_at__gte = start_date,
                                                created_at__lte = end_date,
                                                ).values('vehicle_type').annotate(
                                                count=Count('pk', distinct=True))
        elif filter_by == "date":
            start_date = request.query_params.get("start_date")
            end_date = request.query_params.get("end_date")
            start_date, end_date = convert_to_date(start_date, end_date)

            queryset = FileRequest.objects.filter(created_at__gte = start_date,
                                                created_at__lte = end_date,
                                                ).values('vehicle_type').annotate(
                                                count=Count('pk', distinct=True))
        return Response({
            'data': queryset,
            'message':"Statics loaded successfully."
        }, status=status.HTTP_200_OK)

class VehicleTunedByCategoryCreditView(APIView):

    permission_classes = [IsAuthenticated,]
    authentication_classes = [TokenAuthentication, ]

    def get(self,request):
        data = {}
        filter_by = request.query_params.get("filter_by")

        if filter_by == "month":
            year = datetime.now().year
            month = int(request.query_params.get("month",1))
            year = int(request.query_params.get("year",year))  
            start_date, end_date =  get_month_first_and_last_date_by_month(year, month)

            tuning_required_list = FileRequest.objects.values_list('tuning_required', flat=True).distinct()

            files_by_category = FileRequest.objects.filter(created_at__gte = start_date,
                                                created_at__lte = end_date,
                                                tuning_required__in = tuning_required_list,
                                                status="CLOSED").values('tuning_required').annotate(
                                                count=Count('tuning_required')).order_by('count')

            credit_usage = CustomerSpentHistory.objects.filter(
                                            created_at__gte = start_date,
                                            created_at__lte = end_date
                                        ).aggregate(
                                            file_credit=Sum('credit', filter=Q(credit_type=1)),
                                            function_credit=Sum('credit', filter=Q(credit_type=3)), )
        
        if filter_by == "date":

            start_date = request.query_params.get("start_date")
            end_date = request.query_params.get("end_date")
            start_date, end_date = convert_to_date(start_date, end_date)

            tuning_required_list = FileRequest.objects.values_list('tuning_required', flat=True).distinct()

            files_by_category = FileRequest.objects.filter(created_at__gte = start_date,
                                                created_at__lte = end_date,
                                                tuning_required__in = tuning_required_list,
                                                status="CLOSED").values('tuning_required').annotate(
                                                count=Count('tuning_required')).order_by('count')

            credit_usage = CustomerSpentHistory.objects.filter(
                                            created_at__gte = start_date,
                                            created_at__lte = end_date
                                        ).aggregate(
                                            file_credit=Sum('credit', filter=Q(credit_type=1)),
                                            function_credit=Sum('credit', filter=Q(credit_type=3)), )

        data['files_by_category'] = files_by_category
        data['credit_usage'] = credit_usage

        return Response({
            'data': data,
            'message':"Statics loaded successfully."
        }, status=status.HTTP_200_OK)

class VehicleTunedByCategoryStatusView(APIView):

    permission_classes = [IsAuthenticated,]
    authentication_classes = [TokenAuthentication, ]

    def get(self,request):
        data = {}



        # if start_date and end_date:
        #     start_date, end_date = convert_to_date(start_date, end_date)
        # else:
        #     start_date,end_date = get_first_last_date()
        filter_by = request.query_params.get("filter_by","month")
        month = int(request.query_params.get("month",1))
        year = datetime.now().year
        year = int(request.query_params.get("year",year))

        start_date = request.query_params.get("start_date","")
        end_date = request.query_params.get("end_date","")

        if filter_by == "month":
            start_date, end_date =  get_month_first_and_last_date_by_month(year, month)
        else:
            start_date, end_date = convert_to_date(start_date, end_date)

        tuning_required_list = FileRequest.objects.values_list('tuning_required', flat=True).distinct()

        files_by_category = FileRequest.objects.filter(created_at__gte = start_date,
                                            created_at__lte = end_date,
                                            tuning_required__in = tuning_required_list,
                                            status="CLOSED").values('tuning_required').annotate(
                                            count=Count('tuning_required')).order_by('count')

        process_status = FileRequest.objects.filter(
            created_at__gte=start_date,
            created_at__lte=end_date
        ).aggregate(
            manual_handle=Count('pk', filter=Q(status="Manual Handle")),
            successfull=Count('pk', filter=Q(status='CLOSED')),
            # Count the files created by the file maker
            created_by_filemaker=Count('pk', filter=Q(status='CLOSED') & Q(directory_file__created_by_filemaker=True))
        )
        process_status['not_created_by_filemaker'] = process_status['successfull'] - process_status['created_by_filemaker']
        data['files_by_category'] = files_by_category
        data['process_status'] = process_status

        return Response({
            'data': data,
            'message':"Statics loaded successfully."
        }, status=status.HTTP_200_OK)

class AverageTimeFileRequestView(APIView):

    permission_classes = [IsAuthenticated,]
    authentication_classes = [TokenAuthentication, ]

    def get(self,request):
        filter_by = request.query_params.get("filter_by", "month")
        start_date = request.query_params.get("start_date")
        end_date = request.query_params.get("end_date")

        # Determine start and end dates based on filter
        if filter_by == "date":
            start_date, end_date = convert_to_date(start_date, end_date)
        elif filter_by == "month":
            start_date, end_date = get_month_first_and_last_date_by_month(datetime.now().year, datetime.now().month)

        # Fetch distinct tuning_required values
        request_list = FileRequest.objects.filter(
            created_at__gte=start_date,
            created_at__lte=end_date,
            status="CLOSED"
        ).values_list('tuning_required', flat=True).distinct()

        result = []
        for each in request_list:
            # Filter by tuning_required and aggregate average time for both file types
            instance = FileRequest.objects.filter(
                created_at__gte=start_date,
                created_at__lte=end_date,
                tuning_required=each
            )

            master_avg_time = instance.filter(file_type="Master").aggregate(avg_time=Avg('file_request_time__second_diff'))['avg_time'] or 0
            client_avg_time = instance.filter(file_type="Client/Slave").aggregate(avg_time=Avg('file_request_time__second_diff'))['avg_time'] or 0

            # Append the calculated result
            result.append({
                'tuning_required': each,
                'master': master_avg_time,
                'client': client_avg_time,
                'master_time_stamp': seconds_to_hms(master_avg_time),
                'client_time_stamp': seconds_to_hms(client_avg_time)
            })

        return Response({
            'data': result,
            'message': "Statistics loaded successfully."
        }, status=status.HTTP_200_OK)
    
    # def get(self,request):
    #     data = {}

    #     filter_by = request.query_params.get("filter_by","month")
    #     start_date = request.query_params.get("start_date")
    #     end_date = request.query_params.get("end_date")

    #     if filter_by == "date":
    #         start_date, end_date = convert_to_date(start_date, end_date)
    #     elif filter_by == "month":
    #         start_date,end_date = get_month_first_and_last_date_by_month(datetime.now().year, datetime.now().month)

    #     # month = int(request.query_params.get("month",1))
    #     # year = datetime.now().year
    #     # year = int(request.query_params.get("year",year))  
    #     # start_date, end_date =  get_month_first_and_last_date_by_month(year, month)

    #     request_list = FileRequest.objects.filter(
    #                                 created_at__gte = start_date,
    #                                 created_at__lte = end_date,
    #                                 status = "CLOSED"
    #                             ).values_list('tuning_required', flat=True).distinct()
    #     result = []
    #     for each in list(request_list):
    #         instance = FileRequest.objects.filter(
    #                                 created_at__gte = start_date,
    #                                 created_at__lte = end_date,
    #                                 tuning_required = each
    #                     )
    #         master = instance.filter(
    #                     file_type = "Master"
    #                 )
    #         client = instance.filter(
    #                     file_type = "Client/Slave"
    #                 )
            
    #         master_time = 0.0
    #         client_time = 0.0

    #         master_time_count = 0.0
    #         client_time_count = 0.0
    #         master_avg_time = 0.0
    #         client_avg_time = 0.0

    #         for i in master:
    #             if hasattr(i,'file_request_time'):
    #                 if i.file_request_time.second_diff:
    #                     master_time += i.file_request_time.second_diff 
    #                     master_time_count +=1
            
    #         try:
    #             master_avg_time = master_time/master_time_count
    #         except:
    #             master_avg_time = 0

    #         for i in client:
    #             if hasattr(i,'file_request_time'):
    #                 if i.file_request_time.second_diff:
    #                     client_time += i.file_request_time.second_diff 
    #                     client_time_count +=1
    #         try:
    #             client_avg_time = client_time/client_time_count
    #         except:
    #             client_avg_time = 0

    #         # data['total_credit_purchased'] = time['second_diff__avg']
    #         result.append(
    #             {
    #                 'tuning_required':each,
    #                 'master':master_avg_time,
    #                 'client':client_avg_time,
    #                 'master_time_stamp':seconds_to_hms(master_avg_time),
    #                 'client_time_stamp':seconds_to_hms(client_avg_time)
    #             }
    #         )
                
    #     return Response({
    #         'data': result,
    #         'message':"Statics loaded successfully."
    #     }, status=status.HTTP_200_OK)

class FileSuccessNumberReport(APIView):

    permission_classes = [IsAuthenticated,]
    authentication_classes = [TokenAuthentication, ]

    def get(self,request):
        filter_by = request.query_params.get("filter_by","month")
        start_date = request.query_params.get("start_date")
        end_date = request.query_params.get("end_date")

        month = int(request.query_params.get("month",1))
        year = int(request.query_params.get("year",datetime.now().year))  

        if filter_by == "date":
            start_date, end_date = convert_to_date(start_date, end_date)
        else:
            start_date,end_date = get_month_first_and_last_date_by_month(year, month)

        queryset = FileRequestAveragePerformance.objects.filter(
                                        created_at__gte = start_date,
                                        created_at__lte = end_date
                                    ).aggregate(
                                        original_match_found=Count('pk', filter=Q(original_found=True)),
                                        matching_refrence_found=Count('pk', filter=Q(refrence_found=True)), 
                                        decoding_success=Count('pk', filter=Q(decoding_success=True))
                                    )
        return Response({
            'data': queryset,
            'message':"Statics loaded successfully."
        }, status=status.HTTP_200_OK)

class FileSuccessAverageReport(APIView):

    permission_classes = [IsAuthenticated,]
    authentication_classes = [TokenAuthentication, ]

    def get(self,request):
        filter_by = request.query_params.get("filter_by","month")
        start_date = request.query_params.get("start_date")
        end_date = request.query_params.get("end_date")

        month = int(request.query_params.get("month",1))
        year = int(request.query_params.get("year",datetime.now().year))  

        if filter_by == "date":
            start_date, end_date = convert_to_date(start_date, end_date)
        else:
            start_date,end_date = get_month_first_and_last_date_by_month(year, month)

        queryset = FileRequestAveragePerformance.objects.filter(
                                        created_at__gte = start_date,
                                        created_at__lte = end_date
                                    ).aggregate(
                                        original_match=Avg('original_found_time'),
                                        matching_refrence=Avg('refrence_found_time'), 
                                        decoding_success_time=Avg('decoding_success_time'), 
                                    )
        return Response({
            'data': queryset,
            'message':"Statics loaded successfully."
        }, status=status.HTTP_200_OK)

class FileFailNumberReport(APIView):

    permission_classes = [IsAuthenticated,]
    authentication_classes = [TokenAuthentication, ]

    def get(self,request):
        filter_by = request.query_params.get("filter_by","month")
        start_date = request.query_params.get("start_date")
        end_date = request.query_params.get("end_date")

        month = int(request.query_params.get("month",1))
        year = int(request.query_params.get("year",datetime.now().year))  

        if filter_by == "date":
            start_date, end_date = convert_to_date(start_date, end_date)
        else:
            start_date,end_date = get_month_first_and_last_date_by_month(year, month)

        queryset = FileRequestAveragePerformance.objects.filter(
                                        created_at__gte = start_date,
                                        created_at__lte = end_date
                                    ).aggregate(
                                        original_match_found=Count('pk', filter=Q(original_not_found=True)),
                                        matching_refrence_found=Count('pk', filter=Q(refrence_not_found=True)), 
                                        decoding_failure=Count('pk', filter=Q(decoding_failure=True)),
                                    )
        return Response({
            'data': queryset,
            'message':"Statics loaded successfully."
        }, status=status.HTTP_200_OK)

class FileFailAverageReport(APIView):

    permission_classes = [IsAuthenticated,]
    authentication_classes = [TokenAuthentication, ]

    def get(self,request):
        # # start_date = request.query_params.get("start_date")
        # # end_date = request.query_params.get("end_date")

        # # if start_date and end_date:
        # #     start_date, end_date = convert_to_date(start_date, end_date)
        # # else:
        # #     start_date,end_date = get_first_last_date()

        # month = int(request.query_params.get("month",1))
        # year = datetime.now().year
        # year = int(request.query_params.get("year",year))  
        # start_date, end_date =  get_month_first_and_last_date_by_month(year, month)

        filter_by = request.query_params.get("filter_by","month")
        start_date = request.query_params.get("start_date")
        end_date = request.query_params.get("end_date")

        month = int(request.query_params.get("month",1))
        year = int(request.query_params.get("year",datetime.now().year))  

        if filter_by == "date":
            start_date, end_date = convert_to_date(start_date, end_date)
        else:
            start_date,end_date = get_month_first_and_last_date_by_month(year, month)

        queryset = FileRequestAveragePerformance.objects.filter(
                                        created_at__gte = start_date,
                                        created_at__lte = end_date
                                    ).aggregate(
                                        original_not_found=Avg('original_not_found_time'),
                                        refrence_not_found=Avg('refrence_not_found_time'), 
                                        decoding_failure_time=Avg('decoding_failure_time'), 
                                    )
        return Response({
            'data': queryset,
            'message':"Statics loaded successfully."
        }, status=status.HTTP_200_OK)

class ToolUsageView(APIView):

    permission_classes = [IsAuthenticated,]
    authentication_classes = [TokenAuthentication, ]

    def get(self,request):
        filter_by = request.query_params.get("filter_by")

        if filter_by == "month":
            month = int(request.query_params.get("month",1))
            year = datetime.now().year
            year = int(request.query_params.get("year",year))  
            start_date, end_date =  get_month_first_and_last_date_by_month(year, month)

            queryset = FileRequest.objects.filter(
                                            created_at__gte = start_date,
                                            created_at__lte = end_date,
                                            status="CLOSED"
                                        ).values('tuning_tool_used').annotate(
                                        count=Count('pk', distinct=True))

            sum_all = sum([x['count'] for x in queryset])
            percentage_usage = []
            for tool in queryset:
                data = {}
                data['tuning_tool_used'] = tool['tuning_tool_used']
                data['percentage_usage'] =  format((tool['count']/sum_all)*100, ".2f")
                percentage_usage.append(data)
        
        if filter_by == "date":

            start_date = request.query_params.get("start_date")
            end_date = request.query_params.get("end_date")
            start_date, end_date = convert_to_date(start_date, end_date)
            queryset = FileRequest.objects.filter(
                                            created_at__gte = start_date,
                                            created_at__lte = end_date,
                                            status="CLOSED"
                                        ).values('tuning_tool_used').annotate(
                                        count=Count('pk', distinct=True))

            sum_all = sum([x['count'] for x in queryset])
            percentage_usage = []
            for tool in queryset:
                data = {}
                data['tuning_tool_used'] = tool['tuning_tool_used']
                data['percentage_usage'] = format((tool['count']/sum_all)*100, ".2f")
                percentage_usage.append(data)

        return Response({
            'data': percentage_usage,
            'message':"Statics loaded successfully."
        }, status=status.HTTP_200_OK)

class ManagementDashboardStatsView(APIView):

    permission_classes = [IsAuthenticated,]
    authentication_classes = [TokenAuthentication, ]

    def get(self,request):
        data = {}
        start_date = request.query_params.get("start_date")
        end_date = request.query_params.get("end_date")
        
        if start_date and end_date:
            start_date, end_date = convert_to_date(start_date, end_date)
        else:
            start_date,end_date = get_first_last_date()

        all_users_queryset = MyUser.objects.all()

        total_credit_purchased = OrderList.objects.filter(
                                  created_at__gte = start_date,
                                  created_at__lte = end_date,
                                  status = 2,
                                  user__in=all_users_queryset).aggregate(
                                  Sum('total_price'))

        data['total_credit_purchased'] = total_credit_purchased['total_price__sum']
        customer_count_queryset = MyUser.objects.filter().aggregate(
                                            business=Count('pk', filter=Q(user_type=3)),
                                            individual=Count('pk', filter=Q(user_type=4)),
                                            reseller=Count('pk', filter=Q(user_type=6)), 
                                            dealer=Count('pk', filter=Q(user_type=7)), 
                                    )
        data['registered_customers'] = customer_count_queryset
        zero_balance_queryset = CustomerCredit.objects.filter(
                                    file_key_credit = 0,
                                    function_credit = 0,
                                    evc_credit = 0).count()
        data['registered_business_zero_credit'] = zero_balance_queryset

        from django.utils import timezone
        from datetime import timedelta

        now = datetime.now().date
        one_month_ago = timezone.now() - timedelta(days=30)

        inactive_users = MyUser.objects.filter(
                            Q(last_login__lte = one_month_ago) |
                            Q(last_login__isnull = True)
                        ).count()

        create_users_not_login = MyUser.objects.filter(
                            Q(created_at__lte = one_month_ago) &
                            Q(last_login__isnull = True)
                        ).count()

        
        credit_purchased = OrderList.objects.filter(
                                  created_at__gte = start_date,
                                  created_at__lte = end_date,
                                  status = 2,
                                  user__in=all_users_queryset).aggregate(
                                    file_credit=Sum('file_credit'),
                                    function_credit=Sum('function_credit'),
                                    evc_credit=Sum('evc_credit'),) 
        data['credit_purchased'] = credit_purchased
        data['inactive_users'] = inactive_users + create_users_not_login

        file_credit_manual_add = ManualCreditHistory.objects.filter(
                                  created_at__gte = start_date,
                                  created_at__lte = end_date,
                                ).aggregate(
                                    file_credit=Sum('file_key_credit')
                                )

        function_credit_manual_add = ManualCreditHistory.objects.filter(
                                  created_at__gte = start_date,
                                  created_at__lte = end_date,
                                ).aggregate(
                                    function_credit=Sum('function_credit')
                                )
        evc_credit_manual_add = ManualCreditHistory.objects.filter(
                                  created_at__gte = start_date,
                                  created_at__lte = end_date,
                                ).aggregate(
                                    evc_credit=Sum('evc_credit')
                                )
        data['credit_manual_added'] = {'file_credit':file_credit_manual_add['file_credit'],
                                    'function_credit':function_credit_manual_add['function_credit'],
                                    'evc_credit':evc_credit_manual_add['evc_credit']}

        return Response({
            'data': data,
            'message':"Statics loaded successfully."
        }, status=status.HTTP_200_OK)

class DealerCreditUsageView(APIView):

    permission_classes = [IsAuthenticated,]
    authentication_classes = [TokenAuthentication, ]

    def get(self,request):
        data = {}
        start_date = request.query_params.get("start_date")
        end_date = request.query_params.get("end_date")
        
        if start_date and end_date:
            start_date, end_date = convert_to_date(start_date, end_date)
        else:
            start_date,end_date = get_first_last_date()

        all_dealer_queryset = MyUser.objects.filter(user_type = 7)

        serializer = CustomerSpentSerializer(all_dealer_queryset, many = True).data
        return Response({
            'data': serializer,
            'message':"Statics loaded successfully."
        }, status=status.HTTP_200_OK)

class IndividualStatsView(APIView):

    permission_classes = [IsAuthenticated,]
    authentication_classes = [TokenAuthentication, ]

    def get(self,request):
        data = {}

        from_date = request.query_params.get("from_date")
        to_date = request.query_params.get("to_date")
        if from_date is not None and to_date is not None:
            month_first_day, month_last_day = convert_to_date(from_date, to_date)
        else:
            month_first_day,month_last_day = get_first_last_date()

        # Credit spent history
        credit_spent_count = CustomerSpentHistory.objects.filter(
                        created_at__gte = month_first_day,
                        created_at__lte = month_last_day,
                        user=request.user).aggregate(Sum('credit'))
        data['credit_spent_current_month'] = credit_spent_count['credit__sum']

        # credit purchase history
        file_credit_purchased_sum = OrderList.objects.filter(
                                  created_at__gte = month_first_day,
                                  created_at__lte = month_last_day,
                                  status = 2,
                                  user=request.user).aggregate(Sum('file_credit'))
        file_credit_purchased_sum = 0 if file_credit_purchased_sum['file_credit__sum'] is None else file_credit_purchased_sum['file_credit__sum']

        data['credit_purchased'] = file_credit_purchased_sum 

        # Available customer credit
        queryset_available_credit = CustomerCredit.objects.filter(user=request.user)
        data['available_credit_balance'] = CustomerCreditSerializer(queryset_available_credit,many=True).data

        return Response({
            'data': data,
            'message':"Statics loaded successfully."
        }, status=status.HTTP_200_OK)

class InternalTicketByStatusActivity(APIView):

    permission_classes = [IsAuthenticated,]
    authentication_classes = [TokenAuthentication, ]

    def get(self,request):
        data = {}
        ticket_status_by_month = []

        status_queryset = TicketStatus.objects.filter().values('pk','team_status').distinct()
        status_list = [status['pk'] for status in status_queryset 
                    if status['team_status'] is not None]
        
        range = request.query_params.get("range",6)
        filter_by = request.query_params.get("filter_by", "range")
        if filter_by == "range":
            if int(range) == 1:
                range = 12

            start_date = now() - relativedelta(months=+int(range)-1)
            end_date =  now() 
            
            while start_date <= end_date:
                start_date = start_date.replace(day=1, hour=0, minute=0, second=0, microsecond=0)
                last_date = calendar.monthrange(start_date.year, start_date.month)[1]
                month_last_day = start_date.replace(day=last_date, hour=0, minute=0, second=0, microsecond=0)
                result = TicketHistory.objects.filter(
                                        created_at__gte = start_date,
                                        created_at__lte = month_last_day,
                                        ticket_status__in=status_list
                                    ).values('ticket_status__team_status').annotate(
                                    count=Count('ticket_status__team_status'))

                new_count = TicketHistory.objects.filter(
                                    created_at__gte = start_date,
                                    created_at__lte = month_last_day,
                                    ticket_status = None).count()
                new_dict = {
                                "ticket_status__team_status": "New",
                                "count": new_count
                            }
                result = list(result)
                #result.insert(0, new_dict)
                        
                ticket_status_by_month.append({'month':start_date.strftime("%b-%Y"),'status':result})
                start_date += relativedelta(months=1)

            data['status_by_month'] = ticket_status_by_month
        
        if filter_by == "date":
            format = '%Y-%m-%d'
            start_date = request.query_params.get("start_date")
            end_date = request.query_params.get("end_date")

            start_date = datetime.strptime(start_date, format)
            end_date = datetime.strptime(end_date, format)

            while start_date <= end_date:
                result = TicketHistory.objects.filter(
                                        created_at__date = start_date.date(),
                                        ticket_status__in=status_list
                                    ).values('ticket_status__team_status').annotate(
                                    count=Count('ticket_status__team_status'))

                new_count = TicketHistory.objects.filter(Q(ticket_status__in = [3]) | Q(ticket_status = None),
                                    created_at__date = start_date.date(),
                                    ).count()
                new_dict = {
                                "ticket_status__team_status": "New",
                                "count": new_count
                            }
                result = list(result)
                #result.insert(0, new_dict)
                        
                ticket_status_by_month.append({'month':start_date.strftime("%d-%b-%Y"),'status':result})
                start_date += relativedelta(days=1)

            data['status_by_month'] = ticket_status_by_month

        return Response({
            'data': data,
            'message':"Statics loaded successfully."
        }, status=status.HTTP_200_OK)
    
class IndividualFileSubmittedView(APIView):

    permission_classes = [IsAuthenticated,]
    authentication_classes = [TokenAuthentication, ]

    def get(self,request):
        import calendar

        # from_date = request.query_params.get("from_date")
        # to_date = request.query_params.get("to_date")
        # if from_date is not None and to_date is not None:
        #     month_first_day, month_last_day = convert_to_date(from_date, to_date)
        # else:
        #     month_first_day,month_last_day = get_first_last_date()
        year = datetime.now().year

        filter_by = request.query_params.get("filter_by")
        month_number = int(request.query_params.get("month_number",1))
        range = int(request.query_params.get("range",6))
        year = int(request.query_params.get("year",1))

        month_first_day, month_last_day = get_month_first_and_last_date_by_month(year, month_number)

        month_name = calendar.month_name[month_number]+'-'+ str(year)

        if filter_by == 'month' and month_number:
            data = FileRequest.objects.filter(
                    user = request.user,
                    created_at__gte = month_first_day,
                    created_at__lte = month_last_day
                ).count()
            data = [{'month':month_name,'count':data}]

        if filter_by == 'range':
            if int(range) == 1:
                range = 12
            data = []

            start_date = now() - relativedelta(months=+int(range)-1)
            end_date =  now() 

            while start_date <= end_date:
                start_date = start_date.replace(day=1, hour=0, minute=0, second=0, microsecond=0)
                last_date = calendar.monthrange(start_date.year, start_date.month)[1]
                month_last_day = start_date.replace(day=last_date, hour=0, minute=0, second=0, microsecond=0)
                count = FileRequest.objects.filter(
                        user = request.user,
                        created_at__gte = start_date,
                        created_at__lte = month_last_day
                    ).count()
                        
                data.append({'month':start_date.strftime("%b-%Y"),'count':count})
                start_date += relativedelta(months=1)

        if filter_by == 'date':
            data = []
            format = '%Y-%m-%d'
            start_date = request.query_params.get("start_date")
            end_date = request.query_params.get("end_date")

            start_date = datetime.strptime(start_date, format)
            end_date = datetime.strptime(end_date, format)

            while start_date <= end_date:
                count = FileRequest.objects.filter(
                        user = request.user,
                        created_at__date = start_date.date(),
                    ).count()
                data.append({'month':start_date.strftime("%d-%b-%Y"),'count':count})
                start_date += relativedelta(days=1)

        return Response({
            'data': data,
            'message':"File data loaded successfully."
        }, status=status.HTTP_200_OK)

class IndividualTicketByStatusView(APIView):

    permission_classes = [IsAuthenticated,]
    authentication_classes = [TokenAuthentication, ]

    def get(self,request):
        data = {}
        filter_type = request.query_params.get("filter_type")
        now_year = datetime.now().year
        month_number = int(request.query_params.get("month_number",1))
        year = int(request.query_params.get("year",now_year))

        if filter_type == "date":
            from_date = request.query_params.get("from_date")
            to_date = request.query_params.get("to_date")
            month_first_day, month_last_day = convert_to_date(from_date, to_date)
        else:
            month_first_day, month_last_day =  get_month_first_and_last_date_by_month(year, month_number)

        data = TicketHistory.objects.filter(
                created_by = request.user,
                created_at__gte = month_first_day,
                created_at__lte = month_last_day,
            ).aggregate(
                new=Count('pk', filter=Q(ticket_status__in=[18]) | Q(ticket_status__isnull=True)),
                closed=Count('pk', filter=Q(ticket_status__in=[20,41, 43])),
                in_progress=Count('pk', filter=Q(ticket_status__in=[19, 21])),   
                in_development=Count('pk', filter=Q(ticket_status__in=[23, 24, 25, 26, 27, 28, 29, 30, 32])),   
                ecu_booked_in=Count('pk', filter=Q(ticket_status__in=[35])),   
                awaiting_feedback=Count('pk', filter=Q(ticket_status__in=[33,34])),  
                esclated = Count('pk', filter=Q(ticket_status__in=[31])),  
        )
        
        return Response({
            'data': data,
            'message':"Statics loaded successfully."
        }, status=status.HTTP_200_OK)


# class IndividualTicketByStatusView(generics.ListAPIView):

#     permission_classes = [IsAuthenticated,]
#     authentication_classes = [TokenAuthentication, ]
#     serializer_class = TicketHistorySerializer
#     pagination_class = SetPagination

#     def get(self,request):
#         ticket_status = int(request.query_params.get("status",''))

#         from_date = request.query_params.get("from_date")
#         to_date = request.query_params.get("to_date")
#         if from_date is not None and to_date is not None:
#             month_first_day, month_last_day = convert_to_date(from_date, to_date)
#         else:
#             month_first_day,month_last_day = get_first_last_date()


#         if ticket_status == 1:
#             queryset = TicketHistory.objects.filter(
#                     Q(ticket_status__user_status=1) | Q(ticket_status__user_status__isnull=True),
#                     created_by = request.user,
#                     created_at__gte = month_first_day,
#                     created_at__lte = month_last_day,
#                 )
#             serializer = self.serializer_class(queryset, many=True)
#             page = self.paginate_queryset(serializer.data)
#             data = dict(self.get_paginated_response(page).data)
#         else:
#             queryset = TicketHistory.objects.filter(
#                     created_by = request.user,
#                     created_at__gte = month_first_day,
#                     created_at__lte = month_last_day,
#                     ticket_status__user_status=ticket_status)
#             serializer = self.serializer_class(queryset, many=True)
#             page = self.paginate_queryset(serializer.data)
#             data = dict(self.get_paginated_response(page).data)
#         return Response({
#             'data': data,
#             'message':"Date reterived successfully."
#         }, status=status.HTTP_200_OK)

# class IndividualVehicleTunedSixMonthView(APIView):

#     permission_classes = [IsAuthenticated,]
#     authentication_classes = [TokenAuthentication, ]

#     def get(self,request):

#         data = {}
#         is_filter = request.query_params.get("filter")
#         is_filter = True if is_filter == "true" else False
#         range = request.query_params.get("range",6)
#         individual = MyUser.objects.filter(uuid = request.user.uuid)
#         if is_filter == False:
#             if int(range) == 1:
#                 range = 11

#             start_date = now() - relativedelta(months=+int(range)-1)
#             end_date =  now() 

#             tuned_by_month = []
#             while start_date <= end_date:
#                 start_date = start_date.replace(day=1, hour=0, minute=0, second=0, microsecond=0)
#                 last_date = calendar.monthrange(start_date.year, start_date.month)[1]
#                 month_last_day = start_date.replace(day=last_date, hour=0, minute=0, second=0, microsecond=0)
#                 queryset = CustomerSpentHistory.objects.filter(
#                                     user__in = individual,
#                                     created_at__gte = start_date,
#                                     created_at__lte = month_last_day,
#                             ).aggregate(
#                                 file_credit=Count('pk', filter=Q(credit_type=1)),
#                                 function_credit=Count('pk', filter=Q(credit_type=3)),
#                                 evc_credit=Count('pk', filter=Q(credit_type=2)),
#                             )
#                 tuned_by_month.append({'month':start_date.strftime("%b-%Y"),'count':queryset})
#                 start_date += relativedelta(months=1)
#         elif int(range) == -1:
#             start_date = request.query_params.get("start_date")
#             end_date = request.query_params.get("end_date")
#             dates = create_dates_between_range(start_date, end_date)
#             for date in dates:
#                 print(date.replace(hour=0, minute=0, second=0))
#                 print(date.replace(hour=23, minute=59, second=59))
#                 # queryset = CustomerSpentHistory.objects.filter(
#                 #                     user__in = individual,
#                 #                     created_at__gte= date.replace(hour=0, minute=0, second=0),
#                 #                     created_at__lte= date.replace(hour=0, minute=0, second=0),
#                 #             ).aggregate(
#                 #                 file_credit=Count('pk', filter=Q(credit_type=1)),
#                 #                 function_credit=Count('pk', filter=Q(credit_type=3)),
#                 #                 evc_credit=Count('pk', filter=Q(credit_type=2)),
#                 #             )
#                 # print(queryset)

#         data['vehicle_tuned'] = tuned_by_month
#         return Response({
#             'data': data,
#             'message':"Statics loaded successfully."
#         }, status=status.HTTP_200_OK)

# class IndividualVehicleTunedMonthView(generics.ListAPIView):

#     permission_classes = [IsAuthenticated,]
#     authentication_classes = [TokenAuthentication, ]
#     serializer_class = VehicleRequestListSerializer
#     pagination_class = SetPagination

#     def get(self,request):
#         month = int(request.query_params.get("month",''))
#         now = datetime.now()
#         month_first_day = datetime(now.year, month, 1)
#         last_day = calendar.monthrange(now.year, 2)[1]
#         month_last_day = month_first_day.replace(day=last_day, hour=0, minute=0, second=0, microsecond=0)
#         queryset = FileRequest.objects.filter(
#                             user = request.user,
#                             created_at__gte = month_first_day,
#                             created_at__lte = month_last_day
#                     )
#         serializer = self.serializer_class(queryset, many=True)
#         page = self.paginate_queryset(serializer.data)
#         data = dict(self.get_paginated_response(page).data)
#         return Response({
#             'data': data,
#             'message':"Statics loaded successfully."
#         }, status=status.HTTP_200_OK)


class CreditSpentListView(generics.ListAPIView):

    permission_classes = [IsAuthenticated]
    authentication_classes = [TokenAuthentication]
    serializer_class = SpentHistorySerializer
    queryset = CustomerSpentHistory.objects.all().order_by('-id')
    pagination_class = SetPagination

    def get_queryset(self):
        params = self.request.query_params
        uuid = params['uuid']
        user = MyUser.objects.get(uuid = uuid)
        month_first_day,month_last_day = get_first_last_date()
        queryset = CustomerSpentHistory.objects.filter(
                        created_at__gte = month_first_day,
                        created_at__lte = month_last_day,
                        user=user).order_by('-id')
        return queryset
    
    def list(self, request, *args, **kwargs):
        data = super(CreditSpentListView, self).list(request, *args, **kwargs).data
        return Response({
            'message': "Data reterived successfully",
            'data': data
        }, status=status.HTTP_200_OK)

class CreditPurchaseListView(generics.ListAPIView):

    permission_classes = [IsAuthenticated]
    authentication_classes = [TokenAuthentication]
    serializer_class = OrderListSerializer
    queryset = OrderList.objects.all().order_by('-id')
    pagination_class = SetPagination

    def get_serializer_context(self):
        return {'request': self.request}

    def get_queryset(self):
        month_first_day,month_last_day = get_first_last_date()
        return OrderList.objects.filter(
                    user=self.request.user,
                    created_at__gte = month_first_day,
                    created_at__lte = month_last_day
                ).order_by('-id')
    
    def list(self, request, *args, **kwargs):
        data = super(CreditPurchaseListView, self).list(request, *args, **kwargs).data
        return Response({
            'message': "Data reterived successfully",
            'data': data
        }, status=status.HTTP_200_OK)


# Sub dealers

class SubDealerTicketStatusView(APIView):

    permission_classes = [IsAuthenticated,]
    authentication_classes = [TokenAuthentication, ]

    def get(self,request):

        now_year = datetime.now().year
        filter_type = request.query_params.get("filter_type")

        month = int(request.query_params.get("month",1))
        year = int(request.query_params.get("year",now_year))

        if filter_type == "date":
            from_date = request.query_params.get("from_date")
            to_date = request.query_params.get("to_date")
            month_first_day, month_last_day = convert_to_date(from_date, to_date)
        else:
            month_first_day, month_last_day =  get_month_first_and_last_date_by_month(year, month)
        data = TicketHistory.objects.filter(
                created_by = request.user,
                created_at__gte = month_first_day,
                created_at__lte = month_last_day
            ).aggregate(
                new=Count('pk', filter=Q(ticket_status__in=[18]) | Q(ticket_status__isnull=True)),
                closed=Count('pk', filter=Q(ticket_status__in=[20,41, 43])),
                in_progress=Count('pk', filter=Q(ticket_status__in=[19, 21])),  
                pending_reply=Count('pk', filter=Q(ticket_status__in=[22])),       
                in_development=Count('pk', filter=Q(ticket_status__in=[23, 24, 25, 26, 27, 28, 29, 30, 32])),   
                ecu_booked_in=Count('pk', filter=Q(ticket_status__in=[35])),   
                awaiting_feedback=Count('pk', filter=Q(ticket_status__in=[33,34])),  
                esclated = Count('pk', filter=Q(ticket_status__in=[31])),   
        )

        return Response({
            'data': data,
            'message':"Statics loaded successfully."
        }, status=status.HTTP_200_OK)

class SubDealerStatsView(APIView):

    permission_classes = [IsAuthenticated,]
    authentication_classes = [TokenAuthentication, ]

    def get(self,request):
        data = {}

        # from_date = request.query_params.get("from_date")
        # to_date = request.query_params.get("to_date")

        # if from_date is not None and to_date is not None:
        #     month_first_day, month_last_day = convert_to_date(from_date, to_date)
        # else:
        #     month_first_day,month_last_day = get_first_last_date()
        # month = int(request.query_params.get("month",1))
        # year = datetime.now().year
        # month_first_day, month_last_day =  get_month_first_and_last_date_by_month(year, month)
        month_first_day,month_last_day = get_first_last_date()
        print(month_first_day, month_last_day)
        # Credit spent history
        credit_spent_count = CustomerSpentHistory.objects.filter(
                        created_at__gte = month_first_day,
                        created_at__lte = month_last_day,
                        user=request.user).aggregate(Sum('credit'))
        data['credit_spent_current_month'] = credit_spent_count['credit__sum']

        # credit purchase history
        file_credit_purchased_sum = OrderList.objects.filter(
                                  created_at__gte = month_first_day,
                                  created_at__lte = month_last_day,
                                  status = 2,
                                  user=request.user).aggregate(Sum('file_credit'))
        file_credit_purchased_sum = 0 if file_credit_purchased_sum['file_credit__sum'] is None else file_credit_purchased_sum['file_credit__sum']

        function_credit_purchased_sum = OrderList.objects.filter(
                                  created_at__gte = month_first_day,
                                  created_at__lte = month_last_day,
                                  status = 2,
                                  user=request.user).aggregate(Sum('function_credit'))
        function_credit_purchased_sum = 0 if function_credit_purchased_sum['function_credit__sum'] is None else function_credit_purchased_sum['function_credit__sum']

        evc_credit_purchased_sum = OrderList.objects.filter(
                                  created_at__gte = month_first_day,
                                  created_at__lte = month_last_day,
                                  status = 2,
                                  user=request.user).aggregate(Sum('evc_credit'))
        evc_credit_purchased_sum = 0 if evc_credit_purchased_sum['evc_credit__sum'] is None else evc_credit_purchased_sum['evc_credit__sum']

        data['credit_purchased'] = file_credit_purchased_sum + \
                                   function_credit_purchased_sum + \
                                   evc_credit_purchased_sum

        # Available customer credit
        queryset_available_credit = CustomerCredit.objects.filter(user=request.user)
        data['available_credit_balance'] = CustomerCreditSerializer(queryset_available_credit,many=True).data

        return Response({
            'data': data,
            'message':"Statics loaded successfully."
        }, status=status.HTTP_200_OK)

class SubDealerUsedKeyMonthView(APIView):

    permission_classes = [IsAuthenticated,]
    authentication_classes = [TokenAuthentication, ]

    def get(self,request):
        data = {}
        range = request.query_params.get("range",6)
        if int(range) != -1:
            if int(range) == 1:
                range = 11

            start_date = now() - relativedelta(months=+int(range)-1)
            end_date =  now() 

            credit_used_by_month = []
            while start_date <= end_date:
                start_date = start_date.replace(day=1, hour=0, minute=0, second=0, microsecond=0)
                last_date = calendar.monthrange(start_date.year, start_date.month)[1]
                month_last_day = start_date.replace(day=last_date, hour=0, minute=0, second=0, microsecond=0)
                queryset = CustomerSpentHistory.objects.filter(
                                                user = request.user,
                                                created_at__gte = start_date,
                                                created_at__lte = month_last_day
                                            ).aggregate(
                                                file_credit=Sum('credit', filter=Q(credit_type=1)),
                                                evc_credit=Sum('credit', filter=Q(credit_type=2)),
                                                function_credit=Sum('credit', filter=Q(credit_type=3)), 
                                        )
                credit_used_by_month.append({'month':start_date.strftime("%b-%Y"),'credit':queryset})
                start_date += relativedelta(months=1)

            data['credit_used_by_month'] = credit_used_by_month
        elif int(range) == -1:
            start_date = request.query_params.get("start_date")
            end_date = request.query_params.get("end_date")
            # dates = create_dates_between_range(start_date, end_date)

            # credit_used_by_month = CustomerSpentHistory.objects.filter(
            #     created_at__range = [start_date,end_date]
            # ).values('created_at__date').annotate(
            #     file_credit = Count('pk', filter=Q(credit_type=1)),
            #     function_credit=Count('pk', filter=Q(credit_type=3)),
            #     evc_credit=Count('pk', filter=Q(credit_type=2)),
            # )
            # result = []

            #     result.append({
            #         "month":each['created_at__date'].strftime('%Y-%m-%d'),
            #         'credit':{
            #             "file_credit":each['file_credit'],
            #             "function_credit":each['function_credit'],
            #             "evc_credit":each['evc_credit'],

            #         }
            #     })
            # data['credit_used_by_month'] = result

            credit_data = CustomerSpentHistory.objects.filter(created_at__range=[start_date, end_date],
                                                              user = request.user).values('created_at__date').annotate(
                file_credit=Sum('credit', filter=Q(credit_type=1)),
                function_credit=Sum('credit', filter=Q(credit_type=3)),
                evc_credit=Sum('credit', filter=Q(credit_type=2)),
            ).order_by('created_at__date')

            data['credit_used_by_month'] = [
                {
                    "month": item['created_at__date'].strftime('%d-%b-%Y'),
                    "credit": {
                        "file_credit": item['file_credit'] or 0,
                        "function_credit": item['function_credit'] or 0,
                        "evc_credit": item['evc_credit'] or 0,
                    }
                }
                for item in credit_data
            ]

        return Response({
            'data': data,
            'message':"Statics loaded successfully."
        }, status=status.HTTP_200_OK)

class SubDealerFileSubmittedView(APIView):

    permission_classes = [IsAuthenticated,]
    authentication_classes = [TokenAuthentication, ]

    def get(self,request):

        file_by_month = []
        data = {}
        range = request.query_params.get("range",6)
        if int(range) != -1:
            if int(range) == 1:
                range = 12

            start_date = now() - relativedelta(months=+int(range)-1)
            end_date =  now() 

            while start_date <= end_date:
                start_date = start_date.replace(day=1, hour=0, minute=0, second=0, microsecond=0)
                last_date = calendar.monthrange(start_date.year, start_date.month)[1]
                month_last_day = start_date.replace(day=last_date, hour=0, minute=0, second=0, microsecond=0)
                data = FileRequest.objects.filter(
                        user = request.user,
                        created_at__gte = start_date,
                        created_at__lte = month_last_day
                    ).count()
                file_by_month.append({'month':start_date.strftime("%b-%Y"),'count':data})
                start_date += relativedelta(months=1)

        else:
            format = '%Y-%m-%d'
            start_date = request.query_params.get("start_date")
            end_date = request.query_params.get("end_date")

            start_date = datetime.strptime(start_date, format)
            end_date = datetime.strptime(end_date, format)

            while start_date <= end_date:
                data = FileRequest.objects.filter(
                        user = request.user,
                        created_at__date = start_date,
                    ).count()
                file_by_month.append({'month':start_date.strftime("%d-%b-%Y"),'count':data})
                start_date += relativedelta(days=1)

        return Response({
            'data': file_by_month,
            'message':"Statics loaded successfully."
        }, status=status.HTTP_200_OK)

class SubDealerFileSubmittedByToolView(APIView):

    permission_classes = [IsAuthenticated,]
    authentication_classes = [TokenAuthentication, ]

    def get(self,request):

        now_year = datetime.now().year
        filter_type = request.query_params.get("filter_type")

        month = int(request.query_params.get("month",1))
        year = int(request.query_params.get("year",now_year))

        if filter_type == "date":
            from_date = request.query_params.get("from_date")
            to_date = request.query_params.get("to_date")
            month_first_day, month_last_day = convert_to_date(from_date, to_date)
        else:
            month_first_day, month_last_day =  get_month_first_and_last_date_by_month(year, month)

        # month_first_day,month_last_day = get_first_last_date()
        queryset = FileRequest.objects.filter(
                    user=request.user,
                    created_at__gte = month_first_day,
                    created_at__lte = month_last_day
                    ).values('tuning_tool_used').annotate(
                    count=Count('tuning_tool_used')).order_by('count')

        return Response({
            'data': queryset,
            'message':"File data loaded successfully."
        }, status=status.HTTP_200_OK)
    

# ========================== Sub-dealer Data Mode View ==================
class SubDealerUsedKeyMonthDataView(APIView):

    permission_classes = [IsAuthenticated,]
    authentication_classes = [TokenAuthentication, ]

    def get(self,request):
        data_by = request.query_params.get("data_by","month")
        month_number = request.query_params.get("month_number")
        year = request.query_params.get("year", datetime.now().year)

        if data_by == "month":
            start_date, month_last_day = get_first_and_last_date_by_args(month_number, year)
            queryset = CustomerSpentHistory.objects.filter(user = request.user, created_at__range = [start_date, month_last_day])
            serializer = CustomerSpentDataSerializer(queryset, many=True)
            return Response({
                'data': serializer.data,
                'message':"Statics loaded successfully."
            }, status=status.HTTP_200_OK)
        
        elif data_by == "date":
            start_date = request.query_params.get("start_date")
            end_date = request.query_params.get("end_date")
            queryset = CustomerSpentHistory.objects.filter(created_at__range=[start_date, end_date],user = request.user)
            serializer = CustomerSpentDataSerializer(queryset, many=True)
            return Response({
                'data': serializer.data,
                'message':"Statics loaded successfully."
            }, status=status.HTTP_200_OK)
        
class SubDealerTicketStatusDataView(APIView):

    permission_classes = [IsAuthenticated,]
    authentication_classes = [TokenAuthentication, ]

    def get(self,request):
        now_year = datetime.now().year
        filter_type = request.query_params.get("filter_type")

        month = int(request.query_params.get("month",1))
        year = int(request.query_params.get("year",now_year))
        ticket_status = request.query_params.get("status")

        if filter_type == "date":
            from_date = request.query_params.get("from_date")
            to_date = request.query_params.get("to_date")
            month_first_day, month_last_day = convert_to_date(from_date, to_date)
        else:
            month_first_day, month_last_day =  get_month_first_and_last_date_by_month(year, month)

        status_list = manage_ticket_user_status(ticket_status)
        if ticket_status != "New":
            print(1)
            queryset = TicketHistory.objects.filter(
                    created_by = request.user,
                    created_at__gte = month_first_day,
                    created_at__lte = month_last_day,
                    ticket_status__in = status_list
                )
        else:
            print(2)
            queryset = TicketHistory.objects.filter(
                    Q(ticket_status__in=[18]) | Q(ticket_status__isnull=True),
                    created_by = request.user,
                    created_at__gte = month_first_day,
                    created_at__lte = month_last_day,
                )
        
        serializer = TicketHistorySerializer(queryset, many=True)

        return Response({
            'data': serializer.data,
            'message':"Statics loaded successfully."
        }, status=status.HTTP_200_OK)
    
class SubDealerFileSubmittedByTooDatalView(APIView):

    permission_classes = [IsAuthenticated,]
    authentication_classes = [TokenAuthentication, ]

    def get(self,request):

        now_year = datetime.now().year
        filter_type = request.query_params.get("filter_type")

        month = int(request.query_params.get("month",1))
        year = int(request.query_params.get("year",now_year))
        tool_name = request.query_params.get("tool_name")

        if filter_type == "date":
            from_date = request.query_params.get("from_date")
            to_date = request.query_params.get("to_date")
            month_first_day, month_last_day = convert_to_date(from_date, to_date)
        else:
            month_first_day, month_last_day =  get_month_first_and_last_date_by_month(year, month)

        queryset = FileRequest.objects.filter(user=request.user, created_at__gte = month_first_day,
                                        created_at__lte = month_last_day, tuning_tool_used = tool_name)
        serializer = VehicleRequestSerializer(queryset, many = True)

        return Response({
            'data': serializer.data,
            'message':"File data loaded successfully."
        }, status=status.HTTP_200_OK)
    
class SubDealerFileSubmittedDataView(APIView):

    permission_classes = [IsAuthenticated,]
    authentication_classes = [TokenAuthentication, ]

    def get(self,request):
        data_by = request.query_params.get("data_by","month")
        month_number = request.query_params.get("month_number")
        year = request.query_params.get("year", datetime.now().year)


        if data_by == "month":
            start_date, month_last_day = get_first_and_last_date_by_args(month_number, year)
            queryset = FileRequest.objects.filter(
                        user = request.user,
                        created_at__gte = start_date,
                        created_at__lte = month_last_day
                    )

        if data_by == "date":
            start_date = request.query_params.get("start_date")
            end_date = request.query_params.get("end_date")
            queryset = FileRequest.objects.filter(
                        user = request.user,
                        created_at__gte = start_date,
                        created_at__lte = end_date
                    )

        serializer = VehicleRequestSerializer(queryset, many = True)

        return Response({
            'data': serializer.data,
            'message':"Statics loaded successfully."
        }, status=status.HTTP_200_OK)
# ========================== Sub-dealer Data Mode View ==================


# ========================== Individual Data Mode View ==================
class IndividualFileSubmittedDataView(APIView):

    permission_classes = [IsAuthenticated,]
    authentication_classes = [TokenAuthentication, ]

    def get(self,request):
        data_by = request.query_params.get("data_by","month")
        month_number = request.query_params.get("month_number")
        year = request.query_params.get("year", datetime.now().year)


        if data_by == "month":
            start_date, month_last_day = get_first_and_last_date_by_args(month_number, year)
            queryset = FileRequest.objects.filter(
                        user = request.user,
                        created_at__gte = start_date,
                        created_at__lte = month_last_day
                    )

        if data_by == "date":
            start_date = request.query_params.get("start_date")
            end_date = request.query_params.get("end_date")
            queryset = FileRequest.objects.filter(
                        user = request.user,
                        created_at__gte = start_date,
                        created_at__lte = end_date
                    )

        serializer = VehicleRequestSerializer(queryset, many = True)

        return Response({
            'data': serializer.data,
            'message':"Statics loaded successfully."
        }, status=status.HTTP_200_OK)
    
class IndividualTicketByStatusDataView(APIView):

    permission_classes = [IsAuthenticated,]
    authentication_classes = [TokenAuthentication, ]

    def get(self,request):
        now_year = datetime.now().year
        filter_type = request.query_params.get("filter_type")

        month = int(request.query_params.get("month",1))
        year = int(request.query_params.get("year",now_year))
        ticket_status = request.query_params.get("status")

        if filter_type == "date":
            from_date = request.query_params.get("from_date")
            to_date = request.query_params.get("to_date")
            month_first_day, month_last_day = convert_to_date(from_date, to_date)
        else:
            month_first_day, month_last_day =  get_month_first_and_last_date_by_month(year, month)

        status_list = manage_ticket_user_status(ticket_status)
        if ticket_status != "New":
            print(1)
            queryset = TicketHistory.objects.filter(
                    created_by = request.user,
                    created_at__gte = month_first_day,
                    created_at__lte = month_last_day,
                    ticket_status__in = status_list
                )
        else:
            print(2)
            queryset = TicketHistory.objects.filter(
                    Q(ticket_status__in=[18]) | Q(ticket_status__isnull=True),
                    created_by = request.user,
                    created_at__gte = month_first_day,
                    created_at__lte = month_last_day,
                )
        
        serializer = TicketHistorySerializer(queryset, many=True)

        return Response({
            'data': serializer.data,
            'message':"Statics loaded successfully."
        }, status=status.HTTP_200_OK)
# ========================== Individual Data Mode View ==================


# ========================== Reseller Data Mode View ====================
class ResellerUsedKeyMonthDataView(APIView):

    permission_classes = [IsAuthenticated,]
    authentication_classes = [TokenAuthentication, ]

    def get(self,request):
        data_by = request.query_params.get("data_by","month")
        month_number = request.query_params.get("month_number")
        year = request.query_params.get("year", datetime.now().year)

        if data_by == "month":
            start_date, month_last_day = get_first_and_last_date_by_args(month_number, year)
            queryset = CustomerSpentHistory.objects.filter(user = request.user, created_at__range = [start_date, month_last_day])
            serializer = CustomerSpentDataSerializer(queryset, many=True)
            return Response({
                'data': serializer.data,
                'message':"Statics loaded successfully."
            }, status=status.HTTP_200_OK)
        
        elif data_by == "date":
            start_date = request.query_params.get("start_date")
            end_date = request.query_params.get("end_date")
            queryset = CustomerSpentHistory.objects.filter(created_at__range=[start_date, end_date],user = request.user)
            serializer = CustomerSpentDataSerializer(queryset, many=True)
            return Response({
                'data': serializer.data,
                'message':"Statics loaded successfully."
            }, status=status.HTTP_200_OK)
        

class ResellerTicketByStatusActivityData(APIView):

    permission_classes = [IsAuthenticated,]
    authentication_classes = [TokenAuthentication, ]

    def get(self,request):
        now_year = datetime.now().year
        filter_type = request.query_params.get("filter_type")

        month = int(request.query_params.get("month",1))
        year = int(request.query_params.get("year",now_year))
        ticket_status = request.query_params.get("status")

        if filter_type == "date":
            from_date = request.query_params.get("from_date")
            to_date = request.query_params.get("to_date")
            month_first_day, month_last_day = convert_to_date(from_date, to_date)
        else:
            month_first_day, month_last_day =  get_month_first_and_last_date_by_month(year, month)

        status_list = manage_ticket_user_status(ticket_status)
        if ticket_status != "New":
            print(1)
            queryset = TicketHistory.objects.filter(
                    created_by = request.user,
                    created_at__gte = month_first_day,
                    created_at__lte = month_last_day,
                    ticket_status__in = status_list
                )
        else:
            print(2)
            queryset = TicketHistory.objects.filter(
                    Q(ticket_status__in=[18]) | Q(ticket_status__isnull=True),
                    created_by = request.user,
                    created_at__gte = month_first_day,
                    created_at__lte = month_last_day,
                )
        
        serializer = TicketHistorySerializer(queryset, many=True)

        return Response({
            'data': serializer.data,
            'message':"Statics loaded successfully."
        }, status=status.HTTP_200_OK)
    
class ResellerVehicleTunedByMonthDataView(APIView):

    permission_classes = [IsAuthenticated,]
    authentication_classes = [TokenAuthentication, ]

    def get(self,request):

        filter_by = request.query_params.get("filter_by")
        month_number = int(request.query_params.get("month_number",1))
        year = int(request.query_params.get("year",datetime.now().year))

        if filter_by == "date":
            from_date = request.query_params.get("from_date")
            to_date = request.query_params.get("to_date")
            month_first_day, month_last_day = convert_to_date(from_date, to_date)
        else:
            month_first_day, month_last_day =  get_month_first_and_last_date_by_month(year, month_number)


        reseller = MyUser.objects.filter(uuid = request.user.uuid)
        subdealers_list = MyUser.objects.filter(parent__uuid = request.user.uuid)
        users_list = subdealers_list | reseller

        queryset = FileRequest.objects.filter(
                            user__in = users_list,
                            created_at__gte = month_first_day,
                            created_at__lte = month_last_day,
                    )    
        serializer = VehicleRequestListSerializer(queryset, many=True)
        return Response({
            'data': serializer.data,
            'message':"Statics loaded successfully."
        }, status=status.HTTP_200_OK)

# ========================== Reseller Data Mode View ====================

# ========================== Internal dashboard view ====================
class TechnicalFileTATMonthDataView(APIView):

    permission_classes = [IsAuthenticated,]
    authentication_classes = [TokenAuthentication, ]

    def get(self,request):

        year = datetime.now().year
        filter_by = request.query_params.get("filter_by")
        month_number = int(request.query_params.get("month_number",1))
        year = int(request.query_params.get("year",year))   
        if filter_by == "date":
            from_date = request.query_params.get("start_date")
            to_date = request.query_params.get("end_date")
            month_first_day, month_last_day = convert_to_date(from_date, to_date)
            queryset = FileRequestTime.objects.filter(
                    created_at__date = month_first_day.date(),
                ).exclude(end_time__isnull = True)
        
        else:        
            month_first_day, month_last_day =  get_month_first_and_last_date_by_month(year, month_number) 
            queryset = FileRequestTime.objects.filter(
                    created_at__date__range = [month_first_day, month_last_day],
                ).exclude(end_time__isnull = True)
        serializer = FileRequestTimeSerializer(queryset, many=True)        

        return Response({
            'data': serializer.data,
            'message':"Statics loaded successfully."
        }, status=status.HTTP_200_OK)

class VehicleTunedByCategoryDataView(APIView):

    permission_classes = [IsAuthenticated,]
    authentication_classes = [TokenAuthentication, ]

    def get(self,request):

        year = datetime.now().year
        filter_by = request.query_params.get("filter_by")
        month_number = int(request.query_params.get("month_number",1))
        year = int(request.query_params.get("year",year))  
        tuning_required = request.query_params.get("tuning_required",year)

        start_date = request.query_params.get("start_date")
        end_date = request.query_params.get("end_date")
        if filter_by == "date":
             month_first_day, month_last_day = convert_to_date(start_date, end_date)
        else:
            month_first_day, month_last_day =  get_month_first_and_last_date_by_month(year, month_number) 

        queryset = FileRequest.objects.filter(created_at__gte = month_first_day,
                                            created_at__lte = month_last_day,
                                            tuning_required__in = [tuning_required],
                                            status="CLOSED")
        print(queryset)
        serializer = VehicleRequestListSerializer(queryset, many=True)

        return Response({
            'data': serializer.data,
            'message':"Statics loaded successfully."
        }, status=status.HTTP_200_OK)
    
class InternalTicketByStatusActivityData(APIView):

    permission_classes = [IsAuthenticated,]
    authentication_classes = [TokenAuthentication, ]

    def get(self,request):
        now_year = datetime.now().year
        filter_type = request.query_params.get("filter_type")

        month = int(request.query_params.get("month",1))
        year = int(request.query_params.get("year",now_year))
        ticket_status = request.query_params.get("ticket_status")
        # print(ticket_status)

        if filter_type == "date":
            from_date = request.query_params.get("from_date")
            to_date = request.query_params.get("to_date")
            month_first_day, month_last_day = convert_to_date(from_date, to_date)
        else:
            month_first_day, month_last_day =  get_month_first_and_last_date_by_month(year, month)

        # status_list = manage_ticket_user_status(ticket_status)
        # print(status_list)

        if ticket_status != "New":
            queryset = TicketHistory.objects.filter(
                    created_at__gte = month_first_day,
                    created_at__lte = month_last_day,
                    ticket_status__team_status = ticket_status
                )
        else:
            queryset = TicketHistory.objects.filter(
                    Q(ticket_status__team_status=ticket_status),
                    created_at__gte = month_first_day,
                    created_at__lte = month_last_day,
                )
        
        serializer = TicketHistorySerializer(queryset, many=True)

        return Response({
            'data': serializer.data,
            'message':"Statics loaded successfully."
        }, status=status.HTTP_200_OK)
    
class VehicleModelFilesDataView(APIView):

    permission_classes = [IsAuthenticated,]
    authentication_classes = [TokenAuthentication, ]

    def get(self,request):

        now_year = datetime.now().year
        filter_by = request.query_params.get("filter_by")

        month = int(request.query_params.get("month",1))
        year = int(request.query_params.get("year",now_year))

        if filter_by == "date":
            from_date = request.query_params.get("start_date")
            to_date = request.query_params.get("end_date")
            month_first_day, month_last_day = convert_to_date(from_date, to_date)
        else:
            month_first_day, month_last_day =  get_month_first_and_last_date_by_month(year, month)

        if filter_by == "month":
            queryset = FileRequest.objects.filter(created_at__gte = month_first_day,
                                                created_at__lte = month_last_day,
                                                status="CLOSED").values('request_id','created_at','vehicle_make','model')
        elif filter_by == "date":
            # print(month_first_day.date())
            # print(month_last_day.date())

            # print("============")
            
            # queryset = FileRequest.objects.filter(created_at__date = month_first_day.date(),
            #                                     created_at__lte = month_last_day.date(),
            #                                     status="CLOSED").values('request_id','created_at','vehicle_make','model')[:10]
            
            queryset = FileRequest.objects.filter(created_at__gte = month_first_day,
                                                created_at__lte = month_last_day,
                                                status="CLOSED").values('request_id','created_at','vehicle_make','model').order_by()
        return Response({
            'data': queryset,
            'message':"Statics loaded successfully."
        }, status=status.HTTP_200_OK)
    
class VehicleTunedByTypeDataView(APIView):
    from apps.dashboard.serializer import VehicleRequestListDashboardSerializer

    permission_classes = [IsAuthenticated,]
    authentication_classes = [TokenAuthentication, ]

    def get(self,request):
        filter_by = request.query_params.get("filter_by","month")
        vehicle_type = request.query_params.get("vehicle_type")

        if filter_by == "month":

            month = int(request.query_params.get("month",1))
            year = datetime.now().year
            year = int(request.query_params.get("year",year))  
            start_date, end_date =  get_month_first_and_last_date_by_month(year, month)

            queryset = FileRequest.objects.filter(created_at__gte = start_date,
                                                created_at__lte = end_date,
                                                vehicle_type = vehicle_type
                                                )
        elif filter_by == "date":

            start_date = request.query_params.get("start_date")
            end_date = request.query_params.get("end_date")
            start_date, end_date = convert_to_date(start_date, end_date)

            queryset = FileRequest.objects.filter(created_at__gte = start_date,
                                                created_at__lte = end_date,
                                                vehicle_type = vehicle_type
                                                )
            
        serializer = self.VehicleRequestListDashboardSerializer(queryset, many=True)

        return Response({
            'data': serializer.data,
            'message':"Statics loaded successfully."
        }, status=status.HTTP_200_OK)
    
class ToolUsageDataView(APIView):
    from apps.dashboard.serializer import VehicleRequestListDashboardSerializer

    permission_classes = [IsAuthenticated,]
    authentication_classes = [TokenAuthentication, ]

    def get(self,request):
        filter_by = request.query_params.get("filter_by")

        if filter_by == "month":
            month = int(request.query_params.get("month",1))
            year = datetime.now().year
            year = int(request.query_params.get("year",year))  
            start_date, end_date =  get_month_first_and_last_date_by_month(year, month)
            queryset = FileRequest.objects.filter(created_at__gte = start_date,created_at__lte = end_date,status="CLOSED")
        
        if filter_by == "date":
            start_date = request.query_params.get("start_date")
            end_date = request.query_params.get("end_date")
            start_date, end_date = convert_to_date(start_date, end_date)
            queryset = FileRequest.objects.filter(created_at__gte = start_date,created_at__lte = end_date,status="CLOSED")

        serializer = self.VehicleRequestListDashboardSerializer(queryset, many=True)

        return Response({
            'data': serializer.data,
            'message':"Statics loaded successfully."
        }, status=status.HTTP_200_OK)
    
class FileSuccessNumberDataReport(APIView):
    from apps.dashboard.serializer import VehicleRequestListDashboardSerializer

    permission_classes = [IsAuthenticated,]
    authentication_classes = [TokenAuthentication, ]

    def get(self,request):
        filter_by = request.query_params.get("filter_by","month")
        start_date = request.query_params.get("start_date")
        end_date = request.query_params.get("end_date")

        month = int(request.query_params.get("month",1))
        year = int(request.query_params.get("year",datetime.now().year))  
        stage = request.query_params.get("stage")  

        if filter_by == "date":
            start_date, end_date = convert_to_date(start_date, end_date)
            queryset = FileRequestAveragePerformance.objects.filter(created_at__gte = start_date.date(),created_at__lte = end_date.date())
        else:
            start_date,end_date = get_month_first_and_last_date_by_month(year, month)
            queryset = FileRequestAveragePerformance.objects.filter(created_at__gte = start_date,created_at__lte = end_date)

        if stage == "original_match_found":
            queryset = queryset.filter(original_found=True).values_list('file_request_obj__request_id')
        if stage == "original_not_found":
            queryset = queryset.filter(original_not_found=True).values_list('file_request_obj__request_id')
        if stage == "matching_refrence_found":
            queryset = queryset.filter(refrence_found=True).values_list('file_request_obj__request_id')
        if stage == "decoding_success":
            queryset = queryset.filter(decoding_success=True).values_list('file_request_obj__request_id')
        if stage == "decoding_failure":
            queryset = queryset.filter(decoding_failure=True).values_list('file_request_obj__request_id')
        
        file_queryset = FileRequest.objects.filter(request_id__in = queryset)
        serializer = self.VehicleRequestListDashboardSerializer(file_queryset, many=True)

        return Response({
            'data': serializer.data,
            'message':"Statics loaded successfully."
        }, status=status.HTTP_200_OK)
    
class FileSuccessAverageReportData(APIView):
    from apps.dashboard.serializer import VehicleRequestListDashboardSerializer

    permission_classes = [IsAuthenticated,]
    authentication_classes = [TokenAuthentication, ]

    def get(self,request):
        filter_by = request.query_params.get("filter_by","month")
        start_date = request.query_params.get("start_date")
        end_date = request.query_params.get("end_date")

        month = int(request.query_params.get("month",1))
        year = int(request.query_params.get("year",datetime.now().year))  
        stage = request.query_params.get("stage")  

        if filter_by == "date":
            start_date, end_date = convert_to_date(start_date, end_date)
        else:
            start_date,end_date = get_month_first_and_last_date_by_month(year, month)

        queryset = FileRequestAveragePerformance.objects.filter(
                                        created_at__gte = start_date,
                                        created_at__lte = end_date
                                    )
        if stage == "original_match_found":
            queryset = queryset.filter(original_found=True).values_list('file_request_obj__request_id')
        if stage == "original_not_found":
            queryset = queryset.filter(original_not_found=True).values_list('file_request_obj__request_id')
        if stage == "matching_refrence_found":
            queryset = queryset.filter(refrence_found=True).values_list('file_request_obj__request_id')
        if stage == "decoding_success":
            queryset = queryset.filter(decoding_success=True).values_list('file_request_obj__request_id')
        if stage == "decoding_failure":
            queryset = queryset.filter(decoding_failure=True).values_list('file_request_obj__request_id')
        
        file_queryset = FileRequest.objects.filter(request_id__in = queryset)
        serializer = self.VehicleRequestListDashboardSerializer(file_queryset, many=True)

        return Response({
            'data': serializer.data,
            'message':"Statics loaded successfully."
        }, status=status.HTTP_200_OK)
    
class FileFailNumberReportData(APIView):
    from apps.dashboard.serializer import VehicleRequestListDashboardSerializer

    permission_classes = [IsAuthenticated,]
    authentication_classes = [TokenAuthentication, ]

    def get(self,request):
        filter_by = request.query_params.get("filter_by","month")
        start_date = request.query_params.get("start_date")
        end_date = request.query_params.get("end_date")

        month = int(request.query_params.get("month",1))
        year = int(request.query_params.get("year",datetime.now().year))  
        stage = request.query_params.get("stage")  

        if filter_by == "date":
            start_date, end_date = convert_to_date(start_date, end_date)
        else:
            start_date,end_date = get_month_first_and_last_date_by_month(year, month)

        queryset = FileRequestAveragePerformance.objects.filter(
                                        created_at__gte = start_date,
                                        created_at__lte = end_date
                                    )
        
        if stage == "original_match_found":
            queryset = queryset.filter(original_found=True).values_list('file_request_obj__request_id')
        if stage == "original_not_found":
            queryset = queryset.filter(original_not_found=True).values_list('file_request_obj__request_id')
        if stage == "matching_refrence_found":
            queryset = queryset.filter(refrence_found=True).values_list('file_request_obj__request_id')
        if stage == "decoding_success":
            queryset = queryset.filter(decoding_success=True).values_list('file_request_obj__request_id')
        if stage == "decoding_failure":
            queryset = queryset.filter(decoding_failure=True).values_list('file_request_obj__request_id')

        file_queryset = FileRequest.objects.filter(request_id__in = queryset)
        serializer = self.VehicleRequestListDashboardSerializer(file_queryset, many=True)

        return Response({
            'data': serializer.data,
            'message':"Statics loaded successfully."
        }, status=status.HTTP_200_OK)

class FileFailAverageReportData(APIView):
    from apps.dashboard.serializer import VehicleRequestListDashboardSerializer

    permission_classes = [IsAuthenticated,]
    authentication_classes = [TokenAuthentication, ]

    def get(self,request):

        filter_by = request.query_params.get("filter_by","month")
        start_date = request.query_params.get("start_date")
        end_date = request.query_params.get("end_date")

        month = int(request.query_params.get("month",1))
        year = int(request.query_params.get("year",datetime.now().year))  
        stage = request.query_params.get("stage")  

        if filter_by == "date":
            start_date, end_date = convert_to_date(start_date, end_date)
        else:
            start_date,end_date = get_month_first_and_last_date_by_month(year, month)

        queryset = FileRequestAveragePerformance.objects.filter(created_at__gte = start_date,created_at__lte = end_date)

        if stage == "original_not_found":
            queryset = queryset.filter(original_not_found=True).values_list('file_request_obj__request_id')
        if stage == "refrence_not_found":
            queryset = queryset.filter(refrence_not_found=True).values_list('file_request_obj__request_id')
        if stage == "decoding_success":
            queryset = queryset.filter(decoding_success=True).values_list('file_request_obj__request_id')


        file_queryset = FileRequest.objects.filter(request_id__in = queryset)
        serializer = self.VehicleRequestListDashboardSerializer(file_queryset, many=True)

        return Response({
            'data': serializer.data,
            'message':"Statics loaded successfully."
        }, status=status.HTTP_200_OK)
    
class VehicleTunedByCategoryCreditViewData(APIView):
    from apps.dashboard.serializer import VehicleRequestListDashboardSerializer

    permission_classes = [IsAuthenticated,]
    authentication_classes = [TokenAuthentication, ]

    def get(self,request):
        data = {}
        filter_by = request.query_params.get("filter_by")
        tuning_required = request.query_params.get("tuning_required")

        if filter_by == "month":
            year = datetime.now().year
            month = int(request.query_params.get("month",1))
            year = int(request.query_params.get("year",year))  
            start_date, end_date =  get_month_first_and_last_date_by_month(year, month)

            tuning_required_list = FileRequest.objects.values_list('tuning_required', flat=True).distinct()

            files_by_category = FileRequest.objects.filter(created_at__gte = start_date,
                                                created_at__lte = end_date,
                                                tuning_required__in = [tuning_required],
                                                status="CLOSED")

            credit_usage = CustomerSpentHistory.objects.filter(
                                            created_at__gte = start_date,
                                            created_at__lte = end_date
                                        )
        
        if filter_by == "date":

            start_date = request.query_params.get("start_date")
            end_date = request.query_params.get("end_date")
            start_date, end_date = convert_to_date(start_date, end_date)

            tuning_required_list = FileRequest.objects.values_list('tuning_required', flat=True).distinct()

            files_by_category = FileRequest.objects.filter(created_at__gte = start_date,
                                                created_at__lte = end_date,
                                                tuning_required__in = [tuning_required],
                                                status="CLOSED")

            credit_usage = CustomerSpentHistory.objects.filter(
                                            created_at__gte = start_date,
                                            created_at__lte = end_date
                                        )

        files_by_category_serializer = self.VehicleRequestListDashboardSerializer(files_by_category, many=True)
        # credit_usage_serializer = CustomerSpentDealerSerializer(credit_usage, many=True)

        data['files_by_category'] = files_by_category_serializer.data
        # data['credit_usage'] = credit_usage_serializer.data

        return Response({
            'data': data,
            'message':"Statics loaded successfully."
        }, status=status.HTTP_200_OK)
    
class AverageTimeFileRequestViewData(APIView):
    from apps.dashboard.serializer import VehicleRequestListDashboardSerializer

    permission_classes = [IsAuthenticated,]
    authentication_classes = [TokenAuthentication, ]

    def get(self,request):
        filter_by = request.query_params.get("filter_by","month")
        start_date = request.query_params.get("start_date")
        end_date = request.query_params.get("end_date")
        tuning_required = request.query_params.get("tuning_required")
        month = request.query_params.get("month")
        year = request.query_params.get("year")

        if filter_by == "date":
            start_date, end_date = convert_to_date(start_date, end_date)
        elif filter_by == "month":
            start_date,end_date = get_month_first_and_last_date_by_month(int(year), int(month))

        queryset = FileRequestTime.objects.filter(
                                    created_at__gte = start_date,
                                    created_at__lte = end_date,
                                    file_request__tuning_required = tuning_required,
                                    file_request__status = "CLOSED"
                                ).values("file_request__request_id")
        ids = [q['file_request__request_id'] for q in queryset]
        queryset_file = FileRequest.objects.filter(request_id__in = ids)
        serializer = self.VehicleRequestListDashboardSerializer(queryset_file, many=True)

        return Response({
            'data': serializer.data,
            'message':"Statics loaded successfully."
        }, status=status.HTTP_200_OK)