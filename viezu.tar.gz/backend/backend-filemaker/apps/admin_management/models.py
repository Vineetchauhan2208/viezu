import datetime
from django.db import models
from apps.admin_management.constants import (
    TEMPLATE_TYPE, USER_TECKET_STATUS,
    TICKET_ATTACHEMENT_TYPE
)
from apps.file_request.models import FileRequest
from apps.utils.models import BaseModel
from djrichtextfield.models import RichTextField
from apps.account.models import MyUser, RolesAndPermissions
from apps.utils.helper import filename_path, triger_socket, filename_attach_path
from django.conf import settings

def ticket_attachment(instance, filename):
    return filename_attach_path('ticket', instance, filename)


def conversation_attachment(instance, filename):
    return filename_path('conversation', instance, filename)


class ViezuProduct(BaseModel):
    product_name = models.CharField(max_length=255, null=True, blank=True, unique=True, )

    class Meta:
        verbose_name = 'ViezuProduct'
        verbose_name_plural = 'ViezuProduct'

    def __str__(self):
        return self.product_name


class TemplateCategory(BaseModel):
    name = models.CharField(max_length=255, null=True, blank=True, unique=True, )

    class Meta:
        verbose_name = 'Template Category'
        verbose_name_plural = 'Template Category'

    def __str__(self):
        return self.name


class TicketStatus(BaseModel):
    team_status = models.CharField(max_length=255, null=True, blank=True)
    user_status = models.PositiveSmallIntegerField(choices=USER_TECKET_STATUS)

    class Meta:
        verbose_name = 'Ticket Status'
        verbose_name_plural = 'Ticket Status'

    # def __str__(self):
    #     return "{}:{}".format(self.team_status,self.user_status)


class Template(BaseModel):
    ids = models.CharField(max_length=255, null=True, blank=True)
    category = models.ForeignKey(TemplateCategory, on_delete=models.SET_NULL, null=True, blank=True,
                                 related_name='template_category')
    template_type = models.PositiveSmallIntegerField(choices=TEMPLATE_TYPE, default=1)
    subject = models.CharField(max_length=255, null=True, blank=True)
    body = RichTextField(null=True, blank=True)

    def update_ids(self):
        self.ids = "TP{}".format(str(self.id))
        print(self.ids)
        self.save()

    class Meta:
        verbose_name = 'Template'
        verbose_name_plural = 'Template'

    def __str__(self):
        return self.subject


class TicketCategory(BaseModel):
    name = models.CharField(max_length=255, null=True, blank=True, unique=True, )

    class Meta:
        verbose_name = 'Ticket Category'
        verbose_name_plural = 'Ticket Category'

    def __str__(self):
        return self.name


class TicketHistory(BaseModel):
    ids = models.CharField(max_length=255, null=True, blank=True)
    ticket_status = models.ForeignKey(TicketStatus, on_delete=models.SET_NULL, null=True, blank=True,
                                      related_name='ticket_status')
    created_by = models.ForeignKey(MyUser, on_delete=models.CASCADE, related_name='ticket_created_by')
    assigned_to = models.ForeignKey(MyUser, on_delete=models.CASCADE, null=True, blank=True,
                                    related_name='ticket_assigned_to')
    category = models.ForeignKey(TicketCategory, on_delete=models.CASCADE, related_name='ticket_category')
    tags = models.ManyToManyField(MyUser, related_name='ticket_category', blank=True)
    file_request = models.ForeignKey(FileRequest, on_delete=models.CASCADE, null=True, blank=True,
                                     related_name='ticket_file_request')
    subject = models.CharField(max_length=255, null=True, blank=True)
    description = models.TextField(null=True, blank=True)
    active_users = models.ManyToManyField(MyUser, null=True, blank=True)
    admin_ticket = models.ManyToManyField(FileRequest, blank=True)
    vehicle_details = models.JSONField(default=dict)
    request_id = models.CharField(max_length=255, null=True, blank=True)

    def update_ids(self):
        prefix = ''
        if self.id < 10:
            prefix = '00'
        elif self.id >= 10 and self.id < 100:
            prefix = '0'
        from datetime import datetime
        now = datetime.now()
        self.ids = "TK{}".format(prefix + str(self.id))
        self.save()

    class Meta:
        verbose_name = 'Ticket History'
        verbose_name_plural = 'Ticket History'

    # def __str__(self):
    #     return self.id


class Conversation(BaseModel):
    ticket = models.ForeignKey(TicketHistory, on_delete=models.CASCADE, related_name='ticket_history')
    sender = models.ForeignKey(MyUser, on_delete=models.CASCADE, related_name='sent_messages')
    recipient = models.ForeignKey(MyUser, on_delete=models.CASCADE, related_name='received_messages')
    text = models.TextField(null=True, blank=True)
    file = models.URLField(null=True, blank=True, max_length=500)
    message_type = models.CharField(max_length=255, null=True, blank=True)

    def save(self, *args, **kwargs):
        # Call the superclass's save method to perform the actual save operation
        super().save(*args, **kwargs)
        self.ticket.save()
        if self.ticket.created_by.id == self.sender.id:
            from django.db import transaction

            # Wrap the update operation in a transaction
            with transaction.atomic():
                try:
                    ticket_status_to_change = TicketStatus.objects.get(team_status="New")
                    TicketHistory.objects.filter(ids=self.ticket.ids).update(ticket_status=ticket_status_to_change)
                    updated_ticket = TicketHistory.objects.get(ids=self.ticket.ids)
                    UpdateCloseTicketOpen.objects.create(ticket=updated_ticket)
                    # Trigger sockets

                    context = {
                        'ticket': updated_ticket,
                        'status': updated_ticket.ticket_status.team_status,
                        'message': self.text,
                        'frontend_url': 'www.viezu-files.com',
                    }
                    from django.template.loader import render_to_string
                    from apps.utils.helper import SendMail

                    get_template = render_to_string('email_template/ticket/ticket_closed_reply.html', context)
                    SendMail.mail("Customer responded to a closed ticket:{0}".format(updated_ticket.ids),
                                  "technical@viezu.com", get_template)
                except Exception as error:
                    print(error)

            # triger_socket({
            #     'uuid':str(self.sender.uuid),
            #     'type':'ticket_reopen_sender',
            #     'ids':str(self.ticket.ids)
            # })
            #
            # triger_socket({
            #     'uuid':str(self.recipient.uuid),
            #     'type':'ticket_reopen_receiver',
            #     'ids':str(self.ticket.ids)
            # })


class TicketAttachment(BaseModel):
    uploaded_by = models.ForeignKey(MyUser, on_delete=models.CASCADE, related_name='attachment_uploaded_by')
    ticket = models.ForeignKey(TicketHistory, on_delete=models.CASCADE, related_name='attachment_ticket')
    file = models.FileField(upload_to=ticket_attachment, blank=True, null=True, max_length=500)
    attachement_type = models.PositiveSmallIntegerField(choices=TICKET_ATTACHEMENT_TYPE, null=True,
                                                        blank=True, default=2)
    attachement_name = models.CharField(max_length=255, null=True, blank=True)

    class Meta:
        verbose_name = 'Ticket Attachment'
        verbose_name_plural = 'Ticket Attachment'


class Notification(BaseModel):
    recipient = models.ForeignKey(MyUser, on_delete=models.CASCADE, related_name="notification_recipient")
    sender = models.ForeignKey(MyUser, on_delete=models.CASCADE, null=True, blank=True,
                               related_name="notification_sender")
    ticket = models.ForeignKey(TicketHistory, on_delete=models.CASCADE, null=True, blank=True,
                               related_name="notification_ticket")
    file = models.ForeignKey(FileRequest, on_delete=models.CASCADE, null=True, blank=True,
                             related_name="notification_file")
    title = models.CharField(max_length=150, null=True, blank=False)
    message = models.CharField(max_length=255, null=True, blank=False)
    is_seen = models.BooleanField(default=False)

    class Meta:
        ordering = ('-id',)


class Directory(BaseModel):
    vehicle_type = models.CharField(max_length=150, null=True, blank=True)
    vehicle_producer = models.CharField(max_length=150, null=True, blank=True)
    vehicle_series = models.CharField(max_length=150, null=True, blank=True)
    vehicle_model = models.CharField(max_length=150, null=True, blank=True)
    vehicle_model_year = models.CharField(max_length=150, null=True, blank=True)
    ecu_use = models.CharField(max_length=150, null=True, blank=True)
    ecu_producer = models.CharField(max_length=150, null=True, blank=True)
    ecu_build = models.CharField(max_length=150, null=True, blank=True)
    ecu_prodnr = models.CharField(max_length=150, null=True, blank=True)
    ecu_stgnr = models.CharField(max_length=150, null=True, blank=True)
    ecu_software_version = models.CharField(max_length=150, null=True, blank=True)
    engine_name = models.CharField(max_length=150, null=True, blank=True)
    engine_displacement = models.CharField(max_length=150, null=True, blank=True)
    engine_type = models.CharField(max_length=150, null=True, blank=True)
    directory_path = models.CharField(max_length=255, null=True, blank=True)
    ini_file_path = models.CharField(max_length=255, null=True, blank=True)
    created_by_filemaker = models.BooleanField(default=False)
    file_request = models.ForeignKey(FileRequest, on_delete=models.CASCADE,
                                     null=True, blank=True,
                                     related_name="directory_file")

    class Meta:
        verbose_name = 'Directory'
        verbose_name_plural = 'Directory'


class TicketNote(BaseModel):
    user = models.ForeignKey(MyUser, on_delete=models.CASCADE, related_name="ticket_creator",
                             null=True, blank=True)
    ticket = models.ForeignKey(TicketHistory, on_delete=models.CASCADE, related_name='ticket_notes')
    note = models.TextField(null=True, blank=True)

    class Meta:
        verbose_name = 'Ticket Notes'
        verbose_name_plural = 'Ticket Notes'


class CustomFilter(BaseModel):
    user = models.ForeignKey(MyUser, on_delete=models.CASCADE, related_name="filter_creator",
                             null=True, blank=True)
    module_name = models.CharField(max_length=255, null=True, blank=True)
    custom_filter = models.JSONField(default=dict)

    class Meta:
        verbose_name = 'Custom Filter'
        verbose_name_plural = 'Custom Filter'


class ManageDashboard(BaseModel):
    """ User permissions database schema for module access."""

    role_name = models.CharField(max_length=255, null=True, blank=True, unique=True, )
    dashboard_json = models.JSONField(default=dict)

    class Meta:
        verbose_name = 'Manage Dashboard'
        verbose_name_plural = 'Manage Dashboard'


class TicketGroup(BaseModel):
    """ User permissions database schema for module access."""

    title = models.CharField(max_length=255, null=True, blank=True)
    created_by = models.ForeignKey(MyUser, on_delete=models.CASCADE, related_name="ticket_group_creator", null=True,
                                   blank=True)
    filter = models.JSONField(default=dict, null=True, blank=True)
    role_id = models.PositiveIntegerField(default=0)

    class Meta:
        verbose_name = 'Ticket Group'
        verbose_name_plural = 'Ticket Group'


class TicketActiveFilter(BaseModel):
    """ User permissions database schema for module access."""

    user = models.ForeignKey(MyUser, on_delete=models.CASCADE, related_name="ticket_active_filter_user", null=True,
                             blank=True)
    active_filter = models.ForeignKey(TicketGroup, on_delete=models.CASCADE, related_name="ticket_active_filter",
                                      null=True, blank=True)

    class Meta:
        verbose_name = 'Ticket Active Filter'
        verbose_name_plural = 'Ticket Active Filter'


class UpdateCloseTicketOpen(BaseModel):
    ticket = models.ForeignKey(TicketHistory, on_delete=models.CASCADE, related_name='ticket_history_open')

    class Meta:
        verbose_name = 'Update Close Ticket Open'
        verbose_name_plural = 'Update Close Ticket Open'
