from drf_yasg import openapi


ticket_status_schema = openapi.Schema(
    title =("Update Ticket History Status"),
    type=openapi.TYPE_OBJECT, 
    properties={
        'ticket_status': openapi.Schema(type=openapi.TYPE_NUMBER),
    },
    required=['ticket_status',],
)

ticket_assign_schema = openapi.Schema(
    title =("Assign Ticket History"),
    type=openapi.TYPE_OBJECT, 
    properties={
        'user_id': openapi.Schema(type=openapi.TYPE_NUMBER),
    },
    required=['user_id',],
)


download_s3_schema = openapi.Schema(
    title =("Download S3 File"),
    type=openapi.TYPE_OBJECT, 
    properties={
        'prefix': openapi.Schema(type=openapi.TYPE_STRING,example='Main/folder1/05D86014'),
    },
    required=['prefix',],
)


rename_s3_file_schema = openapi.Schema(
    title =("Rename S3 File"),
    type=openapi.TYPE_OBJECT, 
    properties={
        'prefix': openapi.Schema(type=openapi.TYPE_STRING,example='Main/folder1/file_name'),
        'file_name': openapi.Schema(type=openapi.TYPE_STRING,example='Main/folder1/new_filename'),
    },
    required=['prefix','file_name'],
)


get_sub_dir_schema = openapi.Schema(
    title =("Get Sub S3 File"),
    type=openapi.TYPE_OBJECT, 
    properties={
        'prefix': openapi.Schema(type=openapi.TYPE_STRING,example='Main/folder1/file_name'),
    },
    required=['prefix'],
)

ecu_version_schema = openapi.Schema(
    title =("Get Sub S3 File"),
    type=openapi.TYPE_OBJECT, 
    properties={
        'name': openapi.Schema(type=openapi.TYPE_STRING,example='IAW 5AF'),
    },
    required=['name'],
)

reseller_schema  = openapi.Schema(
 title =("Reseller Register"),
    type=openapi.TYPE_OBJECT,
    properties={
        
        'address': openapi.Schema(type=openapi.TYPE_OBJECT, description=('Address'), 
            properties={
                'address_2':openapi.Schema(type=openapi.TYPE_STRING, example="OKhla Phase one"),
                'address':openapi.Schema(type=openapi.TYPE_STRING, example="OKhla Phase one"),
                'country': openapi.Schema(type=openapi.TYPE_STRING, example='India'),
                'state': openapi.Schema(type=openapi.TYPE_STRING, example='New Delhi'),
                'city': openapi.Schema(type=openapi.TYPE_STRING, example='Okhla'),
                'zip':openapi.Schema(type=openapi.TYPE_STRING, example='110020'),
            }
        ),
        'reseller': openapi.Schema(type=openapi.TYPE_OBJECT, description=('Reseller'), 
            properties={
                'first_name': openapi.Schema(type=openapi.TYPE_STRING,example="Aftab"),
                'last_name': openapi.Schema(type=openapi.TYPE_STRING,example="Hussain"),
                'phone_no': openapi.Schema(type=openapi.TYPE_STRING,example="+917278737088"),
                'mobile_no': openapi.Schema(type=openapi.TYPE_STRING,example="+917278737088"),
                'email': openapi.Schema(type=openapi.TYPE_STRING,example="aftab4evr786@gmail.com")
            }
        ),
        'detail': openapi.Schema(type=openapi.TYPE_OBJECT, description=('Reseller'), 
            properties={
                'bussness_name': openapi.Schema(type=openapi.TYPE_STRING,example="Aftab"),
                'tax_number': openapi.Schema(type=openapi.TYPE_STRING,example="Hussain"),
                'company_number': openapi.Schema(type=openapi.TYPE_STRING,example="dfgd"),
                'win_ols_license_number': openapi.Schema(type=openapi.TYPE_STRING,example="fgdg"),
            }
        ),
    },
)

update_reseller_schema = openapi.Schema(
 title =("Update Reseller"),
    type=openapi.TYPE_OBJECT,
    properties={
        'uuid': openapi.Schema(type=openapi.TYPE_STRING,example='UUID'),
        'address': openapi.Schema(type=openapi.TYPE_OBJECT, description=('Address'), 
            properties={
                'address_2':openapi.Schema(type=openapi.TYPE_STRING, example="OKhla Phase one"),
                'address':openapi.Schema(type=openapi.TYPE_STRING, example="OKhla Phase one"),
                'country': openapi.Schema(type=openapi.TYPE_STRING, example='India'),
                'state': openapi.Schema(type=openapi.TYPE_STRING, example='New Delhi'),
                'city': openapi.Schema(type=openapi.TYPE_STRING, example='Okhla'),
                'zip':openapi.Schema(type=openapi.TYPE_STRING, example='110020'),
            }
        ),
        'reseller': openapi.Schema(type=openapi.TYPE_OBJECT, description=('Reseller'), 
            properties={
                'first_name': openapi.Schema(type=openapi.TYPE_STRING,example="Aftab"),
                'last_name': openapi.Schema(type=openapi.TYPE_STRING,example="Hussain"),
                'phone_no': openapi.Schema(type=openapi.TYPE_STRING,example="+917278737088"),
                'mobile_no': openapi.Schema(type=openapi.TYPE_STRING,example="+917278737088"),
            }
        ),
    },
)
dealer_schema  = openapi.Schema(
 title =("Dealer Register"),
    type=openapi.TYPE_OBJECT,
    properties={
        'address': openapi.Schema(type=openapi.TYPE_OBJECT, description=('Address'), 
            properties={
                'address_2':openapi.Schema(type=openapi.TYPE_STRING, example="OKhla Phase one"),
                'address':openapi.Schema(type=openapi.TYPE_STRING, example="OKhla Phase one"),
                'country': openapi.Schema(type=openapi.TYPE_STRING, example='India'),
                'state': openapi.Schema(type=openapi.TYPE_STRING, example='New Delhi'),
                'city': openapi.Schema(type=openapi.TYPE_STRING, example='Okhla'),
                'zip':openapi.Schema(type=openapi.TYPE_STRING, example='110020'),
            }
        ),
        'dealer': openapi.Schema(type=openapi.TYPE_OBJECT, description=('Dealer'), 
            properties={
                'first_name': openapi.Schema(type=openapi.TYPE_STRING,example="Aftab"),
                'last_name': openapi.Schema(type=openapi.TYPE_STRING,example="Hussain"),
                'phone_no': openapi.Schema(type=openapi.TYPE_STRING,example="+917278737088"),
                'mobile_no': openapi.Schema(type=openapi.TYPE_STRING,example="+917278737088"),
                'email': openapi.Schema(type=openapi.TYPE_STRING,example="aftab4evr786@gmail.com")
            }
        ),
    },
)