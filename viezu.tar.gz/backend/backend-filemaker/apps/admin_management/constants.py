USER_TECKET_STATUS = (
    (1, 'Pending'),
    (2, 'On Hold'),
    (3, 'Closed'),
    (4, 'In progress'),
    (5, 'New'),
    (6, 'Pending reply'),
    (7, 'In Development'),
    (8, 'Escalated'),
    (9, 'Awaiting feedback'),
    (10, 'ECU Booked in'),
)


USER_STATUS_MAP = {
    'Pending': 1,
    'On Hold': 2,
    'Closed': 3,
    'In progress': 4,
    'New': 5,
    'Pending reply': 6,
    'In Development': 7,
    'Escalated': 8,
    'Awaiting feedback': 9,
    'ECU Booked in': 10,
}



TEMPLATE_TYPE = (
    (1, 'Log Report'),
    (2, 'Ticket'),
)


TICKET_ATTACHEMENT_TYPE = (
    (1, 'Tuning file'),
    (2, 'Basic Attachment'),
)


def validate_user_ticket(user, ticket, assigned_to=None):
    flag = False
    if user and ticket:
        if user.user_type in [3, 4, 6, 7] and ticket:
            # check
            if ticket and (ticket.created_by == user or (assigned_to and ticket.assigned_to == user)):
                flag = True
        elif user.user_type in [1, 2, 5]:
            flag = True
    return flag


def validate_user_is_admin(user):
    flag = False
    if user.user_type in [1, 2, 5]:
        flag = True
    return flag
