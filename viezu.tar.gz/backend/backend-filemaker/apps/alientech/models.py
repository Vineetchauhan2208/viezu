import datetime

from django.db import models
from apps.account.models import MyUser

from apps.utils.helper import filename_path
from apps.utils.models import BaseModel


def decode_attachment(instance, filename):
    return filename_path('decode', instance, filename)

def encode_attachment(instance, filename):
    return filename_path('encode/modified', instance, filename)

def encode_original_attachment(instance, filename):
    return filename_path('encode/original', instance, filename)


class DecodeFiles(BaseModel):
    TOOL_TYPE = (
        (1, 'kessv2'),
        (2, 'kess3'),
        (3, 'ktag'),
        (4, 'Magic'),
    )
    STATUS = (
        (1,'Pending'),
        (2,'Success'),
        (3,'Failed'),
    )
    REQUEST_TYPE = (
        (1,'Initial'),
        (1,'Async')
    )
    Process_TYPE = (
        (1,'Manual'),
        (2,'Automation')
    )
    user = models.ForeignKey(MyUser, on_delete=models.CASCADE,related_name='user_decode_file')
    tool_type = models.PositiveSmallIntegerField(choices=TOOL_TYPE,default=1)
    status = models.PositiveSmallIntegerField(choices=STATUS,default=1)
    request_type = models.PositiveSmallIntegerField(choices=REQUEST_TYPE,default=1)
    ids = models.CharField(max_length=255,null=True,blank=True)
    file_request_id = models.CharField(max_length=255,null=True,blank=True)# new added
    guid = models.CharField(max_length=255,null=True,blank=True)
    slot_guid = models.CharField(max_length=255,null=True,blank=True)
    decode_response = models.JSONField(default=dict)
    async_response = models.JSONField(default=dict)
    file = models.FileField(upload_to=decode_attachment, blank=True, null=True,max_length=500)
    is_completed = models.BooleanField(default=False)
    is_file_closed = models.BooleanField(default=False)
    process_type = models.PositiveSmallIntegerField(choices=Process_TYPE,default=1)


    def update_ids(self):
        self.ids = "DE{}".format(self.id)
        self.save()


class EncodeFiles(BaseModel):
    STATUS = (
        (1,'Pending'),
        (2,'Success'),
        (3,'Failed'),
    )
    user = models.ForeignKey(MyUser, on_delete=models.CASCADE,related_name='user_encode_file')
    parent = models.ForeignKey('self', null=True, blank=True,on_delete=models.SET_NULL, related_name='parent_encode')
    decode = models.ForeignKey(DecodeFiles, on_delete=models.CASCADE,related_name='decode')
    guid = models.CharField(max_length=255,null=True,blank=True)
    slot_guid = models.CharField(max_length=255,null=True,blank=True)
    ids = models.CharField(max_length=255,null=True,blank=True)
    file_type = models.CharField(max_length=255,null=True,blank=True)
    encode_response = models.JSONField(default=dict)
    async_response = models.JSONField(default=dict)
    file = models.FileField(upload_to=encode_attachment, blank=True, null=True, max_length=500)
    status = models.PositiveSmallIntegerField(choices=STATUS,default=1)
    is_completed = models.BooleanField(default=False)
    request_type = models.CharField(max_length=255,null=True,blank=True)
    is_file_closed = models.BooleanField(default=False)

    def update_ids(self):
        self.ids = "EN{}{}".format(
            str(datetime.date.today()).replace('-',''),self.id
        )
        self.save()

class ManualFile(BaseModel):

    dir_name = models.CharField(max_length=255,null=True,blank=True)
    decode = models.ForeignKey(DecodeFiles, on_delete=models.CASCADE,related_name='manual_decode_file')
    encode = models.ForeignKey(EncodeFiles, on_delete=models.CASCADE,
                            related_name='manual_encode_file', null=True,blank=True)
    file_name = models.CharField(max_length=255,null=True,blank=True)
    file_url = models.URLField(null=True,blank=True)

    class Meta:
        verbose_name = 'Manual File'
        verbose_name_plural = 'Manual File'
