import json
from rest_framework.response import Response
from rest_framework.filters import SearchFilter
from django_filters import rest_framework as filters

from rest_framework.views import APIView
from rest_framework import status, generics, viewsets

from rest_framework.authentication import TokenAuthentication
from rest_framework.permissions import IsAuthenticated
from rest_framework.parsers import FormParser, MultiPartParser
from apps.account.models import MyUser

from django.db.models import Q
from apps.alientech.models import DecodeFiles, EncodeFiles, ManualFile
from apps.alientech.serializer import DecodeFileSerializer, EncodeFilesFileSerializer, ManualFileSerializer
from apps.utils.ecode_decode import FileOperation

from apps.utils.pagination import SetPagination
import apps.admin_management.response_message as resp_msg
from django.db.models import Count

from drf_yasg.utils import swagger_auto_schema

import apps.utils.evc_apis as evc_utils
from apps.account.models import EVCCredentials

from apps.alientech.schema import (
    encode_download_any_file_schema,kessv2_encode_file_schema,ktag_encode_file_schema
)

import logging
logger = logging.getLogger('django')


class DecodeFileView(generics.CreateAPIView,generics.ListAPIView):
    pagination_class = SetPagination
    parser_classes = (FormParser, MultiPartParser)
    serializer_class = DecodeFileSerializer
    permission_classes = [IsAuthenticated,]
    authentication_classes = [TokenAuthentication, ]
    queryset = DecodeFiles.objects.all().order_by('-id')

    def post(self,request):
        params = request.data
        is_sucess,response  = False,None
        print(f"file : {request.FILES['readfile']}")
        logger.info(f"file : {request.FILES['readfile']}")
        tool_type = params['tool_type']
        print(f"tool type is : {tool_type}")
        logger.info(f"tool type == {tool_type}")

        evc_instance = EVCCredentials.objects.all().last()
        if params['tool_type'] == 1 or params['tool_type'] == '1':
            is_sucess,response = FileOperation().decode_kessV2_file(evc_instance.alientechauttoken,request.FILES['readfile'])
        elif params['tool_type'] == 2 or params['tool_type'] == '2':
            is_sucess,response = FileOperation().decode_kess3_file(evc_instance.alientechauttoken,request.FILES['readfile'])
            logger.info(is_sucess)
            logger.info(response)
        elif params['tool_type'] == 3 or params['tool_type'] == '3':
            is_sucess,response = FileOperation().decode_ktag_file(evc_instance.alientechauttoken,request.FILES['readfile'])
        elif params['tool_type'] == 4 or params['tool_type'] == '4':
            print("inside tool 4 magic api------------")
            logger.info("inside magic api code ------------")
            is_sucess,response = FileOperation().decode_Magic_file(request.FILES['readfile'])
            # if is_sucess:
                # instance = DecodeFiles.objects.create(
                #     user = request.user,
                #     tool_type = params['tool_type'],
                #     file = request.FILES['readfile'],
                #     decode_response = response,
                #     status = 2,
                #     is_completed=True,
                # )
                # instance.update_ids()
                # instance.save()
                # print(f"Magic API Decode instance object : {instance}")
                # return Response({
                #     'message':'File upload successfully for decode file.',
                #     'data':response
                # })
            # else:
            #     return Response({
            #         'message':'Something went wrong while file decode.',
            #         'detail':response
            #     },status=status.HTTP_400_BAD_REQUEST)
        else:
            return Response({
                'details':"Invalid tool_type"
            },status=status.HTTP_400_BAD_REQUEST)
        if is_sucess:
            instance = DecodeFiles.objects.create(
                user = request.user,
                tool_type = params['tool_type'],
                file = request.FILES['readfile'],
                decode_response  = response,
                # guid = response['guid']
                guid = response.get('guid',''),
                status = 2 if params['tool_type'] in [4,'4'] else 1,
                is_completed=True if params['tool_type'] in [4,'4'] else False,
            )
            instance.update_ids()
            instance.save()
            print(f"Alein Tech Decode instance object : {instance}")
            return Response({
                'message':'File upload successfully for decode file.',
                'data':response
            })
        return Response({
            'message':'Something went wrong while file decode.',
            'detail':response
        },status=status.HTTP_400_BAD_REQUEST)
    

    def get_queryset(self):
        params = self.request.query_params
        queryset = DecodeFiles.objects.all().order_by('-id')
        if 'tool_type' in params and params['tool_type'] != '':
            queryset = queryset.filter(tool_type = params['tool_type'])
        if  'status' in params and params['status'] != '':
            queryset = queryset.filter(status = params['status'])
        return queryset
    
    
    def list(self, request, *args, **kwargs):
        field_to_sort = request.query_params.get('field')
        order_in = request.query_params.get('order_in')

        if order_in == 'asc':
            order_by_str = field_to_sort
        elif order_in == 'dec':
            order_by_str = '-'+field_to_sort
        else:
            order_by_str = ''

        if field_to_sort is not None and order_by_str is not None:
            queryset = self.get_queryset().order_by(order_by_str)
            serializer = DecodeFileSerializer(queryset, many=True)
            page = self.paginate_queryset(serializer.data)
            data = dict(self.get_paginated_response(page).data)
        else:
            data = super(DecodeFileView, self).list(request, *args, **kwargs).data
        return Response({
            'message': resp_msg.RECORD_FETCHED_SUCCESSFULLY,
            'data': data
        }, status=status.HTTP_200_OK)

class DecodeByIDView(APIView):
    permission_classes = [IsAuthenticated,]
    authentication_classes = [TokenAuthentication, ]

    def get(self,request,ids):
        queryset = DecodeFiles.objects.get(ids=ids)
        serializer  = DecodeFileSerializer(queryset)
        return Response({
            'message': resp_msg.RECORD_FETCHED_SUCCESSFULLY,
            'data': serializer.data
        }, status=status.HTTP_200_OK)

class DownloadAnyFileFileView(APIView):
    permission_classes = [IsAuthenticated,]
    authentication_classes = [TokenAuthentication, ]

    @swagger_auto_schema(request_body=encode_download_any_file_schema)
    def post(self,request):
        params = request.data
        evc_instance = EVCCredentials.objects.all().last()

        is_sucess,response = FileOperation().download_file(
            evc_instance.alientechauttoken,
            params['url']
        )
        if is_sucess:
            return Response({
                'message':'Data fatched successfully',
                'data':response,
            })
        return Response({
            'message':'Something went wrong while file decode.',
            'detail':response,
        },status=status.HTTP_400_BAD_REQUEST)


class DecodeDownloadKessv2FileView(APIView):
    permission_classes = [IsAuthenticated,]
    authentication_classes = [TokenAuthentication, ]
    def get(slef,request,ids):
        evc_instance = EVCCredentials.objects.all().last()
        decode_instance = DecodeFiles.objects.get(ids=ids)
        is_sucess,response = FileOperation().download_decode_file(
            evc_instance.alientechauttoken,
            decode_instance.slot_guid,
            'kessv2'
        )
        if is_sucess:
            return Response({
                'message':'Data fatched successfully',
                'data':response,
                'filename': json.loads(decode_instance.async_response)['result']['name']  if'result' in json.loads(decode_instance.async_response) and 'name' in json.loads(decode_instance.async_response)['result'] else 'N/A'
            })
        return Response({
            'message':'Something went wrong while file decode.',
            'detail':response,
        },status=status.HTTP_400_BAD_REQUEST)
    


class EncodeModifiedFileView(generics.CreateAPIView,generics.ListAPIView):
    pagination_class = SetPagination
    parser_classes = (FormParser, MultiPartParser)
    serializer_class = EncodeFilesFileSerializer
    permission_classes = [IsAuthenticated,]
    authentication_classes = [TokenAuthentication, ]
    queryset = EncodeFiles.objects.all().order_by('-id')

    def post(self,request):
        params = request.data
        is_sucess,response  = False,None
        evc_instance = EVCCredentials.objects.all().last()
        decode_instance = DecodeFiles.objects.get(ids = params['decode_ids'])
        
        if decode_instance.tool_type == 1 or decode_instance.tool_type == '1':
            is_sucess,response = FileOperation().kessv2_upload_modified_file(
                evc_instance.alientechauttoken,
                request.FILES['readfile'],
                decode_instance.slot_guid,
            )
        elif decode_instance.tool_type == 2 or decode_instance.tool_type == '2':
            is_sucess,response = FileOperation().kessv3_upload_modified_file(
                evc_instance.alientechauttoken,
                request.FILES['readfile'],
                decode_instance.slot_guid,
                params['type'],
            )
        elif decode_instance.tool_type == 3 or decode_instance.tool_type == '3':
            is_sucess,response = FileOperation().ktag_upload_modified_file(
                evc_instance.alientechauttoken,
                request.FILES['readfile'],
                decode_instance.slot_guid,
                params['type'],
            )
        if is_sucess:
            instance = EncodeFiles.objects.create(
                user = request.user,
                decode = decode_instance,
                guid = response['guid'] if 'guid' in response else 'N/A',
                file = request.FILES['readfile'],
                encode_response  = response,
                file_type = params['type'] if 'type' in params else 'N/A'
            )
            if 'parent' in params and params['parent'] != '':
                parent = EncodeFiles.objects.get(ids = params['parent'],parent__isnull=True)
                instance.parent = parent
                instance.ids = parent.ids
            else:
                instance.update_ids()
            instance.save()
            return Response({
                'data':EncodeFilesFileSerializer(instance).data,
                'message':'File upload successfully for encode file.',
            })
        return Response({
            'message':'Something went wrong while file decode.',
            'detail':response
        },status=status.HTTP_400_BAD_REQUEST)
    


    def get_queryset(self):
        return EncodeFiles.objects.filter(parent__isnull=True).order_by('-id')

    def list(self, request, *args, **kwargs):
        response = super(EncodeModifiedFileView, self).list(request, *args, **kwargs)
        return Response({
            'message': resp_msg.RECORD_FETCHED_SUCCESSFULLY,
            'data': response.data
        }, status=status.HTTP_200_OK)
    
  
class EncodeModifiedByGuidFileView(APIView):
    permission_classes = [IsAuthenticated,]
    authentication_classes = [TokenAuthentication, ]
    def get(self,request,ids):
        instance = EncodeFiles.objects.filter(ids = ids).order_by('id')
        serializer = EncodeFilesFileSerializer(instance,many=True).data
        return Response({
            'data':serializer,
            'messgae':"Data fatched successfully"
        })
    

class EncodeFileView(APIView):
    permission_classes = [IsAuthenticated,]
    authentication_classes = [TokenAuthentication, ]

    @swagger_auto_schema(request_body=kessv2_encode_file_schema)

    def post(self,request):
        evc_instance = EVCCredentials.objects.all().last()
        params = request.data
        encode_instance = EncodeFiles.objects.get(ids = params['parent'],parent__isnull=True)
        if encode_instance.decode.tool_type == 1 or encode_instance.decode.tool_type == '1':
            is_sucess,response = FileOperation().kessv2_encode_file(
                evc_instance.alientechauttoken,
                encode_instance.decode.slot_guid,
                encode_instance.guid,
                params['is_correct_cvn']
            )
        else:
            return Response({
                'details':"Invalid Type"
            },status=status.HTTP_400_BAD_REQUEST)
        if is_sucess:
            instance = EncodeFiles.objects.create(
                user = request.user,
                decode = encode_instance.decode,
                guid = response['guid'] if 'guid' in response else 'N/A',
                encode_response  = response,
                file_type = params['type'] if 'type' in params else 'Encode',
                parent = encode_instance,
                ids = encode_instance.ids
            )
            return Response({
                'message':'Original File upload successfully for encode file.',
                'data':response
            })
        return Response({
            'message':'Something went wrong while file decode.',
            'detail':response
        },status=status.HTTP_400_BAD_REQUEST)
    

class EncodeKTagFileView(APIView):
    permission_classes = [IsAuthenticated,]
    authentication_classes = [TokenAuthentication, ]

    @swagger_auto_schema(request_body=ktag_encode_file_schema)

    def post(self,request):
        evc_instance = EVCCredentials.objects.all().last()
        params = request.data
        encode_instance = EncodeFiles.objects.get(ids = params['ids'],parent__isnull=True)
        if encode_instance.decode.tool_type == 3 or encode_instance.decode.tool_type == '3':
            is_sucess,response = FileOperation().ktag_encode_file(
                evc_instance.alientechauttoken,
                encode_instance.decode.slot_guid,
                params['micro_guid'],
                params['flash_guid'],
                params['eeprom_guid'],
                params['flash_guid']
            )
        else:
            return Response({
                'details':"Invalid Type"
            },status=status.HTTP_400_BAD_REQUEST)
        if is_sucess:
            instance = EncodeFiles.objects.create(
                user = request.user,
                decode = encode_instance.decode,
                guid = response['guid'] if 'guid' in response else 'N/A',
                encode_response  = response,
                file_type = 'Encode',
                parent = encode_instance,
                ids = encode_instance.ids
            )
            return Response({
                'message':'Encoded successfully.',
                'data':response
            })
        return Response({
            'message':'Something went wrong while file decode.',
            'detail':response
        },status=status.HTTP_400_BAD_REQUEST)


class EncodeKKess3FileView(APIView):
    permission_classes = [IsAuthenticated,]
    authentication_classes = [TokenAuthentication, ]

    # @swagger_auto_schema(request_body=ktag_encode_file_schema)

    def post(self,request):
        evc_instance = EVCCredentials.objects.all().last()
        params = request.data
        encode_instance = EncodeFiles.objects.get(ids = params['ids'],parent__isnull=True)
        if encode_instance.decode.tool_type == 2 or encode_instance.decode.tool_type == '2':
            if params['kess3_mode'] == "OBD":

                is_sucess,response = FileOperation().encode_kess3_obd_file(
                    evc_instance.alientechauttoken,
                    encode_instance.decode.slot_guid,
                    params["modified_file_guid"],
                    params["original_file_guid"],
                    params["will_correct_cvn"]
                )
            elif params['kess3_mode'] == "BootBench":
                is_sucess,response = FileOperation().encode_kess3_boot_bench_file(
                    evc_instance.alientechauttoken,
                    encode_instance.decode.slot_guid,
                    params["micro_file_guid"],
                    params["flash_file_guid"],
                    params["eeprom_file_guid"],
                    params["mapfile_file_guid"]
                )
            else:
                return Response({
                    'details':"Invalid Kess3 Mode"
                },status=status.HTTP_400_BAD_REQUEST)
        else:
            return Response({
                'details':"Invalid Type"
            },status=status.HTTP_400_BAD_REQUEST)
        if is_sucess:
            instance = EncodeFiles.objects.create(
                user = request.user,
                decode = encode_instance.decode,
                guid = response['guid'] if 'guid' in response else 'N/A',
                encode_response  = response,
                file_type = 'Encode',
                parent = encode_instance,
                ids = encode_instance.ids
            )
            return Response({
                'message':'Encoded successfully.',
                'data':response
            })
        return Response({
            'message':'Something went wrong while file decode.',
            'detail':response
        },status=status.HTTP_400_BAD_REQUEST)

class ViewManualDirectoryView(APIView):

    permission_classes = [IsAuthenticated,]
    authentication_classes = [TokenAuthentication, ]
    pagination_class = SetPagination
    serializer_class = ManualFileSerializer
    queryset = ManualFile.objects.all().order_by('-id')

    def get(self,request,ids):
        decode = DecodeFiles.objects.get(ids = ids)
        queryset = ManualFile.objects.filter(decode = decode)
        serializer  = ManualFileSerializer(queryset, many=True)
        return Response({
            'message': resp_msg.RECORD_FETCHED_SUCCESSFULLY,
            'data': serializer.data
        }, status=status.HTTP_200_OK)