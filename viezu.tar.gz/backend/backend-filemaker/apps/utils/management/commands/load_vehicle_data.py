import csv
from django.core.management.base import BaseCommand
from apps.file_request.models import *

def load_vehicle():
    print("Uploading Vehicle please wait it will take some time......\n")
    with open("file-data/ECUs by vehicle manufacturer and model.csv") as f:
        reader = csv.reader(f)
        i = 0
        count = 0
        for row in reader:
            # print(row)
            if i!= 0:
                vehicle_type = row[0]
                ecu_type	 = row[1]
                brand	 = row[2]	
                model	 = row[3]	
                fuel	 = row[4]	
                ecu_brand	 = row[5]	
                ecu_version	 = row[6]

                try:
                    instaince_vehicle_type = VehicleType.objects.get(name = vehicle_type)
                    instaince_brand  = VehicleBrand.objects.get(
                                                        vehicle_type = instaince_vehicle_type,
                                                        brand_name= brand)
                    instaince_model  = VehicleModel.objects.get(
                                                        vehicle_brand = instaince_brand,
                                                        model_name= model)
                    instaince_model  = VehicleControl.objects.get(
                                                        vehicle_model = instaince_model,
                                                        ecu_brand= ecu_brand,
                                                        ecu_version =ecu_version,
                                                        fuel_type=fuel)
                    instaince_model.ecu_type = ecu_type
                    instaince_model.save()
                except Exception as error:
                    print(error)
                    count +=1
            
            i += 1


class Command(BaseCommand):
    
    help = 'Loading data into Database'

    def handle(self, *args, **kwargs):
        load_vehicle()