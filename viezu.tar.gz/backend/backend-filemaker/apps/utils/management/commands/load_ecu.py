import csv
from django.core.management.base import BaseCommand
from apps.file_request.models import DataEcuBrand, DataEcuVersion

def load_ecu():
    print("Uploading ECU data please wait it will take some time......\n")
    with open("file-data/ECUs by vehicle manufacturer and model.csv") as f:
        reader = csv.reader(f)
        i = 0
        for row in reader:
            # print(row)
            if i!= 0:
                ecu_brand	 = row[5]	
                ecu_version	 = row[6]

                if ecu_brand == "Bosch" and ecu_version == "EDC17CP02":
                    percentage  = 98
                elif ecu_brand == "Bosch" and ecu_version == "EDC17C60":
                    percentage = 99.75
                elif ecu_brand == "Siemens" and ecu_version == "SID208":
                    percentage = 99.93
                elif ecu_brand == "Continental" and ecu_version == "SID208":
                    percentage = 99.93
                else:
                    percentage = 98


                instaince_brand,_  = DataEcuBrand.objects.get_or_create(
                                                    brand_name= ecu_brand)
                instaince_model,_  = DataEcuVersion.objects.get_or_create(
                                     brand = instaince_brand,
                                     ecu_version_name = ecu_version,
                                     percentage = percentage)
            
            i += 1



class Command(BaseCommand):
    
    help = 'Loading ECU into Database'

    def handle(self, *args, **kwargs):
        load_ecu()