from datetime import datetime, timedelta

def get_current_date():
    """ Get current date.

    Returns:
        date object: Current date
    """
    current_date = datetime.now().date() + timedelta(days=1)
    return current_date

def get_back_date_by_number_of_days(date, back_days=7):
    """Get back date by number of days.

    Args:
        date (date object): date from which back date to be get by days. 
        back_days (int, optional): Number of days to get back date. Defaults to 7.

    Returns:
        date objetc: back date
    """
    date = date - timedelta(days=back_days)
    return date

