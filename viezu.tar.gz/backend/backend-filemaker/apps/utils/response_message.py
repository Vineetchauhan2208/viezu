DATA_FETCHED_SUCCESSFULL = "Data fetched successfully." 
UNAUTHORIZED_ACCESS = "You are not authorized to perform this action. Only User can perform this action"
ADMIN_ONLY_DELETE_ACCESS = "You are not authorized to perform this action. only admin or internal team can delete the customer."