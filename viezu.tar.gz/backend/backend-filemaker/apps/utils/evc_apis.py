import requests
import json

BASE_URL = "https://evc.de/services/"
def add_customer_credits(apiid, customer, 
                        username, password,
                        verb, credit):
    url = BASE_URL+"api_resellercredits.asp?apiid={}&customer={}&username={}&password={}&verb=addcustomeraccount&credit={}".format(apiid, customer, 
                        username, password,
                        verb, credit)
    payload={}
    headers = {}
    response = requests.request("GET", url, headers=headers, data=payload)
    
    return response.text 

def add_customer_evc(apiid, customer, 
                    username, password,
                    verb):
    url = BASE_URL+"api_resellercredits.asp?apiid={}&username=13213&password=ebKQbQZx5G7oI1Qe&verb=addcustomer&customer=33333".format(apiid, customer, 
                        username, password,
                        verb)
    payload={}
    headers = {}
    response = requests.request("GET", url, headers=headers, data=payload)
    
    return response.text 

def list_customers(apiid, 
                    username, password):
    url = BASE_URL+"api_resellercredits.asp?apiid={}&username=13213&password=ebKQbQZx5G7oI1Qe&verb=listcustomers".format(apiid, 
                        username, password)

    payload={}
    headers = {}
    response = requests.request("GET", url, headers=headers, data=payload)
    
    return response.text 

def customer_recent_purchase(apiid, customer, 
                    username, password,
                    verb, lastndays):
    url = BASE_URL+"api_resellercredits.asp?apiid={}&username={}&password={}&verb=getrecentpurchases&lastndays={}".format(apiid, customer, 
                        username, password,
                        verb, lastndays)
    payload={}
    headers = {}
    response = requests.request("GET", url, headers=headers, data=payload)
    
    return response.text 

def get_recent_purchase(
                    apiid, username,
                    password, lastndays, 
                    customer):

    url = BASE_URL+"api_resellercredits.asp?apiid={}&username={}&password={}&verb=getrecentpurchases&lastndays={}&customer={}".format(apiid, 
                        username, password,lastndays, customer)
    payload={}
    headers = {}
    response = requests.request("GET", url, headers=headers, data=payload)
    text = response.text
    if response.status_code == 200:
        if "ok: JSON follows" in text:
            response = text.replace("ok: JSON follows","")
            response = json.loads(response)
        else:
            response = []
    else:
        response = []
    
    return response 


def add_remove_account_balance(apiid, customer,  username, password, credit):

    url = BASE_URL+"api_resellercredits.asp?apiid={}&username={}&password={}&verb=addcustomeraccount&customer={}".format(apiid, customer, 
                        username, password,
                        credit)
    payload={}
    headers = {}
    response = requests.request("GET", url, headers=headers, data=payload)
    text = response.text
    if response.status_code == 200:
        if "ok:" in text:
            response = text.replace("ok: ","")
            response = json.loads(response)
        else:
            response = []
    else:
        response = []
    
    return response.text 

def add_remove_account_balance(apiid, 
                    username, password,
                    customer, credit_to_apply):
    credit = 0
    url = BASE_URL+"api_resellercredits.asp?apiid={}&username={}&password={}&verb=addcustomeraccount&customer={}&credits={}".format(apiid, username, 
                        password,customer,
                        credit_to_apply)
    payload={}
    headers = {}
    response = requests.request("GET", url, headers=headers, data=payload)
    text = response.text
    if response.status_code == 200:
        if "ok:" in text:
            response = text.replace("ok: ","")
            credit = int(json.loads(response))
        else:
            credit = 0
    else:
        credit = 0
    
    return credit 

def personal_account_balance(apiid, customer, username, password):
    url = "{}api_resellercredits.asp?apiid={}&username={}&password={}&verb=getcustomeraccount&customer={}".format(
        BASE_URL,apiid,username,password,customer
    )
    payload={}
    headers = {}
    response = requests.request("GET", url, headers=headers, data=payload)
    text = response.text
    is_sucess = False
    credit = 0
    if response.status_code == 200 and "ok:" in text:
        response = text.replace("ok: ","")
        credit = int(json.loads(response))
        is_sucess = True
    return is_sucess,credit 


def is_evc_customer_exist(apiid, customer, username, password):
    url = "{}api_resellercredits.asp?apiid={}&username={}&password={}&verb=checkevccustomer&customer={}".format(
        BASE_URL,apiid,username,password,customer
    )
    payload={}
    headers = {}
    response = requests.request("GET", url, headers=headers, data=payload)
    text = response.text
    is_sucess = False
    if response.status_code == 200 and  "ok:" in text:
        response = text.replace("ok: ","")
        if response == 'evc customer exists':
            is_sucess = True
    return is_sucess


def is_evc_reseller_customer_exist(apiid, customer, username, password):
    url = "{}api_resellercredits.asp?apiid={}&username={}&password={}&verb=checkcustomer&customer={}".format(
        BASE_URL,apiid,username,password,customer
    )
    payload={}
    headers = {}
    response = requests.request("GET", url, headers=headers, data=payload)
    text = response.text
    print(text)
    is_sucess = False
    if response.status_code == 200 and  "ok" in text and text == 'ok':
        is_sucess = True
    
    print("is success:",is_sucess)

    return is_sucess