import os
import time
import datetime
import json
from apps.utils.tasks import task_manual_file_download
import logging
logger = logging.getLogger('django')

from decouple import config

from django.db.models import Q
from django.conf import settings
from apps.account.models import EVCCredentials
from apps.alientech.models import DecodeFiles, EncodeFiles
from apps.utils.ecode_decode import FileOperation
from apps.utils.helper import triger_socket
from apps.account.models import (MyUser, ZOHOUser)
from apps.customer.utils import create_stripe_customer
from apps.utils.zoho_books_utils import create_customer_to_zohobook

def decode_file_status():
    now = datetime.datetime.now()
    logger.info("=============DECODE=======================")
    logger.info("Running Timing:", now.strftime("%Y-%m-%d %H:%M:%S"))
    today = datetime.datetime.now().date()
    for each in DecodeFiles.objects.filter(is_completed = False):
        evc_instance = EVCCredentials.objects.all().last()
        is_sucess,response = FileOperation().async_operation_guid(evc_instance.alientechauttoken,each.guid)
        logger.info(f"Async_response : {response}")
        if is_sucess:
            each.is_completed = response['isCompleted']
            if response['isCompleted']:
                each.status = 3 if response['hasFailed'] else 2
            if response['isSuccessful']:
                each.slot_guid = response['slotGUID']
                triger_socket({
                    'uuid':str(each.user.uuid),
                    'ids':each.ids,
                    'type':'admin_file_decode',
                    'message':"File decoded successfully."
                })
                task_manual_file_download.delay(str(each.ids))
            # is_file_close,resp = FileOperation().close_file_slot(evc_instance.alientechauttoken,each.slot_guid,each.get_tool_type_display()) # new code
            # each.is_file_closed = is_file_close # new code
            each.async_response = json.dumps(response)
            each.save()


def encode_file_status():
    now = datetime.datetime.now()
    logger.info("==============ENCODE======================")
    logger.info("Running Timing:", now.strftime("%Y-%m-%d %H:%M:%S"))
    today = datetime.datetime.now().date()

    for each in EncodeFiles.objects.filter(is_completed = False,file_type = 'Encode'):
        evc_instance = EVCCredentials.objects.all().last()
        print(each.guid)
        is_sucess,response = FileOperation().async_operation_guid(evc_instance.alientechauttoken,each.guid)
        logger.info(response)
        if is_sucess:
            each.is_completed = response['isCompleted']
            if response['isCompleted']:
                each.status = 3 if response['hasFailed'] else 2
            if response['isSuccessful']:
                each.slot_guid = response['slotGUID']
                triger_socket({
                    'uuid':str(each.user.uuid),
                    'type':'admin_file_encode',
                    'ids':each.ids,
                    'message':"File encode successfully."
                })
                task_manual_file_download.delay(str(each.ids))
            is_file_close,resp= FileOperation().close_file_slot(evc_instance.alientechauttoken,each.slot_guid,each.decode.get_tool_type_display())
            each.is_file_closed = is_file_close
            each.async_response = json.dumps(response)
            each.save()


# class refresh_alientech_token():
#     now = datetime.datetime.now()
#     print("==============Refresh Token ======================")
#     print("Running Timing:", now.strftime("%Y-%m-%d %H:%M:%S"))
#     today = datetime.datetime.now().date()
#     evc_instance = EVCCredentials.objects.all().last()
#     is_sucess,response = obj = FileOperation().generate_auth_token()
#     if is_sucess:
#         evc_instance.alientechauttoken = response
#         evc_instance.save()

def task_create_remaining_user_zoho():

    users_list = MyUser.objects.filter(user_type__in = [3,4,6])
    data = [x.email for x in users_list]
    users_list = data
    print(users_list)
    for user in users_list:
        queryset = ZOHOUser.objects.filter(user__email = user)
        if len(queryset) > 0:
            is_zoho_user_exists = True
        else:
            is_zoho_user_exists = False

        print("email:{0} exist as zoho: {1}".format(user, is_zoho_user_exists))

        if not is_zoho_user_exists:
            user = MyUser.objects.get(email = user)
            try:
                create_customer_to_zohobook(user)
                customer_object = MyUser.objects.get(uuid = user.uuid)
                create_stripe_customer(customer_object)
            except Exception as error:
                logger.error(error)
                logger.info("User name: {} {}".format(user.first_name, user.last_name))
                logger.info("User email: {}".format(user.email))

    print("User registration at completed.")