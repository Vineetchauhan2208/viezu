from decouple import config

import base64 
from Crypto.Cipher import AES
from Crypto.Util.Padding import pad,unpad
from Crypto.Random import get_random_bytes #only for AES CBC mode

class Encryption:
    def __init__(self):
        self.__key = config('ENCRYPTION_KEY')
        self.__iv = config('ENCRYPTION_IV_KEY').encode('utf-8')
        super().__init__()

    def encrypt(self,data):
        data= pad(data.encode(),16)
        try:
            cipher = AES.new(self.__key.encode('utf-8'),AES.MODE_CBC,self.__iv)
            return base64.b64encode(cipher.encrypt(data)).decode("utf-8", "ignore")
        except Exception as error:
            return error.args[0]

    def decrypt(self,data):
        data = base64.b64decode(data)
        try:
            cipher = AES.new(self.__key.encode('utf-8'), AES.MODE_CBC, self.__iv)
            return unpad(cipher.decrypt(data),16).decode("utf-8", "ignore")
        except Exception as error:
            return  error.args[0]



# obj = Encryption()
# decrypted = obj.encrypt('Ghost@1234')
# print(decrypted)