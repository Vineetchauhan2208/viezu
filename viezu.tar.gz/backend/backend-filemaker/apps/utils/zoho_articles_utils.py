import requests
import json
from decouple import config
from apps.utils.models import ZOHOKnowledgeBaseArticles
from apps.zoho.models import ZOHOToken
from apps.utils.zoho_utils import (
    generate_zoho_access_with_refresh_token, update_zoho_tokens_in_db
)

from django.db import transaction


def load_zoho_articles(category_id, access_token, user_type, start=1):
    """Fetch and save Zoho articles from API."""
    limit = 10
    url = f"https://desk.zoho.eu/api/v1/articles?categoryId={category_id}&from={start}&limit={limit}"
    headers = {
        'orgId': config('ZOHO_ORGID'),
        'Authorization': 'Zoho-oauthtoken ' + access_token
    }
    response = requests.request("GET", url, headers=headers)
    data = response.json()

    if "errorCode" in data:
        print("in error")
        response = generate_zoho_access_with_refresh_token(token_for=1)
        access_token = response["access_token"]
        obj = ZOHOToken.objects.filter(token_for=1)[0]
        refresh_token = obj.refresh_token
        update_zoho_tokens_in_db(access_token, refresh_token, token_for=1)
        return load_zoho_articles(category_id, access_token, user_type, start)
    else:
        print("in success")
        with transaction.atomic():
            for article in data['data']:
                url = f"https://desk.zoho.eu/api/v1/articles/{article['id']}"
                response = requests.request("GET", url, headers=headers)
                if response.status_code == 200:
                    result = response.json()
                    ZOHOKnowledgeBaseArticles.objects.create(
                        article_id=article['id'],
                        title=article['title'],
                        status=article['status'],
                        category=article['category']['name'],
                        category_id=int(article['category']['id']),
                        root_category_id=int(article['rootCategoryId']),
                        summary=article['summary'],
                        owner_name=article['author']['name'],
                        owner_id=article['author']['id'],
                        perma_link=article['portalUrl'],
                        user_type=user_type,
                        answer=result.get('answer', ''),
                        tags=",".join(result.get('tags', []))
                    )
                    print(f"Article id: {article['id']} data saved successfully")
                else:
                    print(f"Failed to fetch article id: {article['id']}")

            if len(data['data']) == 0:
                return True
            start += limit
            return load_zoho_articles(category_id, access_token, user_type, start)


def get_root_categories():
    url = "https://desk.zoho.eu/api/v1/kbRootCategories"

    payload = {}
    zoho_tokens = ZOHOToken.objects.filter(token_for=1)[0]
    headers = {
        'orgId': config('ZOHO_ORGID'),
        'Authorization': 'Zoho-oauthtoken ' + zoho_tokens.access_token
    }
    response = requests.request("GET", url, headers=headers, data=payload)
    print(response)
    if response.status_code == 200:
        data = json.loads(response.text)["data"]
    else:
        response = generate_zoho_access_with_refresh_token(token_for=1)
        access_token = response["access_token"]
        obj = ZOHOToken.objects.filter(token_for=1)[0]
        refresh_token = obj.refresh_token
        update_zoho_tokens_in_db(access_token, refresh_token, token_for=1)
        return get_root_categories()

    return data


def categorize_data(data):
    business_tree = []
    reseller_tree = []
    individual_tree = []
    dealer_tree = []
    admin_tree = []

    for category in data:
        description = category.get("description", "").lower()
        if "business" in description:
            business_tree.append(category)
            admin_tree.append(category)
            reseller_tree.append(category)
        elif "reseller" in description:
            reseller_tree.append(category)
            admin_tree.append(category)
        elif "individual" in description:
            individual_tree.append(category)
            admin_tree.append(category)
        elif "dealer" in description:
            dealer_tree.append(category)
            admin_tree.append(category)
        else:
            admin_tree.append(category)

    return business_tree, reseller_tree, individual_tree, dealer_tree, admin_tree


def get_category_tree(category_id, access_token):
    url = f"https://desk.zoho.eu/api/v1/kbRootCategories/{category_id}/categoryTree"
    headers = {
        'orgId': config('ZOHO_ORGID'),
        'Authorization': 'Zoho-oauthtoken ' + access_token
    }
    response = requests.request("GET", url, headers=headers)
    if response.status_code == 200:
        return json.loads(response.text)
    else:
        response = generate_zoho_access_with_refresh_token(token_for=1)
        access_token = response["access_token"]
        obj = ZOHOToken.objects.filter(token_for=1)[0]
        refresh_token = obj.refresh_token
        update_zoho_tokens_in_db(access_token, refresh_token, token_for=1)
        return get_category_tree(category_id, access_token)
