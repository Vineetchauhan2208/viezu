import json

from django.db.models import Q

from apps.account.serializer import UserDetailSerializer

from channels.generic.websocket import WebsocketConsumer
from asgiref.sync import async_to_sync
from apps.account.models import MyUser

from apps.admin_management.models import Conversation, TicketHistory
from apps.customer.serializer import ConversationListSerializers
from datetime import datetime
from apps.admin_management.models import TicketAttachment
from apps.utils.helper import triger_socket, create_notification


class NotificationConsumer(WebsocketConsumer):
    def connect(self):
        self.room_name = self.scope['url_route']['kwargs']['uuid']
        self.room_group_name = 'notification_%s' % self.room_name
        async_to_sync(self.channel_layer.group_add)(
            self.room_group_name,
            self.channel_name
        )
        self.accept()

    def disconnect(self, close_code):
        async_to_sync(self.channel_layer.group_discard)(
            self.room_group_name,
            self.channel_name
        )

    def receive(self, text_data):
        async_to_sync(self.channel_layer.group_send)(
            self.room_group_name,
            {
                'type': 'send_notification_cosumer',
                'payload': text_data
            }
        )

    def send_notification_cosumer(self, event):
        data = event.get('payload')
        self.send(text_data=json.dumps({
            'payload': data
        }))


class ConversationConsumer(WebsocketConsumer):
    def connect(self):
        response = {}
        ticket_id = self.scope['url_route']['kwargs']['ids']
        print("connect", ticket_id)
        ticket_history = TicketHistory.objects.get(ids=ticket_id)
        try:
            sender_id = self.scope['url_route']['kwargs']['sender_id']
            print("connect", sender_id)
            sender = MyUser.objects.get(uuid=sender_id)
            if sender.user_type in [1, 2, 5]:
                ticket_history.active_users.add(sender)
                ticket_history.save(update_fields=['active_users'])
        except:
            pass
        self.room_group_name = 'order_%s' % ticket_id
        async_to_sync(self.channel_layer.group_add)(
            self.room_group_name,
            self.channel_name
        )
        self.accept()
        active_users = []
        ticket_history = TicketHistory.objects.get(ids=ticket_id)
        if ticket_history is not None:
            active_users = UserDetailSerializer(ticket_history.active_users.all(), many=True).data
        response['active_users'] = active_users
        response['message_type'] = 'online'
        async_to_sync(self.channel_layer.group_send)(
            self.room_group_name,
            {
                'type': 'send_notification',
                'payload': json.dumps(response)
            }
        )

    def disconnect(self, close_code):
        response = {}
        ticket_id = self.scope['url_route']['kwargs']['ids']
        print("disconnect", ticket_id)
        ticket_history = TicketHistory.objects.get(ids=ticket_id)
        try:
            sender_id = self.scope['url_route']['kwargs']['sender_id']
            print("disconnect", sender_id)
            sender = MyUser.objects.get(uuid=sender_id)
            if sender.user_type in [1, 2, 5]:
                ticket_history.active_users.remove(sender)
                ticket_history.save(update_fields=['active_users'])
        except:
            pass
        self.room_group_name = 'order_%s' % ticket_id
        async_to_sync(self.channel_layer.group_discard)(
            self.room_group_name,
            self.channel_name
        )
        active_users = []
        ticket_history = TicketHistory.objects.get(ids=ticket_id)
        if ticket_history is not None:
            active_users = UserDetailSerializer(ticket_history.active_users.all(), many=True).data
        response['active_users'] = active_users
        response['message_type'] = 'offline'
        async_to_sync(self.channel_layer.group_send)(
            self.room_group_name,
            {
                'type': 'send_notification',
                'payload': json.dumps(response)
            }
        )

    def receive(self, text_data):
        params = json.loads(text_data)
        ticket_id = self.scope['url_route']['kwargs']['ids']
        ticket_history = TicketHistory.objects.get(ids=ticket_id)
        sender = MyUser.objects.get(id=params['sender'])
        recipient = MyUser.objects.get(id=params['recipient'])
        try:
            active_users_list = list(TicketHistory.active_users.values_list('id', flat=True))
            if sender.user_type in [1, 2, 5] and sender.id not in active_users_list:
                ticket_history.active_users.remove(sender)
                ticket_history.save(update_fields=['active_users'])
        except:
            pass
        if 'file' in params['file']:
            attach = TicketAttachment.objects.create(
                        uploaded_by=sender,
                        ticket=ticket_history,
                        file=params['file'] if 'file' in params and params['file'] != '' else None,
                        # attachement_type=attachment_type,
                        attachement_name=params['attachement_name'] if params['attachement_name'] else None,
                    )
        obj = Conversation.objects.create(
            ticket=ticket_history,
            sender=sender,
            recipient=recipient,
            text=params['message'],
            message_type=params['message_type'],
            file=params['file'] if 'file' in params and params['file'] != '' else None
        )
        ticket_history = TicketHistory.objects.get(ids=ticket_id)
        response = ConversationListSerializers(obj).data
        active_users = UserDetailSerializer(ticket_history.active_users.all(), many=True).data
        response['active_users'] = active_users
        self.room_group_name = 'order_%s' % ticket_id
        async_to_sync(self.channel_layer.group_send)(
            self.room_group_name,
            {
                'type': 'send_notification',
                'payload': json.dumps(response)
            }
        )
        conversation_count = Conversation.objects.filter(ticket=ticket_history).count()
        triger_socket({
            'uuid':str(ticket_history.created_by.uuid),
            'type':'ticket_info_update',
            'ticket_id':str(ticket_history.ids),
            'ticket_status':str(ticket_history.ticket_status.get_user_status_display()),
            'ticket_conversation':str(conversation_count),
            'ticket_modified_time':str(ticket_history.updated_at.replace(tzinfo=None).isoformat() + 'Z'),
            'ticket_assigned':str(ticket_history.assigned_to.first_name + ' ' + ticket_history.assigned_to.last_name)
        })
        users = MyUser.objects.filter(
            Q(user_type=2) |
            Q(user_type=5) |
            Q(user_type=1)
        )
        for each in users:
            triger_socket({
                'uuid':str(each.uuid),
                'type':'ticket_info_update',
                'ticket_id':str(ticket_history.ids),
                'ticket_status':str(ticket_history.ticket_status.team_status),
                'ticket_conversation':str(conversation_count),
                'ticket_modified_time':str(ticket_history.updated_at.replace(tzinfo=None).isoformat() + 'Z'),
                'ticket_assigned':str(ticket_history.assigned_to.first_name + ' ' + ticket_history.assigned_to.last_name)
            })

    def send_notification(self, event):
        data = event.get('payload')
        self.send(text_data=json.dumps({
            'payload': data
        }))
