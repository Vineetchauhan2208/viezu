import os
from datetime import datetime

import requests
import json
from apps.account.models import ZOHOInvoices, ZOHOUser
import logging

logger = logging.getLogger('django')
from apps.utils.zoho_utils import (
    generate_zoho_access_with_refresh_token,
    update_zoho_tokens_in_db
)
from apps.zoho.models import ZOHOToken
from django.conf import settings
import boto3
from apps.customer.models import OrderList
from apps.account.models import EVCCredentials, AccessLogsModel, EmailLogSettings
from django.http import request

ZOHO_BOOKS_V3_BASE_URL = "https://www.zohoapis.eu/books/v3/"


def create_customer_to_zohobook(user):
    """ Create or update a customer on Zoho based on email existence.

    Args:
        user: user_object (Django user object)

    Returns:
        JSON: JSON response from the API.
    """
    logger.info("----------In create or update customer on Zoho------------")
    is_zoho_user_created = False
    error = None

    queryset = ZOHOToken.objects.filter(token_for=2).first()
    logger.info(f"queryset == {queryset}")
    if not queryset:
        logger.info(f"Zoho credentials do not exist ----------------------- ")
        error = "Zoho credentials do not exist."
        return is_zoho_user_created, error

    headers = {
        'Authorization': 'Zoho-oauthtoken {}'.format(queryset.access_token),
        'Content-Type': 'application/json',
    }
    logger.info(f"headers == {headers}")
    logger.info(f"queryset Access Token == {queryset.access_token}")
    logger.info(f"queryset organization_id == {queryset.organization_id}")

    # Step 1: Check if the user exists in Zoho based on email
    search_url = ZOHO_BOOKS_V3_BASE_URL + "contacts?organization_id={}&email={}".format(queryset.organization_id,
                                                                                        user.email)
    logger.info(f"search_url : {search_url}")
    search_response = requests.get(search_url, headers=headers)

    logger.info(f"search_response == {search_response}")
    search_result = json.loads(search_response.text)
    logger.info(f"search_result == {search_result}")

    logger.info(f"search_response.status_code == {search_response.status_code}")
    if search_response.status_code == 200:
        logger.info(f"inside 200 status code ----------- ")
        contacts = search_result.get('contacts', [])
        logger.info(f"contacts == {contacts}")
        active_contact = next((contact for contact in contacts if contact.get('status') == 'active'), None)
        
        logger.info(f"active_contact == {active_contact}")
        if active_contact:
            logger.info("--------------Inside active contact[user exists]--------------")
            # If the user exists, update the user
            contact_id = active_contact['contact_id']
            logger.info(f"contact_id == {contact_id}")

            url = ZOHO_BOOKS_V3_BASE_URL + "contacts/{}?organization_id={}".format(contact_id, queryset.organization_id)
            http_method = "PUT"
            logger.info(f"url == {url}\nhttp method == {http_method}")
        else:
            logger.info(f"-------Inside else condition create user on zoho with POST")
            # If the user does not exist, create a new one
            url = ZOHO_BOOKS_V3_BASE_URL + "contacts?organization_id={}".format(queryset.organization_id)
            http_method = "POST"
            logger.info(f"url == {url}\nhttp method == {http_method}")

    elif search_response.status_code == 400:
        logger.info(f"Inside 400 status code ----------- ")
        is_zoho_user_created = False
        error = search_result.get('message', 'Unknown error occurred during email search.')
        logger.info(f"error == {error}")
        return is_zoho_user_created, error
    
    elif search_result.get('code') == 57:
        print("In error code 57 during email search")

        logger.info("Generate zoho acces with refresh token------------")
        response = generate_zoho_access_with_refresh_token(token_for=2)

        logger.info(f"response == {response}")
        access_token = response["access_token"]

        logger.info(f"access_token == {access_token}")
        obj = ZOHOToken.objects.filter(token_for=2)[0]

        logger.info(f"obj == {obj}")
        refresh_token = obj.refresh_token

        logger.info(f"refresh_token == {refresh_token}")

        logger.info("--------update zohotoken in database-------")
        update_zoho_tokens_in_db(access_token, refresh_token, token_for=2)

        logger.info(f"again caal to Create customer to zohobook")
        return create_customer_to_zohobook(user)

    if user.user_type == 3:
        user_type = "business"
    elif user.user_type == 4:
        user_type = "individual"
    elif user.user_type == 6:
        user_type = "business"
    else:
        user_type = None

    vat_treatment = "uk" if user.address_user.country and user.address_user.country == "United Kingdom" else "overseas"

    payload = json.dumps({
        "contact_name": user.first_name + ' ' + user.last_name,
        "language_code": "en",
        "vat_treatment": vat_treatment,
        "contact_type": "customer",
        "customer_sub_type": user_type,
        "currency_id": settings.ZOHO_BOOKS_CURRENCY_ID,
        "billing_address": {
            "attention": user.first_name + ' ' + user.last_name,
            "address": user.address_user.address or ' ',
            "street2": user.address_user.address_2 or ' ',
            "city": user.address_user.city or ' ',
            "state": user.address_user.state or ' ',
            "zip": user.address_user.zip or ' ',
            "country": user.address_user.country or ' ',
            "phone": user.phone_no
        },
        "shipping_address": {
            "attention": user.first_name + ' ' + user.last_name,
            "address": user.address_user.address or ' ',
            "street2": user.address_user.address_2 or ' ',
            "city": user.address_user.city or ' ',
            "state": user.address_user.state or ' ',
            "zip": user.address_user.zip or ' ',
            "country": user.address_user.country or ' ',
            "phone": user.phone_no
        },
        "contact_persons": [
            {
                "first_name": user.first_name,
                "last_name": user.last_name,
                "email": user.email,
                "phone": user.phone_no,
                "mobile": user.mobile_no,
                "is_primary_contact": True
            }
        ]
    })
    logger.info(f"payload ==> {payload}")

    response = requests.request(http_method, url, headers=headers, data=payload)
    
    logger.info(f"API response == {response}")
    text = json.loads(response.text)
    print("Text ----- ",text)

    if response.status_code in [200, 201]:
        logger.info(f"response.status_code[200, 201] == {response.status_code}")
        response_data = json.loads(response.text)
        logger.info(f"response_data == {response_data}")

        contact_id = response_data['contact']['contact_id']
        primary_contact_id = response_data['contact']['primary_contact_id']
        ZOHOUser.objects.update_or_create(
            user=user,
            defaults={
                'contact_id': contact_id,
                'primary_contact_id': primary_contact_id,
            }
        )
        logger.info(f"zoho_user creater or updated.")
        is_zoho_user_created = True
        error = None
    elif text.get('code') == 57:
        is_zoho_user_created = False
        error = "Token is invalid or doesn't have scopes."
        print("In error code 57 during creation or update")
        response = generate_zoho_access_with_refresh_token(token_for=2)
        access_token = response["access_token"]
        obj = ZOHOToken.objects.filter(token_for=2)[0]
        refresh_token = obj.refresh_token
        update_zoho_tokens_in_db(access_token, refresh_token, token_for=2)
        return create_customer_to_zohobook(user)
    else:
        is_zoho_user_created = False
        error = text.get('message', 'Unknown error occurred during creation or update.')

    return is_zoho_user_created, error


def update_customer_to_zohobook(user):
    """ Create or update a customer on Zoho based on email existence.

    Args:
        user: user_object (Django user object)

    Returns:
        JSON: JSON response from the API.
    """
    print("In create or update customer on Zoho")
    is_zoho_user_created = False
    error = None

    queryset = ZOHOToken.objects.filter(token_for=2).first()
    if not queryset:
        error = "Zoho credentials do not exist."
        return is_zoho_user_created, error

    headers = {
        'Authorization': 'Zoho-oauthtoken {}'.format(queryset.access_token),
        'Content-Type': 'application/json',
    }

    # Step 1: Check if the user exists in Zoho based on email
    search_url = ZOHO_BOOKS_V3_BASE_URL + "contacts?organization_id={}&email={}".format(queryset.organization_id,
                                                                                        user.email)
    search_response = requests.get(search_url, headers=headers)
    search_result = json.loads(search_response.text)

    if search_response.status_code == 200:
        contacts = search_result.get('contacts', [])
        active_contact = next((contact for contact in contacts if contact.get('status') == 'active'), None)
        if active_contact:
            # If the user exists, update the user
            contact_id = active_contact['contact_id']
            url = ZOHO_BOOKS_V3_BASE_URL + "contacts/{}?organization_id={}".format(contact_id, queryset.organization_id)
            http_method = "PUT"
        else:
            # If the user does not exist, create a new one
            url = ZOHO_BOOKS_V3_BASE_URL + "contacts?organization_id={}".format(queryset.organization_id)
            http_method = "POST"
    elif search_response.status_code == 400:
        is_zoho_user_created = False
        error = search_result.get('message', 'Unknown error occurred during email search.')
        return is_zoho_user_created, error
    elif search_result.get('code') == 57:
        print("In error code 57 during email search")
        response = generate_zoho_access_with_refresh_token(token_for=2)
        access_token = response["access_token"]
        obj = ZOHOToken.objects.filter(token_for=2)[0]
        refresh_token = obj.refresh_token
        update_zoho_tokens_in_db(access_token, refresh_token, token_for=2)
        return create_customer_to_zohobook(user)

    if user.user_type == 3:
        user_type = "business"
    elif user.user_type == 4:
        user_type = "individual"
    elif user.user_type == 6:
        user_type = "business"
    else:
        user_type = None

    vat_treatment = "uk" if user.address_user.country and user.address_user.country == "United Kingdom" else "overseas"

    payload = json.dumps({
        "contact_name": user.first_name + ' ' + user.last_name,
        "language_code": "en",
        "vat_treatment": vat_treatment,
        "contact_type": "customer",
        "customer_sub_type": user_type,
        "currency_id": settings.ZOHO_BOOKS_CURRENCY_ID,
        "billing_address": {
            "attention": user.first_name + ' ' + user.last_name,
            "address": user.address_user.address or ' ',
            "street2": user.address_user.address_2 or ' ',
            "city": user.address_user.city or ' ',
            "state": user.address_user.state or ' ',
            "zip": user.address_user.zip or ' ',
            "country": user.address_user.country or ' ',
            "phone": user.phone_no
        },
        "shipping_address": {
            "attention": user.first_name + ' ' + user.last_name,
            "address": user.address_user.address or ' ',
            "street2": user.address_user.address_2 or ' ',
            "city": user.address_user.city or ' ',
            "state": user.address_user.state or ' ',
            "zip": user.address_user.zip or ' ',
            "country": user.address_user.country or ' ',
            "phone": user.phone_no
        },
        "contact_persons": [
            {
                "first_name": user.first_name,
                "last_name": user.last_name,
                "email": user.email,
                "phone": user.phone_no,
                "mobile": user.mobile_no,
                "is_primary_contact": True
            }
        ]
    })

    response = requests.request(http_method, url, headers=headers, data=payload)
    text = json.loads(response.text)
    print(text)

    if response.status_code in [200, 201]:
        response_data = json.loads(response.text)
        contact_id = response_data['contact']['contact_id']
        primary_contact_id = response_data['contact']['primary_contact_id']
        ZOHOUser.objects.update_or_create(
            user=user,
            defaults={
                'contact_id': contact_id,
                'primary_contact_id': primary_contact_id,
            }
        )
        is_zoho_user_created = True
        error = None
    elif text.get('code') == 57:
        print("In error code 57 during creation or update")
        response = generate_zoho_access_with_refresh_token(token_for=2)
        access_token = response["access_token"]
        obj = ZOHOToken.objects.filter(token_for=2)[0]
        refresh_token = obj.refresh_token
        update_zoho_tokens_in_db(access_token, refresh_token, token_for=2)
        return create_customer_to_zohobook(user)
    else:
        is_zoho_user_created = False
        error = text.get('message', 'Unknown error occurred during creation or update.')

    return is_zoho_user_created, error

# ---------------- new code -------------
# def create_zoho_invoice(order_list):
#     """ Create a customer on Zoho Books and generate an invoice.

#     Avoids creating a duplicate invoice if one already exists for the same order.
    
#     Args:
#         order_list: The order list object to generate an invoice for.

#     Returns:
#         Tuple: (is_zoho_invoice_created, error, invoice)
#     """
#     print("in zoho invoice create.")   
#     is_zoho_invoice_created = False
#     invoice = None
    
#     # Fetch Zoho credentials
#     queryset = ZOHOToken.objects.filter(token_for=2).first()
#     if not queryset:
#         error = "Zoho credentials do not exist."
#         return is_zoho_invoice_created, error, invoice
    
#     url = ZOHO_BOOKS_V3_BASE_URL + "invoices?organization_id={}".format(queryset.organization_id)

#     now = datetime.now().date()

#     order_by_user = order_list.user
#     zoho_user = ZOHOUser.objects.get(user=order_by_user)
#     checkout_data = order_list.checkout_data
#     apply_vat = order_by_user.address_user.country == "United Kingdom"

#     # Check if invoice already exists for this order and customer
#     existing_invoice = check_existing_invoice(order_list.ids, zoho_user.contact_id, queryset.access_token)
#     if existing_invoice:
#         print("Invoice already exists, skipping creation.")
#         return True, "Invoice already exists", existing_invoice

#     # Prepare items for the invoice
#     items_list = []
#     for item in checkout_data['line_items']:
#         product = {
#             'product_type': "goods",
#             'name': item['name'],
#             'rate': item['price'],
#             'quantity': item['quantity'],
#         }
#         if apply_vat:
#             product['tax_name'] = "Standard Rate"
#             product['tax_id'] = settings.ZOHO_BOOKS_TAX_ID
#             product['tax_type'] = "tax"
#             product['tax_percentage'] = 20  # VAT for UK
#         else:
#             product['tax_name'] = ""
#             product['tax_id'] = None
#             product['tax_type'] = ""
#             product['tax_percentage'] = 0

#         items_list.append(product)

#     # Prepare payload for Zoho Books API
#     payload = json.dumps({
#         "customer_id": int(zoho_user.contact_id),
#         "currency_id": settings.ZOHO_BOOKS_CURRENCY_ID,
#         "reference_number": order_list.ids,
#         "contact_persons": [int(zoho_user.primary_contact_id)],
#         "template_id": settings.ZOHO_BOOKS_TEMPLATE_ID,
#         "date": now.strftime("%Y-%m-%d"),
#         "due_date": now.strftime("%Y-%m-%d"),
#         "salesperson_name": "File Portal",
#         "line_items": items_list,
#         "notes": "Looking forward for your business."
#     })
    
#     # Call Zoho Books API to create the invoice
#     headers = {
#         'Authorization': 'Zoho-oauthtoken {}'.format(queryset.access_token),
#         'Content-Type': 'application/json',
#     }

#     response = requests.post(url, headers=headers, data=payload)
#     print(f"response == {response}")
    
#     # Parse response
#     text = json.loads(response.text)
#     print("text === ", text)

#     # Handle successful response (invoice creation)
#     if response.status_code == 201:
#         print("Invoice created successfully.")
#         response_data = json.loads(response.text)
#         invoice = ZOHOInvoices.objects.create(
#             user=zoho_user,
#             invoice_id=response_data['invoice']['invoice_id'],
#             invoice_number=response_data['invoice']['invoice_number'],
#             customer_id=response_data['invoice']['customer_id'],
#             customer_name=response_data['invoice']['customer_name'],
#             invoice_json=response_data,
#             order_list=order_list
#         )
#         is_zoho_invoice_created = True
#         error = None
#     # Handle token refresh if necessary
#     elif text['code'] == 57:
#         print("Token expired, refreshing access token.")
#         response = generate_zoho_access_with_refresh_token(token_for=2)
#         access_token = response["access_token"]
#         obj = ZOHOToken.objects.filter(token_for=2)[0]
#         refresh_token = obj.refresh_token
#         update_zoho_tokens_in_db(access_token, refresh_token, token_for=2)
#         return create_zoho_invoice(order_list)
#     else:
#         print("Error occurred:", text.get("message", "Unknown error"))
#         is_zoho_invoice_created = False
#         error = text.get("message", "Unknown error")

#     return is_zoho_invoice_created, error, invoice

# def check_existing_invoice(reference_number, customer_id, access_token):
#     """Check if an invoice with the given reference number already exists for the customer.

#     Args:
#         reference_number (str): The reference number for the invoice.
#         customer_id (int): The customer ID in Zoho Books.
#         access_token (str): The Zoho Books access token.

#     Returns:
#         dict: The existing invoice details if found, otherwise None.
#     """
#     url = ZOHO_BOOKS_V3_BASE_URL + f"invoices?customer_id={customer_id}&reference_number={reference_number}"
#     headers = {
#         'Authorization': f'Zoho-oauthtoken {access_token}',
#         'Content-Type': 'application/json',
#     }
#     response = requests.get(url, headers=headers)
    
#     if response.status_code == 200:
#         data = response.json()
#         if data['invoices']:
#             return data['invoices'][0]  # Return the first matching invoice
#     return None

# ---------------end new code -------------

def create_zoho_invoice(order_list):
# def create_zoho_invoice():
    """ Create a customer on the zoho.

    To be created at the time of user creation from the registration form.
    Args:
        customer_zoho_object: customer_zoho_object (django zohoUser object)

    Returns:
        JSON: JSON response from the API.
    """
    print("in zoho invoice create.")  
    logger.info(f"{order_list.ids} - enter in ---- create_zoho_invoice function") 
    # order_list = OrderList.objects.get(stripe_id="cs_test_a1e9erncL0Zs7e2lhurZbSlutOBESE9NJXxAVCOcfrY9kKt9VANPwDFlAs") 
    is_zoho_invoice_created = False
    invoice = None
    queryset = ZOHOToken.objects.filter(token_for=2).first()
    logger.info(f"{order_list.ids} - queryset == {queryset}")

    if not queryset:
        error = "Zoho credentails does not exists."
        logger.info(f"{order_list.ids} - Query set not exists : {error}")
        return is_zoho_invoice_created, error, invoice
    url = ZOHO_BOOKS_V3_BASE_URL + "invoices?organization_id={}".format(queryset.organization_id)

    now = datetime.now().date()

    order_by_user = order_list.user
    logger.info(f"{order_list.ids} - order_by_user == {order_by_user}")
    zoho_user = ZOHOUser.objects.get(user=order_by_user)
    logger.info(f"{order_list.ids} - zoho_user == {zoho_user}")
    checkout_data = order_list.checkout_data
    logger.info(f"\n {order_list.ids} - checkout_data == {checkout_data}\n\n")
    apply_vat = order_by_user.address_user.country == "United Kingdom"
    logger.info(f"{order_list.ids} - apply_vat == {apply_vat}")
    items_list = []
    for item in checkout_data['line_items']:
        product = {
            'product_type': "goods",
            'name': item['name'],
            # 'bcy_rate': item['price'],
            # 'rate': item['total'], # old code
            'rate': item['price'], # new code
            'quantity': item['quantity'],
        }
        if apply_vat:
            product['tax_name'] = "Standard Rate"
            product['tax_id'] = settings.ZOHO_BOOKS_TAX_ID
            product['tax_type'] = "tax"
            product['tax_percentage'] = 20  # Example VAT percentage for UK
        else:
            product['tax_name'] = ""
            product['tax_id'] = None
            product['tax_type'] = ""
            product['tax_percentage'] = 0

        items_list.append(product)
    logger.info(f"{order_list.ids} - items_list == {items_list}")
    payload = json.dumps({
        "customer_id": int(zoho_user.contact_id),
        "currency_id": settings.ZOHO_BOOKS_CURRENCY_ID,
        "reference_number": order_list.ids,
        "contact_persons": [int(zoho_user.primary_contact_id)],
        "template_id": settings.ZOHO_BOOKS_TEMPLATE_ID,
        "date": now.strftime("%Y-%m-%d"),
        "due_date": now.strftime("%Y-%m-%d"),
        "salesperson_name": "File Portal",
        "line_items": items_list,
        "notes": "Looking forward for your business."
    })
    logger.info(f"{order_list.ids} - Payload == {payload}")
    headers = {
        'Authorization': 'Zoho-oauthtoken {}'.format(queryset.access_token),
        'Content-Type': 'application/json',
    }
    logger.info(f"{order_list.ids} - headers == {headers}")
    logger.info(f"order_list_id == {order_list.id}")

    data_invoice = ZOHOInvoices.objects.filter(order_list_id=402).exists()
    logger.info(f"{order_list.ids} - data_invoice == {data_invoice}")
    
    response = requests.request("POST", url, headers=headers, data=payload)

    logger.info(f"{order_list.ids} - Response == {response}")
    logger.info(f"{order_list.ids} - Response status code == {response.status_code}")
    logger.info(f"{order_list.ids} - Response text == {response.text}")

    text = json.loads(response.text)
    logger.info(f"{order_list.ids} - Text == {text} type : {type(text)}")
    if response.status_code == 201:
        print("status code 201.")
        logger.info(f"{order_list.ids} - Enter in Zoho invoice create condition status code 201-----------")
        if not ZOHOInvoices.objects.filter(order_list_id=order_list.id).exists():
            response = json.loads(response.text)
            invoice = ZOHOInvoices.objects.create(
                user=zoho_user,
                invoice_id=response['invoice']['invoice_id'],
                invoice_number=response['invoice']['invoice_number'],
                customer_id=response['invoice']['customer_id'],
                customer_name=response['invoice']['customer_name'],
                invoice_json=response,
                order_list=order_list
            )
            is_zoho_invoice_created = True
            logger.info(f"{order_list.ids} - invoice == {invoice}")
            error = None
    elif text['code'] == 57:
        logger.info(f"{order_list.ids} - status code 57.")
        response = generate_zoho_access_with_refresh_token(token_for=2)
        access_token = response["access_token"]
        obj = ZOHOToken.objects.filter(token_for=2)[0]
        refresh_token = obj.refresh_token
        update_zoho_tokens_in_db(access_token, refresh_token, token_for=2)
        return create_zoho_invoice(order_list)
    else:
        logger.info(f"{order_list.ids} - inside else: ----------- text message")
        is_zoho_invoice_created = False
        # error = text.message
        error = text['message']
    logger.info(f"{order_list.ids} - Return Data : is_zoho_invoice_created : {is_zoho_invoice_created} \nerror : {error} \ninvoice : {invoice}")
    return is_zoho_invoice_created, error, invoice


def zoho_approve_invoice(invoice_id):
    print("in approve invoice.")
    is_zoho_invoice_approved = False
    error = None
    invoice = None
    queryset = ZOHOToken.objects.filter(token_for=2).first()
    if not queryset:
        error = "Zoho credentails does not exists."
        return is_zoho_invoice_approved, error, invoice
    url = ZOHO_BOOKS_V3_BASE_URL + "invoices/" + invoice_id + "/approve?organization_id={}".format(
        queryset.organization_id)

    headers = {
        'Authorization': 'Zoho-oauthtoken {}'.format(queryset.access_token),
        'Content-Type': 'application/json',
    }
    logger.info(f"Zoho approval URL == {url}\nheaders == {headers}")

    response = requests.request("POST", url, headers=headers, data={})

    text = json.loads(response.text)
    logger.info(f"text = {text}")
    logger.info("Zoho approval Response text == ",response.text)
    logger.info(f"response.status_code == {response.status_code}")

    if response.status_code == 201:
        is_zoho_invoice_approved = True
        error = None
        invoice = ZOHOInvoices.objects.get(invoice_id=invoice_id)
    elif text['code'] == 57:
        logger.info("inside code 57 ----- ")
        is_zoho_invoice_approved = False
        error = "Token is invalid or doesn't have scopes."

        logger.info("Approv zoho | Generate zoho access with refresh token function -------- ")
        response = generate_zoho_access_with_refresh_token(token_for=2)
        logger.info(f"new approval generate zoho token response == {response}")
        access_token = response["access_token"]
        obj = ZOHOToken.objects.filter(token_for=2)[0]
        refresh_token = obj.refresh_token
        update_zoho_tokens_in_db(access_token, refresh_token, token_for=2)
        logger.info("again call zoho approve invoice function -------- ")
        zoho_approve_invoice(invoice_id)
    else:
        is_zoho_invoice_approved = False
        error = text.get('message', 'Unknown error occurred during creation or update.')
        print(f"Error ====== {error}")
    print("end approve invoice.")

    return is_zoho_invoice_approved, error, invoice


def record_zoho_invoice_payment(zoho_invoice_object):
    print("in record payment---------------")

    is_payment_recorded = False
    error = None
    invoice = None
    queryset = ZOHOToken.objects.filter(token_for=2).first()
    url = ZOHO_BOOKS_V3_BASE_URL + "customerpayments?organization_id={}".format(queryset.organization_id)
    logger.info(f"url == {url}")
    if not queryset:
        error = "Zoho credentails does not exists."
        return is_payment_recorded, error, invoice

    now = datetime.now().date()
    payload = json.dumps({
        "customer_id": int(zoho_invoice_object.customer_id),
        "payment_mode": "Stripe",
        "reference_number": zoho_invoice_object.order_list.ids,
        "amount": zoho_invoice_object.invoice_json['invoice']['total'],
        "date": now.strftime("%Y-%m-%d"),
        "invoices": [
            {
                "invoice_id": zoho_invoice_object.invoice_id,
                "amount_applied": zoho_invoice_object.invoice_json['invoice']['total']
            }
        ],
        "invoice_id": zoho_invoice_object.invoice_id,
        "amount_applied": zoho_invoice_object.invoice_json['invoice']['total'],
        "contact_persons": [str(zoho_invoice_object.customer_id)],
        "account_id": settings.ZOHO_BOOKS_ACCOUNT_ID
    })
    logger.info(f"payload == {payload}")
    headers = {
        'Authorization': 'Zoho-oauthtoken {}'.format(queryset.access_token),
        'Content-Type': 'application/json',
    }
    logger.info(f"headers == {headers}")

    response = requests.request("POST", url, headers=headers, data=payload)

    logger.info(f"response == {response}")
    logger.info(f"response.status_code == {response.status_code}")

    text = json.loads(response.text)
    logger.info("Record Zoho invoice payment response text = ",text)

    if response.status_code == 201:
        response = json.loads(response.text)
        is_payment_recorded = True
        error = None
        invoice = zoho_invoice_object
    elif text['code'] == 57:
        is_payment_recorded = False
        error = "Token is invalid or doesn't have scopes."
        response = generate_zoho_access_with_refresh_token(token_for=2)
        access_token = response["access_token"]
        obj = ZOHOToken.objects.filter(token_for=2)[0]
        refresh_token = obj.refresh_token
        update_zoho_tokens_in_db(access_token, refresh_token, token_for=2)
        record_zoho_invoice_payment(zoho_invoice_object)
    else:
        logger.info("inside else ---------- ")
        is_payment_recorded = False
        # error = text.message
        error = text.get('message','Error occur while record zoho invoice payment')
        logger.info(f"error = {error}")

    print("end record payment")
    logger.info("is_payment_recorded == ",is_payment_recorded)
    logger.info("ERROR == ",error)
    print("====================")
    return is_payment_recorded, error, invoice


def zoho_email_invoice(zoho_invoice_object):
    print("in email invoice")

    is_invoice_emailed = False
    error = None
    queryset = ZOHOToken.objects.filter(token_for=2).first()
    if not queryset:
        error = "Zoho credentails does not exists."
        return is_invoice_emailed, error

    invoice_id = zoho_invoice_object.invoice_id
    url = ZOHO_BOOKS_V3_BASE_URL + "invoices/" + invoice_id + "/email?organization_id={}".format(
        queryset.organization_id)

    headers = {
        'Authorization': 'Zoho-oauthtoken {}'.format(queryset.access_token),
        'Content-Type': 'application/json',
    }

    response = requests.request("POST", url, headers=headers, data="")
    text = response.text
    if response.status_code == 200:
        response = json.loads(response.text)
        is_invoice_emailed = True
        error = None
    elif text['code'] == 57:
        is_invoice_emailed = False
        error = "Token is invalid or doesn't have scopes."
        response = generate_zoho_access_with_refresh_token(token_for=2)
        access_token = response["access_token"]
        obj = ZOHOToken.objects.filter(token_for=2)[0]
        refresh_token = obj.refresh_token
        update_zoho_tokens_in_db(access_token, refresh_token, token_for=2)
        zoho_email_invoice(zoho_invoice_object)
    else:
        is_invoice_emailed = False
        error = text.message
    print("end email invoice")

    return is_invoice_emailed, error


def download_zoho_invoice_pdf(zoho_invoice_object):
    print("in recursive")
    # is_invoice_emailed = False
    is_pdf_response = False
    error = None
    queryset = ZOHOToken.objects.filter(token_for=2).first()
    if not queryset:
        error = "Zoho credentails does not exists."
        return is_pdf_response, error

    invoice_id = zoho_invoice_object.invoice_id
    print(invoice_id)

    url = ZOHO_BOOKS_V3_BASE_URL + "invoices/" + invoice_id + "?organization_id=" + queryset.organization_id + "&accept=pdf"

    payload = {}
    headers = {
        'X-com-zoho-invoice-organizationid': queryset.organization_id,
        'Authorization': 'Zoho-oauthtoken {}'.format(queryset.access_token),
    }

    response = requests.request("GET", url, headers=headers, data=payload)
    if response.status_code != 200:
        text = json.loads(response.text)
    if response.status_code == 200:
        is_pdf_response = True
        error = None
        is_success, url = create_invoice_in_media(
            zoho_invoice_object.invoice_number,
            response.content)
        if is_success:
            zoho_invoice_object.is_invoice_avail = True
            zoho_invoice_object.invoice_s3_url = url
            zoho_invoice_object.save()

        response = response.text
    elif response.status_code == 400:
        is_pdf_response = False
        error = response.message
    elif text['code'] == 57:
        is_invoice_emailed = False
        error = "Token is invalid or doesn't have scopes."
        response = generate_zoho_access_with_refresh_token(token_for=2)
        access_token = response["access_token"]
        obj = ZOHOToken.objects.filter(token_for=2)[0]
        refresh_token = obj.refresh_token
        update_zoho_tokens_in_db(access_token, refresh_token, token_for=2)
        download_zoho_invoice_pdf(zoho_invoice_object)

    return is_pdf_response, error, response


def create_invoice_in_media(invoice_number: str, base64_response: str):
    # Ensure the media directory exists
    media_dir = 'media'
    if not os.path.exists(media_dir):
        os.makedirs(media_dir)
    file_name = 'media/' + invoice_number + '.pdf'
    with open(file_name, "wb") as pdf:
        pdf.write(base64_response)
    pdf.close()
    is_success, url = upload_file_to_s3(file_name, "{}".format('invoices/' + invoice_number + '.pdf'))
    return is_success, url


def upload_file_to_s3(local_path, bucket_path):
    myfile = local_path

    client = boto3.client(
        's3',
        region_name='us-east-1',
        aws_access_key_id=settings.AWS_ACCESS_KEY_ID,
        aws_secret_access_key=settings.AWS_SECRET_ACCESS_KEY
    )
    try:
        response = client.upload_file(
            myfile,
            settings.AWS_STORAGE_BUCKET_NAME,
            bucket_path,
            ExtraArgs={'ACL': 'public-read'}
        )
        url = "https://{}.s3.us-east-1.amazonaws.com/{}".format(
            settings.AWS_STORAGE_BUCKET_NAME, bucket_path)
        import os
        os.remove(local_path)
        return True, url
    except Exception as e:
        print("S3", e)
        return False, None
