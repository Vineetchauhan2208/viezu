from typing import List
from functools import wraps
from rest_framework.exceptions import ValidationError


def raise_(exc):
    raise exc

def required_fields(field_list: List[str]):
    def required_fields_deco(function):
        @wraps(function)
        def required_fields_wrapper(*args, **kwargs):
            request = args[1]
            succ = list(map(lambda field:
                1 if field in request.data and (request.data[field] or isinstance(request.data[field], bool)) else raise_(
                    ValidationError({'detail': '%s is required field.' % (field)}))
                if field not in request.data else raise_(ValidationError({'detail': '%s cannot be blank.' % (field)})), field_list))
            if len(succ) == len(field_list):
                return function(*args, **kwargs)
        return required_fields_wrapper
    return required_fields_deco