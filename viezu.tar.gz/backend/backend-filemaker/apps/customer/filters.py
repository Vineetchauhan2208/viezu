import django_filters
from apps.admin_management.models import TicketHistory


class TicketFilter(django_filters.FilterSet):
    status = django_filters.CharFilter(field_name='status', method='filter_status')
    def filter_status(self, queryset, name, value):
        list_of_ids = value.split(',')
        if '0' in list_of_ids:
            null_queryset =  queryset.filter(ticket_status__isnull=True)
            queryset =  queryset.filter(ticket_status__id__in=list_of_ids)
            return queryset | null_queryset
        return  queryset.filter(ticket_status__id__in=list_of_ids)
    

    class Meta:
        model = TicketHistory
        fields = ('status', )