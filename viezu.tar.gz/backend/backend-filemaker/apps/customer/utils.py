import stripe
from decouple import config
stripe.api_key = config('STRIPE_SECRET_KEY')
import logging
logger = logging.getLogger(__name__)

def create_stripe_customer(customer_object):

    is_customer_created = False

    address = {}
    address['city'] = customer_object.address_user.city if customer_object.address_user.city is not None else ' ',
    address['country'] = customer_object.address_user.country if customer_object.address_user.country is not None else ' ',
    address['line1'] = customer_object.address_user.address if customer_object.address_user.address is not None else ' ',
    address['line2'] = customer_object.address_user.address_2 if customer_object.address_user.address_2 is not None else ' ',
    address['state'] = customer_object.address_user.state if customer_object.address_user.state is not None else ' ',
    address['postal_code'] = customer_object.address_user.zip if customer_object.address_user.zip is not None else ' ',


    resp = stripe.Customer.create(
        email = customer_object.email,
        address = address,
        name = customer_object.first_name + ' '+customer_object.last_name,
    )
    logger.info(resp)
    if "id" in resp:
        customer_object.stripe_customer_id = resp['id']
        customer_object.save()
        logger.info("customer created.")
        is_customer_created = True
    else:
        is_customer_created = False

    return is_customer_created