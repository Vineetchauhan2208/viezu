from django.contrib import admin

from .models import (
    Cart, CustomerSpentHistory, 
    OrderList,OrderItem, 
    CustomerCredit,
    ManualCreditHistory, ResellerDistributeCredit
)

admin.site.register(OrderItem)
class OrderItemInline(admin.TabularInline):
    model = OrderItem
    max_num=1

@admin.register(OrderList)
class OrderListAdmin(admin.ModelAdmin):
    list_display = ("ids",'status','stripe_id','file_credit',
                    'function_credit','evc_credit',
                    'created_at')
    
    inlines = [OrderItemInline,]

@admin.register(CustomerCredit)
class CustomerCreditAdmin(admin.ModelAdmin):
    list_display = ("user",'file_key_credit','function_credit','evc_credit',)


@admin.register(Cart)
class CartAdmin(admin.ModelAdmin):
    list_display = ("user",'product','quantity','price','tunning_credit','type')


@admin.register(CustomerSpentHistory)
class CustomerSpentHistoryAdmin(admin.ModelAdmin):
    list_display = ("user",'credit','credit_type','file_request_id',)

@admin.register(ManualCreditHistory)
class ManualCreditHistoryAdmin(admin.ModelAdmin):
    list_display = ("user",'file_key_credit',
                'function_credit','evc_credit',
                'manual_update_to_user',)

@admin.register(ResellerDistributeCredit)
class ResellerDistributeCreditAdmin(admin.ModelAdmin):
    list_display = ("user",'file_key_credit',
                'function_credit','evc_credit',)
