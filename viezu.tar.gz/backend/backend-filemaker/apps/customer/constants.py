ORDER_STATUS = (
    (1, 'Pending'),
    (2, 'Complete'),
    (3, 'Failed'),
)

DEALER_CREDIT_TYPE = (
    (1, 'FILE_CREDIT'),
    (2, 'FUNCTION_CREDIT'),
    (3, 'EVC_CREDIT'),
)
