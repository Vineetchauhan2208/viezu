from django.db import models

# Create your models here.
class ZOHOToken(models.Model):
    """ Model schema for zoho credentials."""

    TOKEN_CHOICES = [
        (1, "KNOWLEDGEBASE"),
        (2, "INVOICE"),
    ]

    code = models.TextField(max_length=1000, null=True, blank=True)
    client_id = models.TextField(max_length=1000, null=True, blank=True)
    client_secret = models.TextField(max_length=1000, null=True, blank=True)
    access_token = models.TextField(max_length=1000, null=True, blank=True)
    refresh_token = models.TextField(max_length=1000, null=True, blank=True)
    is_valid_tokens = models.BooleanField(default=False)
    token_for =  models.PositiveSmallIntegerField(choices=TOKEN_CHOICES, default=1)
    organization_id = models.CharField(max_length=255, null=True, blank=True)

    class Meta:
        verbose_name = 'ZOHOToken'
        verbose_name_plural = 'ZOHOToken'

class ZOHOCategoryTree(models.Model):
    """ Model schema for zoho category tree."""

    tree = models.JSONField(default=dict)
    reseller_tree = models.JSONField(default=dict)
    individual_tree = models.JSONField(default=dict)
    admin_tree = models.JSONField(default=dict)
    dealer_tree = models.JSONField(default=dict)

    class Meta:
        verbose_name = 'ZOHOCategoryTree'
        verbose_name_plural = 'ZOHOCategoryTree'
