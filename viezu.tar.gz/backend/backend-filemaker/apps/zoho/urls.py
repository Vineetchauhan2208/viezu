from django.urls import path
from apps.zoho import views

app_name = 'zoho'


zoho_patterns = [
    path('update/articles', views.UpdateArticlesView.as_view()),
    # path('all/articles',views.AllArticles.as_view()),
    path('add/credentials', views.ZOHOAddCredentialsView.as_view()),
    path('get/root/categories', views.GetZOHOCategoriesView.as_view()),
    path('update/categories', views.UpdateZOHOCategoriesView.as_view()),
]

article_urlpatterns = [
    path('list/articles', views.KnowledgeBaseArticlesListView.as_view()),
    path('list/articles/<str:category_id>/', views.KnowledgeBaseArticlesByCategoryListView.as_view()),

    path('article/detail/<str:slug>', views.KnowledgeBaseArticlesDetailView.as_view()),
]

urlpatterns = (zoho_patterns + article_urlpatterns)
