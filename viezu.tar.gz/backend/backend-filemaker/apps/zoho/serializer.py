from rest_framework import serializers
from apps.utils.models import ZOHOKnowledgeBaseArticles

class ZOHOTokenSerializer(serializers.Serializer):

    code = serializers.CharField(max_length=1000, required=True)
    client_id = serializers.CharField(max_length=1000, required=True)
    client_secret = serializers.CharField(max_length=1000, required=True)
    token_for = serializers.CharField(max_length=1000, required=True)
    organization_id = serializers.CharField(max_length=1000, required=True)


class KnowledgeBaseListSerializer(serializers.ModelSerializer):

    class Meta:
        model = ZOHOKnowledgeBaseArticles
        fields = ('article_id','title','summary',
                    'category','category_id','perma_link','slug','updated_at')

class KnowledgeBaseDetailSerializer(serializers.ModelSerializer):

    class Meta:
        model = ZOHOKnowledgeBaseArticles
        fields = '__all__'


