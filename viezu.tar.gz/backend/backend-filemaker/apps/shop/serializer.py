from rest_framework import serializers
from apps.customer.models import OrderList

class CategorySerializer(serializers.Serializer):
    category_name = serializers.CharField(max_length=255, required=True)
    img_src = serializers.URLField(required=True)

class TagSerializer(serializers.Serializer):
    id = serializers.CharField(max_length=100, required=False)
    tag_name = serializers.CharField(max_length=255, required=True)
    description = serializers.CharField(max_length=2000, required=False)

class OrderBillingSerializer(serializers.Serializer):

    first_name = serializers.CharField(max_length=100)
    last_name = serializers.CharField(max_length=100)
    address_1 = serializers.CharField(max_length=1000)
    address_2 = serializers.CharField(max_length=1000, required=False)
    city = serializers.CharField(max_length=100)
    state = serializers.CharField(max_length=100)
    postcode = serializers.CharField(max_length=100)
    country = serializers.CharField(max_length=100)
    email = serializers.CharField(max_length=100)
    phone = serializers.CharField(max_length=100)

class OrderShippingSerializer(serializers.Serializer):

    first_name = serializers.CharField(max_length=100)
    last_name = serializers.CharField(max_length=100)
    address_1 = serializers.CharField(max_length=1000)
    address_2 = serializers.CharField(max_length=1000, required=False)
    city = serializers.CharField(max_length=100)
    state = serializers.CharField(max_length=100)
    postcode = serializers.CharField(max_length=100)
    country = serializers.CharField(max_length=100)

class OrderSerializer(serializers.Serializer):

    billing = OrderBillingSerializer()
    shipping = OrderShippingSerializer()

class OrderListSerializer(serializers.ModelSerializer):
    class Meta:
        model = OrderList
        fields = '__all__'