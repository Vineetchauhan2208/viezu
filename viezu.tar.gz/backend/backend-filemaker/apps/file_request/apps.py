from django.apps import AppConfig


class fileRequestConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'apps.file_request'
