from django.contrib import admin
from .models import (
    FileRequest, FileRequestFormData, RefrenceMadeFile,
    VehicleType, VehicleBrand, VehicleModel,
    VehicleControl, FileRequestHistory,
    FileFormScheduleTaskLog, DataEcuBrand,
    DataEcuVersion, FileRequestTime,
    FileRequestAveragePerformance, VehicleManagement
)
from .models import RequestDownloadFiles
from .utils import VehicleManagementAdminForm

# Register your models here.
# admin.site.register(FileRequest)
admin.site.register(FileRequestFormData)
admin.site.register(VehicleType)


@admin.register(VehicleBrand)
class VehicleBrandAdmin(admin.ModelAdmin):
    list_display = ("vehicle_type", "brand_name")
    search_fields = ['brand_name', ]


@admin.register(VehicleModel)
class VehicleModelAdmin(admin.ModelAdmin):
    list_display = ("vehicle_brand", "model_name", "file_key_credit",)
    search_fields = ['model_name', ]


@admin.register(VehicleControl)
class VehicleControlAdmin(admin.ModelAdmin):
    list_display = ("vehicle_model", "ecu_brand",
                    "ecu_version", "fuel_type",)
    search_fields = ['ecu_version', ]


@admin.register(FileRequest)
class FileRequestAdmin(admin.ModelAdmin):
    list_display = (
        "request_id", "file_type", "vehicle_type", "created_at", "tuning_tool_used", "vehicle_make", "model",
        "ecu_brand", "ecu_version", "status", "tuning_required",
        "additional_function",)
    exclude = ('file_hexa_content', 'file_hexa_content_list',)


@admin.register(RequestDownloadFiles)
class FileRequestAdmin(admin.ModelAdmin):
    list_display = ("fil_request_id", "title", "url",)


@admin.register(FileRequestHistory)
class FileRequestHistoryAdmin(admin.ModelAdmin):
    list_display = ("file_request_id", "title", "description", "is_success", "url")


@admin.register(FileFormScheduleTaskLog)
class FileFormScheduleTaskLogAdmin(admin.ModelAdmin):
    list_display = ("file_request_id", "is_running",
                    "is_master", "has_error",
                    "error",)


@admin.register(DataEcuBrand)
class DataEcuBrandAdmin(admin.ModelAdmin):
    list_display = ("id", "brand_name",)
    search_fields = ['ecu_version_name', ]


@admin.register(DataEcuVersion)
class DataEcuVersionAdmin(admin.ModelAdmin):
    list_display = ("brand", "ecu_version_name",
                    "percentage",)
    search_fields = ['ecu_version_name', ]


@admin.register(FileRequestTime)
class FileRequestTimeAdmin(admin.ModelAdmin):
    list_display = ("file_request", "created_at",
                    "start_time", "end_time", "second_diff",)


@admin.register(FileRequestAveragePerformance)
class FileRequestAveragePerformanceAdmin(admin.ModelAdmin):
    list_display = ("file_request_obj", "file_type",
                    "original_found", "original_found_time",
                    "original_not_found", "original_not_found_time",
                    "refrence_found", "refrence_found_time",
                    "refrence_not_found", "refrence_not_found_time",
                    )


@admin.register(RefrenceMadeFile)
class RefrenceMadeFileAdmin(admin.ModelAdmin):
    list_display = ("file_name", "file_directory",
                    "created_at", "file_request",)


@admin.register(VehicleManagement)
class VehicleManagementAdmin(admin.ModelAdmin):
    form = VehicleManagementAdminForm
    list_display = (
        'id', 'vehicle_type', 'brand_name', 'model_name', 'file_key_credit', 'ecu_brand', 'ecu_version', 'fuel_type',
        'ecu_type', 'percentage', 'adblue', 'dpf', 'egr', 'intake_flaps', 'hot_start_fix', 'popcorn_limiter', 'dtc',
        'other', 'o2_decat', 'gpf_opf_ppf', 'pops_and_bangs')
    search_fields = ('vehicle_type', 'brand_name', 'model_name', 'ecu_brand', 'ecu_version', 'fuel_type')
    list_filter = (
        'vehicle_type', 'brand_name', 'model_name', 'file_key_credit', 'ecu_brand', 'ecu_version', 'fuel_type',
        'ecu_type',
        'percentage')
    list_per_page = 20