from rest_framework import permissions


class CustomerCreateOnly(permissions.BasePermission):

    message = "Only customer can create file request."

    def has_permission(self, request, view):
        if request.user.is_authenticated:
            return True

    def has_object_permission(self, request, view, obj):
        print(request.user.user_type)
        if (request.user.user_type == 3 or
            request.user.user_type == 4):
            return True

        return False