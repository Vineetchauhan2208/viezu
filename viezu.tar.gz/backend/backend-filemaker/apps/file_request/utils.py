import binascii

from google.cloud import bigquery

from apps.file_request.models import FileRequest
from gridfs import GridFS
from pymongo import MongoClient
from django.conf import settings
import os
import logging

logger = logging.getLogger('django')


def read_user_file_request(file_request_id):
    """_summary_

    Args:
        file_request_id (file_request_id): File request to be read

    Returns:
        data (dict): data dictionary with ecu_brand and version.
    """
    # print("Step 1: Read user's file submitted in the file request form.")

    logger.info("Step 1: Read user's file submitted in the file request form.")
    data = {}
    file_request_obj = FileRequest.objects.get(request_id=file_request_id)
    data['ecu_brand'] = file_request_obj.ecu_brand
    data['ecu_version'] = file_request_obj.ecu_version
    return data


def upload_file_to_mongo(local_file_name, dir_name_to_create):
    logger.info("Upload file at s3.")
    is_file_uploaded_mongo = False
    client = MongoClient(settings.MONGO_HOST, 27017)
    db = client['filemaker_directory']
    fs = GridFS(db)
    coll = db['directory']

    with open(local_file_name, 'rb') as f:
        file = f.read()

    directory = {}
    directory["directory_name"] = dir_name_to_create.split("/")[-1]
    directory["file_name"] = local_file_name.split("/")[-1]
    try:
        coll.insert_one(directory)
        fs.put(
            file,
            filename=local_file_name.split("/")[-1],
            metadata={"directory_name": dir_name_to_create}
        )
        is_file_uploaded_mongo = True
        logger.info("uploaded to mongo")
    except Exception as error:
        logger.error(error)
        is_file_uploaded_mongo = False
    logger.info(directory)

    return is_file_uploaded_mongo


def upload_file_to_gcp(local_file_name, directory_name, file_name):
    logger.info("Upload file at GCP.")
    os.environ['GOOGLE_CLOUD_PROJECT'] = 'bigquery-project-437912'
    os.environ['GOOGLE_APPLICATION_CREDENTIALS'] = 'file-matching-43da45e9f9b8.json'

    with open(local_file_name, 'rb') as f:
        file_data = f.read()
    hex_blocks = convert_binary_to_hex_blocks(file_data)
    row = [{
        'directory_name': directory_name,
        'file_name': file_name,
        'hex_block': hex_blocks
    }]

    # Insert into BigQuery
    insert_into_bigquery('filemaker_directory', 'file_data', row)
    logger.info("File uploaded to GCP and inserted into BigQuery successfully.")


def insert_into_bigquery(dataset_id, table_id, rows_to_insert):
    client = bigquery.Client()
    table_ref = client.dataset(dataset_id).table(table_id)

    errors = client.insert_rows_json(table_ref, rows_to_insert)

    if errors:
        logger.error(f"Error inserting batch into BigQuery: {errors}")
    else:
        logger.info(f"Inserted BigQuery successfully")


def convert_binary_to_hex_blocks(binary_data):
    hex_data = binascii.hexlify(binary_data).decode()
    return convert_to_n_size_block(hex_data, 20)


def convert_to_n_size_block(hexadata, size):
    hexadata_list = [hexadata[i:i + size] for i in range(0, len(hexadata), size)]
    return hexadata_list


from django import forms
from .models import VehicleManagement


class VehicleManagementAdminForm(forms.ModelForm):
    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)

        self.fields['vehicle_type'] = forms.ChoiceField(
            choices=[(v, v) for v in VehicleManagement.objects.values_list('vehicle_type', flat=True).distinct()],
            required=True
        )
        self.fields['brand_name'] = forms.ChoiceField(
            choices=[(v, v) for v in VehicleManagement.objects.values_list('brand_name', flat=True).distinct()],
            required=True
        )
        self.fields['model_name'] = forms.ChoiceField(
            choices=[(v, v) for v in VehicleManagement.objects.values_list('model_name', flat=True).distinct()],
            required=True
        )
        self.fields['file_key_credit'] = forms.ChoiceField(
            choices=[(v, v) for v in VehicleManagement.objects.values_list('file_key_credit', flat=True).distinct()],
            required=True
        )
        self.fields['ecu_brand'] = forms.ChoiceField(
            choices=[(v, v) for v in VehicleManagement.objects.values_list('ecu_brand', flat=True).distinct()],
            required=True
        )
        self.fields['ecu_version'] = forms.ChoiceField(
            choices=[(v, v) for v in VehicleManagement.objects.values_list('ecu_version', flat=True).distinct()],
            required=True
        )
        self.fields['fuel_type'] = forms.ChoiceField(
            choices=[(v, v) for v in VehicleManagement.objects.values_list('fuel_type', flat=True).distinct()],
            required=True
        )
        self.fields['ecu_type'] = forms.ChoiceField(
            choices=[(v, v) for v in VehicleManagement.objects.values_list('ecu_type', flat=True).distinct()],
            required=True
        )
        self.fields['percentage'] = forms.ChoiceField(
            choices=[(v, v) for v in VehicleManagement.objects.values_list('percentage', flat=True).distinct()],
            required=True
        )
    class Meta:
        model = VehicleManagement
        fields = '__all__'