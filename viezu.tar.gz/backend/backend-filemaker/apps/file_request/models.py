from django.db import models
from apps.utils.models import BaseModel
from apps.account.models import MyUser
from apps.utils.helper import file_request_path

def tuning_file(instance, filename):
    """ Create a directory on aws bucket path.

    Args:
        instance (object): file request object.
        filename (str): name of the file

    Returns:
        file_path: str
    """
    from datetime import datetime
    now = datetime.now()
    date = now.strftime("%d-%m-%Y")
    return file_request_path('tuning/{0}/{1}/{2}'.format(instance.user.uuid,
        date, instance.request_id), instance, filename)


class VehicleType(models.Model):
    """ Database schema for vehicle type: car,bike,truck."""

    name = models.CharField(max_length=100, null=False, blank=False)

    class Meta:
        verbose_name = 'VehicleType'
        verbose_name_plural = 'VehicleType'

    def __str__(self) -> str:
        return str(self.id)

class VehicleBrand(models.Model):
    """ Database schema for vehicle brands: Aprila, bmw."""

    vehicle_type = models.ForeignKey(VehicleType, on_delete=models.CASCADE, 
                                    related_name = "vehicle_type")
    brand_name = models.CharField(max_length=255, null=True, blank=True)

    class Meta:
        verbose_name = 'VehicleBrand'
        verbose_name_plural = 'VehicleBrand'

    def __str__(self) -> str:
        return str(self.id)


class VehicleModel(models.Model):
    """ Database schema for vehicle models: RSV"""

    vehicle_brand = models.ForeignKey(VehicleBrand, on_delete=models.CASCADE, 
                                    related_name = "vehicle_brand", default=None)
    model_name = models.CharField(max_length=255, null=True, blank=True)
    file_key_credit = models.IntegerField(default=1, null=True, blank=True)

    class Meta:
        verbose_name = 'VehicleModel'
        verbose_name_plural = 'VehicleModel'

    def __str__(self) -> str:
        return str(self.id)

class VehicleControl(models.Model):
    """ Database schema for vehicle engine conf"""

    vehicle_model = models.ForeignKey(VehicleModel, on_delete=models.CASCADE, related_name="vehicle_model")
    ecu_brand = models.CharField(max_length=255, null=True, blank=True)
    ecu_version = models.CharField(max_length=255, null=True, blank=True)
    fuel_type = models.CharField(max_length=255, null=True, blank=True)
    ecu_type = models.CharField(max_length=255, null=True, blank=True)

    class Meta:
        verbose_name = 'VehicleControl'
        verbose_name_plural = 'VehicleControl'

    def __str__(self) -> str:
        return str(self.id)


class VehicleManagement(models.Model):
    """Database schema for managing vehicle-related data in one table."""

    # Fields from VehicleType
    vehicle_type = models.CharField(max_length=100, null=False, blank=False)

    # Fields from VehicleBrand
    brand_name = models.CharField(max_length=255, null=True, blank=True)

    # Fields from VehicleModel
    model_name = models.CharField(max_length=255, null=True, blank=True)
    file_key_credit = models.IntegerField(default=1, null=True, blank=True)

    # Fields from VehicleControl
    ecu_brand = models.CharField(max_length=255, null=True, blank=True)
    ecu_version = models.CharField(max_length=255, null=True, blank=True)
    fuel_type = models.CharField(max_length=255, null=True, blank=True)
    ecu_type = models.CharField(max_length=255, null=True, blank=True)
    percentage = models.FloatField(max_length=10,null=True, blank=True)

    # Additional feature columns using CharField
    adblue = models.CharField(max_length=255, default='', blank=True)
    dpf = models.CharField(max_length=255, default='', blank=True)
    egr = models.CharField(max_length=255, default='', blank=True)
    intake_flaps = models.CharField(max_length=255, default='', blank=True)
    hot_start_fix = models.CharField(max_length=255, default='', blank=True)
    popcorn_limiter = models.CharField(max_length=255, default='', blank=True)
    dtc = models.CharField(max_length=255, default='', blank=True)
    other = models.CharField(max_length=255, default='', blank=True)
    o2_decat = models.CharField(max_length=255, default='', blank=True)
    gpf_opf_ppf = models.CharField(max_length=255, default='', blank=True)
    pops_and_bangs = models.CharField(max_length=255, default='', blank=True)

    class Meta:
        verbose_name = 'VehicleManagement'
        verbose_name_plural = 'VehicleManagements'

    def __str__(self) -> str:
        return str(self.id)


class FileRequest(BaseModel):
    """ Customer file request database schema."""

    STATUS_CHOICES = (
        ("OPEN", "OPEN"),
        ("IN_PROGRESS", "IN_PROGRESS"),
        ("CLOSED", "CLOSED"),
        ("Manual Handle", "Manual handle"),
        ("CANCELLED", "CANCELLED"),
    )
    
    REQUEST_CHOICES = (
        ("SUPPORT", "SUPPORT"),
        ("FILE_REQUEST", "FILE_REQUEST"),
    )

    user = models.ForeignKey(MyUser, on_delete=models.CASCADE, null=False,
                                    blank=False, related_name="file_request_user")
    customer_first_name = models.CharField(max_length=100,null=True, blank=True)
    customer_last_name = models.CharField(max_length=100,null=True, blank=True)
    request_id = models.CharField(max_length=100,null=False, blank=False)
    vehicle_type = models.CharField(max_length=100, null=True, blank=True)
    vehicle_make = models.CharField(max_length=100, null=True, blank=True)
    model = models.CharField(max_length=100, null=True, blank=True)
    vehicle_registration = models.CharField(max_length=100, null=True, blank=True)
    vehicle_year = models.PositiveIntegerField(null=True, blank=True)
    vehicle_VIN = models.CharField(max_length=100, null=True, blank=True)
    engine_size = models.CharField(max_length=100, null=True, blank=True)
    transmission = models.CharField(max_length=100, null=True, blank=True)
    fuel_type = models.CharField(max_length=100, null=True, blank=True)
    mileage_type = models.CharField(max_length=100, null=True, blank=True)
    mileage = models.FloatField(max_length=100, null=True, blank=True)

    ecu_brand = models.CharField(max_length=100, null=True, blank=True)
    ecu_version = models.CharField(max_length=100, null=True, blank=True)
    control_unit = models.CharField(max_length=100, null=True, blank=True)

    file_type = models.CharField(max_length=100, null=True, blank=True)
    country = models.CharField(max_length=100, null=True, blank=True)
    tuning_tool_used = models.CharField(max_length=255, null=True, blank=True)
    tuning_required = models.CharField(max_length=255, null=True, blank=True)
    additional_info = models.TextField(max_length=2000, null=True, blank=True)
    tuning_file = models.FileField(upload_to=tuning_file, blank=True, null=True, max_length=500)
    status = models.CharField(max_length = 20,choices = STATUS_CHOICES,default = 'OPEN')
    additional_function = models.JSONField(max_length=1000, null=True, blank=True)


    file_hexa_content = models.TextField(max_length=None, null=True, blank=True)
    file_hexa_content_list = models.TextField(max_length=None, null=True, blank=True)
    file_size = models.FloatField(null=True, blank=True)
    request_type = models.CharField(max_length = 20,choices = REQUEST_CHOICES,
                                default = 'FILE_REQUEST')
    # has_error = models.BooleanField(default=False)

    is_error = models.BooleanField(default=False)
    other_fields = models.CharField(max_length=255, null=True, blank=True)
    
    class Meta:
        verbose_name = 'FileRequest'
        verbose_name_plural = 'FileRequest'

    def generate_unique_id(self):
        prefix = ''
        if self.id < 10:
            prefix = '00'
        elif self.id >= 10 and self.id <100:
            prefix = '0'
        from datetime import datetime
        now = datetime.now()
        self.request_id = "FR{}".format(prefix+str(self.id))
        self.save()

class RequestDownloadFiles(models.Model):

    fil_request_id = models.ForeignKey(FileRequest, on_delete=models.CASCADE, 
                    related_name="Download_file_request")
    title = models.CharField(max_length=255, null=True, blank=True)
    url = models.URLField(null=True, blank=True, max_length=500)
    created_at = models.DateTimeField("Created At", auto_now_add=True, null=True, blank=True)
    downloaded_times = models.PositiveSmallIntegerField(null=True, blank=True)
    sent_to_user = models.BooleanField(default=False)

    class Meta:
        verbose_name = 'RequestDownloadFiles'
        verbose_name_plural = 'RequestDownloadFiles'

class FileRequestHistory(models.Model):

    file_request_id = models.ForeignKey(FileRequest, on_delete=models.CASCADE, null=False,
                                    blank=False, related_name="file_request_id")
    created_at = models.DateTimeField("Created At", auto_now_add=True)
    title = models.TextField(null=True, blank=True)
    description = models.TextField(null=True, blank=True)
    is_success = models.BooleanField(default=False)
    url = models.URLField(null=True, blank=True, max_length=500)
    additional_information = models.TextField(null=True, blank=True)

    class Meta:
        verbose_name = 'FileRequestHistory'
        verbose_name_plural = 'FileRequestHistory'


class FileRequestFormData(models.Model):
    """ Database schema for file form."""

    transmission = models.JSONField()
    fuel_type = models.JSONField()
    milage = models.JSONField()
    tuning_tool_used = models.JSONField()
    control_unit = models.JSONField(null=True, blank=True)
    tuning_required = models.JSONField(null=True, blank=True)
    additional_functions = models.JSONField(null=True, blank=True)
    ecu_brands = models.TextField(null=True, blank=True)
    ecu_version = models.TextField(null=True, blank=True)

    class Meta:
        verbose_name = 'FileRequestFormData'
        verbose_name_plural = 'FileRequestFormData'

class FileFormScheduleTaskLog(BaseModel):

    file_request_id = models.OneToOneField(FileRequest, on_delete=models.CASCADE, null=False,
                                    blank=False, related_name="schedule_file_request_id")
    is_running = models.BooleanField(default=False)
    is_master = models.BooleanField(default=False)
    has_error = models.BooleanField(default=False)
    error = models.TextField(null=True, blank=True)

    class Meta:
        verbose_name = 'FileRequestScheduleTask'
        verbose_name_plural = 'FileRequestScheduleTask'

class DataEcuBrand(models.Model):

    brand_name = models.CharField(max_length=255, null=True, blank=True)

    class Meta:
        verbose_name = 'DataEcuBrand'
        verbose_name_plural = 'DataEcuBrand'

class DataEcuVersion(models.Model):

    brand = models.ForeignKey(DataEcuBrand,on_delete=models.CASCADE,
                                    null=True, blank=True, related_name="data_ecu_brand")
    ecu_version_name = models.CharField(max_length=255, null=True, blank=True)
    percentage = models.FloatField(max_length=10,null=True, blank=True)

    class Meta:
        verbose_name = 'DataEcuVersion'
        verbose_name_plural = 'DataEcuVersion'


class FileRequestTime(models.Model):

    file_request = models.OneToOneField(FileRequest, on_delete=models.CASCADE,
                                    null=True, blank=True, related_name="file_request_time")
    created_at = models.DateTimeField("Created Date", auto_now_add=True)
    start_time = models.DateTimeField(null=True, blank=True)
    end_time = models.DateTimeField(null=True, blank=True)
    second_diff = models.FloatField(null=True, blank=True) 

    class Meta:
        verbose_name = 'FileRequestTime'
        verbose_name_plural = 'FileRequestTime'

class FileRequestAveragePerformance(models.Model):

    file_request_obj = models.ForeignKey(FileRequest, on_delete=models.CASCADE,
                                    null=True, blank=True, related_name="file_request_average")
    file_type = models.CharField(max_length=255, null=True, blank=True)
    created_at = models.DateTimeField("Created Date", auto_now_add=True, null=True, blank=True)

    original_found = models.BooleanField(null=True, blank=True, default=False)
    original_found_time = models.FloatField(null=True, blank=True)

    original_not_found = models.BooleanField(null=True, blank=True, default=False)
    original_not_found_time = models.FloatField(null=True, blank=True)

    refrence_found = models.BooleanField(null=True, blank=True, default=False)
    refrence_found_time = models.FloatField(null=True, blank=True)

    refrence_not_found = models.BooleanField(null=True, blank=True, default=False)
    refrence_not_found_time = models.FloatField(null=True, blank=True)

    decoding_success = models.BooleanField(null=True, blank=True, default=False)
    decoding_success_time = models.FloatField(null=True, blank=True)

    decoding_failure = models.BooleanField(null=True, blank=True, default=False)
    decoding_failure_time = models.FloatField(null=True, blank=True)

    class Meta:
        verbose_name = 'FileRequestAveragePerformance'
        verbose_name_plural = 'FileRequestAveragePerformance'

class RefrenceMadeFile(models.Model):

    file_name = models.CharField(max_length=255, null=True, blank=True)
    file_directory = models.CharField(max_length=255, null=True, blank=True)
    created_at = models.DateTimeField("Created Date", auto_now_add=True, null=True, blank=True)
    file_request =  models.ForeignKey(FileRequest, on_delete=models.CASCADE,
                                    null=True, blank=True, related_name="file_request_refrence")
    refrence_made = models.JSONField(null=True, blank=True)

    class Meta:
        verbose_name = 'RefrenceMadeFile'
        verbose_name_plural = 'RefrenceMadeFile'

