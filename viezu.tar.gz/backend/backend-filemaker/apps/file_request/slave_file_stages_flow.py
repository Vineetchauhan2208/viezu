SLAVE_FILE_STAGE_1 = "File has been submitted by the user."
SLAVE_FILE_STAGE_2 = "ECU brand {} in user's submitted file."
SLAVE_FILE_STAGE_3 = "ECU version {} in user's submitted file."
SLAVE_FILE_STAGE_4 = "Directories found based on ECU brand and version?: {}."
SLAVE_FILE_STAGE_5 = "Matching File Found."
SLAVE_FILE_STAGE_6 = "Get version files from matching original directory."
SLAVE_FILE_STAGE_7 = "Match version file percentage."
SLAVE_FILE_STAGE_8 = "Create directory on cloud."



SLAVE_FILE_STAGE_MANUAL = "No ECU brand and version found, file sent to manual handling."
SLAVE_FILE_STAGE_MANUAL_1 = "No matching percentage are found or zero."
SLAVE_FILE_STAGE_MANUAL_2 = "No matching version file found and sent for manual handling."