from drf_yasg import openapi

request_form_schema = openapi.Schema(
    title =("Vehicle request Form"),
    type=openapi.TYPE_OBJECT, 
    properties={
        'vehicle_type': openapi.Schema(type=openapi.TYPE_STRING,example="car"),
        'vehicle_registration': openapi.Schema(type=openapi.TYPE_STRING,example="UK1100"),
        'vehicle_make': openapi.Schema(type=openapi.TYPE_STRING,example="example"),
        'model': openapi.Schema(type=openapi.TYPE_STRING,example="VW"),
        'transmission': openapi.Schema(type=openapi.TYPE_STRING,example="example"),
        'fuel_type': openapi.Schema(type=openapi.TYPE_STRING,example="example"),
        'file_type': openapi.Schema(type=openapi.TYPE_INTEGER,example=1),
        'engine_size': openapi.Schema(type=openapi.TYPE_STRING,example="example"),
        'vehicle_VIN': openapi.Schema(type=openapi.TYPE_STRING,example="example"),
        'vehicle_year': openapi.Schema(type=openapi.TYPE_INTEGER,example=2017),
        'mileage_type': openapi.Schema(type=openapi.TYPE_INTEGER,example=1),
        'mileage': openapi.Schema(type=openapi.TYPE_INTEGER,example=22.5),
        'country': openapi.Schema(type=openapi.TYPE_STRING,example="IN"),
    },
)