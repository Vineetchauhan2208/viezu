from django.contrib import admin

from .models import (
    MyUser, ResellerAndSubDealer, UserProfile,
    RolesAndPermissions,AccessLogsModel,
    Address,EmailLogSettings,
    BusinessCustomer, IndividualCustomer,
    EVCCredentials, AlienTechToken,
    ZOHOUser,ZOHOInvoices,
)
@admin.register(MyUser)
class MyUserAdmin(admin.ModelAdmin):
    list_display = ("first_name","last_name",
                "email", "uuid","user_type")
    search_fields =["email","user_type",]

admin.site.register(UserProfile)
admin.site.register(RolesAndPermissions)
admin.site.register(Address)
admin.site.register(IndividualCustomer)

@admin.register(ResellerAndSubDealer)
class ResellerAndSubDealerModelAdmin(admin.ModelAdmin):
    list_display = ("user",'win_ols_license_number',)

@admin.register(BusinessCustomer)
class BusinessCustomerModelAdmin(admin.ModelAdmin):
    list_display = ("user",'win_ols_license_number',)

@admin.register(AccessLogsModel)
class AccessLogsModelAdmin(admin.ModelAdmin):
    list_display = ("user",'method', "referrer",'path')

@admin.register(EmailLogSettings)
class EmailLogSettingsAdmin(admin.ModelAdmin):
    list_display = ("module",'path',)

@admin.register(EVCCredentials)
class EVCCredentialsAdmin(admin.ModelAdmin):
    list_display = ("username",'password','apiid',)

@admin.register(AlienTechToken)
class AlienTechTokenAdmin(admin.ModelAdmin):
    list_display = ("access_token",)

@admin.register(ZOHOUser)
class ZOHOUserAdmin(admin.ModelAdmin):
    list_display = ("user","contact_id","primary_contact_id",)

@admin.register(ZOHOInvoices)
class ZOHOInvoicesAdmin(admin.ModelAdmin):
    list_display = ("user","invoice_id","invoice_number","customer_id",
                    "customer_name",)

