import uuid
from django.db import models
from django.contrib.auth.models import AbstractUser
from django.db import models

from .constants import USER_TYPE_CHOICES
from apps.utils.models import BaseModel
from random import randint
from django.contrib.auth.models import BaseUserManager

from apps.utils.helper import filename_path


def profile_picture(instance, filename):
    return filename_path('profile', instance, filename)


class UserManager(BaseUserManager):
    def create_user(self, email, password, **extra_fields):
        if not email:
            raise ValueError('The Email must be set')
        email = self.normalize_email(email)
        user = self.model(email=email, **extra_fields)
        user.set_password(password)
        user.save()
        return user

    def create_superuser(self, email, password, **extra_fields):
        extra_fields.setdefault('is_superuser', True)
        extra_fields.setdefault('is_staff', True)
        extra_fields.setdefault('is_active', True)
        extra_fields.setdefault('user_type',1)
        if extra_fields.get('is_superuser') is not True:
            raise ValueError('Superuser must have is_superuser=True.')
        user = self.create_user(email, password, **extra_fields)
        return user

class RolesAndPermissions(BaseModel):

    """ User permissions database schema for module access."""

    name = models.CharField(max_length=255,null=True,blank=True,unique=True,)
    permissions = models.JSONField(default=dict)

class MyUser(AbstractUser,BaseModel):

    """ User model database schema for multi-user and their fields."""

    username = None
    parent =  models.ForeignKey('self', null=True, blank=True,on_delete=models.SET_NULL, related_name='parrent')

    roles =  models.ForeignKey(RolesAndPermissions, null=True, blank=True,on_delete=models.SET_NULL, related_name='role')
    created_by =  models.ForeignKey('self', null=True, blank=True,on_delete=models.SET_NULL, related_name='createdby')
    uuid = models.UUIDField(default=uuid.uuid4, editable=False)
    email = models.EmailField(unique=True, null=True, db_index=True)
    is_active = models.BooleanField(default=True)
    is_staff = models.BooleanField(default=False)
    user_type = models.PositiveSmallIntegerField(choices=USER_TYPE_CHOICES)
    otp = models.IntegerField(null=True,blank=True)
    image = models.FileField(upload_to=profile_picture, blank=True, null=True)
    country_code = models.CharField(max_length=5, null=True,blank=True,)
    phone_no = models.CharField(max_length=15, null=True,blank=True,)
    mobile_no = models.CharField(max_length=15, null=True,blank=True,)
    description = models.TextField(null=True,blank=True)
    
    is_evc_customer = models.BooleanField(default=False)
    is_evc_reseller_customer = models.BooleanField(default=False)
    stripe_customer_id = models.CharField(max_length=255, null=True, blank=True)
    on_stop = models.BooleanField(default=False)

    REQUIRED_FIELDS = []
    USERNAME_FIELD = 'email'

    def generate_otp(self):
        self.otp = otp = str(''.join([str(randint(1, 9)) for _ in range(4)]))
        self.save()
        return self.otp

    objects = UserManager()

    class Meta:
        verbose_name = 'MyUser'
        verbose_name_plural = 'MyUser'


class UserProfile(BaseModel):

    """ User model profile database schema."""

    user = models.OneToOneField(MyUser, on_delete=models.CASCADE,primary_key=True, related_name="profile")
    is_email_verified = models.BooleanField(default=False)
    is_temp_password_changed = models.BooleanField(default=False)

    def __str__(self):
        return self.user.email

class Address(BaseModel):
    user = models.OneToOneField(MyUser, on_delete=models.CASCADE,primary_key=True, related_name="address_user")
    country = models.CharField(max_length=255,null=True,blank=True)
    state = models.CharField(max_length=255,null=True,blank=True)
    city = models.CharField(max_length=255,null=True,blank=True)
    zip = models.CharField(max_length=255,null=True,blank=True)
    address = models.TextField(null=True,blank=True)
    address_2 = models.TextField(null=True,blank=True)

    def __str__(self):
        return self.user.email
    
    class Meta:
        verbose_name = 'Address'
        verbose_name_plural = 'Address'


class IndividualCustomer(BaseModel):
    user = models.OneToOneField(MyUser, on_delete=models.CASCADE,primary_key=True, related_name="individual_user")
    product_name = models.CharField(max_length=255,null=True,blank=True)
    tool_serial_number = models.CharField(max_length=255,null=True,blank=True)

    def __str__(self):
        return self.user.email
    
    class Meta:
        verbose_name = 'Individual Customer'
        verbose_name_plural = 'Individual Customer'

class BusinessCustomer(BaseModel):
    user = models.OneToOneField(MyUser, on_delete=models.CASCADE,primary_key=True, related_name="business_user")
    bussness_name = models.CharField(max_length=255,null=True,blank=True)
    tax_number = models.CharField(max_length=255,null=True,blank=True)
    company_number = models.CharField(max_length=255,null=True,blank=True)
    win_ols_license_number = models.CharField(max_length=255,null=True,blank=True)

    def __str__(self):
        return self.user.email
    
    class Meta:
        verbose_name = 'Business Customer'
        verbose_name_plural = 'Business Customer'

class ResellerAndSubDealer(BaseModel):
    user = models.OneToOneField(MyUser, on_delete=models.CASCADE,primary_key=True, related_name="reseller_sub_dealer")
    bussness_name = models.CharField(max_length=255,null=True,blank=True)
    tax_number = models.CharField(max_length=255,null=True,blank=True)
    company_number = models.CharField(max_length=255,null=True,blank=True)
    win_ols_license_number = models.CharField(max_length=255,null=True,blank=True)

    def __str__(self):
        return self.user.email
    
    class Meta:
        verbose_name = 'ResellerAndSubDealer'
        verbose_name_plural = 'ResellerAndSubDealer'

class ZOHOUser(BaseModel):
    user = models.OneToOneField(MyUser, on_delete=models.CASCADE,primary_key=True, related_name="zoho_user")
    contact_id = models.CharField(max_length=255,null=True,blank=True)
    primary_contact_id = models.CharField(max_length=255,null=True,blank=True)

    def __str__(self):
        return self.user.email
    
    class Meta:
        verbose_name = 'ZOHO User'
        verbose_name_plural = 'ZOHO User'

class ZOHOInvoices(BaseModel):
    user = models.ForeignKey(ZOHOUser, 
                    on_delete=models.CASCADE,
                    related_name="zoho_invoice_user",
                    null=True,blank=True )
    invoice_id = models.CharField(max_length=255,null=True,blank=True)
    invoice_number = models.CharField(max_length=255,null=True,blank=True)
    customer_id = models.CharField(max_length=255,null=True,blank=True)
    customer_name = models.CharField(max_length=255,null=True,blank=True)
    invoice_json = models.JSONField(default=dict)
    order_list = models.ForeignKey('customer.OrderList', null=True, blank=True, 
                                on_delete=models.CASCADE,related_name="zoho_order_list",)
    is_invoice_avail = models.BooleanField(default=False)
    invoice_s3_url = models.URLField(null=True, blank=True)

    def __str__(self):
        return self.user.user.email
    
    class Meta:
        verbose_name = 'ZOHO Invoice'
        verbose_name_plural = 'ZOHO Invoice'

class EmailLogSettings(BaseModel):
    module = models.CharField(max_length=255,null=True,blank=True,unique=True)
    path = models.CharField(max_length=255,null=True,blank=True)
    emails = models.TextField(null=True,blank=True)

class AccessLogsModel(BaseModel):
    module =  models.ForeignKey(EmailLogSettings, null=True, blank=True,on_delete=models.SET_NULL, related_name='module_logs')
    user =  models.ForeignKey(MyUser, null=True, blank=True,on_delete=models.CASCADE, related_name='user_logs')
    sys_id = models.AutoField(primary_key=True, null=False, blank=True)
    session_key = models.CharField(max_length=1024, null=False, blank=True)
    path = models.CharField(max_length=1024, null=False, blank=True)
    method = models.CharField(max_length=8, null=False, blank=True)
    event = models.CharField(null=True, blank=True,max_length=255)
    data = models.TextField(null=True, blank=True)
    ip_address = models.CharField(max_length=45, null=False, blank=True)
    referrer = models.CharField(max_length=512, null=True, blank=True)
    timestamp = models.DateTimeField(null=False, blank=True)
    title = models.CharField(null=True, blank=True,max_length=255)
    description = models.TextField(null=True, blank=True)
    old_details = models.TextField(null=True, blank=True)
    new_details = models.TextField(null=True, blank=True)
    customer = models.ForeignKey(MyUser, null=True, blank=True,
            on_delete=models.CASCADE, 
            related_name='log_customer')
    to_customer_only = models.BooleanField(default=False)   # Check to show only on customer side.

    # For credit update type
    file_request = models.CharField(max_length=255,null=True,blank=True)
    credit_update_type = models.CharField(max_length=255,null=True,blank=True)
    credit_update_description = models.TextField(null=True, blank=True)

class EVCCredentials(models.Model):

    username = models.CharField(max_length=255, null=True, blank=True)
    password = models.CharField(max_length=255, null=True, blank=True)
    apiid = models.CharField(max_length=255, null=True, blank=True)
    alientechauttoken = models.CharField(max_length=255,null=True,blank=True)
    class Meta:
        verbose_name = 'EVC Credentials'
        verbose_name_plural = 'EVC Credentials'

class AlienTechToken(models.Model):

    access_token = models.CharField(max_length=255, null=True, blank=True)
    customer_code = models.CharField(max_length=255, null=True, blank=True)

    class Meta:
        verbose_name = 'AlienTech Token'
        verbose_name_plural = 'AlienTech Token'

class EncodeDecodeFile(models.Model):

    unique_id = models.CharField(max_length=255, null=True, blank=True)
    tool = models.CharField(max_length=255, null=True, blank=True)
    guid = models.CharField(max_length=255, null=True, blank=True)
    client_application_guid = models.CharField(max_length=255, null=True, blank=True)
    slot_guid = models.CharField(max_length=255, null=True, blank=True)
    isSuccessful = models.BooleanField(default=False)
    hasFailed = models.BooleanField(default=False)
    file_name = models.CharField(max_length=255, null=True, blank=True)


    class Meta:
        verbose_name = 'AlienTech Token'
        verbose_name_plural = 'AlienTech Token'
