from django.urls import path
from apps.account import views

app_name = 'account'

urlpatterns = [
    path('individual-register/', views.IndividualRegisterView.as_view()),
    path('business-register/', views.BusinessRegisterView.as_view()),

    path('login/', views.LoginView.as_view()),
    path('verify-email', views.VerifyEmailView.as_view()),
    path('forgot-password', views.ForgotPasswordView.as_view()),
    path('otp-verify', views.OTPVerifyView.as_view()),
    path('reset-password', views.ResetPassword.as_view()),
    path('logout', views.LogoutView.as_view()),
    path('resend-verification-email', views.ResendVerificationEmail.as_view()),
    path('change-password', views.ChangePasswordView.as_view()),
    path('update-email-request', views.UpdateEmailRequestView.as_view()),
    path('update-email', views.UpdateEmailView.as_view()),
 
    path('notification/', views.NotificationView.as_view()),
    path('profile/', views.ProfileView.as_view()),

    path('test/zoho', views.TestZohoFlow.as_view()),
    path('evc/customer', views.CreateEVCResellerCustomer.as_view()),
    path('customer/delete/<str:uuid>', views.DeleteCustomer.as_view()),
    path('internal_user/delete/<int:id>', views.DeleteInternalUser.as_view()),
    path('internal_user/on_stop/<int:id>', views.InternalAccountStopView.as_view()),
    path('customer/on_stop/<str:uuid>', views.CustomerAccountStopView.as_view()),

    path('sample/email', views.SampleEmail.as_view()),
    path('hello/', views.hello_world),
    # path('zoho-users/', views.GetAactiveUsers.as_view()),
]