from drf_yasg import openapi


individual_register_register_schema = openapi.Schema(
 title =("Individual Register"),
    type=openapi.TYPE_OBJECT,
    properties={
        'individual_profile': openapi.Schema(type=openapi.TYPE_OBJECT, description=('Individual Profile'), 
            properties={
                'product_name': openapi.Schema(type=openapi.TYPE_STRING,example="Macbook M2"),
                'tool_serial_number': openapi.Schema(type=openapi.TYPE_STRING,example="M245664"),
            }
        ),
        'address': openapi.Schema(type=openapi.TYPE_OBJECT, description=('Address'), 
            properties={
                'address_2':openapi.Schema(type=openapi.TYPE_STRING, example="OKhla Phase one"),
                'address':openapi.Schema(type=openapi.TYPE_STRING, example="OKhla Phase one"),
                'country': openapi.Schema(type=openapi.TYPE_STRING, example='India'),
                'state': openapi.Schema(type=openapi.TYPE_STRING, example='New Delhi'),
                'city': openapi.Schema(type=openapi.TYPE_STRING, example='Okhla'),
                'zip':openapi.Schema(type=openapi.TYPE_STRING, example='110020'),
            }
        ),
        'individual': openapi.Schema(type=openapi.TYPE_OBJECT, description=('Individual'), 
            properties={
                'first_name': openapi.Schema(type=openapi.TYPE_STRING,example="Aftab"),
                'last_name': openapi.Schema(type=openapi.TYPE_STRING,example="Hussain"),
                'phone_no': openapi.Schema(type=openapi.TYPE_STRING,example="+917278737088"),
                'email': openapi.Schema(type=openapi.TYPE_STRING,example="aftab4evr786@gmail.com")
            }
        ),
        'captcha_response': openapi.Schema(type=openapi.TYPE_STRING,example=""),

        
    },
)



business_register_register_schema = openapi.Schema(
 title =("Business Register"),
    type=openapi.TYPE_OBJECT,
    properties={
        'business_profile': openapi.Schema(type=openapi.TYPE_OBJECT, description=('Business Profile'), 
            properties={
                'bussness_name': openapi.Schema(type=openapi.TYPE_STRING,example="Macbook M2"),
                'tax_number': openapi.Schema(type=openapi.TYPE_STRING,example="M245664"),
                'company_number': openapi.Schema(type=openapi.TYPE_STRING,example="M245664"),
                'win_ols_license_number': openapi.Schema(type=openapi.TYPE_STRING,example="M245664"),

            }
        ),
        'address': openapi.Schema(type=openapi.TYPE_OBJECT, description=('Address'), 
            properties={
                'address_2':openapi.Schema(type=openapi.TYPE_STRING, example="OKhla Phase one"),
                'address':openapi.Schema(type=openapi.TYPE_STRING, example="OKhla Phase one"),
                'country': openapi.Schema(type=openapi.TYPE_STRING, example='India'),
                'state': openapi.Schema(type=openapi.TYPE_STRING, example='New Delhi'),
                'city': openapi.Schema(type=openapi.TYPE_STRING, example='Okhla'),
                'zip':openapi.Schema(type=openapi.TYPE_STRING, example='110020'),
            }
        ),
        'business': openapi.Schema(type=openapi.TYPE_OBJECT, description=('Individual'), 
            properties={
                'first_name': openapi.Schema(type=openapi.TYPE_STRING,example="Aftab"),
                'last_name': openapi.Schema(type=openapi.TYPE_STRING,example="Hussain"),
                'phone_no': openapi.Schema(type=openapi.TYPE_STRING,example="+917278737088"),
                'email': openapi.Schema(type=openapi.TYPE_STRING,example="aftab4evr786@gmail.com")
            }
        ),
        'captcha_response': openapi.Schema(type=openapi.TYPE_STRING,example=""),

        
    },
)





login_user_schema = openapi.Schema(
    title =("Login"),
    type=openapi.TYPE_OBJECT, 
    properties={
        'email': openapi.Schema(type=openapi.TYPE_STRING,example="aftab.hussain@oodles.io"),
        'password': openapi.Schema(type=openapi.TYPE_STRING,example="3nGqHWtcntdFb5IWNEyNGw=="),
    },
    required=['email','password',],
)
forgot_user_schema =  openapi.Schema(
    title =("Forgot Password"),
    type=openapi.TYPE_OBJECT, 
    properties={
        'email': openapi.Schema(type=openapi.TYPE_STRING,example="aftab.hussain@oodles.io"),
    },
    required=['email',],
)

otp_verify_schema = openapi.Schema(
    title =("OTP Verify"),
    type=openapi.TYPE_OBJECT, 
    properties={
        'email': openapi.Schema(type=openapi.TYPE_STRING,example="aftab.hussain@oodles.io"),
        'otp': openapi.Schema(type=openapi.TYPE_STRING,example='1234'),
    },
    required=['email','otp'],
)

reset_password_schema = openapi.Schema(
    title =("Reset Password"),
    type=openapi.TYPE_OBJECT, 
    properties={
        'email': openapi.Schema(type=openapi.TYPE_STRING,example="aftab.hussain@oodles.io"),
        'password': openapi.Schema(type=openapi.TYPE_STRING,example="Aftab@123"),
        'confirm_password': openapi.Schema(type=openapi.TYPE_STRING,example="Aftab@123"),
    },
    required=['email','password','confirm_password'],
)


email_verify_schema = openapi.Schema(
    title =("Email verify"),
    type=openapi.TYPE_OBJECT, 
    properties={
        'uuid': openapi.Schema(type=openapi.TYPE_STRING,example="b4a53895-2701-4f3a-a895-70bccab01263"),
    },
    required=['uuid',],
)

change_password_schema = openapi.Schema(
    title =("Change Password"),
    type=openapi.TYPE_OBJECT, 
    properties={
        'current_password': openapi.Schema(type=openapi.TYPE_STRING,example="80TFI6jor2bgTpqdVuQC3A=="),
        'new_password': openapi.Schema(type=openapi.TYPE_STRING,example="80TFI6jor2bgTpqdVuQC3A=="),
    },
    required=['current_password','new_password',],
)


update_email_request_schema = openapi.Schema(
    title =("Update Email Request"),
    type=openapi.TYPE_OBJECT, 
    properties={
        'email': openapi.Schema(type=openapi.TYPE_STRING,example="aftab.hussain@oodles.io"),
    },
    required=['email',],
)


update_email_schema = openapi.Schema(
    title =("Update Email Request"),
    type=openapi.TYPE_OBJECT, 
    properties={
        'email': openapi.Schema(type=openapi.TYPE_STRING,example="aftab.hussain@oodles.io"),
        'otp': openapi.Schema(type=openapi.TYPE_STRING,example='1234'),

    },
    required=['email','otp'],
)



update_credit_point_schema = openapi.Schema(
    title =("Update Credit Point"),
    type=openapi.TYPE_OBJECT, 
    properties={
        'uuid': openapi.Schema(type=openapi.TYPE_STRING,example="534534-345-453545"),
        'file_key_credit': openapi.Schema(type=openapi.TYPE_NUMBER,example=12),
        'function_key_credit': openapi.Schema(type=openapi.TYPE_NUMBER,example=10),
        'evc_key_credit': openapi.Schema(type=openapi.TYPE_NUMBER,example=9),
    },
    required=['uuid','file_key_credit','function_key_credit','evc_key_credit'],
)
