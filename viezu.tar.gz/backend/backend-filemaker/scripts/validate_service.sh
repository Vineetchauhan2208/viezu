#!/bin/bash
docker ps | grep backend
