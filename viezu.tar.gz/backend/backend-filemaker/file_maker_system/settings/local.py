from .base import *
from decouple import config

DEBUG = True
# DATABASES = {
#     'default': {
#         'ENGINE': 'django.db.backends.postgresql_psycopg2',
#         'NAME': config('LOCAL_DB_NAME'),
#         'USER': config('LOCAL_USER'),
#         'PASSWORD': config('LOCAL_PASSWORD'),
#         'HOST': config('LOCAL_HOST'),
#         'PORT': config('LOCAL_PORT'),
#     }
# }
DATABASES = {
    'default': {
        'ENGINE': 'django.db.backends.postgresql_psycopg2',
        'NAME': 'filemaker_staging',
        'USER': 'filemakerst_user',
        'PASSWORD': 'ytvkdgsr!2024#1707',
        'HOST': '3.210.128.24',
        'PORT': '5000',
    }
}
# -- local DB use ----------------------------
# DATABASES = {
#     'default': {
#         'ENGINE': 'django.db.backends.postgresql_psycopg2',
#         'NAME': 'file_maker_local_test',
#         'USER': 'postgres',
#         'PASSWORD': 'mohit',  # Ensure this is the correct password
#         'HOST': 'localhost',
#         'PORT': '5432',
#     }
# }

ELASTIC_APM = {
    'SERVICE_NAME': 'ELK_SERVICE_NAME',
    'SECRET_TOKEN': 'ELK_SECRET_TOKEN',
    'SERVER_URL': 'ELK_SERVER_URL',
    'ENVIRONMENT': 'ELK_ENVIRONMENT',
}

FRONTEND_BASE_URL = 'https://testing.viezu-client-files.com'
FRONTEND_EMAIL_VERIFY_URL = 'verify-email'

MONGO_HOST = config('LOCAL_MONGO_HOST')
MONGO_DATABASE = config('LOCAL_MONGO_DATABASE')
MONGO_PORT = config('LOCAL_MONGO_PORT')

DEFAULT_FILE_STORAGE = 'storages.backends.s3boto3.S3Boto3Storage'
AWS_ACCESS_KEY_ID = config('AWS_ACCESS_KEY_ID')
AWS_SECRET_ACCESS_KEY = config('AWS_SECRET_ACCESS_KEY')
AWS_STORAGE_BUCKET_NAME = config('TESTING_AWS_STORAGE_BUCKET_NAME')
AWS_S3_OBJECT_PARAMETERS = {'CacheControl': 'max-age=86400', }
AWS_QUERYSTRING_AUTH = False
AWS_DEFAULT_ACL = None
AWS_S3_REGION_NAME = config('AWS_S3_REGION_NAME')
DATE_INPUT_FORMATS = ('%d-%m-%Y','%Y-%m-%d')

BROKER_URL = config('LOCAL_CELERY_BROKER_URL')
CELERY_RESULT_BACKEND = config('LOCAL_CELERY_RESULT_BACKEND')
CELERY_WORKER_CONCURRENCY = config('LOCAL_CELERY_WORKER_CONCURRENCY')
CELERY_ACCEPT_CONTENT = ['application/json']
CELERY_TASK_SERIALIZER = 'json'
CELERY_RESULT_SERIALIZER = 'json'
CELERY_TIMEZONE = 'UTC'
CELERY_ENVIOREMENT_SETTING = config('LOCAL_SETTING')
CELERY_WORKER_AUTOSCALE = ('min_workers', 'max_workers')
