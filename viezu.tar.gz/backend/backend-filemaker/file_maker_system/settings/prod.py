from .base import *
from decouple import config

DEBUG = False


FRONTEND_BASE_URL = 'https://www.viezu-files.com'
FRONTEND_EMAIL_VERIFY_URL = 'verify-email'
