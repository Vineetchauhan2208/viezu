from .base import *
from decouple import config

DEBUG = True
DATABASES = {
    'default': {
        'ENGINE': 'django.db.backends.postgresql_psycopg2',
        'NAME': config('STAGE_DB_NAME'), 
        'USER': config('STAGE_USER'), 
        'PASSWORD': config('STAGE_PASSWORD'),
        'HOST': config('STAGE_HOST'), 
        'PORT': config('STAGE_PORT'),
    }
}

FRONTEND_BASE_URL = 'https://www.viezu-files.com'
FRONTEND_EMAIL_VERIFY_URL = 'verify-email'

MONGO_HOST = config('STAGE_MONGO_HOST')
MONGO_DATABASE = config('STAGE_MONGO_DATABASE')
MONGO_PORT = config('STAGE_MONGO_PORT')

DEFAULT_FILE_STORAGE = 'storages.backends.s3boto3.S3Boto3Storage'
AWS_ACCESS_KEY_ID = config('AWS_ACCESS_KEY_ID')
AWS_SECRET_ACCESS_KEY = config('AWS_SECRET_ACCESS_KEY')
AWS_STORAGE_BUCKET_NAME = config('STAGE_AWS_STORAGE_BUCKET_NAME')
AWS_S3_OBJECT_PARAMETERS = {'CacheControl': 'max-age=86400', }
AWS_QUERYSTRING_AUTH = False
AWS_DEFAULT_ACL = None
AWS_S3_REGION_NAME = config('AWS_S3_REGION_NAME')
DATE_INPUT_FORMATS = ('%d-%m-%Y','%Y-%m-%d')


BROKER_URL = config('STAGE_CELERY_BROKER_URL')
CELERY_RESULT_BACKEND = config('STAGE_CELERY_RESULT_BACKEND')
CELERY_WORKER_CONCURRENCY = config('STAGE_CELERY_WORKER_CONCURRENCY')
CELERY_ACCEPT_CONTENT = ['application/json']
CELERY_TASK_SERIALIZER = 'json'
CELERY_RESULT_SERIALIZER = 'json'
CELERY_TIMEZONE = 'UTC'
CELERY_ENVIOREMENT_SETTING = config('STAGE_SETTING')
CELERY_WORKER_AUTOSCALE = ('min_workers', 'max_workers')

import sentry_sdk
from sentry_sdk.integrations.django import DjangoIntegration

sentry_sdk.init(
    dsn="https://862d06d0dfa440c69d4f277157c1c524@o1107214.ingest.sentry.io/4505446917931008",

    # Set traces_sample_rate to 1.0 to capture 100%
    # of transactions for performance monitoring.
    # We recommend adjusting this value in production,
    traces_sample_rate=1.0,
    integrations=[
        DjangoIntegration(
            transaction_style='url',
            middleware_spans=True,
            signals_spans=False,
            cache_spans=False,
        ),
    ],
)